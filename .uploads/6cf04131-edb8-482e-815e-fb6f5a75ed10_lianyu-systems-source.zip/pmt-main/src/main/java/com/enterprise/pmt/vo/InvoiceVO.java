package com.enterprise.pmt.vo;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class InvoiceVO {
    private Long id;
    private String invoiceNo;
    private String invoiceCode;
    private String invoiceType;
    private Long contractId;
    private String contractNo;
    private Long customerId;
    private String customerName;
    private LocalDate invoiceDate;
    private BigDecimal invoiceAmount;
    private BigDecimal invoiceAmountExclTax;
    private String invoiceStatus;
    private String remark;
    private LocalDateTime createTime;
}
