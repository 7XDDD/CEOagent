package com.enterprise.pmt.approval.resolver.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.enterprise.pmt.approval.resolver.ApproverResolver;
import com.enterprise.pmt.entity.ApprovalNode;
import com.enterprise.pmt.entity.UserRole;
import com.enterprise.pmt.mapper.UserRoleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 指定角色审批人解析器
 */
@Component
public class SpecificRoleApproverResolver implements ApproverResolver {

    @Autowired
    private UserRoleMapper userRoleMapper;

    @Override
    public String getSupportedType() {
        return "SPECIFIC_ROLE";
    }

    @Override
    public List<Long> resolveApproverIds(ApprovalNode node, Long applicantId, Long projectId, Long deptId) {
        Long roleId = node.getApproverRoleId();
        if (roleId == null) {
            return Collections.emptyList();
        }
        LambdaQueryWrapper<UserRole> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(UserRole::getRoleId, roleId);
        List<UserRole> userRoles = userRoleMapper.selectList(wrapper);
        return userRoles.stream()
                .map(UserRole::getUserId)
                .distinct()
                .collect(Collectors.toList());
    }
}
