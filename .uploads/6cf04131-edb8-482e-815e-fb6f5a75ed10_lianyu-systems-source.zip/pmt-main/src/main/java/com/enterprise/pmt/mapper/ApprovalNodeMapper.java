package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.ApprovalNode;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface ApprovalNodeMapper extends BaseMapper<ApprovalNode> {

    @Select("SELECT * FROM pmt_approval_node WHERE flow_id = #{flowId} AND deleted = 0 ORDER BY node_order ASC")
    List<ApprovalNode> selectByFlowId(@Param("flowId") Long flowId);

    @Select("SELECT * FROM pmt_approval_node WHERE flow_id = #{flowId} AND node_order = #{nodeOrder} AND deleted = 0 LIMIT 1")
    ApprovalNode selectByFlowIdAndOrder(@Param("flowId") Long flowId, @Param("nodeOrder") Integer nodeOrder);

    @Update("UPDATE pmt_approval_node SET deleted = id WHERE deleted = 0 AND flow_id = #{flowId}")
    int softDeleteByFlowId(@Param("flowId") Long flowId);

    @Update("UPDATE pmt_approval_node SET deleted = #{id} WHERE deleted = 0 AND id = #{id}")
    int softDeleteById(@Param("id") Long id);
}
