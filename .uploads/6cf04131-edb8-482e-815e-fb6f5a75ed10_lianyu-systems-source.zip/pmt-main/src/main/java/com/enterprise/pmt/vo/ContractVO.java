package com.enterprise.pmt.vo;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class ContractVO {
    private Long id;
    private String contractCode;
    private String contractName;
    private String contractType;
    private Long parentId;
    private Long projectId;
    private String projectName;
    private Long customerId;
    private String customerName;
    private BigDecimal amount;
    private String currency;
    private LocalDate signDate;
    private LocalDate startDate;
    private LocalDate endDate;
    private String contractStatus;
    private String remark;
    private LocalDateTime createTime;
}
