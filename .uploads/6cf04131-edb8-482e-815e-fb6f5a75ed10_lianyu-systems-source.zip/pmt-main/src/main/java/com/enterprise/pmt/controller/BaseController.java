package com.enterprise.pmt.controller;

import com.enterprise.pmt.common.SecurityContextUtil;

public class BaseController {

    protected Long getCurrentUserId() {
        return SecurityContextUtil.getCurrentUserId();
    }

    protected String getCurrentUsername() {
        return SecurityContextUtil.getCurrentUsername();
    }

    protected Long getCurrentOrgId() {
        return SecurityContextUtil.getCurrentOrgId();
    }
}
