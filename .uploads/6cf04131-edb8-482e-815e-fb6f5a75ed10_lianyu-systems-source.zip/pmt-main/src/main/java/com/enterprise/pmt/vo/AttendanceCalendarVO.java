package com.enterprise.pmt.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;

@Data
public class AttendanceCalendarVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate calDate;

    /**
     * 日期类型：1-工作日 2-休息日 3-法定节假日 4-调休上班
     */
    private Integer dayType;

    private String holidayName;

    private String shiftType;

    private String remark;

    private Integer calYear;

    private Integer calMonth;

    private String dayTypeText;

    private String weekday;
}
