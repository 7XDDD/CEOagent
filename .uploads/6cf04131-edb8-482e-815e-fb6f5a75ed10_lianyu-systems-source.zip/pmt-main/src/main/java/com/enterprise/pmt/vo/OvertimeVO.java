package com.enterprise.pmt.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class OvertimeVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String approvalNo;

    private Long employeeId;

    private String employeeName;

    private String jobNumber;

    private String departmentName;

    private Long projectId;

    private String projectCode;

    private String projectName;

    private String overtimeType;

    private String overtimeTypeText;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime applyTime;

    private BigDecimal grossDurationHours;

    private BigDecimal netDurationHours;

    private Integer isLateApply;

    private String reason;

    /**
     * 审批状态：DRAFT-草稿 PENDING-审批中 APPROVED-已通过 REJECTED-已驳回 CANCELED-已撤销
     */
    private String approvalStatus;

    private String approvalStatusText;

    private Integer convertToComp;

    private String remark;
}
