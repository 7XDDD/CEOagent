package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.DictItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface DictItemMapper extends BaseMapper<DictItem> {

    @Select("SELECT * FROM pmt_dict_item WHERE dict_id = #{dictId} AND deleted = 0 ORDER BY sort_order ASC")
    List<DictItem> findByDictId(@Param("dictId") Long dictId);

    @Select("SELECT * FROM pmt_dict_item WHERE dict_id = #{dictId} AND item_code = #{itemCode} AND deleted = 0 LIMIT 1")
    DictItem findByDictIdAndItemCode(@Param("dictId") Long dictId, @Param("itemCode") String itemCode);

    @Select("SELECT di.* FROM pmt_dict_item di INNER JOIN pmt_dict d ON di.dict_id = d.id WHERE d.dict_code = #{dictCode} AND di.deleted = 0 AND di.status = 1 ORDER BY di.sort_order ASC")
    List<DictItem> findByDictCode(@Param("dictCode") String dictCode);

    @Select("SELECT di.* FROM pmt_dict_item di INNER JOIN pmt_dict d ON di.dict_id = d.id WHERE d.dict_code = #{dictCode} AND di.deleted = 0 ORDER BY di.sort_order ASC")
    List<DictItem> findAllByDictCode(@Param("dictCode") String dictCode);

    @Select("SELECT di.* FROM pmt_dict_item di INNER JOIN pmt_dict d ON di.dict_id = d.id WHERE di.item_code = #{code} AND di.deleted = 0 AND di.status = 1 ORDER BY di.sort_order ASC LIMIT 1")
    DictItem findByItemCode(@Param("code") String code);

    @Select("SELECT di.* FROM pmt_dict_item di INNER JOIN pmt_dict d ON di.dict_id = d.id WHERE d.dict_code IN (${codes}) AND di.deleted = 0 AND di.status = 1 ORDER BY d.dict_code, di.sort_order ASC")
    List<DictItem> findByDictCodes(@Param("codes") String codes);

    @Select("SELECT di.* FROM pmt_dict_item di INNER JOIN pmt_dict d ON di.dict_id = d.id WHERE d.dict_code IN (${codes}) AND d.system_type = #{systemType} AND di.deleted = 0 AND di.status = 1 ORDER BY d.dict_code, di.sort_order ASC")
    List<DictItem> findByDictCodesAndSystemType(@Param("codes") String codes, @Param("systemType") String systemType);

    @Select("SELECT COUNT(*) FROM pmt_dict_item WHERE dict_id = #{dictId} AND deleted = 0")
    Long countByDictId(@Param("dictId") Long dictId);

    int softDeleteById(@Param("id") Long id);

    int softDeleteByDictId(@Param("dictId") Long dictId);
}
