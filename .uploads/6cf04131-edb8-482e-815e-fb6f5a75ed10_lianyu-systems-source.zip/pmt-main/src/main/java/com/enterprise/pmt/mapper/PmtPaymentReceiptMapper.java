package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.PmtPaymentReceipt;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtPaymentReceiptMapper extends BaseMapper<PmtPaymentReceipt> {

    Page<PmtPaymentReceipt> selectPageList(Page<PmtPaymentReceipt> page,
                                           @Param("contractId") Long contractId,
                                           @Param("customerId") Long customerId,
                                           @Param("keyword") String keyword,
                                           @Param("receiptStatus") String receiptStatus);

    List<PmtPaymentReceipt> selectListByCondition(@Param("contractId") Long contractId,
                                                  @Param("customerId") Long customerId);

    int softDeleteById(@Param("id") Long id);

    Long countAll();

    Long countByStatus(@Param("receiptStatus") String receiptStatus);

    java.math.BigDecimal sumReceiptAmountCny();

    java.math.BigDecimal sumMonthlyReceiptAmountCny(@Param("year") int year, @Param("month") int month);

    Long countMonthlyReceipts(@Param("year") int year, @Param("month") int month);
}
