package com.enterprise.pmt.controller.base;

import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.annotation.OperationLog.OperationType;
import com.enterprise.pmt.common.BusinessException;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.ResultCode;
import com.enterprise.pmt.config.HrProperties;
import com.enterprise.pmt.entity.PmtEmployee;
import com.enterprise.pmt.entity.PmtOvertimeRequest;
import com.enterprise.pmt.entity.PmtProject;
import com.enterprise.pmt.entity.User;
import com.enterprise.pmt.mapper.PmtEmployeeMapper;
import com.enterprise.pmt.mapper.PmtOvertimeRequestMapper;
import com.enterprise.pmt.mapper.PmtProjectMapper;
import com.enterprise.pmt.mapper.UserMapper;
import com.enterprise.pmt.service.HrDataService;
import com.enterprise.pmt.service.DataScopeService;
import com.enterprise.pmt.common.SecurityContextUtil;
import com.enterprise.pmt.vo.OvertimeVO;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/base/overtime")
@RequiredArgsConstructor
public class OvertimeController {

    private final HrDataService hrDataService;
    private final DataScopeService dataScopeService;
    private final HrProperties hrProperties;
    private final UserMapper userMapper;
    private final PmtOvertimeRequestMapper overtimeMapper;
    private final PmtEmployeeMapper employeeMapper;
    private final PmtProjectMapper projectMapper;

    private static final DateTimeFormatter DT_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    @PreAuthorize("@permissionChecker.hasPermission('pmt:overtime:view')")
    @GetMapping("/page")
    public Result<Page<OvertimeVO>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String overtimeType,
            @RequestParam(required = false) Long employeeId,
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate) {
        return Result.success(hrDataService.pageOvertime(pageNum, pageSize, keyword, status, overtimeType, employeeId, projectId, startDate, endDate, dataScopeService.resolveCurrentUserScope()));
    }

    @GetMapping("/my-page")
    public Result<Page<OvertimeVO>> myPage(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        User user = userMapper.selectById(userId);
        Long employeeId = user != null ? user.getEmployeeId() : null;
        return Result.success(hrDataService.pageOvertime(pageNum, pageSize, keyword, status, null, employeeId, null, startDate, endDate, null));
    }

    @GetMapping("/my-stats")
    public Result<Map<String, Object>> myStats() {
        Long userId = SecurityContextUtil.getCurrentUserId();
        User user = userMapper.selectById(userId);
        Long employeeId = user != null ? user.getEmployeeId() : null;

        Map<String, Object> stats = new HashMap<>();
        if (employeeId == null) {
            stats.put("totalHours", BigDecimal.ZERO);
            stats.put("approvedHours", BigDecimal.ZERO);
            stats.put("pendingCount", 0);
            stats.put("compHours", BigDecimal.ZERO);
            return Result.success(stats);
        }

        Page<OvertimeVO> allPage = hrDataService.pageOvertime(1, 10000, null, null, null, employeeId, null, null, null, null);
        List<OvertimeVO> allRecords = allPage.getRecords();

        BigDecimal totalHours = BigDecimal.ZERO;
        BigDecimal approvedHours = BigDecimal.ZERO;
        int pendingCount = 0;
        BigDecimal compHours = BigDecimal.ZERO;

        for (OvertimeVO vo : allRecords) {
            BigDecimal hours = vo.getNetDurationHours() != null ? vo.getNetDurationHours() : BigDecimal.ZERO;
            totalHours = totalHours.add(hours);
            if ("APPROVED".equals(vo.getApprovalStatus())) {
                approvedHours = approvedHours.add(hours);
                if (vo.getConvertToComp() != null && vo.getConvertToComp() == 1) {
                    compHours = compHours.add(hours);
                }
            }
            if ("PENDING".equals(vo.getApprovalStatus())) {
                pendingCount++;
            }
        }

        stats.put("totalHours", totalHours.setScale(1, RoundingMode.HALF_UP));
        stats.put("approvedHours", approvedHours.setScale(1, RoundingMode.HALF_UP));
        stats.put("pendingCount", pendingCount);
        stats.put("compHours", compHours.setScale(1, RoundingMode.HALF_UP));
        return Result.success(stats);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:overtime:view')")
    @GetMapping("/{id:\\d+}")
    public Result<PmtOvertimeRequest> getById(@PathVariable Long id) {
        return Result.success(overtimeMapper.selectById(id));
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:overtime:view')")
    @GetMapping("/hr-mode")
    public Result<Map<String, Object>> getHrMode() {
        Map<String, Object> result = new HashMap<>();
        result.put("hrMode", hrProperties.isEnabled());
        result.put("readOnly", hrProperties.isEnabled());
        return Result.success(result);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:overtime:update')")
    @PostMapping("/sync")
    public Result<Integer> syncFromHr() {
        checkHrEnabled();
        int count = hrDataService.syncOvertime();
        return Result.success("同步成功，共同步" + count + "条加班数据", count);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:overtime:create')")
    @OperationLog(module = "加班管理", description = "新增加班申请", type = OperationType.INSERT)
    @PostMapping
    public Result<PmtOvertimeRequest> save(@RequestBody PmtOvertimeRequest entity) {
        if (entity.getEmployeeId() == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请选择员工");
        }
        if (entity.getStartTime() == null || entity.getEndTime() == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "开始时间和结束时间不能为空");
        }
        if (entity.getEndTime().isBefore(entity.getStartTime())) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "结束时间不能早于开始时间");
        }
        if (entity.getOvertimeType() == null) {
            entity.setOvertimeType("weekday");
        }
        if (entity.getApprovalStatus() == null) {
            entity.setApprovalStatus("APPROVED");
        }
        if (entity.getApplyTime() == null) {
            entity.setApplyTime(LocalDateTime.now());
        }
        if (entity.getConvertToComp() == null) {
            entity.setConvertToComp(0);
        }
        if (entity.getIsLateApply() == null) {
            entity.setIsLateApply(0);
        }
        if (entity.getApprovalNo() == null || entity.getApprovalNo().isEmpty()) {
            entity.setApprovalNo("OT" + System.currentTimeMillis());
        }

        long minutes = Duration.between(entity.getStartTime(), entity.getEndTime()).toMinutes();
        BigDecimal hours = BigDecimal.valueOf(minutes).divide(BigDecimal.valueOf(60), 1, RoundingMode.HALF_UP);
        entity.setGrossDurationHours(hours);
        if (entity.getNetDurationHours() == null) {
            entity.setNetDurationHours(hours);
        }

        if (entity.getId() != null) {
            overtimeMapper.updateById(entity);
        } else {
            overtimeMapper.insert(entity);
        }
        return Result.success(entity);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:overtime:delete')")
    @OperationLog(module = "加班管理", description = "删除加班记录", type = OperationType.DELETE)
    @DeleteMapping("/{id:\\d+}")
    public Result<Void> delete(@PathVariable Long id) {
        overtimeMapper.deleteById(id);
        return Result.success();
    }

    // ==================== 导入导出 ====================

    @PreAuthorize("@permissionChecker.hasPermission('pmt:overtime:view')")
    @GetMapping("/import-template")
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        ExcelWriter writer = ExcelUtil.getWriter();

        List<Map<String, Object>> demo = new ArrayList<>();
        Map<String, Object> row1 = new LinkedHashMap<>();
        row1.put("工号*", "E010");
        row1.put("员工姓名", "张三");
        row1.put("项目名称", "示例项目-系统开发");
        row1.put("加班类型*", "工作日加班");
        row1.put("开始时间*(yyyy-MM-dd HH:mm:ss)", "2026-08-11 18:00:00");
        row1.put("结束时间*(yyyy-MM-dd HH:mm:ss)", "2026-08-11 21:00:00");
        row1.put("审批状态", "已通过");
        row1.put("是否转调休(是/否)", "否");
        row1.put("加班原因*", "完成紧急需求开发");
        row1.put("备注", "");
        demo.add(row1);

        writer.write(demo, true);

        Workbook wb = writer.getWorkbook();
        Sheet sheet = wb.getSheetAt(0);
        wb.setSheetName(0, "加班数据导入");

        CellStyle textStyle = wb.createCellStyle();
        DataFormat fmt = wb.createDataFormat();
        textStyle.setDataFormat(fmt.getFormat("@"));
        textStyle.setBorderTop(BorderStyle.THIN);
        textStyle.setBorderBottom(BorderStyle.THIN);
        textStyle.setBorderLeft(BorderStyle.THIN);
        textStyle.setBorderRight(BorderStyle.THIN);

        int colCount = 10;
        for (int col = 0; col < colCount; col++) {
            sheet.setDefaultColumnStyle(col, textStyle);
            sheet.setColumnWidth(col, 20 * 256);
        }
        sheet.setColumnWidth(8, 30 * 256);

        Sheet noteSheet = wb.createSheet("填写说明");
        String[] notes = {
                "加班数据导入模板填写说明：",
                "",
                "1. 带*号的列为必填项",
                "2. 工号必须已在员工管理中存在",
                "3. 项目名称必须已在项目管理中存在（选填，不填则不关联项目）",
                "4. 加班类型可选：工作日加班、周末加班、节假日加班（或 weekday/weekend/holiday）",
                "5. 开始时间和结束时间格式：yyyy-MM-dd HH:mm:ss",
                "6. 审批状态可选：草稿、审批中、已通过、已驳回、已撤销（默认已通过）",
                "7. 是否转调休填：是 或 否（默认否）",
                "8. 系统自动计算加班时长",
                "",
                "提示：从其他Excel拷贝数据时，请使用「选择性粘贴 → 仅粘贴值」。"
        };
        for (int i = 0; i < notes.length; i++) {
            Row nr = noteSheet.createRow(i);
            Cell nc = nr.createCell(0);
            nc.setCellValue(notes[i]);
        }
        noteSheet.setColumnWidth(0, 90 * 256);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode("加班数据导入模板.xlsx", "UTF-8"));
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:overtime:create')")
    @OperationLog(module = "加班管理", description = "导入加班数据", type = OperationType.IMPORT)
    @PostMapping("/import-excel")
    public Result<Map<String, Object>> importExcel(@RequestParam("file") MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BusinessException("请选择要导入的文件");
        }

        int inserted = 0;
        int updated = 0;
        int failed = 0;
        List<String> errors = new ArrayList<>();

        List<List<Object>> rows;
        try {
            ExcelReader reader = ExcelUtil.getReader(file.getInputStream());
            rows = reader.read();
            reader.close();
        } catch (Exception e) {
            throw new BusinessException("Excel 解析失败: " + e.getMessage());
        }

        if (rows == null || rows.size() <= 1) {
            Map<String, Object> result = new HashMap<>();
            result.put("inserted", 0);
            result.put("updated", 0);
            result.put("failed", 0);
            result.put("errors", Collections.singletonList("文件为空或没有数据"));
            return Result.success(result);
        }

        for (int i = 1; i < rows.size(); i++) {
            List<Object> row = rows.get(i);
            if (row == null || row.isEmpty() || isRowEmpty(row)) {
                continue;
            }
            try {
                String jobNumber = getCellStringValue(row, 0);
                String projectName = getCellStringValue(row, 2);
                String overtimeTypeStr = getCellStringValue(row, 3);
                String startTimeStr = getCellStringValue(row, 4);
                String endTimeStr = getCellStringValue(row, 5);
                String statusStr = getCellStringValue(row, 6);
                String convertCompStr = getCellStringValue(row, 7);
                String reason = getCellStringValue(row, 8);
                String remark = getCellStringValue(row, 9);

                StringBuilder errMsg = new StringBuilder();
                if (jobNumber == null) errMsg.append("工号不能为空; ");
                if (startTimeStr == null) errMsg.append("开始时间不能为空; ");
                if (endTimeStr == null) errMsg.append("结束时间不能为空; ");
                if (reason == null) errMsg.append("加班原因不能为空; ");

                if (errMsg.length() > 0) {
                    failed++;
                    errors.add("第" + (i + 1) + "行: " + errMsg.toString());
                    continue;
                }

                PmtEmployee employee = employeeMapper.selectOne(new LambdaQueryWrapper<PmtEmployee>()
                        .eq(PmtEmployee::getJobNumber, jobNumber.trim())
                        .eq(PmtEmployee::getDeleted, 0)
                        .last("LIMIT 1"));
                if (employee == null) {
                    failed++;
                    errors.add("第" + (i + 1) + "行: 工号[" + jobNumber + "]不存在");
                    continue;
                }

                Long projectId = null;
                if (projectName != null && !projectName.trim().isEmpty()) {
                    PmtProject project = projectMapper.selectOne(new LambdaQueryWrapper<PmtProject>()
                            .eq(PmtProject::getProjectName, projectName.trim())
                            .eq(PmtProject::getDeleted, 0)
                            .last("LIMIT 1"));
                    if (project == null) {
                        failed++;
                        errors.add("第" + (i + 1) + "行: 项目[" + projectName + "]不存在");
                        continue;
                    }
                    projectId = project.getId();
                }

                String overtimeType = parseOvertimeType(overtimeTypeStr);
                String approvalStatus = parseStatus(statusStr);
                Integer convertToComp = parseYesNo(convertCompStr);

                LocalDateTime startTime;
                LocalDateTime endTime;
                try {
                    startTime = LocalDateTime.parse(startTimeStr.trim(), DT_FMT);
                    endTime = LocalDateTime.parse(endTimeStr.trim(), DT_FMT);
                } catch (Exception e) {
                    failed++;
                    errors.add("第" + (i + 1) + "行: 时间格式错误，应为 yyyy-MM-dd HH:mm:ss");
                    continue;
                }

                if (endTime.isBefore(startTime)) {
                    failed++;
                    errors.add("第" + (i + 1) + "行: 结束时间不能早于开始时间");
                    continue;
                }

                long minutes = Duration.between(startTime, endTime).toMinutes();
                BigDecimal hours = BigDecimal.valueOf(minutes).divide(BigDecimal.valueOf(60), 1, RoundingMode.HALF_UP);

                PmtOvertimeRequest entity = new PmtOvertimeRequest();
                entity.setApprovalNo("OT" + System.currentTimeMillis() + (int)(Math.random() * 1000));
                entity.setEmployeeId(employee.getId());
                entity.setProjectId(projectId);
                entity.setOvertimeType(overtimeType);
                entity.setStartTime(startTime);
                entity.setEndTime(endTime);
                entity.setApplyTime(LocalDateTime.now());
                entity.setGrossDurationHours(hours);
                entity.setNetDurationHours(hours);
                entity.setIsLateApply(0);
                entity.setReason(reason);
                entity.setApprovalStatus(approvalStatus);
                entity.setConvertToComp(convertToComp);
                entity.setRemark(remark);

                overtimeMapper.insert(entity);
                inserted++;

            } catch (Exception e) {
                failed++;
                errors.add("第" + (i + 1) + "行: 处理失败 - " + e.getMessage());
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("inserted", inserted);
        result.put("updated", updated);
        result.put("failed", failed);
        result.put("errors", errors.size() > 50 ? errors.subList(0, 50) : errors);
        result.put("totalErrors", errors.size());
        return Result.success(result);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:overtime:view')")
    @OperationLog(module = "加班管理", description = "导出加班数据", type = OperationType.EXPORT)
    @PostMapping("/export")
    public void export(@RequestBody(required = false) Map<String, Object> params, HttpServletResponse response) throws Exception {
        String keyword = params != null ? (String) params.get("keyword") : null;
        String status = params != null ? (String) params.get("status") : null;
        String overtimeType = params != null ? (String) params.get("overtimeType") : null;
        Long employeeId = params != null && params.get("employeeId") != null ? Long.valueOf(params.get("employeeId").toString()) : null;
        Long projectId = params != null && params.get("projectId") != null ? Long.valueOf(params.get("projectId").toString()) : null;
        String startDate = params != null ? (String) params.get("startDate") : null;
        String endDate = params != null ? (String) params.get("endDate") : null;

        Page<OvertimeVO> page = hrDataService.pageOvertime(1, 10000, keyword, status, overtimeType, employeeId, projectId, startDate, endDate, dataScopeService.resolveCurrentUserScope());
        List<OvertimeVO> list = page.getRecords();

        ExcelWriter writer = ExcelUtil.getWriter();
        writer.addHeaderAlias("approvalNo", "审批单号");
        writer.addHeaderAlias("jobNumber", "工号");
        writer.addHeaderAlias("employeeName", "姓名");
        writer.addHeaderAlias("departmentName", "部门");
        writer.addHeaderAlias("projectName", "所属项目");
        writer.addHeaderAlias("overtimeTypeText", "加班类型");
        writer.addHeaderAlias("startTime", "开始时间");
        writer.addHeaderAlias("endTime", "结束时间");
        writer.addHeaderAlias("grossDurationHours", "总时长(h)");
        writer.addHeaderAlias("netDurationHours", "有效时长(h)");
        writer.addHeaderAlias("approvalStatusText", "审批状态");
        writer.addHeaderAlias("convertToCompText", "是否转调休");
        writer.addHeaderAlias("reason", "加班原因");
        writer.addHeaderAlias("remark", "备注");

        List<Map<String, Object>> exportData = new ArrayList<>();
        for (OvertimeVO vo : list) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("approvalNo", vo.getApprovalNo());
            row.put("jobNumber", vo.getJobNumber());
            row.put("employeeName", vo.getEmployeeName());
            row.put("departmentName", vo.getDepartmentName());
            row.put("projectName", vo.getProjectName());
            row.put("overtimeTypeText", vo.getOvertimeTypeText());
            row.put("startTime", vo.getStartTime() != null ? vo.getStartTime().format(DT_FMT) : "");
            row.put("endTime", vo.getEndTime() != null ? vo.getEndTime().format(DT_FMT) : "");
            row.put("grossDurationHours", vo.getGrossDurationHours());
            row.put("netDurationHours", vo.getNetDurationHours());
            row.put("approvalStatusText", vo.getApprovalStatusText());
            row.put("convertToCompText", vo.getConvertToComp() != null && vo.getConvertToComp() == 1 ? "是" : "否");
            row.put("reason", vo.getReason());
            row.put("remark", vo.getRemark());
            exportData.add(row);
        }

        writer.write(exportData, true);
        writer.setColumnWidth(0, 18);
        writer.setColumnWidth(1, 10);
        writer.setColumnWidth(2, 10);
        writer.setColumnWidth(3, 16);
        writer.setColumnWidth(4, 24);
        writer.setColumnWidth(12, 30);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode("加班数据.xlsx", "UTF-8"));
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    // ==================== 私有方法 ====================

    private boolean isRowEmpty(List<Object> row) {
        for (Object cell : row) {
            if (cell != null && cell.toString().trim().length() > 0) {
                return false;
            }
        }
        return true;
    }

    private String getCellStringValue(List<Object> row, int index) {
        if (index >= row.size()) return null;
        Object val = row.get(index);
        if (val == null) return null;
        String s = val.toString().trim();
        return s.isEmpty() ? null : s;
    }

    private String parseOvertimeType(String s) {
        if (s == null) return "weekday";
        s = s.trim();
        if (s.contains("工作日") || "weekday".equalsIgnoreCase(s)) return "weekday";
        if (s.contains("周末") || "weekend".equalsIgnoreCase(s)) return "weekend";
        if (s.contains("节假日") || "holiday".equalsIgnoreCase(s)) return "holiday";
        return "weekday";
    }

    private String parseStatus(String s) {
        if (s == null || s.trim().isEmpty()) return "APPROVED";
        s = s.trim();
        if (s.contains("草稿") || "DRAFT".equalsIgnoreCase(s)) return "DRAFT";
        if (s.contains("审批中") || "PENDING".equalsIgnoreCase(s)) return "PENDING";
        if (s.contains("通过") || "APPROVED".equalsIgnoreCase(s)) return "APPROVED";
        if (s.contains("驳回") || "REJECTED".equalsIgnoreCase(s)) return "REJECTED";
        if (s.contains("撤销") || "CANCELED".equalsIgnoreCase(s)) return "CANCELED";
        return "APPROVED";
    }

    private Integer parseYesNo(String s) {
        if (s == null || s.trim().isEmpty()) return 0;
        s = s.trim();
        if ("是".equals(s) || "yes".equalsIgnoreCase(s) || "1".equals(s) || "true".equalsIgnoreCase(s)) return 1;
        return 0;
    }

    private void checkHrEnabled() {
        if (!hrProperties.isEnabled()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR系统集成未启用（pmt.hr.enabled=false），无法执行同步操作");
        }
    }
}
