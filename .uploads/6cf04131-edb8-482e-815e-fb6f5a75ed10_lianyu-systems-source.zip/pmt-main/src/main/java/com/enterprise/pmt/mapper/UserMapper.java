package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.dto.system.UserQueryDTO;
import com.enterprise.pmt.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper extends BaseMapper<User> {

    @Select("SELECT * FROM pmt_user WHERE username = #{username} AND deleted = 0 LIMIT 1")
    User findByUsername(@Param("username") String username);

    @Select("SELECT * FROM pmt_user WHERE (username = #{keyword} OR phone = #{keyword}) AND deleted = 0 LIMIT 1")
    User findByUsernameOrPhone(@Param("keyword") String keyword);

    @Select("SELECT * FROM pmt_user WHERE employee_id = #{employeeId} AND deleted = 0 LIMIT 1")
    User findByEmployeeId(@Param("employeeId") Long employeeId);

    @Select("SELECT * FROM pmt_user WHERE username = #{username} AND deleted = 0 AND (#{excludeId} IS NULL OR id != #{excludeId}) LIMIT 1")
    User findByUsernameExist(@Param("username") String username, @Param("excludeId") Long excludeId);

    Page<Map<String, Object>> selectPageList(Page<Map<String, Object>> page, @Param("q") UserQueryDTO query);

    List<Map<String, Object>> selectAvailableEmployees();

    @Select("SELECT COUNT(*) FROM pmt_user WHERE deleted = 0")
    long countAll();

    @Select("SELECT COUNT(*) FROM pmt_user WHERE deleted = 0 AND status = 1")
    long countActive();
}
