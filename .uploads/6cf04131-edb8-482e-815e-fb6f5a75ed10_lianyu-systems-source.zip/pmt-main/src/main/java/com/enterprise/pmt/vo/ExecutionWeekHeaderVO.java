package com.enterprise.pmt.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * 执行状态矩阵：周列表表头（每一列的元数据）
 */
@Data
public class ExecutionWeekHeaderVO {
    /** 周一起始日（yyyy-MM-dd），作为 row.weekValues 的 key */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate weekStart;
    /** 展示标签，如 08/17/26 */
    private String label;
    /** PAST=过去周 / CURRENT=当前周 / FUTURE=未来周（前端按此值着色） */
    private String type;
}
