package com.enterprise.pmt.controller.system;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.annotation.OperationLog.OperationType;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.entity.ApprovalConfig;
import com.enterprise.pmt.service.ApprovalConfigService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Api(tags = "系统管理-审批配置(旧版)")
@RestController
@RequestMapping("/system/approval-config-legacy")
public class ApprovalConfigController {

    @Autowired
    private ApprovalConfigService approvalConfigService;

    @ApiOperation("分页查询审批配置(旧版)")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:view')")
    @GetMapping("/page")
    public Result<Page<ApprovalConfig>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer status) {
        return Result.success(approvalConfigService.pageList(pageNum, pageSize, keyword, status));
    }

    @ApiOperation("获取审批配置详情(旧版)")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:view')")
    @GetMapping("/{id:\\d+}")
    public Result<ApprovalConfig> getDetail(@PathVariable Long id) {
        return Result.success(approvalConfigService.getDetail(id));
    }

    @ApiOperation("新增审批配置(旧版)")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:create')")
    @OperationLog(module = "审批配置", description = "新增审批配置", type = OperationType.INSERT)
    @PostMapping
    public Result<?> create(@RequestBody ApprovalConfig config) {
        approvalConfigService.create(config);
        return Result.success("创建成功");
    }

    @ApiOperation("修改审批配置(旧版)")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:update')")
    @OperationLog(module = "审批配置", description = "修改审批配置", type = OperationType.UPDATE)
    @PutMapping("/{id}")
    public Result<?> update(@PathVariable Long id, @RequestBody ApprovalConfig config) {
        approvalConfigService.update(id, config);
        return Result.success("修改成功");
    }

    @ApiOperation("删除审批配置(旧版)")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:delete')")
    @OperationLog(module = "审批配置", description = "删除审批配置", type = OperationType.DELETE)
    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id) {
        approvalConfigService.delete(id);
        return Result.success("删除成功");
    }
}
