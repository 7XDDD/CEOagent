package com.enterprise.pmt.mapper;

import com.enterprise.pmt.entity.PmtProjectMemberPeriod;
import com.enterprise.pmt.vo.ManpowerBudgetDetailVO;
import com.enterprise.pmt.vo.ManpowerBudgetMemberVO;
import com.enterprise.pmt.vo.ManpowerBudgetOverviewVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ManpowerBudgetMapper {

    /**
     * 跨项目人力工时预算总览
     */
    List<ManpowerBudgetOverviewVO> selectOverview(@Param("keyword") String keyword,
                                                  @Param("status") String status,
                                                  @Param("projectType") String projectType,
                                                  @Param("pmId") Long pmId,
                                                  @Param("projectIds") List<Long> projectIds);

    /**
     * 单项目预算详情（不含成员明细）
     */
    ManpowerBudgetDetailVO selectProjectBudgetDetail(@Param("projectId") Long projectId);

    /**
     * 单项目成员预算明细（含每人已用工时）
     */
    List<ManpowerBudgetMemberVO> selectMemberBudgets(@Param("projectId") Long projectId);

    /**
     * 单项目各成员周期（用于推导分月预算）
     */
    List<PmtProjectMemberPeriod> selectProjectPeriods(@Param("projectId") Long projectId);

    /**
     * 单项目分月实际工时（已审批，截至当天）
     * @return 每行 [month, hours]
     */
    List<java.util.Map<String, Object>> selectMonthlyActuals(@Param("projectId") Long projectId);
}
