package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.PmtMaterial;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtMaterialMapper extends BaseMapper<PmtMaterial> {

    List<PmtMaterial> selectAllActive();

    Page<PmtMaterial> selectPageList(Page<PmtMaterial> page,
                                     @Param("keyword") String keyword,
                                     @Param("materialType") String materialType,
                                     @Param("isActive") Integer isActive);

    List<PmtMaterial> selectListActive();

    int countByCode(@Param("materialCode") String materialCode, @Param("excludeId") Long excludeId);

    int softDeleteById(@Param("id") Long id);
}
