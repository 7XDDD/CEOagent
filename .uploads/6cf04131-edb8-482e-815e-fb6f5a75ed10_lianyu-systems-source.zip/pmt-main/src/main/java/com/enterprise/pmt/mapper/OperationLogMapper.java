package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.dto.system.OperationLogQueryDTO;
import com.enterprise.pmt.entity.OperationLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface OperationLogMapper extends BaseMapper<OperationLog> {

    Page<OperationLog> selectPageList(Page<OperationLog> page, @Param("q") OperationLogQueryDTO query);
}
