package com.enterprise.pmt.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 工时执行状态：专用聚合查询（按 employee+project+week 查 APPROVED 实际/加班）
 */
public interface TimesheetExecutionMapper {

    /**
     * 批量查询：过去周及本周（ws <= thisMonday）每个员工-项目-周的已审批实际工时合计
     * 返回 Map 列：employee_id, project_id, week_start_date, total_hours = SUM(workHours)
     * status=APPROVED 才计入；deleted=0
     */
    @Select("SELECT t.employee_id AS employeeId, t.project_id AS projectId, t.week_start_date AS weekStartDate, " +
            "COALESCE(SUM(i.work_hours), 0) AS totalHours " +
            "FROM pmt_timesheet t " +
            "LEFT JOIN pmt_timesheet_item i ON i.timesheet_id = t.id AND i.deleted = 0 " +
            "WHERE t.deleted = 0 AND t.status = 'APPROVED' " +
            "  AND t.week_start_date <= #{thisMonday} " +
            "  AND (#{minWeek} IS NULL OR t.week_start_date >= #{minWeek}) " +
            "  AND (#{maxWeek} IS NULL OR t.week_start_date <= #{maxWeek}) " +
            "GROUP BY t.employee_id, t.project_id, t.week_start_date")
    List<Map<String, Object>> selectApprovedActualByWeek(
            @Param("thisMonday") LocalDate thisMonday,
            @Param("minWeek") LocalDate minWeek,
            @Param("maxWeek") LocalDate maxWeek);

    /**
     * 批量查询：过去周及本周每个员工-项目-周的工时单状态（用于区分「草稿/待审批/已驳回」）
     * 同一员工+项目+周有多条时按状态优先级返回：PENDING > REJECTED > DRAFT
     * 返回 Map：employeeId, projectId, weekStartDate, status
     */
    @Select("SELECT t.employee_id AS employeeId, t.project_id AS projectId, t.week_start_date AS weekStartDate, " +
            "MAX(CASE " +
            "  WHEN t.status = 'PENDING' THEN 3 " +
            "  WHEN t.status = 'REJECTED' THEN 2 " +
            "  WHEN t.status = 'DRAFT' THEN 1 " +
            "  ELSE 0 END) AS statusRank " +
            "FROM pmt_timesheet t " +
            "WHERE t.deleted = 0 AND t.status IN ('DRAFT','PENDING','REJECTED') " +
            "  AND t.week_start_date <= #{thisMonday} " +
            "  AND (#{minWeek} IS NULL OR t.week_start_date >= #{minWeek}) " +
            "  AND (#{maxWeek} IS NULL OR t.week_start_date <= #{maxWeek}) " +
            "GROUP BY t.employee_id, t.project_id, t.week_start_date")
    List<Map<String, Object>> selectUnapprovedStatusByWeek(
            @Param("thisMonday") LocalDate thisMonday,
            @Param("minWeek") LocalDate minWeek,
            @Param("maxWeek") LocalDate maxWeek);

    /**
     * 批量查询：过去周及本周每个员工-项目-周的净加班小时合计（approvalStatus='APPROVED'）
     * 返回 Map：employeeId, projectId, weekStartDate, otHours = SUM(COALESCE(net_duration_hours, gross_duration_hours, 0))
     * start_time 归属周 = DATE(start_time) 对齐到周一
     */
    @Select("SELECT o.employee_id AS employeeId, o.project_id AS projectId, " +
            "DATE_SUB(DATE(o.start_time), INTERVAL (WEEKDAY(DATE(o.start_time))) DAY) AS weekStartDate, " +
            "SUM(COALESCE(o.net_duration_hours, o.gross_duration_hours, 0)) AS otHours " +
            "FROM pmt_overtime_request o " +
            "WHERE o.deleted = 0 AND o.approval_status = 'APPROVED' " +
            "  AND o.employee_id IS NOT NULL AND o.project_id IS NOT NULL " +
            "  AND DATE_SUB(DATE(o.start_time), INTERVAL (WEEKDAY(DATE(o.start_time))) DAY) <= #{thisMonday} " +
            "  AND (#{minWeek} IS NULL OR DATE_SUB(DATE(o.start_time), INTERVAL (WEEKDAY(DATE(o.start_time))) DAY) >= #{minWeek}) " +
            "  AND (#{maxWeek} IS NULL OR DATE_SUB(DATE(o.start_time), INTERVAL (WEEKDAY(DATE(o.start_time))) DAY) <= #{maxWeek}) " +
            "GROUP BY o.employee_id, o.project_id, DATE_SUB(DATE(o.start_time), INTERVAL (WEEKDAY(DATE(o.start_time))) DAY)")
    List<Map<String, Object>> selectApprovedOvertimeByWeek(
            @Param("thisMonday") LocalDate thisMonday,
            @Param("minWeek") LocalDate minWeek,
            @Param("maxWeek") LocalDate maxWeek);

    /**
     * 批量查询：周范围内审批通过的请假记录（请假表无项目维度，仅按员工归属）。
     * 起止日均按日期相交判断：start_date <= 最大周周日 且 end_date >= 最小周周一，
     * 跨天请假的按天拆分在 Java 侧完成（与"我的工时"页 computeLeaveHoursForWeek 口径一致）。
     * 返回 Map：employeeId, startTime, endTime
     */
    @Select("SELECT l.employee_id AS employeeId, l.start_time AS startTime, l.end_time AS endTime " +
            "FROM pmt_leave_request l " +
            "WHERE l.deleted = 0 AND l.approval_status = 'APPROVED' " +
            "  AND l.employee_id IS NOT NULL " +
            "  AND DATE(l.start_time) <= #{rangeEnd} " +
            "  AND DATE(l.end_time) >= #{minWeek}")
    List<Map<String, Object>> selectApprovedLeavesInRange(
            @Param("minWeek") LocalDate minWeek,
            @Param("rangeEnd") LocalDate rangeEnd);

    /**
     * 实际工时明细：查询指定周范围内（<=本周）的工时单+明细天（扁平结果，Java聚合）。
     * 返回：employeeId, jobNumber, userName, projectId, projectCode, projectName,
     *       weekStartDate, status, roleInProject, memberWorkNature,
     *       workDate, dayOfWeek, workHours, isRemote, itemWorkNature, settlementStatus, workDays
     */
    @Select("<script>" +
            "SELECT t.employee_id AS employeeId, t.job_number AS jobNumber, t.user_name AS userName, " +
            "       t.project_id AS projectId, t.project_code AS projectCode, t.project_name AS projectName, " +
            "       t.week_start_date AS weekStartDate, t.status AS status, " +
            "       pm.role_in_project AS roleInProject, pm.work_nature AS memberWorkNature, " +
            "       i.work_date AS workDate, i.day_of_week AS dayOfWeek, i.work_hours AS workHours, " +
            "       i.is_remote AS isRemote, i.work_nature AS itemWorkNature, " +
            "       i.settlement_status AS settlementStatus, i.work_days AS workDays, " +
            "       COALESCE(ot_daily.ot_hours, 0) AS overtimeHours " +
            "FROM pmt_timesheet t " +
            "LEFT JOIN pmt_project_member pm ON pm.project_id = t.project_id AND pm.deleted = 0 " +
            "  AND (pm.user_id = t.user_id OR pm.employee_id = t.employee_id) " +
            "LEFT JOIN pmt_timesheet_item i ON i.timesheet_id = t.id AND i.deleted = 0 " +
            "LEFT JOIN ( " +
            "  SELECT o.employee_id, o.project_id, DATE(o.start_time) AS ot_date, " +
            "         SUM(COALESCE(o.net_duration_hours, o.gross_duration_hours, 0)) AS ot_hours " +
            "  FROM pmt_overtime_request o " +
            "  WHERE o.deleted = 0 AND o.approval_status = 'APPROVED' " +
            "    AND o.employee_id IS NOT NULL AND o.project_id IS NOT NULL " +
            "  GROUP BY o.employee_id, o.project_id, DATE(o.start_time) " +
            ") ot_daily ON ot_daily.employee_id = t.employee_id " +
            "          AND ot_daily.project_id = t.project_id " +
            "          AND ot_daily.ot_date = i.work_date " +
            "WHERE t.deleted = 0 AND t.week_start_date &lt;= #{thisMonday} " +
            "  AND t.week_start_date &gt;= #{startDate} AND t.week_start_date &lt;= #{endDate} " +
            "  <if test='projectId != null'>AND t.project_id = #{projectId}</if> " +
            "  <if test='projectIds != null'>AND t.project_id IN <foreach item='pid' collection='projectIds' open='(' separator=',' close=')'>#{pid}</foreach></if> " +
            "  <if test='keyword != null and keyword != \"\"'>AND (t.user_name LIKE CONCAT('%',#{keyword},'%') OR t.job_number LIKE CONCAT('%',#{keyword},'%'))</if> " +
            "  <if test='employeeNo != null and employeeNo != \"\"'>AND t.job_number = #{employeeNo}</if> " +
            "ORDER BY t.project_code, t.job_number, t.week_start_date, i.work_date" +
            "</script>")
    List<Map<String, Object>> selectActualDetail(
            @Param("thisMonday") LocalDate thisMonday,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate,
            @Param("projectId") Long projectId,
            @Param("projectIds") List<Long> projectIds,
            @Param("keyword") String keyword,
            @Param("employeeNo") String employeeNo);

    /**
     * 实际工时天：查询指定月份内今天之前的工时明细天（扁平结果，Java聚合）。
     * 返回：employeeId, jobNumber, userName, projectId, projectCode, projectName,
     *       roleInProject, memberWorkNature, workDate, workHours, isRemote,
     *       itemWorkNature, settlementStatus, workDays
     */
    @Select("<script>" +
            "SELECT t.employee_id AS employeeId, t.job_number AS jobNumber, t.user_name AS userName, " +
            "       t.project_id AS projectId, t.project_code AS projectCode, t.project_name AS projectName, " +
            "       t.status AS status, " +
            "       pm.role_in_project AS roleInProject, pm.work_nature AS memberWorkNature, " +
            "       i.work_date AS workDate, i.work_hours AS workHours, i.is_remote AS isRemote, " +
            "       i.work_nature AS itemWorkNature, i.settlement_status AS settlementStatus, i.work_days AS workDays, " +
            "       COALESCE(ot_daily.ot_hours, 0) AS overtimeHours " +
            "FROM pmt_timesheet t " +
            "LEFT JOIN pmt_project_member pm ON pm.project_id = t.project_id AND pm.deleted = 0 " +
            "  AND (pm.user_id = t.user_id OR pm.employee_id = t.employee_id) " +
            "INNER JOIN pmt_timesheet_item i ON i.timesheet_id = t.id AND i.deleted = 0 " +
            "LEFT JOIN ( " +
            "  SELECT o.employee_id, o.project_id, DATE(o.start_time) AS ot_date, " +
            "         SUM(COALESCE(o.net_duration_hours, o.gross_duration_hours, 0)) AS ot_hours " +
            "  FROM pmt_overtime_request o " +
            "  WHERE o.deleted = 0 AND o.approval_status = 'APPROVED' " +
            "    AND o.employee_id IS NOT NULL AND o.project_id IS NOT NULL " +
            "  GROUP BY o.employee_id, o.project_id, DATE(o.start_time) " +
            ") ot_daily ON ot_daily.employee_id = t.employee_id " +
            "          AND ot_daily.project_id = t.project_id " +
            "          AND ot_daily.ot_date = i.work_date " +
            "WHERE t.deleted = 0 AND i.work_date &lt; #{today} " +
            "  AND i.work_date &gt;= #{monthStart} AND i.work_date &lt;= #{monthEnd} " +
            "  <if test='projectId != null'>AND t.project_id = #{projectId}</if> " +
            "  <if test='projectIds != null'>AND t.project_id IN <foreach item='pid' collection='projectIds' open='(' separator=',' close=')'>#{pid}</foreach></if> " +
            "  <if test='keyword != null and keyword != \"\"'>AND (t.user_name LIKE CONCAT('%',#{keyword},'%') OR t.job_number LIKE CONCAT('%',#{keyword},'%'))</if> " +
            "  <if test='employeeNo != null and employeeNo != \"\"'>AND t.job_number = #{employeeNo}</if> " +
            "ORDER BY t.project_code, t.job_number, i.work_date" +
            "</script>")
    List<Map<String, Object>> selectActualDay(
            @Param("monthStart") LocalDate monthStart,
            @Param("monthEnd") LocalDate monthEnd,
            @Param("today") LocalDate today,
            @Param("projectId") Long projectId,
            @Param("projectIds") List<Long> projectIds,
            @Param("keyword") String keyword,
            @Param("employeeNo") String employeeNo);
}
