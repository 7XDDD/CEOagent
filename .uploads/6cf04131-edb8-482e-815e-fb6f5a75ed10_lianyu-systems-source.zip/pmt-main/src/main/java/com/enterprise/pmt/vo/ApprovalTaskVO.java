package com.enterprise.pmt.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
public class ApprovalTaskVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private Long instanceId;

    private String instanceNo;

    private String approvalNo;

    private String bizType;

    private String approvalType;

    private Long bizId;

    private String bizNo;

    private String title;

    private Long initiatorId;

    private String initiatorName;

    private String applicantName;

    private String nodeName;

    private String taskStatus;

    private String status;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime submitTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime actionTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime approveTime;

    private String actionRemark;

    private String comment;

    private String result;

    private String approverName;
}
