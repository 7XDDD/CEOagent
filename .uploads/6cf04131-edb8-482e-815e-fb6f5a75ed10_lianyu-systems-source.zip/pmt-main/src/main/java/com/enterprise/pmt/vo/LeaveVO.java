package com.enterprise.pmt.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class LeaveVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    private String approvalNo;

    private Long employeeId;

    private String employeeName;

    private String jobNumber;

    private String departmentName;

    private String leaveType;

    private String leaveTypeText;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime applyTime;

    private BigDecimal durationDays;

    private BigDecimal durationHours;

    private String reason;

    private String approvalStatus;

    private String approvalStatusText;

    private String remark;
}
