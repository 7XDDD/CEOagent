package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.common.UserDataScope;
import com.enterprise.pmt.entity.PmtLeaveRequest;
import com.enterprise.pmt.vo.LeaveVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtLeaveRequestMapper extends BaseMapper<PmtLeaveRequest> {

    List<LeaveVO> selectPageList(Page<LeaveVO> page,
                                  @Param("keyword") String keyword,
                                  @Param("status") String status,
                                  @Param("leaveType") String leaveType,
                                  @Param("employeeId") Long employeeId,
                                  @Param("startDate") String startDate,
                                  @Param("endDate") String endDate,
                                  @Param("scope") UserDataScope scope);
}
