package com.enterprise.pmt.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ApprovalFlowVO {
    private Long id;
    private String businessType;
    private String businessTypeName;
    private String flowName;
    private Integer status;
    private String description;
    /** 是否启用项目经理审批人特殊配置 0=否 1=是 */
    private Integer pmApproverEnabled;
    /** 项目经理审批人用户ID列表，逗号分隔 */
    private String pmApproverUserIds;
    /** PM审批人会签类型 OR=或签 AND=会签 */
    private String pmApproverSignType;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;
    private List<ApprovalNodeVO> nodes;
}
