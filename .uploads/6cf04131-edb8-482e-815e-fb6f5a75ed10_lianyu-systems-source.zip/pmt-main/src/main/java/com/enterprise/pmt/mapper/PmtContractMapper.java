package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.dto.ContractQueryDTO;
import com.enterprise.pmt.entity.PmtContract;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface PmtContractMapper extends BaseMapper<PmtContract> {

    Page<PmtContract> selectPageList(Page<PmtContract> page, @Param("query") ContractQueryDTO query);

    List<PmtContract> selectListByCondition(@Param("query") ContractQueryDTO query);

    List<PmtContract> selectAllActive();

    PmtContract findByNo(@Param("contractNo") String contractNo);

    int softDeleteById(@Param("id") Long id);

    int countByCode(@Param("contractCode") String contractCode, @Param("excludeId") Long excludeId);
}
