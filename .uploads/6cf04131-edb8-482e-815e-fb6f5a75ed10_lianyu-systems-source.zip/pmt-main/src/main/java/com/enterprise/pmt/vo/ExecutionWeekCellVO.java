package com.enterprise.pmt.vo;

import lombok.Data;

import java.math.BigDecimal;

/**
 * 执行状态矩阵：单个单元格的数值+展示
 */
@Data
public class ExecutionWeekCellVO {
    /** 直接展示字符串：如 "40"、"-"、"未填报" */
    private String displayValue;
    /** 纯数字：用于前端汇总/计算。"-"/"未填报"则=NULL 视为 0 */
    private BigDecimal hours;
    /** 加班净小时（本周内 APPROVED 且归属到该项目的净加班合计）；NULL 表示无加班 */
    private BigDecimal overtimeHours;
    /** 请假小时（本周内该员工已审批请假合计，员工维度无项目归属，只挂在其主要项目行上）；NULL 表示无请假 */
    private BigDecimal leaveHours;
    /** 若 TRUE → 前端红底红字显示"未填报"（需要填报但实际0且无任何审批工时） */
    private Boolean needReportUnfiled = Boolean.FALSE;
    /** 若 TRUE → 前端显示 "-"（既没预算又不在成员周期，无需填报） */
    private Boolean noBudgetNoRequired = Boolean.FALSE;
    /** 单元格所属周类别：PAST/CURRENT/FUTURE（便于前端直接着色而不用再从 header 查） */
    private String weekType;
}
