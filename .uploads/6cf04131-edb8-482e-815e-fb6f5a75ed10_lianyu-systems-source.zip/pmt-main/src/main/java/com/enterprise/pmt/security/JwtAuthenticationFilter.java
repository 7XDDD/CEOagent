package com.enterprise.pmt.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.ResultCode;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final String NEW_TOKEN_HEADER = "New-Token";
    private static final double REFRESH_THRESHOLD_RATIO = 0.5;

    private final JwtTokenUtil jwtTokenUtil;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${pmt.security.jwt.expiration}")
    private Long expiration;

    public JwtAuthenticationFilter(JwtTokenUtil jwtTokenUtil) {
        this.jwtTokenUtil = jwtTokenUtil;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String header = request.getHeader(jwtTokenUtil.getHeader());

        if (!StringUtils.hasText(header) || !header.startsWith(jwtTokenUtil.getPrefix())) {
            chain.doFilter(request, response);
            return;
        }

        String token = header.substring(jwtTokenUtil.getPrefix().length());
        try {
            Claims claims = jwtTokenUtil.parseToken(token);
            if (claims != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                String username = claims.getSubject();
                Object userIdObj = claims.get("userId");
                Object orgIdObj = claims.get("orgId");
                Object rolesObj = claims.get("roles");
                Object permsObj = claims.get("permissions");

                if (userIdObj == null || !StringUtils.hasText(username)) {
                    SecurityContextHolder.clearContext();
                    chain.doFilter(request, response);
                    return;
                }

                String userId = userIdObj.toString();
                String orgId = orgIdObj != null ? orgIdObj.toString() : null;
                String rolesStr = rolesObj != null ? rolesObj.toString() : null;
                String permsStr = permsObj != null ? permsObj.toString() : null;

                List<SimpleGrantedAuthority> authorities = new ArrayList<>();

                if (StringUtils.hasText(rolesStr)) {
                    Arrays.stream(rolesStr.split(","))
                            .filter(StringUtils::hasText)
                            .map(role -> role.startsWith("ROLE_") ? role : "ROLE_" + role)
                            .map(SimpleGrantedAuthority::new)
                            .forEach(authorities::add);
                }

                if (StringUtils.hasText(permsStr)) {
                    Arrays.stream(permsStr.split(","))
                            .filter(StringUtils::hasText)
                            .map(SimpleGrantedAuthority::new)
                            .forEach(authorities::add);
                }

                List<String> roleList = rolesStr != null && !rolesStr.isEmpty()
                        ? Arrays.stream(rolesStr.split(",")).filter(StringUtils::hasText).collect(Collectors.toList())
                        : Collections.emptyList();
                List<String> permList = permsStr != null && !permsStr.isEmpty()
                        ? Arrays.stream(permsStr.split(",")).filter(StringUtils::hasText).collect(Collectors.toList())
                        : Collections.emptyList();

                Map<String, Object> principal = new HashMap<>();
                principal.put("userId", Long.parseLong(userId));
                principal.put("username", username);
                principal.put("orgId", orgId != null ? Long.parseLong(orgId) : null);
                principal.put("roles", roleList);
                principal.put("permissions", permList);

                UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(principal, null, authorities);
                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
            chain.doFilter(request, response);
        } catch (ExpiredJwtException e) {
            SecurityContextHolder.clearContext();
            chain.doFilter(request, response);
        } catch (JwtException | IllegalArgumentException e) {
            SecurityContextHolder.clearContext();
            chain.doFilter(request, response);
        }
    }

    private void sendErrorResponse(HttpServletResponse response, int code, String message) throws IOException {
        SecurityContextHolder.clearContext();
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(objectMapper.writeValueAsString(Result.error(code, message)));
    }
}
