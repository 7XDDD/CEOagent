package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.Permission;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface PermissionMapper extends BaseMapper<Permission> {

    @Select("SELECT DISTINCT p.* FROM pmt_permission p " +
            "INNER JOIN pmt_role_permission rp ON p.id = rp.permission_id " +
            "INNER JOIN pmt_user_role ur ON rp.role_id = ur.role_id " +
            "WHERE ur.user_id = #{userId} AND p.deleted = 0 AND p.status = 1")
    List<Permission> findPermissionsByUserId(@Param("userId") Long userId);

    @Select("SELECT DISTINCT p.permission_code FROM pmt_permission p " +
            "INNER JOIN pmt_role_permission rp ON p.id = rp.permission_id " +
            "INNER JOIN pmt_user_role ur ON rp.role_id = ur.role_id " +
            "WHERE ur.user_id = #{userId} AND p.deleted = 0 AND p.status = 1")
    List<String> findPermissionCodesByUserId(@Param("userId") Long userId);

    @Select("SELECT * FROM pmt_permission WHERE deleted = 0 AND status = 1 ORDER BY sort_order ASC")
    List<Permission> selectAllActive();

    @Select("SELECT * FROM pmt_permission WHERE parent_id = #{parentId} AND deleted = 0 ORDER BY sort_order ASC")
    List<Permission> findByParentId(@Param("parentId") Long parentId);

    @Select("SELECT * FROM pmt_permission WHERE deleted = 0 ORDER BY sort_order ASC")
    List<Permission> selectAllWithDeleted();

    @Select("SELECT * FROM pmt_permission WHERE deleted = 0 AND system_type = #{systemType} ORDER BY sort_order ASC")
    List<Permission> selectBySystemType(@Param("systemType") String systemType);
}
