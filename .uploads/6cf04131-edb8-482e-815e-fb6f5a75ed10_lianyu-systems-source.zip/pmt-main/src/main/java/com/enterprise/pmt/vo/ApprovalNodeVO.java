package com.enterprise.pmt.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ApprovalNodeVO {
    private Long id;
    private Long flowId;
    private Integer nodeOrder;
    private String nodeName;
    private String approverType;
    private Long approverRoleId;
    private String approverRoleName;
    private String approverUserIds;
    private List<String> approverUserNameList;
    private String approverUserNames;
    private String signType;
    private String passStatus;
    private String rejectStatus;
    private String description;

    // ===== 审批实例节点字段（审批链展示用） =====
    /** 节点状态 PENDING/APPROVED/REJECTED/SKIPPED */
    private String status;
    /** 实际审批人ID（单审批人场景兼容保留；多审批人场景看 actualApproverNameList） */
    private Long actualApproverId;
    /** 实际审批人姓名（单审批人场景兼容保留；多审批人场景看 actualApproverNameList） */
    private String actualApproverName;
    /** 审批时间（取最后一条；多审批人场景看每条的 actionTime 映射） */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime actionTime;
    /** 审批意见（单审批人场景兼容保留；多审批人场景看 signerCommentList） */
    private String comment;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    // ===== 多审批人/会签 展示增强字段 =====
    /** 该节点（会签）总审批人数 */
    private Integer totalApproverCount;
    /** 已 APPROVED 人数（会签进度 x/y） */
    private Integer approvedApproverCount;
    /** 实际操作过的审批人姓名列表（按时间顺序），用于会签展示"张三、李四已通过" */
    private List<String> actualApproverNameList;
    /** 每个审批签字明细（审批人，状态，意见，时间），前端可展开查看 */
    private java.util.List<ApprovalSignerInfo> signerList;

    @Data
    public static class ApprovalSignerInfo implements java.io.Serializable {
        private static final long serialVersionUID = 1L;
        /** 审批人姓名 */
        private String approverName;
        /** 审批人ID */
        private Long approverId;
        /** 签字状态：APPROVED/REJECTED/SKIPPED/PENDING */
        private String signStatus;
        /** 签字意见 */
        private String comment;
        /** 签字时间（APPROVED/REJECTED 才有） */
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private LocalDateTime signTime;
    }
}
