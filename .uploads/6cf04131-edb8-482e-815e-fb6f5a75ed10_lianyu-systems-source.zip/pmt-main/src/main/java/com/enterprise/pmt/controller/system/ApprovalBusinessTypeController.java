package com.enterprise.pmt.controller.system;

import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.annotation.OperationLog.OperationType;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.entity.ApprovalBusinessType;
import com.enterprise.pmt.security.SecurityUtils;
import com.enterprise.pmt.service.ApprovalBusinessTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/approval-business-types")
public class ApprovalBusinessTypeController {

    @Autowired
    private ApprovalBusinessTypeService businessTypeService;

    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:view')")
    @GetMapping
    public Result<List<ApprovalBusinessType>> list(
            @RequestParam(required = false, defaultValue = "false") Boolean enabledOnly) {
        List<ApprovalBusinessType> list = Boolean.TRUE.equals(enabledOnly) 
                ? businessTypeService.listEnabled() 
                : businessTypeService.listAll();
        return Result.success(list);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:view')")
    @GetMapping("/{code}")
    public Result<ApprovalBusinessType> getByCode(@PathVariable String code) {
        ApprovalBusinessType type = businessTypeService.getByCode(code);
        if (type == null) {
            return Result.error(404, "业务类型不存在");
        }
        return Result.success(type);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:create')")
    @OperationLog(module = "审批业务类型", description = "新增业务类型", type = OperationType.INSERT)
    @PostMapping
    public Result<ApprovalBusinessType> create(@RequestBody ApprovalBusinessType type) {
        Long currentUserId = SecurityUtils.getCurrentUserId();
        if (businessTypeService.getByCode(type.getCode()) != null) {
            return Result.error("业务类型编码已存在");
        }
        businessTypeService.saveType(type, currentUserId);
        return Result.success(type);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:update')")
    @OperationLog(module = "审批业务类型", description = "修改业务类型", type = OperationType.UPDATE)
    @PutMapping("/{code}")
    public Result<Void> update(@PathVariable String code, @RequestBody ApprovalBusinessType type) {
        Long currentUserId = SecurityUtils.getCurrentUserId();
        type.setCode(code);
        businessTypeService.updateType(type, currentUserId);
        return Result.success();
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:delete')")
    @OperationLog(module = "审批业务类型", description = "删除业务类型", type = OperationType.DELETE)
    @DeleteMapping("/{code}")
    public Result<Void> delete(@PathVariable String code) {
        Long currentUserId = SecurityUtils.getCurrentUserId();
        businessTypeService.deleteType(code, currentUserId);
        return Result.success();
    }
}
