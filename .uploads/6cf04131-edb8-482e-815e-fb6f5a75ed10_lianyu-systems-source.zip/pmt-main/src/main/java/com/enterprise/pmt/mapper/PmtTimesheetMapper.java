package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.dto.TimesheetQueryDTO;
import com.enterprise.pmt.entity.PmtTimesheet;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Mapper
public interface PmtTimesheetMapper extends BaseMapper<PmtTimesheet> {

    Page<PmtTimesheet> selectPageList(Page<PmtTimesheet> page, @Param("query") TimesheetQueryDTO query);

    List<PmtTimesheet> selectListByCondition(@Param("query") TimesheetQueryDTO query);

    PmtTimesheet selectCurrentWeek(@Param("userId") Long userId, @Param("weekStartDate") LocalDate weekStartDate);

    List<PmtTimesheet> selectMyTimesheets(@Param("userId") Long userId);

    List<PmtTimesheet> selectPendingApproval(@Param("approverId") Long approverId);

    List<Map<String, Object>> selectRecentTimesheets(@Param("userId") Long userId, @Param("limit") int limit);

    /**
     * 根据员工号+周起始日+项目ID查询工时单
     */
    PmtTimesheet selectByUserAndWeekAndProject(@Param("jobNumber") String jobNumber,
                                               @Param("weekStartDate") LocalDate weekStartDate,
                                               @Param("projectId") Long projectId);

    /**
     * 查询某项目历史数据导入已导入的最大周起始日（周一）。
     * 包含 source='HISTORY'（后续导入）与 'HISTORY_FIRST'（第一次导入）。
     * 未导入过返回 null。
     */
    LocalDate selectMaxHistoryWeekStart(@Param("projectId") Long projectId);

    /**
     * 查询某项目历史数据导入锁定的最后周（周一）：该项目全部历史导入工时单
     * （source IN ('HISTORY','HISTORY_FIRST')）的最大周起始日。
     * 后续导入被校验限制不能超过第一次导入的最后周，故该最大值恒等于首次锁定周；
     * 不能只统计 HISTORY_FIRST，否则后续导入覆盖降级 source 后锚点会漂移变小。
     * 未导入过返回 null。
     */
    LocalDate selectMaxHistoryFirstWeekStart(@Param("projectId") Long projectId);

    /**
     * 查询所有已导入过历史数据的项目锁定周锚点（用于导入弹窗/模板说明按项目展示）。
     * source IN ('HISTORY','HISTORY_FIRST') 统一口径，每项包含 projectId、projectName、endDate。
     */
    List<Map<String, Object>> selectHistoryFirstEndByProjects();

    /**
     * 兼容老数据：把某项目旧版本导入的 source='HISTORY' 工时单升级为 'HISTORY_FIRST'。
     * 仅在该项目尚不存在 FIRST 记录时调用一次。
     * @return 受影响行数
     */
    int markHistoryAsFirst(@Param("projectId") Long projectId);

    /**
     * 根据用户ID+周起始日查询该周所有工时单
     */
    List<PmtTimesheet> selectByUserAndWeek(@Param("userId") Long userId,
                                           @Param("jobNumber") String jobNumber,
                                           @Param("weekStartDate") LocalDate weekStartDate);

    int softDeleteById(@Param("id") Long id);

    Long countPendingByUser(@Param("userId") Long userId);

    Long countPendingApproval(@Param("approverId") Long approverId);

    /**
     * 批量锁定工时单（状态改为LOCKED），仅对APPROVED状态的工时单生效
     * @return 更新的记录数
     */
    int batchLock(@Param("ids") List<Long> ids, @Param("operatorId") Long operatorId);

    /**
     * 批量解锁工时单（状态改为APPROVED），仅对LOCKED状态的工时单生效
     */
    int batchUnlock(@Param("ids") List<Long> ids, @Param("operatorId") Long operatorId);

    /**
     * 按项目+周起始日期批量锁定（项目下该周某用户的APPROVED工时单）
     */
    int lockByProjectAndWeek(@Param("projectId") Long projectId,
                             @Param("weekStartDate") LocalDate weekStartDate,
                             @Param("operatorId") Long operatorId);

    /**
     * 查询可结算工时单（LOCKED状态，在日期范围内，未结算的）
     */
    List<PmtTimesheet> selectSettleableSheets(@Param("projectId") Long projectId,
                                              @Param("projectIds") List<Long> projectIds,
                                              @Param("startDate") LocalDate startDate,
                                              @Param("endDate") LocalDate endDate);

    /**
     * 批量标记为已结算
     */
    int batchMarkSettled(@Param("ids") List<Long> ids, @Param("batchId") Long batchId, @Param("operatorId") Long operatorId);

    /**
     * 根据 item 结算情况重算工时单 settled 状态（0=未结算 1=已结算 2=部分结算）。
     * 同时同步 is_settlement 字段（settled=1 时 is_settlement=1，否则 0）。
     */
    int recomputeSettledStatus(@Param("ids") List<Long> ids);

    /**
     * 按工时单ID清空结算批次信息（用于取消结算）。
     */
    int clearSettlementInfo(@Param("ids") List<Long> ids, @Param("operatorId") Long operatorId);

    /**
     * 回填工时单结算批次信息（批次ID、批次号、结算时间）。
     */
    int fillSettlementBatchInfo(@Param("ids") List<Long> ids,
                                @Param("batchId") Long batchId,
                                @Param("batchNo") String batchNo,
                                @Param("operatorId") Long operatorId);

    /**
     * 统计异常数量（按工时单分组）
     */
    List<Map<String, Object>> countAnomaliesByTimesheet(@Param("timesheetIds") List<Long> timesheetIds);

    /**
     * PM工时统计：按项目统计
     */
    List<Map<String, Object>> statsByProject(@Param("projectId") Long projectId,
                                             @Param("projectIds") List<Long> projectIds,
                                             @Param("startDate") LocalDate startDate,
                                             @Param("endDate") LocalDate endDate);

    /**
     * PM工时统计：按员工统计
     */
    List<Map<String, Object>> statsByUser(@Param("projectId") Long projectId,
                                          @Param("projectIds") List<Long> projectIds,
                                          @Param("startDate") LocalDate startDate,
                                          @Param("endDate") LocalDate endDate);

    /**
     * PM工时统计：按周统计
     */
    List<Map<String, Object>> statsByWeek(@Param("projectId") Long projectId,
                                          @Param("projectIds") List<Long> projectIds,
                                          @Param("startDate") LocalDate startDate,
                                          @Param("endDate") LocalDate endDate);
}
