package com.enterprise.pmt.dto;

import lombok.Data;

@Data
public class ApprovalResultDTO {
    private boolean success;
    private String instanceStatus;
    private Integer currentNodeOrder;
    private Long currentNodeId;
    private String businessStatus;
    private String businessNodeName;
    private boolean complete;

    public static ApprovalResultDTO pass(String businessStatus, boolean complete, Integer nodeOrder, Long nodeId, String nodeName) {
        ApprovalResultDTO result = new ApprovalResultDTO();
        result.setSuccess(true);
        result.setInstanceStatus(complete ? "APPROVED" : "RUNNING");
        result.setBusinessStatus(businessStatus);
        result.setComplete(complete);
        result.setCurrentNodeOrder(nodeOrder);
        result.setCurrentNodeId(nodeId);
        result.setBusinessNodeName(nodeName);
        return result;
    }

    public static ApprovalResultDTO reject(String businessStatus, Integer nodeOrder) {
        ApprovalResultDTO result = new ApprovalResultDTO();
        result.setSuccess(true);
        result.setInstanceStatus("REJECTED");
        result.setBusinessStatus(businessStatus);
        result.setComplete(true);
        result.setCurrentNodeOrder(nodeOrder);
        return result;
    }
}
