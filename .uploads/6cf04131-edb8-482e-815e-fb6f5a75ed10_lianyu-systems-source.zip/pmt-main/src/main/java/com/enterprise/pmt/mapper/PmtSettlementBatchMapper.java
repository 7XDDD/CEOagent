package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.PmtSettlementBatch;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface PmtSettlementBatchMapper extends BaseMapper<PmtSettlementBatch> {

    Page<PmtSettlementBatch> selectPageList(Page<PmtSettlementBatch> page,
                                            @Param("keyword") String keyword,
                                            @Param("batchStatus") String batchStatus);

    List<PmtSettlementBatch> selectListAll();

    /** 统计 batch_no 前缀匹配的已存在数量，用于生成 JS+年月+4位序号的批次号 */
    @Select("SELECT COUNT(1) FROM pmt_settlement_batch WHERE deleted = 0 AND batch_no LIKE #{prefix}")
    Long countByPrefix(@Param("prefix") String prefix);
}
