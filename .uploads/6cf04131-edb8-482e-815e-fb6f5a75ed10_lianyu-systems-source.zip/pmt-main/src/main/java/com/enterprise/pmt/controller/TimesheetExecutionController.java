package com.enterprise.pmt.controller;

import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.dto.TimesheetExecutionQuery;
import com.enterprise.pmt.service.TimesheetExecutionService;
import com.enterprise.pmt.vo.TimesheetExecutionResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Api(tags = "工时执行状态")
@RequestMapping("/timesheet-execution")
@RestController
public class TimesheetExecutionController {

    @Autowired
    private TimesheetExecutionService service;

    @ApiOperation("获取版本下拉列表（与预算页相同）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-execution:view')")
    @GetMapping("/versions")
    public Result<List<Map<String, Object>>> versions() {
        return Result.success(service.getVersions());
    }

    @ApiOperation("获取项目下拉（预算里去重，按关键字模糊）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-execution:view')")
    @GetMapping("/projects")
    public Result<List<Map<String, Object>>> projects(@RequestParam(required = false) String keyword) {
        return Result.success(service.getProjectOptions(keyword));
    }

    @ApiOperation("查询工时执行状态（矩阵）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-execution:view')")
    @GetMapping("/list")
    public Result<TimesheetExecutionResultVO> list(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String projectCode,
            @RequestParam(required = false) String employeeNo,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekStart,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekEnd,
            @RequestParam(required = false) String budgetVersion,
            @RequestParam(required = false) Boolean useLatest,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "99999") Integer pageSize) {
        TimesheetExecutionQuery q = new TimesheetExecutionQuery();
        q.setKeyword(keyword);
        q.setProjectCode(projectCode);
        q.setEmployeeNo(employeeNo);
        q.setWeekStart(weekStart);
        q.setWeekEnd(weekEnd);
        q.setBudgetVersion(budgetVersion);
        if (useLatest != null) q.setUseLatest(useLatest);
        q.setPageNum(pageNum == null || pageNum < 1 ? 1 : pageNum);
        q.setPageSize(pageSize == null || pageSize < 1 ? 99999 : pageSize);
        return Result.success(service.getExecutionList(q));
    }

    @ApiOperation("导出工时执行状态（多项目 × 多Sheet：执行状态/执行状态(人天)/实际明细/实际天）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-execution:export')")
    @GetMapping("/export")
    public void export(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String projectCode,
            @RequestParam(required = false) String employeeNo,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekStart,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekEnd,
            @RequestParam(required = false) String budgetVersion,
            @RequestParam(required = false) Boolean useLatest,
            @RequestParam(required = false) String scope,
            @RequestParam(required = false) String month,
            HttpServletResponse response) throws Exception {
        TimesheetExecutionQuery q = new TimesheetExecutionQuery();
        q.setKeyword(keyword);
        q.setProjectCode(projectCode);
        q.setEmployeeNo(employeeNo);
        q.setWeekStart(weekStart);
        q.setWeekEnd(weekEnd);
        q.setBudgetVersion(budgetVersion);
        if (useLatest != null) q.setUseLatest(useLatest);
        q.setScope(scope);
        q.setMonth(month);
        q.setPageNum(1);
        q.setPageSize(999999);
        service.exportExcel(q, response);
    }

    @ApiOperation("实际工时明细（按周+天，当周及之前）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-execution:view')")
    @GetMapping("/actual-detail")
    public Result<Map<String, Object>> actualDetail(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekStart,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekEnd,
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String employeeNo) {
        return Result.success(service.getActualDetail(weekStart, weekEnd, projectId, keyword, employeeNo));
    }

    @ApiOperation("实际工时天（按月+天，今天之前）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-execution:view')")
    @GetMapping("/actual-day")
    public Result<Map<String, Object>> actualDay(
            @RequestParam(required = false) String month,
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String employeeNo) {
        return Result.success(service.getActualDay(month, projectId, keyword, employeeNo));
    }
}
