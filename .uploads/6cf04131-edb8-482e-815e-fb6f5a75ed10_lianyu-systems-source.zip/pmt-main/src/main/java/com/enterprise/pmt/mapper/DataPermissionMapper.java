package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.DataPermission;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 通用数据权限 Mapper
 */
@Mapper
public interface DataPermissionMapper extends BaseMapper<DataPermission> {

    /**
     * 查询用户对某类资源被直接授权(USER)的资源ID列表
     *
     * @param userId       用户ID
     * @param resourceType 资源类型
     * @param actionColumn can_view / can_edit / can_approve
     */
    List<Long> selectUserGrantedResourceIds(@Param("userId") Long userId,
                                            @Param("resourceType") String resourceType,
                                            @Param("actionColumn") String actionColumn);

    /**
     * 查询用户通过角色(ROLE)对某类资源被授权的资源ID列表
     */
    List<Long> selectRoleGrantedResourceIds(@Param("userId") Long userId,
                                            @Param("resourceType") String resourceType,
                                            @Param("actionColumn") String actionColumn);

    /**
     * 查询用户在某资源上的直接授权记录(USER)
     */
    DataPermission selectUserGrant(@Param("userId") Long userId,
                                   @Param("resourceType") String resourceType,
                                   @Param("resourceId") Long resourceId);

    /**
     * 查询用户通过角色在某资源上的授权记录(ROLE)
     */
    List<DataPermission> selectRoleGrants(@Param("userId") Long userId,
                                          @Param("resourceType") String resourceType,
                                          @Param("resourceId") Long resourceId);
}
