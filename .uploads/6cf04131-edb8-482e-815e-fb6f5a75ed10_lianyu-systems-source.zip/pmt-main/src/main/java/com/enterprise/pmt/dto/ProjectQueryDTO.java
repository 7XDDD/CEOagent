package com.enterprise.pmt.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
public class ProjectQueryDTO extends PageQueryDTO {
    private String keyword;
    private String projectCode;
    private String projectName;
    private String customerCode;
    private String customerName;
    private Long customerId;
    private String projectStatus;
    private String projectType;
    private String projectLevel;
    private String parentProjectCode;
    private String parentProjectName;

    /** 数据权限：可管理的项目ID列表（非管理员只能看自己参与/管理的项目） */
    private List<Long> managedProjectIds;
}
