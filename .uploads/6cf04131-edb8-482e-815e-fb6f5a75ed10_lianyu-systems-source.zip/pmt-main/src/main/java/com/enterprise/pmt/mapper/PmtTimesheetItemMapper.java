package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtTimesheetItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Mapper
public interface PmtTimesheetItemMapper extends BaseMapper<PmtTimesheetItem> {

    List<PmtTimesheetItem> selectByTimesheetId(@Param("timesheetId") Long timesheetId);

    /** 按工时单ID批量查询明细（导出用），按 timesheet_id + work_date 排序 */
    List<PmtTimesheetItem> selectByTimesheetIds(@Param("timesheetIds") List<Long> timesheetIds);

    int deleteByTimesheetId(@Param("timesheetId") Long timesheetId);

    List<PmtTimesheetItem> selectByDateRange(@Param("userId") Long userId,
                                             @Param("startDate") LocalDate startDate,
                                             @Param("endDate") LocalDate endDate);

    /**
     * 按工时单ID批量结算未结算的明细天（item 级）。
     * 仅结算已锁定、项目成员工时性质=SETTLE 的工时单下 settlement_status=UNSETTLED 的 item。
     * @return 更新行数
     */
    int batchSettleItemsByTimesheetIds(@Param("timesheetIds") List<Long> timesheetIds,
                                       @Param("batchNo") String batchNo);

    /**
     * 按工作日期范围批量结算未结算的明细天（用于跨月周按月结算）。
     * @param startDate 工作日期起（含）
     * @param endDate 工作日期止（含）
     * @param projectIds 项目ID集合，null 表示全部项目
     * @param batchNo 结算批次号
     */
    int batchSettleItemsByDateRange(@Param("startDate") LocalDate startDate,
                                    @Param("endDate") LocalDate endDate,
                                    @Param("projectIds") List<Long> projectIds,
                                    @Param("batchNo") String batchNo);

    /**
     * 按工时单ID批量取消明细天结算（置回 UNSETTLED，清空批次号）。
     */
    int batchUnsettleItemsByTimesheetIds(@Param("timesheetIds") List<Long> timesheetIds);

    /**
     * 统计给定工时单集合中每张工时单的已结算/未结算工时数（仅 BILLABLE 性质 item）。
     * 返回 map: timesheetId, settledHours, unsettledHours, totalItems, settledItems
     */
    List<Map<String, Object>> countSettlementHoursByTimesheetIds(@Param("timesheetIds") List<Long> timesheetIds);

    /**
     * 按工作日期范围查询涉及的工时单ID集合（已锁定+SETTLE性质+有UNSETTLED item）。
     */
    List<Long> findSettleableTimesheetIdsByDateRange(@Param("startDate") LocalDate startDate,
                                                     @Param("endDate") LocalDate endDate,
                                                     @Param("projectIds") List<Long> projectIds);
}
