package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtCustomerFollower;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtCustomerFollowerMapper extends BaseMapper<PmtCustomerFollower> {

    List<PmtCustomerFollower> selectByCustomerId(@Param("customerId") Long customerId);

    List<PmtCustomerFollower> selectByCustomerIds(@Param("customerIds") List<Long> customerIds);

    PmtCustomerFollower selectFollowerById(@Param("id") Long id);

    int insertFollower(PmtCustomerFollower follower);

    int updateFollower(PmtCustomerFollower follower);

    int deleteByCustomerId(@Param("customerId") Long customerId);

    int deleteByCustomerIds(@Param("customerIds") List<Long> customerIds);

    int deleteFollowerById(@Param("id") Long id);

    int clearPrimaryByCustomerId(@Param("customerId") Long customerId);
}
