package com.enterprise.pmt.common;

import java.time.DayOfWeek;
import java.time.LocalDate;

/**
 * 工时填报/提交的周范围校验工具。
 * <p>
 * 业务规则（「我的工时」PC & 移动端）：
 * 1. 历史周不限制：本周及之前的任意周都允许填报/提交（补录历史工时）；
 * 2. 未来周最多只能填到【下一周】，下下周及以后的周一律拦截；
 * 3. 只要用户在所选项目下是成员即可填报，不再依赖工时计划/预算是否存在；
 * 4. 该规则仅对"员工手动填报/手动提交自己的工时单"生效；
 *    管理员在工时管理页面通过 Excel 批量导入工时（importExcel）走的是补录/初始化场景，
 *    不需要限制多少周。
 * </p>
 */
public final class TimesheetWeekValidator {

    private TimesheetWeekValidator() {}

    /**
     * 计算当前系统日期所在周的周一（ISO 周算法：周一 = 周第一天）。
     */
    public static LocalDate currentWeekMonday() {
        return LocalDate.now().with(DayOfWeek.MONDAY);
    }

    /** 上一周周一 */
    public static LocalDate lastWeekMonday() {
        return currentWeekMonday().minusWeeks(1);
    }

    /** 下一周周一（允许填报的最晚一周） */
    public static LocalDate nextWeekMonday() {
        return currentWeekMonday().plusWeeks(1);
    }

    /**
     * 校验给定的 weekStartDate 是否落在允许范围内。
     * <p>规则：历史周（本周及之前）不限；未来周最晚只能到下一周，超过下周则拦截。</p>
     *
     * @param weekStartDate 待校验周（周一，否则会按周一对齐来比较）
     * @param actionName    操作名（保存 / 提交 / 批量提交），会拼到错误提示里
     */
    public static void validate(LocalDate weekStartDate, String actionName) {
        if (weekStartDate == null) {
            throw new BusinessException(actionName + "工时失败：缺少周开始日期");
        }
        LocalDate currentMonday = currentWeekMonday();
        // 对齐到 weekStartDate 所在周的周一（避免前端传进来的不是周一）
        LocalDate targetMonday = weekStartDate.with(DayOfWeek.MONDAY);

        LocalDate nextMonday = currentMonday.plusWeeks(1);
        if (targetMonday.isAfter(nextMonday)) {
            throw new BusinessException(
                    actionName + "工时失败：工时最晚只能填报到下一周（"
                            + nextMonday + "~" + nextMonday.plusDays(6)
                            + "），不能填报下下周及以后的工时。"
            );
        }
    }
}
