package com.enterprise.pmt.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ContractQueryDTO extends PageQueryDTO {
    private String keyword;
    private String contractCode;
    private String contractName;
    private Long customerId;
    private Long projectId;
    private String contractType;
    private String contractStatus;
}
