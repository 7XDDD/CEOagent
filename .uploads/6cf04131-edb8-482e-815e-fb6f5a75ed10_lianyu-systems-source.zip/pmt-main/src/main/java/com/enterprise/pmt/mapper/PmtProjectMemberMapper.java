package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.PmtProjectMember;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface PmtProjectMemberMapper extends BaseMapper<PmtProjectMember> {

    List<PmtProjectMember> selectByProjectId(@Param("projectId") Long projectId);

    List<PmtProjectMember> selectByProjectIds(@Param("projectIds") List<Long> projectIds);

    Page<PmtProjectMember> selectPageByProjectIds(Page<PmtProjectMember> page,
                                                   @Param("projectIds") List<Long> projectIds,
                                                   @Param("keyword") String keyword,
                                                   @Param("roleInProject") String roleInProject);

    int deleteByProjectId(@Param("projectId") Long projectId);

    /**
     * 逻辑删除单个成员（deleted = id）
     */
    int deleteMemberById(@Param("memberId") Long memberId);

    PmtProjectMember findByJobNumber(@Param("jobNumber") String jobNumber);

    PmtProjectMember findByProjectAndEmployee(@Param("projectId") Long projectId, @Param("employeeId") Long employeeId, @Param("jobNumber") String jobNumber);

    /** 查询用户参与的所有项目ID（任意角色，用于查看权限） */
    List<Long> selectMemberProjectIds(@Param("userId") Long userId);

    /** 查询用户担任PM的项目ID（用于编辑/审批权限） */
    List<Long> selectPmProjectIds(@Param("userId") Long userId);

    /** 查询多个项目下所有成员的员工ID（用于数据范围反查：PM看项目成员的请假等） */
    List<Long> selectEmployeeIdsByProjectIds(@Param("projectIds") List<Long> projectIds);

    /**
     * 工时执行状态：查询项目成员行（含没有工时计划/预算的成员）。
     * 返回 Map 键：employeeId, projectId, employeeNo, employeeName, roleInProject,
     *            workNature, projectCode, projectName, workStatus
     */
    List<Map<String, Object>> selectExecutionMemberRows(@Param("projectCode") String projectCode,
                                                        @Param("employeeNo") String employeeNo,
                                                        @Param("keyword") String keyword);

    /** 工时执行状态项目下拉：所有存在项目成员的项目（含无预算项目），返回 projectCode/projectName */
    List<Map<String, Object>> selectDistinctMemberProjects();
}
