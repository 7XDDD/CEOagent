package com.enterprise.pmt.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.common.BusinessException;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.ResultCode;
import com.enterprise.pmt.entity.PmtInvoice;
import com.enterprise.pmt.entity.PmtInvoiceLine;
import com.enterprise.pmt.mapper.PmtInvoiceLineMapper;
import com.enterprise.pmt.mapper.PmtInvoiceMapper;
import com.enterprise.pmt.service.InvoiceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(tags = "发票管理")
@RestController
@RequestMapping("/invoices")
public class InvoiceController {

    private final PmtInvoiceMapper invoiceMapper;
    private final PmtInvoiceLineMapper invoiceLineMapper;
    @Resource
    private InvoiceService invoiceService;

    public InvoiceController(PmtInvoiceMapper invoiceMapper, PmtInvoiceLineMapper invoiceLineMapper) {
        this.invoiceMapper = invoiceMapper;
        this.invoiceLineMapper = invoiceLineMapper;
    }

    @ApiOperation("发票统计")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:invoice:view')")
    @GetMapping("/stats")
    public Result<Map<String, Object>> stats() {
        Map<String, Object> data = new HashMap<>();
        try {
            long totalCount = invoiceMapper.countAll();
            data.put("totalCount", totalCount);
            data.put("draftCount", invoiceMapper.countByStatus("DRAFT"));
            data.put("issuedCount", invoiceMapper.countByStatus("ISSUED"));
            data.put("cancelledCount", invoiceMapper.countByStatus("CANCELLED"));
            data.put("totalAmount", invoiceMapper.sumInvoiceAmount());
            LocalDate now = LocalDate.now();
            data.put("monthlyCount", invoiceMapper.countMonthlyInvoices(now.getYear(), now.getMonthValue()));
            data.put("monthlyAmount", invoiceMapper.sumMonthlyInvoiceAmount(now.getYear(), now.getMonthValue()));
        } catch (Exception e) {
            data.put("totalCount", 0L);
            data.put("draftCount", 0L);
            data.put("issuedCount", 0L);
            data.put("cancelledCount", 0L);
            data.put("totalAmount", BigDecimal.ZERO);
            data.put("monthlyCount", 0L);
            data.put("monthlyAmount", BigDecimal.ZERO);
        }
        return Result.success(data);
    }

    @ApiOperation("分页查询发票(GET)")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:invoice:view')")
    @GetMapping("/page")
    public Result<Page<PmtInvoice>> pageGet(@RequestParam(defaultValue = "1") int pageNum,
                                            @RequestParam(defaultValue = "10") int pageSize,
                                            @RequestParam(required = false) Long projectId,
                                            @RequestParam(required = false) Long customerId,
                                            @RequestParam(required = false) Long contractId,
                                            @RequestParam(required = false) String keyword,
                                            @RequestParam(required = false) String invoiceStatus) {
        Page<PmtInvoice> page = new Page<>(pageNum, pageSize);
        return Result.success(invoiceMapper.selectPageList(page, projectId, customerId, contractId, keyword, invoiceStatus));
    }

    @ApiOperation("获取所有发票")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:invoice:view')")
    @GetMapping("/list")
    public Result<List<PmtInvoice>> listAll(@RequestParam(required = false) Long contractId,
                                            @RequestParam(required = false) Long customerId) {
        return Result.success(invoiceMapper.selectListByCondition(contractId, customerId));
    }

    @ApiOperation("获取发票详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:invoice:view')")
    @GetMapping("/{id}")
    public Result<PmtInvoice> getDetail(@PathVariable Long id) {
        PmtInvoice invoice = invoiceMapper.selectById(id);
        if (invoice == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        return Result.success(invoice);
    }

    @ApiOperation("获取发票行")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:invoice:view')")
    @GetMapping("/{id}/lines")
    public Result<List<PmtInvoiceLine>> getLines(@PathVariable Long id) {
        return Result.success(invoiceLineMapper.selectByInvoiceId(id));
    }

    @ApiOperation("创建发票")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:invoice:create')")
    @PostMapping
    @OperationLog("创建发票")
    @Transactional(rollbackFor = Exception.class)
    public Result<Long> create(@RequestBody PmtInvoice invoice) {
        invoiceMapper.insert(invoice);
        return Result.success(invoice.getId());
    }

    @ApiOperation("更新发票")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:invoice:update')")
    @PutMapping("/{id}")
    @OperationLog("更新发票")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> update(@PathVariable Long id, @RequestBody PmtInvoice invoice) {
        PmtInvoice exist = invoiceMapper.selectById(id);
        if (exist == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        invoice.setId(id);
        return Result.success(invoiceMapper.updateById(invoice) > 0);
    }

    @ApiOperation("删除发票")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:invoice:delete')")
    @DeleteMapping("/{id:\\d+}")
    @OperationLog("删除发票")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> delete(@PathVariable Long id) {
        PmtInvoice invoice = invoiceMapper.selectById(id);
        if (invoice == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        invoiceLineMapper.deleteByInvoiceId(id);
        invoiceMapper.softDeleteById(id);
        return Result.success(true);
    }

    @ApiOperation("导出发票")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:invoice:export')")
    @GetMapping("/export")
    @OperationLog("导出发票")
    public void export(HttpServletResponse response) throws Exception {
        invoiceService.exportInvoices(response);
    }

    @ApiOperation("下载发票导入模板")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:invoice:import')")
    @GetMapping("/template")
    public void downloadTemplate(HttpServletResponse response) throws Exception {
        invoiceService.downloadImportTemplate(response);
    }
}
