package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtTimesheetApprovalLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtTimesheetApprovalLogMapper extends BaseMapper<PmtTimesheetApprovalLog> {

    List<PmtTimesheetApprovalLog> selectByTimesheetId(@Param("timesheetId") Long timesheetId);
}
