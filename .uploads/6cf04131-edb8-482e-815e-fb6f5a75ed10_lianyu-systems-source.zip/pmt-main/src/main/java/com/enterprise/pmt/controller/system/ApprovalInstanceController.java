package com.enterprise.pmt.controller.system;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.SecurityContextUtil;
import com.enterprise.pmt.entity.ApprovalInstance;
import com.enterprise.pmt.entity.ApprovalInstanceNode;
import com.enterprise.pmt.entity.User;
import com.enterprise.pmt.mapper.ApprovalInstanceMapper;
import com.enterprise.pmt.mapper.ApprovalInstanceNodeMapper;
import com.enterprise.pmt.mapper.PmtProjectManagerMapper;
import com.enterprise.pmt.mapper.UserMapper;
import com.enterprise.pmt.service.ApprovalInstanceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Api(tags = "系统管理-审批实例管理")
@RestController
@RequestMapping("/system/approval-instances")
public class ApprovalInstanceController {

    private final ApprovalInstanceMapper instanceMapper;
    private final ApprovalInstanceNodeMapper instanceNodeMapper;
    private final ApprovalInstanceService approvalInstanceService;
    private final PmtProjectManagerMapper projectManagerMapper;
    private final UserMapper userMapper;

    public ApprovalInstanceController(ApprovalInstanceMapper instanceMapper,
                                      ApprovalInstanceNodeMapper instanceNodeMapper,
                                      ApprovalInstanceService approvalInstanceService,
                                      PmtProjectManagerMapper projectManagerMapper,
                                      UserMapper userMapper) {
        this.instanceMapper = instanceMapper;
        this.instanceNodeMapper = instanceNodeMapper;
        this.approvalInstanceService = approvalInstanceService;
        this.projectManagerMapper = projectManagerMapper;
        this.userMapper = userMapper;
    }

    @ApiOperation("分页查询审批实例（管理视图）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval:view')")
    @GetMapping("/page")
    public Result<Page<Map<String, Object>>> page(@RequestParam(defaultValue = "1") int pageNum,
                                                  @RequestParam(defaultValue = "10") int pageSize,
                                                  @RequestParam(required = false) String keyword,
                                                  @RequestParam(required = false) String businessType,
                                                  @RequestParam(required = false) String status,
                                                  @RequestParam(required = false) Long projectId,
                                                  @RequestParam(required = false) Long applicantId) {
        Page<ApprovalInstance> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<ApprovalInstance> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ApprovalInstance::getDeleted, 0L);
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.and(w -> w.like(ApprovalInstance::getTitle, keyword)
                    .or().like(ApprovalInstance::getInstanceNo, keyword)
                    .or().like(ApprovalInstance::getApplicantName, keyword)
                    .or().like(ApprovalInstance::getBusinessNo, keyword));
        }
        if (businessType != null && !businessType.isEmpty()) {
            wrapper.eq(ApprovalInstance::getBusinessType, businessType);
        }
        if (status != null && !status.isEmpty()) {
            wrapper.eq(ApprovalInstance::getStatus, status);
        }
        if (projectId != null) {
            wrapper.eq(ApprovalInstance::getProjectId, projectId);
        }
        if (applicantId != null) {
            wrapper.eq(ApprovalInstance::getApplicantId, applicantId);
        }
        wrapper.orderByDesc(ApprovalInstance::getSubmitTime);
        Page<ApprovalInstance> result = instanceMapper.selectPage(page, wrapper);

        // 转换为Map，附加当前节点名称
        Page<Map<String, Object>> voPage = new Page<>(result.getCurrent(), result.getSize(), result.getTotal());
        List<Map<String, Object>> voList = result.getRecords().stream().map(inst -> {
            Map<String, Object> map = new HashMap<>();
            map.put("id", inst.getId());
            map.put("instanceNo", inst.getInstanceNo());
            map.put("businessType", inst.getBusinessType());
            map.put("businessId", inst.getBusinessId());
            map.put("businessNo", inst.getBusinessNo());
            map.put("title", inst.getTitle());
            map.put("flowId", inst.getFlowId());
            map.put("flowName", inst.getFlowName());
            map.put("applicantId", inst.getApplicantId());
            map.put("applicantName", inst.getApplicantName());
            map.put("status", inst.getStatus());
            map.put("currentNodeOrder", inst.getCurrentNodeOrder());
            map.put("currentNodeId", inst.getCurrentNodeId());
            map.put("submitTime", inst.getSubmitTime());
            map.put("finishTime", inst.getFinishTime());
            map.put("projectId", inst.getProjectId());
            map.put("createTime", inst.getCreateTime());

            // 获取当前节点名称
            if (inst.getCurrentNodeId() != null) {
                ApprovalInstanceNode node = instanceNodeMapper.selectById(inst.getCurrentNodeId());
                if (node != null) {
                    map.put("currentNodeName", node.getNodeName());
                }
            }
            return map;
        }).collect(Collectors.toList());
        voPage.setRecords(voList);
        return Result.success(voPage);
    }

    @ApiOperation("获取审批实例详情（含节点流转记录）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval:view')")
    @GetMapping("/{id:\\d+}")
    public Result<Map<String, Object>> getDetail(@PathVariable Long id) {
        ApprovalInstance inst = instanceMapper.selectById(id);
        if (inst == null || inst.getDeleted() != 0L) {
            return Result.error("审批实例不存在");
        }
        List<ApprovalInstanceNode> nodes = instanceNodeMapper.selectByInstanceId(id);
        Map<String, Object> result = new HashMap<>();
        result.put("instance", inst);
        result.put("nodes", nodes);
        return Result.success(result);
    }

    @ApiOperation("获取我的待审批数量")
    @GetMapping("/my-pending-count")
    public Result<Map<String, Object>> myPendingCount() {
        Long userId = SecurityContextUtil.getCurrentUserId();
        List<ApprovalInstance> runningInstances = instanceMapper.selectList(
                new LambdaQueryWrapper<ApprovalInstance>()
                        .eq(ApprovalInstance::getStatus, "RUNNING")
                        .eq(ApprovalInstance::getDeleted, 0L)
        );
        int count = 0;
        for (ApprovalInstance inst : runningInstances) {
            if (inst.getCurrentNodeId() != null) {
                ApprovalInstanceNode node = instanceNodeMapper.selectById(inst.getCurrentNodeId());
                if (node != null && "PENDING".equals(node.getStatus())) {
                    if (approvalInstanceService.isCurrentApprover(inst.getId(), userId)) {
                        count++;
                    }
                }
            }
        }
        Map<String, Object> result = new HashMap<>();
        result.put("count", count);
        return Result.success(result);
    }

    @ApiOperation("获取所有业务类型")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval:view')")
    @GetMapping("/business-types")
    public Result<List<Map<String, String>>> businessTypes() {
        List<Map<String, String>> types = java.util.Arrays.asList(
                typeMap("TIMESHEET", "工时审批"),
                typeMap("CONTRACT", "合同审批"),
                typeMap("INVOICE", "发票审批"),
                typeMap("COST", "费用审批"),
                typeMap("LEAVE", "请假审批"),
                typeMap("OVERTIME", "加班审批")
        );
        return Result.success(types);
    }

    private Map<String, String> typeMap(String code, String name) {
        Map<String, String> m = new HashMap<>();
        m.put("code", code);
        m.put("name", name);
        return m;
    }
}
