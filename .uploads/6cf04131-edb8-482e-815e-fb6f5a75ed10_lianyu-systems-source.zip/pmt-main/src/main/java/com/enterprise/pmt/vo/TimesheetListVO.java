package com.enterprise.pmt.vo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class TimesheetListVO implements Serializable {
    private Long id;
    private String timesheetCode;
    private String userName;
    private LocalDate weekStartDate;
    private LocalDate weekEndDate;
    private BigDecimal totalHours;
    private String timesheetStatus;
    private String approvalStatus;
}
