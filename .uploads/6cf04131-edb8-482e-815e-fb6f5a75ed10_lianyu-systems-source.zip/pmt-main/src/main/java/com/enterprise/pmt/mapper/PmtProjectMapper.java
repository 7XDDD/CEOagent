package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.dto.ProjectQueryDTO;
import com.enterprise.pmt.entity.PmtProject;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtProjectMapper extends BaseMapper<PmtProject> {

    Page<PmtProject> selectPageList(Page<PmtProject> page, @Param("query") ProjectQueryDTO query);

    List<PmtProject> selectListByCondition(@Param("query") ProjectQueryDTO query);

    List<PmtProject> selectAllActive();

    /**
     * 查询所有启用项目的 ID（用于数据权限"全部项目"总开关展开）
     */
    List<Long> selectAllActiveIds();

    /**
     * 查询所有有效项目，可按数据权限范围过滤
     * @param projectIds null=不过滤(全部)；空列表=无权限(返回空)；非空=限定ID范围
     */
    List<PmtProject> selectAllActiveWithScope(@Param("projectIds") List<Long> projectIds);

    List<PmtProject> selectMyProjects(@Param("userId") Long userId);

    PmtProject findByCode(@Param("projectCode") String projectCode);

    PmtProject findByName(@Param("projectName") String projectName);

    int countByCode(@Param("projectCode") String projectCode, @Param("excludeId") Long excludeId);

    int softDeleteById(@Param("id") Long id);

    int softDeleteByIds(@Param("ids") List<Long> ids);

    List<PmtProject> selectByParentId(@Param("parentId") Long parentId);
}
