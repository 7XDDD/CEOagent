package com.enterprise.pmt.controller.system;

import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.annotation.OperationLog.OperationType;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.dto.system.PermissionCreateDTO;
import com.enterprise.pmt.dto.system.PermissionUpdateDTO;
import com.enterprise.pmt.entity.Permission;
import com.enterprise.pmt.service.PermissionService;
import com.enterprise.pmt.vo.system.PermissionVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "系统管理-权限管理")
@RestController
@RequestMapping("/system/permission")
public class PermissionController {

    @Autowired
    private PermissionService permissionService;

    @ApiOperation("获取权限树")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:permission:view')")
    @GetMapping("/tree")
    public Result<List<PermissionVO>> tree(@RequestParam(required = false) String systemType) {
        return Result.success(permissionService.tree(systemType));
    }

    @ApiOperation("获取所有权限列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:permission:view')")
    @GetMapping("/list")
    public Result<List<Permission>> list() {
        return Result.success(permissionService.listAll());
    }

    @ApiOperation("获取权限详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:permission:view')")
    @GetMapping("/{id}")
    public Result<Permission> getDetail(@PathVariable Long id) {
        return Result.success(permissionService.getDetail(id));
    }

    @ApiOperation("新增权限")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:permission:create')")
    @OperationLog(module = "权限管理", description = "新增权限", type = OperationType.INSERT)
    @PostMapping
    public Result<?> create(@Validated @RequestBody PermissionCreateDTO dto) {
        permissionService.create(dto);
        return Result.success("创建成功");
    }

    @ApiOperation("修改权限")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:permission:update')")
    @OperationLog(module = "权限管理", description = "修改权限", type = OperationType.UPDATE)
    @PutMapping("/{id}")
    public Result<?> update(@PathVariable Long id, @RequestBody PermissionUpdateDTO dto) {
        permissionService.update(id, dto);
        return Result.success("修改成功");
    }

    @ApiOperation("删除权限")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:permission:delete')")
    @OperationLog(module = "权限管理", description = "删除权限", type = OperationType.DELETE)
    @DeleteMapping("/{id:\\d+}")
    public Result<?> delete(@PathVariable Long id) {
        permissionService.delete(id);
        return Result.success("删除成功");
    }
}
