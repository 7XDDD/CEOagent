package com.enterprise.pmt.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
public class ManpowerBudgetDetailVO {

    private Long projectId;

    private String projectCode;

    private String projectName;

    private String pmName;

    private String status;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate plannedStartDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate plannedEndDate;

    /** 项目预算工时（天） */
    private BigDecimal budgetDays;

    /** 人力预算金额 */
    private BigDecimal budgetLaborAmount;

    /** 已分配工时（天） */
    private BigDecimal allocatedDays;

    /** 已用工时（小时） */
    private BigDecimal usedHours;

    /** 未结算工时（小时） */
    private BigDecimal unsettledHours;

    private List<ManpowerBudgetMemberVO> members;
}
