package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.PmtMilestone;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtMilestoneMapper extends BaseMapper<PmtMilestone> {

    Page<PmtMilestone> selectPageList(Page<PmtMilestone> page,
                                      @Param("projectId") Long projectId,
                                      @Param("contractId") Long contractId,
                                      @Param("keyword") String keyword,
                                      @Param("milestoneStatus") String milestoneStatus);

    List<PmtMilestone> selectByContractId(@Param("contractId") Long contractId);

    List<PmtMilestone> selectByProjectId(@Param("projectId") Long projectId);

    int softDeleteById(@Param("id") Long id);
}
