package com.enterprise.pmt.controller;

import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.service.DataScopeService;
import com.enterprise.pmt.service.ManpowerBudgetService;
import com.enterprise.pmt.vo.ManpowerBudgetDetailVO;
import com.enterprise.pmt.vo.ManpowerBudgetOverviewVO;
import com.enterprise.pmt.vo.MonthlyBudgetVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Api(tags = "人力工时预算")
@RestController
@RequestMapping("/manpower-budget")
public class ManpowerBudgetController {

    private final ManpowerBudgetService manpowerBudgetService;
    private final DataScopeService dataScopeService;

    public ManpowerBudgetController(ManpowerBudgetService manpowerBudgetService,
                                    DataScopeService dataScopeService) {
        this.manpowerBudgetService = manpowerBudgetService;
        this.dataScopeService = dataScopeService;
    }

    @ApiOperation("跨项目人力工时预算总览")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:manpower:view')")
    @GetMapping("/overview")
    public Result<List<ManpowerBudgetOverviewVO>> overview(@RequestParam(required = false) String keyword,
                                                           @RequestParam(required = false) String status,
                                                           @RequestParam(required = false) String projectType,
                                                           @RequestParam(required = false) Long pmId) {
        List<Long> projectIds = getDataScopeProjectIds();
        return Result.success(manpowerBudgetService.overview(keyword, status, projectType, pmId, projectIds));
    }

    @ApiOperation("单项目人力工时预算详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:manpower:view')")
    @GetMapping("/projects/{projectId}")
    public Result<ManpowerBudgetDetailVO> detail(@PathVariable Long projectId) {
        dataScopeService.checkAccess(DataScopeService.RESOURCE_PROJECT, projectId, DataScopeService.ACTION_VIEW);
        return Result.success(manpowerBudgetService.detail(projectId));
    }

    @ApiOperation("单项目分月预算vs实际")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:manpower:view')")
    @GetMapping("/projects/{projectId}/monthly")
    public Result<List<MonthlyBudgetVO>> monthly(@PathVariable Long projectId) {
        dataScopeService.checkAccess(DataScopeService.RESOURCE_PROJECT, projectId, DataScopeService.ACTION_VIEW);
        return Result.success(manpowerBudgetService.monthly(projectId));
    }

    @ApiOperation("更新项目总预算工时")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:manpower:update')")
    @PutMapping("/projects/{projectId}/budget")
    @OperationLog("更新项目人力工时预算")
    public Result<Void> updateProjectBudget(@PathVariable Long projectId,
                                            @RequestBody Map<String, Object> body) {
        dataScopeService.checkAccess(DataScopeService.RESOURCE_PROJECT, projectId, DataScopeService.ACTION_EDIT);
        BigDecimal budgetDays = parseBigDecimal(body.get("budgetDays"));
        BigDecimal budgetLaborAmount = parseBigDecimal(body.get("budgetLaborAmount"));
        manpowerBudgetService.updateProjectBudget(projectId, budgetDays, budgetLaborAmount);
        return Result.success();
    }

    @ApiOperation("更新成员预计工时")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:manpower:update')")
    @PutMapping("/members/{memberId}/budget")
    @OperationLog("更新成员人力工时预算")
    public Result<Void> updateMemberBudget(@PathVariable Long memberId,
                                           @RequestBody Map<String, Object> body) {
        BigDecimal budgetDays = parseBigDecimal(body.get("budgetDays"));
        manpowerBudgetService.updateMemberBudget(memberId, budgetDays);
        return Result.success();
    }

    // ==================== 权限 ====================

    private List<Long> getDataScopeProjectIds() {
        return dataScopeService.getViewableProjectIds();
    }

    private BigDecimal parseBigDecimal(Object value) {
        if (value == null) return null;
        String str = value.toString().trim();
        if (str.isEmpty()) return null;
        return new BigDecimal(str);
    }
}
