package com.enterprise.pmt.security;

import java.util.List;
import java.util.Map;

public class LoginUser {
    private Long userId;
    private String username;
    private Long orgId;
    private List<String> roles;
    private List<String> permissions;
    private List<Map<String, Object>> menuTree;

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public Long getOrgId() { return orgId; }
    public void setOrgId(Long orgId) { this.orgId = orgId; }
    public List<String> getRoles() { return roles; }
    public void setRoles(List<String> roles) { this.roles = roles; }
    public List<String> getPermissions() { return permissions; }
    public void setPermissions(List<String> permissions) { this.permissions = permissions; }
    public List<Map<String, Object>> getMenuTree() { return menuTree; }
    public void setMenuTree(List<Map<String, Object>> menuTree) { this.menuTree = menuTree; }

    public List<org.springframework.security.core.GrantedAuthority> getAuthorities() {
        return permissions != null ? 
            permissions.stream()
                .map(p -> new org.springframework.security.core.authority.SimpleGrantedAuthority(p))
                .collect(java.util.stream.Collectors.toList()) :
            java.util.Collections.emptyList();
    }
}
