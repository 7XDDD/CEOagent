package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.PmtCostBudget;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtCostBudgetMapper extends BaseMapper<PmtCostBudget> {

    Page<PmtCostBudget> selectPageList(Page<PmtCostBudget> page,
                                       @Param("projectId") Long projectId,
                                       @Param("keyword") String keyword,
                                       @Param("budgetStatus") String budgetStatus);

    List<PmtCostBudget> selectListByProjectId(@Param("projectId") Long projectId);

    Long countAll();

    java.math.BigDecimal sumTotalBudget();

    java.math.BigDecimal sumMonthlyBudget(@Param("year") int year, @Param("month") int month);
}
