package com.enterprise.pmt.approval.resolver;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 审批人解析器注册中心
 * 自动注入所有ApproverResolver实现，根据approverType分发
 */
@Component
public class ApproverResolverRegistry {

    private final Map<String, ApproverResolver> resolverMap = new HashMap<>();

    @Autowired
    public ApproverResolverRegistry(List<ApproverResolver> resolvers) {
        for (ApproverResolver resolver : resolvers) {
            resolverMap.put(resolver.getSupportedType(), resolver);
        }
    }

    public ApproverResolver getResolver(String approverType) {
        return resolverMap.get(approverType);
    }

    public boolean hasResolver(String approverType) {
        return resolverMap.containsKey(approverType);
    }
}
