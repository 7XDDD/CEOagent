package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.PmtSettlementOrder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtSettlementOrderMapper extends BaseMapper<PmtSettlementOrder> {

    Page<PmtSettlementOrder> selectPageList(Page<PmtSettlementOrder> page,
                                            @Param("batchId") Long batchId,
                                            @Param("projectId") Long projectId,
                                            @Param("keyword") String keyword,
                                            @Param("orderStatus") String orderStatus);

    List<PmtSettlementOrder> selectListByProjectId(@Param("projectId") Long projectId);
}
