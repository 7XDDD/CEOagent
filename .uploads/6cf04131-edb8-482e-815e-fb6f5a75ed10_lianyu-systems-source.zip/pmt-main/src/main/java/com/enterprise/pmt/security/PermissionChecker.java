package com.enterprise.pmt.security;

import com.enterprise.pmt.common.SecurityContextUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 接口权限校验器
 * <p>
 * 供 {@code @PreAuthorize("@permissionChecker.hasPermission('pmt:xxx:yyy')")} 调用。
 * <ul>
 *   <li>超级管理员 PMT_ADMIN / userId=1 直接放行</li>
 *   <li>校验当前用户 JWT 中携带的权限码列表</li>
 *   <li>支持通配符：用户拥有 {@code pmt:project:*} 时可通过 {@code pmt:project:view} 等子权限</li>
 * </ul>
 */
@Slf4j
@Component("permissionChecker")
public class PermissionChecker {

    private static final String ADMIN_ROLE = "PMT_ADMIN";
    private static final String WILDCARD = "*";

    /**
     * 判断当前用户是否拥有指定权限码
     */
    public boolean hasPermission(String permission) {
        if (permission == null || permission.isEmpty()) {
            return true;
        }
        if (isAdmin()) {
            return true;
        }
        List<String> permissions = SecurityContextUtil.getCurrentPermissions();
        if (permissions == null || permissions.isEmpty()) {
            return false;
        }
        for (String p : permissions) {
            if (matches(p, permission)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判断当前用户是否拥有任意一个权限码
     */
    public boolean hasAnyPermission(String... permissions) {
        if (permissions == null || permissions.length == 0) {
            return true;
        }
        if (isAdmin()) {
            return true;
        }
        for (String p : permissions) {
            if (hasPermission(p)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 判断当前用户是否拥有指定角色
     */
    public boolean hasRole(String role) {
        return SecurityContextUtil.hasRole(role);
    }

    private boolean isAdmin() {
        Long userId = SecurityContextUtil.getCurrentUserId();
        if (userId != null && userId == 1L) {
            return true;
        }
        return SecurityContextUtil.hasRole(ADMIN_ROLE);
    }

    /**
     * 权限码匹配：支持精确匹配和通配符
     * 例如 pmt:project:* 匹配 pmt:project:view/create/update
     */
    private boolean matches(String granted, String required) {
        if (granted == null) return false;
        if (granted.equalsIgnoreCase(required)) return true;
        // 通配符匹配：pmt:project:*
        if (granted.endsWith(":" + WILDCARD)) {
            String prefix = granted.substring(0, granted.length() - WILDCARD.length()); // pmt:project:
            if (required.startsWith(prefix)) {
                String tail = required.substring(prefix.length());
                // 不允许跨模块匹配，tail 不能包含冒号
                return !tail.contains(":") && !tail.isEmpty();
            }
        }
        return false;
    }
}
