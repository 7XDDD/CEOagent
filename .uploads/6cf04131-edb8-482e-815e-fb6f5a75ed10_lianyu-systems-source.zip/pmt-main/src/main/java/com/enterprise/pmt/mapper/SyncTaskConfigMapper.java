package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.SyncTaskConfig;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SyncTaskConfigMapper extends BaseMapper<SyncTaskConfig> {
}
