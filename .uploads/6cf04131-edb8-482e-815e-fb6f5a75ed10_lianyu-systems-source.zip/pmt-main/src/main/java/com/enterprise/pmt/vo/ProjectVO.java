package com.enterprise.pmt.vo;

import com.enterprise.pmt.entity.PmtProjectMember;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ProjectVO implements Serializable {
    private Long id;
    private Long parentId;
    private String parentProjectCode;
    private String parentProjectName;
    private String projectPath;
    private String projectCode;
    private String projectName;
    private String projectType;
    private String projectLevel;
    private Long signedCompanyId;
    private String signedCompany;
    private Long customerId;
    private String customerCode;
    private String customerName;
    // 客户关联信息（从客户子表关联查询）
    private String customerAddress;
    private String customerContact;
    private String customerContactPhone;
    private String customerFollower;
    private Long pmId;
    private String pmName;
    private Long salesId;
    private String salesName;
    private Long orgId;
    private String orgCode;
    private String orgName;
    private Long managerId;
    private String managerName;
    private Long departmentId;
    private String departmentName;
    private String priority;
    private String projectStatus;
    private String status;
    private LocalDate plannedStartDate;
    private LocalDate plannedEndDate;
    private LocalDate actualStartDate;
    private LocalDate actualEndDate;
    private BigDecimal plannedDays;
    private BigDecimal actualDays;
    private BigDecimal estimatedWorkDays;
    private BigDecimal budgetAmount;
    private BigDecimal budgetLaborAmount;
    private BigDecimal budgetExpenseAmount;
    private BigDecimal contractAmount;
    private BigDecimal estimatedCost;
    private BigDecimal actualCost;
    private BigDecimal actualLaborCost;
    private BigDecimal actualExpenseCost;
    private BigDecimal costVariance;
    private BigDecimal costVarianceRate;
    private Integer progress;
    private String currentMilestone;
    private LocalDate signDate;
    private String projectAddress;
    private String description;
    private String businessBackground;
    private String technicalRequirements;
    private String deliverables;
    private String remark;
    private Long createdBy;
    private Long createBy;
    private Long updatedBy;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
    private List<PmtProjectMember> members;

    // 工时统计字段
    /** 正常工时（小时）= 总工时 - 周末工时（加班） */
    private BigDecimal normalWorkHours;
    /** 加班工时（小时，周末填写的工时） */
    private BigDecimal overtimeWorkHours;
    /** 请假工时（小时，暂用0，待请假模块对接） */
    private BigDecimal leaveWorkHours;
    /** 总工时（小时） */
    private BigDecimal totalWorkHours;
}
