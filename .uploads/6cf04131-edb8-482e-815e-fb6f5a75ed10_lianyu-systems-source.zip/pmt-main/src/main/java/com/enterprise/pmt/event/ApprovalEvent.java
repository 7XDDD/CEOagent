package com.enterprise.pmt.event;

import com.enterprise.pmt.entity.ApprovalInstance;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * 审批动作事件基类
 * 审批引擎不直接调用业务Service，通过Spring Event通知业务方
 * 业务方只需监听对应事件即可，实现完全解耦
 */
@Getter
public abstract class ApprovalEvent extends ApplicationEvent {

    protected final ApprovalInstance instance;
    protected final String businessType;
    protected final Long businessId;
    protected final String businessStatus;
    protected final Long operatorId;
    protected final String operatorName;
    protected final String remark;

    public ApprovalEvent(Object source, ApprovalInstance instance, String businessStatus,
                         Long operatorId, String operatorName, String remark) {
        super(source);
        this.instance = instance;
        this.businessType = instance.getBusinessType();
        this.businessId = instance.getBusinessId();
        this.businessStatus = businessStatus;
        this.operatorId = operatorId;
        this.operatorName = operatorName;
        this.remark = remark;
    }

    /**
     * 审批通过事件（单个节点通过，流程可能未结束）
     */
    @Getter
    public static class Approved extends ApprovalEvent {
        private final boolean complete;
        private final Integer nodeOrder;

        public Approved(Object source, ApprovalInstance instance, String businessStatus,
                        Long operatorId, String operatorName, String remark,
                        boolean complete, Integer nodeOrder) {
            super(source, instance, businessStatus, operatorId, operatorName, remark);
            this.complete = complete;
            this.nodeOrder = nodeOrder;
        }
    }

    /**
     * 审批驳回事件
     */
    public static class Rejected extends ApprovalEvent {
        public Rejected(Object source, ApprovalInstance instance, String businessStatus,
                        Long operatorId, String operatorName, String remark) {
            super(source, instance, businessStatus, operatorId, operatorName, remark);
        }
    }

    /**
     * 审批撤回事件
     */
    public static class Withdrawn extends ApprovalEvent {
        public Withdrawn(Object source, ApprovalInstance instance, String businessStatus,
                         Long operatorId, String operatorName, String remark) {
            super(source, instance, businessStatus, operatorId, operatorName, remark);
        }
    }

    /**
     * 审批流程完成事件（所有节点通过）
     */
    public static class Completed extends ApprovalEvent {
        public Completed(Object source, ApprovalInstance instance, String businessStatus,
                         Long operatorId, String operatorName, String remark) {
            super(source, instance, businessStatus, operatorId, operatorName, remark);
        }
    }
}
