package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.dto.PageQueryDTO;
import com.enterprise.pmt.entity.PmtPaymentUnit;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtPaymentUnitMapper extends BaseMapper<PmtPaymentUnit> {

    Page<PmtPaymentUnit> selectPageList(Page<PmtPaymentUnit> page, @Param("query") PageQueryDTO query, @Param("contractId") Long contractId);

    List<PmtPaymentUnit> selectByContractId(@Param("contractId") Long contractId);
}
