package com.enterprise.pmt.vo;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * 员工在指定日期范围内可填报的项目及时间段信息（用于工时默认值计算）
 */
@Data
public class MemberPeriodProjectVO {
    private Long memberId;
    private Long projectId;
    private String projectCode;
    private String projectName;
    private Long periodId;
    private LocalDate plannedJoinDate;
    private LocalDate plannedLeaveDate;
    private LocalDate actualJoinDate;
    private LocalDate actualLeaveDate;
    private BigDecimal workloadRatio;
    private BigDecimal estimatedWorkDays;
    private Integer isActive;
    /** 项目成员工时性质：SETTLE=结算，NON_SETTLE=不结算 */
    private String workNature;
}
