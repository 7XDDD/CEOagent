package com.enterprise.pmt.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.dto.ContractQueryDTO;
import com.enterprise.pmt.entity.PmtContract;
import com.enterprise.pmt.entity.PmtContractLine;
import com.enterprise.pmt.service.ContractService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

@Api(tags = "合同管理")
@RestController
@RequestMapping("/contracts")
public class ContractController {

    private final ContractService contractService;

    public ContractController(ContractService contractService) {
        this.contractService = contractService;
    }

    @ApiOperation("分页查询合同(GET)")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:contract:view')")
    @GetMapping("/page")
    public Result<Page<PmtContract>> pageGet(@RequestParam(defaultValue = "1") Integer pageNum,
                                             @RequestParam(defaultValue = "10") Integer pageSize,
                                             @RequestParam(required = false) String keyword,
                                             @RequestParam(required = false) Long projectId,
                                             @RequestParam(required = false) Long customerId,
                                             @RequestParam(required = false) String contractStatus,
                                             @RequestParam(required = false) String contractType) {
        ContractQueryDTO queryDTO = new ContractQueryDTO();
        queryDTO.setPageNum(pageNum);
        queryDTO.setPageSize(pageSize);
        queryDTO.setKeyword(keyword);
        queryDTO.setProjectId(projectId);
        queryDTO.setCustomerId(customerId);
        queryDTO.setContractStatus(contractStatus);
        queryDTO.setContractType(contractType);
        return Result.success(contractService.pageList(queryDTO));
    }

    @ApiOperation("分页查询合同")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:contract:view')")
    @PostMapping("/page")
    public Result<Page<PmtContract>> page(@RequestBody ContractQueryDTO queryDTO) {
        return Result.success(contractService.pageList(queryDTO));
    }

    @ApiOperation("获取合同详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:contract:view')")
    @GetMapping("/{id:\\d+}")
    public Result<PmtContract> getDetail(@PathVariable Long id) {
        return Result.success(contractService.getDetail(id));
    }

    @ApiOperation("获取所有有效合同")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:contract:view')")
    @GetMapping("/list")
    public Result<List<PmtContract>> listAll() {
        return Result.success(contractService.listAll());
    }

    @ApiOperation("获取合同行")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:contract:view')")
    @GetMapping("/{id}/lines")
    public Result<List<PmtContractLine>> getLines(@PathVariable Long id) {
        return Result.success(contractService.getContractLines(id));
    }

    @ApiOperation("创建合同")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:contract:create')")
    @PostMapping
    @OperationLog("创建合同")
    @Transactional(rollbackFor = Exception.class)
    public Result<Long> create(@RequestBody PmtContract contract) {
        return Result.success(contractService.createContract(contract));
    }

    @ApiOperation("更新合同")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:contract:update')")
    @PutMapping("/{id}")
    @OperationLog("更新合同")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> update(@PathVariable Long id, @RequestBody PmtContract contract) {
        return Result.success(contractService.updateContract(id, contract));
    }

    @ApiOperation("删除合同")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:contract:delete')")
    @DeleteMapping("/{id}")
    @OperationLog("删除合同")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> delete(@PathVariable Long id) {
        return Result.success(contractService.deleteContract(id));
    }

    @ApiOperation("导出合同")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:contract:export')")
    @PostMapping("/export")
    @OperationLog("导出合同")
    public void export(@RequestBody(required = false) ContractQueryDTO queryDTO, HttpServletResponse response) throws Exception {
        contractService.exportContracts(queryDTO, response);
    }

    @ApiOperation("下载合同导入模板")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:contract:import')")
    @GetMapping("/import-template")
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        contractService.downloadImportTemplate(response);
    }

    @ApiOperation("导入合同")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:contract:import')")
    @PostMapping("/import-excel")
    @OperationLog("导入合同")
    public Result<Map<String, Object>> importExcel(@RequestParam("file") MultipartFile file) {
        Map<String, Object> result = contractService.importExcel(file);
        int inserted = (int) result.getOrDefault("inserted", 0);
        int updated = (int) result.getOrDefault("updated", 0);
        int failed = (int) result.getOrDefault("failed", 0);
        String msg = "导入完成，新增 " + inserted + " 条，更新 " + updated + " 条，失败 " + failed + " 条";
        return Result.success(msg, result);
    }
}
