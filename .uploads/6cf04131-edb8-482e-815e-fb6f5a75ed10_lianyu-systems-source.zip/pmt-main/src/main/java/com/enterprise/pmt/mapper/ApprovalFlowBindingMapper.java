package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.ApprovalFlowBinding;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ApprovalFlowBindingMapper extends BaseMapper<ApprovalFlowBinding> {

    /**
     * 根据业务类型和上下文查找最合适的流程绑定
     * 按优先级匹配：PROJECT > DEPT > ORG > GLOBAL
     * 支持多项目绑定（scope_ids逗号分隔）
     */
    @Select("<script>" +
            "SELECT * FROM pmt_approval_flow_binding " +
            "WHERE business_type = #{businessType} AND enabled = 1 AND deleted = 0 " +
            "AND (" +
            "  (scope_type = 'PROJECT' AND (scope_id = #{projectId} OR FIND_IN_SET(#{projectId}, scope_ids) > 0)) " +
            "  OR (scope_type = 'DEPT' AND scope_id = #{deptId}) " +
            "  OR (scope_type = 'ORG' AND scope_id = #{orgId}) " +
            "  OR (scope_type = 'GLOBAL')" +
            ") " +
            "ORDER BY priority DESC, " +
            "  CASE scope_type " +
            "    WHEN 'PROJECT' THEN 1 " +
            "    WHEN 'DEPT' THEN 2 " +
            "    WHEN 'ORG' THEN 3 " +
            "    WHEN 'GLOBAL' THEN 4 " +
            "    ELSE 9 END ASC, " +
            "  id ASC " +
            "LIMIT 1" +
            "</script>")
    ApprovalFlowBinding findBestMatching(
            @Param("businessType") String businessType,
            @Param("projectId") Long projectId,
            @Param("deptId") Long deptId,
            @Param("orgId") Long orgId);

    @Select("SELECT * FROM pmt_approval_flow_binding WHERE business_type = #{businessType} AND enabled = 1 AND deleted = 0 ORDER BY priority DESC")
    List<ApprovalFlowBinding> selectByBusinessType(@Param("businessType") String businessType);

    @Select("<script>" +
            "SELECT * FROM pmt_approval_flow_binding " +
            "WHERE scope_type = #{scopeType} AND enabled = 1 AND deleted = 0 " +
            "AND (scope_id = #{scopeId} OR FIND_IN_SET(#{scopeId}, scope_ids) > 0)" +
            "</script>")
    List<ApprovalFlowBinding> selectByScope(@Param("scopeType") String scopeType, @Param("scopeId") Long scopeId);

    /**
     * 批量查询指定流程的【项目级】工时审批绑定（scope_type=PROJECT），用于主管可见域预计算。
     */
    @Select("<script>" +
            "SELECT id, flow_id, scope_id, scope_ids FROM pmt_approval_flow_binding " +
            "WHERE business_type = 'TIMESHEET' AND scope_type = 'PROJECT' AND enabled = 1 AND deleted = 0 " +
            "AND flow_id IN " +
            "<foreach collection='flowIds' item='fid' open='(' separator=',' close=')'>#{fid}</foreach>" +
            "</script>")
    List<ApprovalFlowBinding> selectProjectBindingsByFlowIds(@Param("flowIds") List<Long> flowIds);
}
