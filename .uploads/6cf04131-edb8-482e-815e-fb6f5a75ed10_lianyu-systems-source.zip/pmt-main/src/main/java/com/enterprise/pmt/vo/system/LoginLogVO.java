package com.enterprise.pmt.vo.system;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class LoginLogVO {
    private Long id;
    private Long userId;
    private String username;
    private String realName;
    private String loginType;
    private String ip;
    private String ipLocation;
    private String browser;
    private String os;
    private Integer status;
    private String msg;
    private String loginResult;
    private String failReason;
    private String clientIp;
    private String userAgent;
    private String requestPath;
    private Long responseTimeMs;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime loginTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
}
