package com.enterprise.pmt.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.SecurityContextUtil;
import com.enterprise.pmt.dto.*;
import com.enterprise.pmt.entity.PmtSettlementBatch;
import com.enterprise.pmt.entity.PmtTimesheet;
import com.enterprise.pmt.entity.PmtTimesheetApprovalLog;
import com.enterprise.pmt.entity.PmtTimesheetItem;
import com.enterprise.pmt.entity.User;
import com.enterprise.pmt.mapper.PmtSettlementBatchMapper;
import com.enterprise.pmt.mapper.UserMapper;
import com.enterprise.pmt.service.ApprovalInstanceService;
import com.enterprise.pmt.service.TimesheetService;
import com.enterprise.pmt.vo.ApprovalNodeVO;
import com.enterprise.pmt.vo.TimesheetVO;
import com.enterprise.pmt.vo.TimesheetWeekDefaultsVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Api(tags = "工时管理（PC端）")
@RestController
@RequestMapping("/timesheets")
public class TimesheetController {

    private final TimesheetService timesheetService;
    private final UserMapper userMapper;
    private final PmtSettlementBatchMapper settlementBatchMapper;
    private final ApprovalInstanceService approvalInstanceService;

    public TimesheetController(TimesheetService timesheetService, UserMapper userMapper,
                               PmtSettlementBatchMapper settlementBatchMapper,
                               ApprovalInstanceService approvalInstanceService) {
        this.timesheetService = timesheetService;
        this.userMapper = userMapper;
        this.settlementBatchMapper = settlementBatchMapper;
        this.approvalInstanceService = approvalInstanceService;
    }

    /**
     * 安全地将请求体中的ids转换为List<Long>。
     * Jackson反序列化JSON小数字时可能返回Integer而非Long，直接强转List<Long>会导致ClassCastException。
     */
    @SuppressWarnings("unchecked")
    private List<Long> toLongList(Object obj) {
        if (obj == null) return null;
        if (obj instanceof List) {
            return ((List<Object>) obj).stream()
                    .filter(e -> e != null)
                    .map(e -> Long.valueOf(e.toString()))
                    .collect(Collectors.toList());
        }
        return null;
    }

    @ApiOperation("分页查询工时单(GET)")
    // 除工时查看权限本身外，放行「结算管理查看(settlement:view)」——结算页已/未结算工时分页必须拉此接口；
    // 同时放行「审批人(timesheet:approve)」「异常管理员(timesheet:anomaly-manage)」「工时管理员(timesheet:manage)」「导出角色」，避免出现 UI 上有入口但接口 403。
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:view','pmt:settlement:view','pmt:timesheet:approve','pmt:timesheet:manage','pmt:timesheet:anomaly-manage','pmt:settlement:export','pmt:settlement:stats')")
    @GetMapping("/page")
    public Result<Page<TimesheetVO>> pageGet(@RequestParam(defaultValue = "1") Integer pageNum,
                                             @RequestParam(defaultValue = "10") Integer pageSize,
                                             @RequestParam(required = false) String keyword,
                                             @RequestParam(required = false) String status,
                                             @RequestParam(required = false) String approvalStatus,
                                             @RequestParam(required = false) Long projectId) {
        TimesheetQueryDTO queryDTO = new TimesheetQueryDTO();
        queryDTO.setPageNum(pageNum);
        queryDTO.setPageSize(pageSize);
        queryDTO.setKeyword(keyword);
        queryDTO.setTimesheetStatus(status);
        queryDTO.setApprovalStatus(approvalStatus);
        queryDTO.setProjectId(projectId);
        return Result.success(timesheetService.pageList(queryDTO));
    }

    @ApiOperation("分页查询工时单")
    // 与 GET /page 保持一致：结算查看/审批/异常管理/工时管理/导出/统计都能拉工时列表
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:view','pmt:settlement:view','pmt:timesheet:approve','pmt:timesheet:manage','pmt:timesheet:anomaly-manage','pmt:settlement:export','pmt:settlement:stats')")
    @PostMapping("/page")
    public Result<Page<TimesheetVO>> page(@RequestBody TimesheetQueryDTO queryDTO) {
        return Result.success(timesheetService.pageList(queryDTO));
    }

    @ApiOperation("获取工时单详情（本人可查看自己的，审批人可查看待审批的）")
    @GetMapping("/{id:\\d+}")
    public Result<TimesheetVO> getDetail(@PathVariable Long id) {
        return Result.success(timesheetService.getDetail(id));
    }

    @ApiOperation("获取当前周工时（按项目拆分多张单，返回列表）")
    @GetMapping("/current")
    public Result<List<TimesheetVO>> getCurrent(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekStartDate) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(timesheetService.getWeekTimesheets(userId, weekStartDate));
    }

    @ApiOperation("我的工时列表(分页)")
    @GetMapping("/my-list")
    public Result<Page<TimesheetVO>> myList(@RequestParam(defaultValue = "1") Integer pageNum,
                                            @RequestParam(defaultValue = "10") Integer pageSize,
                                            @RequestParam(required = false) String status,
                                            @RequestParam(required = false) @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE) java.time.LocalDate weekStartDate) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        TimesheetQueryDTO queryDTO = new TimesheetQueryDTO();
        queryDTO.setPageNum(pageNum);
        queryDTO.setPageSize(pageSize);
        queryDTO.setUserId(userId);
        queryDTO.setApprovalStatus(status);
        queryDTO.setWeekStartDate(weekStartDate);
        return Result.success(timesheetService.pageList(queryDTO));
    }

    @ApiOperation("我的工时单")
    @GetMapping("/my")
    public Result<List<TimesheetVO>> myTimesheets() {
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(timesheetService.myTimesheets(userId));
    }

    @ApiOperation("待审批列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:approve')")
    @GetMapping("/pending-approval")
    public Result<Page<TimesheetVO>> pendingApproval(@RequestParam(defaultValue = "1") Integer pageNum,
                                                     @RequestParam(defaultValue = "10") Integer pageSize,
                                                     @RequestParam(required = false) String keyword,
                                                     @RequestParam(required = false) Long projectId,
                                                     @RequestParam(required = false) @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE) java.time.LocalDate startDate,
                                                     @RequestParam(required = false) @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE) java.time.LocalDate endDate) {
        TimesheetQueryDTO queryDTO = new TimesheetQueryDTO();
        queryDTO.setPageNum(pageNum);
        queryDTO.setPageSize(pageSize);
        queryDTO.setApprovalStatus("PENDING");
        queryDTO.setKeyword(keyword);
        queryDTO.setProjectId(projectId);
        queryDTO.setStartDate(startDate);
        queryDTO.setEndDate(endDate);
        queryDTO.setApproverId(SecurityContextUtil.getCurrentUserId());
        queryDTO.setStrictApprovalScope(true);
        return Result.success(timesheetService.pageList(queryDTO));
    }

    @ApiOperation("已审批列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:approve')")
    @GetMapping("/approved-list")
    public Result<Page<TimesheetVO>> approvedList(@RequestParam(defaultValue = "1") Integer pageNum,
                                                  @RequestParam(defaultValue = "10") Integer pageSize,
                                                  @RequestParam(required = false) String keyword,
                                                  @RequestParam(required = false) Long projectId,
                                                  @RequestParam(required = false) @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE) java.time.LocalDate startDate,
                                                  @RequestParam(required = false) @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE) java.time.LocalDate endDate) {
        TimesheetQueryDTO queryDTO = new TimesheetQueryDTO();
        queryDTO.setPageNum(pageNum);
        queryDTO.setPageSize(pageSize);
        queryDTO.setApprovalStatus("APPROVED");
        queryDTO.setKeyword(keyword);
        queryDTO.setProjectId(projectId);
        queryDTO.setStartDate(startDate);
        queryDTO.setEndDate(endDate);
        queryDTO.setApproverId(SecurityContextUtil.getCurrentUserId());
        queryDTO.setStrictApprovalScope(true);
        return Result.success(timesheetService.pageList(queryDTO));
    }

    @ApiOperation("保存工时单（草稿，按项目拆分）")
    @PostMapping("/save")
    @OperationLog("保存工时单")
    public Result<Long> save(@RequestBody TimesheetSaveDTO saveDTO) {
        saveDTO.setSource("PC");
        return Result.success(timesheetService.saveTimesheet(saveDTO));
    }

    @ApiOperation("保存并提交工时单（按项目拆分后批量提交）")
    @PostMapping("/save-and-submit")
    @OperationLog("保存并提交工时单")
    public Result<List<Long>> saveAndSubmit(@RequestBody TimesheetSaveDTO saveDTO) {
        saveDTO.setSource("PC");
        Long firstId = timesheetService.saveTimesheet(saveDTO);
        Long userId = SecurityContextUtil.getCurrentUserId();
        List<Long> submittedIds = timesheetService.submitTimesheetByWeek(userId, saveDTO.getWeekStartDate());
        return Result.success(submittedIds);
    }

    @ApiOperation("提交单个工时单")
    @PostMapping("/{id}/submit")
    @OperationLog("提交工时单")
    public Result<Boolean> submit(@PathVariable Long id) {
        return Result.success(timesheetService.submitTimesheet(id));
    }

    @ApiOperation("批量提交某周所有工时单")
    @PostMapping("/submit-week")
    @OperationLog("批量提交工时")
    public Result<List<Long>> submitWeek(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekStartDate) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(timesheetService.submitTimesheetByWeek(userId, weekStartDate));
    }

    @ApiOperation("撤回工时单")
    @PostMapping("/{id}/withdraw")
    @OperationLog("撤回工时单")
    public Result<Boolean> withdraw(@PathVariable Long id) {
        return Result.success(timesheetService.withdrawTimesheet(id));
    }

    @ApiOperation("审批通过工时单")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:approve')")
    @PostMapping("/{id}/approve")
    @OperationLog("审批通过工时单")
    public Result<Boolean> approve(@PathVariable Long id,
                                   @RequestBody(required = false) Map<String, Object> body,
                                   @RequestParam(required = false) String comment) {
        String actualComment = comment;
        if (body != null && body.get("comment") != null) {
            actualComment = body.get("comment").toString();
        }
        TimesheetApprovalDTO approvalDTO = new TimesheetApprovalDTO();
        approvalDTO.setRemark(actualComment);
        return Result.success(timesheetService.approveTimesheet(id, approvalDTO));
    }

    @ApiOperation("驳回工时单")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:reject')")
    @PostMapping("/{id}/reject")
    @OperationLog("驳回工时单")
    public Result<Boolean> reject(@PathVariable Long id,
                                  @RequestBody(required = false) Map<String, Object> body,
                                  @RequestParam(required = false) String comment) {
        String actualComment = comment;
        if (body != null && body.get("comment") != null) {
            actualComment = body.get("comment").toString();
        }
        TimesheetApprovalDTO approvalDTO = new TimesheetApprovalDTO();
        approvalDTO.setRemark(actualComment);
        return Result.success(timesheetService.rejectTimesheet(id, approvalDTO));
    }

    @ApiOperation("获取工时明细")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:view')")
    @GetMapping("/{id}/items")
    public Result<List<PmtTimesheetItem>> getItems(@PathVariable Long id) {
        return Result.success(timesheetService.getTimesheetItems(id));
    }

    @ApiOperation("获取审批历史")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:view')")
    @GetMapping("/{id}/approvals")
    public Result<List<PmtTimesheetApprovalLog>> getApprovals(@PathVariable Long id) {
        return Result.success(timesheetService.getApprovalHistory(id));
    }

    @ApiOperation("最近工时记录")
    @GetMapping("/recent")
    public Result<List<Map<String, Object>>> recent(@RequestParam(defaultValue = "10") int limit) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(timesheetService.recentTimesheets(userId, limit));
    }

    @ApiOperation("获取指定周可填报项目及每日默认工时（根据项目成员投入占比自动计算）")
    @GetMapping("/week-defaults")
    public Result<TimesheetWeekDefaultsVO> weekDefaults(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekStartDate) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(timesheetService.getWeekDefaults(userId, weekStartDate));
    }

    @ApiOperation("预览工时审批链（提交前查看审批节点和审批人）")
    @GetMapping("/preview-approval-chain")
    public Result<List<ApprovalNodeVO>> previewApprovalChain(@RequestParam(required = false) Long projectId) {
        return Result.success(approvalInstanceService.previewApprovalNodes("TIMESHEET", projectId));
    }

    @ApiOperation("获取某周某用户的异常数量（提交前提醒用）")
    @GetMapping("/week-anomalies-count")
    public Result<Map<String, Object>> weekAnomaliesCount(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekStartDate) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        List<TimesheetVO> sheets = timesheetService.myTimesheets(userId).stream()
                .filter(vo -> weekStartDate.equals(vo.getWeekStartDate()))
                .collect(java.util.stream.Collectors.toList());
        int totalOpen = 0;
        for (TimesheetVO v : sheets) {
            if (v.getAnomalyCount() != null) totalOpen += v.getAnomalyCount();
        }
        java.util.Map<String, Object> result = new java.util.HashMap<>();
        result.put("timesheetCount", sheets.size());
        result.put("openAnomalyCount", totalOpen);
        result.put("hasAnomaly", totalOpen > 0);
        return Result.success(result);
    }

    @ApiOperation("手动消除单个异常")
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:anomaly-resolve','pmt:timesheet:anomaly-manage')")
    @PostMapping("/anomalies/{anomalyId}/resolve")
    @OperationLog("消除工时异常")
    public Result<Boolean> resolveAnomaly(@PathVariable Long anomalyId,
                                          @RequestBody(required = false) Map<String, Object> body) {
        String remark = body == null ? null : (body.get("remark") == null ? null : body.get("remark").toString());
        return Result.success(timesheetService.resolveAnomaly(anomalyId, remark));
    }

    @ApiOperation("批量消除某工时单所有异常")
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:anomaly-resolve','pmt:timesheet:anomaly-manage')")
    @PostMapping("/{id}/anomalies/resolve-all")
    @OperationLog("批量消除工时异常")
    public Result<Integer> resolveAllAnomalies(@PathVariable Long id,
                                               @RequestBody(required = false) Map<String, Object> body) {
        String remark = body == null ? null : (body.get("remark") == null ? null : body.get("remark").toString());
        Long userId = SecurityContextUtil.getCurrentUserId();
        User u = userMapper.selectById(userId);
        String name = u == null ? null : u.getRealName();
        return Result.success(timesheetService.resolveAllAnomalies(id, userId, name, remark));
    }

    // ==================== PM工时管理API ====================

    @ApiOperation("PM工时管理列表（分页，支持日期范围/项目/状态/异常过滤）")
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:view','pmt:timesheet:manage')")
    @GetMapping("/manage/list")
    public Result<Page<TimesheetVO>> manageList(@RequestParam(defaultValue = "1") Integer pageNum,
                                                @RequestParam(defaultValue = "20") Integer pageSize,
                                                @RequestParam(required = false) String keyword,
                                                @RequestParam(required = false) String status,
                                                @RequestParam(required = false) Long projectId,
                                                @RequestParam(required = false) String anomalyFilter,
                                                @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                                                @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        TimesheetQueryDTO queryDTO = new TimesheetQueryDTO();
        queryDTO.setPageNum(pageNum);
        queryDTO.setPageSize(pageSize);
        queryDTO.setKeyword(keyword);
        queryDTO.setApprovalStatus(status);
        queryDTO.setProjectId(projectId);
        queryDTO.setAnomalyFilter(anomalyFilter);
        queryDTO.setStartDate(startDate);
        queryDTO.setEndDate(endDate);
        queryDTO.setExcludeDraft(true);
        queryDTO.setStrictApprovalScope(true);
        return Result.success(timesheetService.pageList(queryDTO));
    }

    @ApiOperation("批量锁定工时单（APPROVED→LOCKED）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:lock')")
    @PostMapping("/batch-lock")
    @OperationLog("批量锁定工时")
    public Result<Integer> batchLock(@RequestBody Map<String, Object> body) {
        @SuppressWarnings("unchecked")
        List<Long> ids = toLongList(body.get("ids"));
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(timesheetService.batchLock(ids, userId));
    }

    @ApiOperation("批量解锁工时单（LOCKED→APPROVED），已结算的不可解锁")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:lock')")
    @PostMapping("/batch-unlock")
    @OperationLog("批量解锁工时")
    public Result<Integer> batchUnlock(@RequestBody Map<String, Object> body) {
        @SuppressWarnings("unchecked")
        List<Long> ids = toLongList(body.get("ids"));
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(timesheetService.batchUnlock(ids, userId));
    }

    @ApiOperation("按项目+周锁定")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:lock')")
    @PostMapping("/lock-by-project-week")
    @OperationLog("按项目周锁定工时")
    public Result<Integer> lockByProjectAndWeek(@RequestParam Long projectId,
                                                @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekStartDate) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(timesheetService.lockByProjectAndWeek(projectId, weekStartDate, userId));
    }

    @ApiOperation("批量审批通过")
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:approve','pmt:timesheet:batch-approve')")
    @PostMapping("/batch-approve")
    @OperationLog("批量审批通过工时")
    public Result<Integer> batchApprove(@RequestBody Map<String, Object> body) {
        @SuppressWarnings("unchecked")
        List<Long> ids = toLongList(body.get("ids"));
        String remark = body.get("remark") == null ? null : body.get("remark").toString();
        Long userId = SecurityContextUtil.getCurrentUserId();
        User u = userMapper.selectById(userId);
        return Result.success(timesheetService.batchApprove(ids, userId, u == null ? null : u.getRealName(), remark));
    }

    @ApiOperation("批量驳回")
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:reject','pmt:timesheet:batch-reject')")
    @PostMapping("/batch-reject")
    @OperationLog("批量驳回工时")
    public Result<Integer> batchReject(@RequestBody Map<String, Object> body) {
        @SuppressWarnings("unchecked")
        List<Long> ids = toLongList(body.get("ids"));
        String remark = body.get("remark") == null ? null : body.get("remark").toString();
        Long userId = SecurityContextUtil.getCurrentUserId();
        User u = userMapper.selectById(userId);
        return Result.success(timesheetService.batchReject(ids, userId, u == null ? null : u.getRealName(), remark));
    }

    @ApiOperation("批量异常检查（重新检测）")
    @PostMapping("/batch-check-anomalies")
    @OperationLog("批量检查工时异常")
    public Result<Integer> batchCheckAnomalies(@RequestBody Map<String, Object> body) {
        @SuppressWarnings("unchecked")
        List<Long> ids = toLongList(body.get("ids"));
        return Result.success(timesheetService.batchCheckAnomalies(ids));
    }

    @ApiOperation("查询可结算工时单（LOCKED状态，未结算）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:view')")
    @GetMapping("/settleable")
    public Result<List<PmtTimesheet>> settleable(@RequestParam(required = false) Long projectId,
                                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                                                 @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return Result.success(timesheetService.getSettleableSheets(projectId, startDate, endDate));
    }

    // ==================== PM工时统计报表API ====================

    @ApiOperation("按项目统计工时")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:view')")
    @GetMapping("/stats/by-project")
    public Result<List<Map<String, Object>>> statsByProject(
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return Result.success(timesheetService.statsByProject(projectId, startDate, endDate));
    }

    @ApiOperation("按员工统计工时")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:view')")
    @GetMapping("/stats/by-user")
    public Result<List<Map<String, Object>>> statsByUser(
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return Result.success(timesheetService.statsByUser(projectId, startDate, endDate));
    }

    @ApiOperation("按周统计工时")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:view')")
    @GetMapping("/stats/by-week")
    public Result<List<Map<String, Object>>> statsByWeek(
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return Result.success(timesheetService.statsByWeek(projectId, startDate, endDate));
    }

    @ApiOperation("工时结算：创建结算批次并将LOCKED工时单标记为已结算")
    // 支持两种权限：旧版 pmt:timesheet:settle（工时模块内结算）、新版 pmt:settlement:settle（结算管理页面批量结算）
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:settle','pmt:settlement:settle')")
    @PostMapping("/settle")
    @OperationLog("工时结算")
    public Result<Map<String, Object>> settle(@RequestBody Map<String, Object> body) {
        Long projectId = body.get("projectId") != null ? Long.valueOf(body.get("projectId").toString()) : null;
        LocalDate startDate = body.get("startDate") != null ? LocalDate.parse(body.get("startDate").toString()) : null;
        LocalDate endDate = body.get("endDate") != null ? LocalDate.parse(body.get("endDate").toString()) : null;
        String batchName = body.get("batchName") != null ? body.get("batchName").toString() : null;
        String remark = body.get("remark") != null ? body.get("remark").toString() : null;

        List<PmtTimesheet> sheets = timesheetService.getSettleableSheets(projectId, startDate, endDate);
        if (sheets == null || sheets.isEmpty()) {
            return Result.error("没有可结算的工时单（需为已锁定状态）");
        }

        List<Long> ids = sheets.stream().map(PmtTimesheet::getId).collect(Collectors.toList());
        Long userId = SecurityContextUtil.getCurrentUserId();
        User u = userMapper.selectById(userId);

        // 创建结算批次
        PmtSettlementBatch batch = new PmtSettlementBatch();
        batch.setBatchNo("ST" + DateTimeFormatter.ofPattern("yyyyMMdd").format(LocalDate.now())
                + String.format("%04d", (int) (Math.random() * 10000)));
        batch.setBatchName(batchName != null ? batchName : "工时结算-" + LocalDate.now().toString());
        batch.setBatchType("TIMESHEET");
        batch.setBatchStatus("SETTLED");
        batch.setProjectId(projectId);
        batch.setStartDate(startDate);
        batch.setEndDate(endDate);
        BigDecimal totalHours = sheets.stream()
                .map(PmtTimesheet::getTotalHours)
                .filter(h -> h != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        batch.setTotalWorkDays(totalHours.divide(BigDecimal.valueOf(8), 2, RoundingMode.HALF_UP));
        batch.setTotalAmount(BigDecimal.ZERO);
        batch.setCreatorId(userId);
        batch.setCreatorName(u != null ? u.getRealName() : null);
        batch.setRemark(remark);
        settlementBatchMapper.insert(batch);

        // 批量标记已结算
        int count = timesheetService.batchMarkSettled(ids, batch.getId(), userId);

        Map<String, Object> result = new HashMap<>();
        result.put("batchId", batch.getId());
        result.put("batchNo", batch.getBatchNo());
        result.put("settledCount", count);
        result.put("totalHours", totalHours);
        result.put("totalDays", batch.getTotalWorkDays());
        return Result.success(result);
    }

    @ApiOperation("PM工时管理统计")
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:view','pmt:timesheet:manage')")
    @GetMapping("/manage/stats")
    public Result<Map<String, Object>> manageStats(@RequestParam(required = false) Long projectId,
                                                   @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
                                                   @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        return Result.success(timesheetService.getManageStats(projectId, startDate, endDate));
    }
    
    @ApiOperation("导出工时数据")
    // 工时模块导出(pmt:timesheet:export) / 结算管理导出(pmt:settlement:export) 均可
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:export','pmt:settlement:export')")
    @PostMapping("/export")
    @OperationLog("导出工时数据")
    public void export(@RequestBody(required = false) TimesheetQueryDTO queryDTO, HttpServletResponse response) throws Exception {
        timesheetService.exportTimesheets(queryDTO, response);
    }
    
    @ApiOperation("下载工时导入模板")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:import')")
    @GetMapping("/import-template")
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        timesheetService.downloadImportTemplate(response);
    }
    
    @ApiOperation("导入工时Excel")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:import')")
    @PostMapping("/import-excel")
    @OperationLog("导入工时数据")
    public Result<Map<String, Object>> importExcel(@RequestParam("file") MultipartFile file) {
        Map<String, Object> result = timesheetService.importExcel(file);
        int inserted = (int) result.getOrDefault("inserted", 0);
        int updated = (int) result.getOrDefault("updated", 0);
        int failed = (int) result.getOrDefault("failed", 0);
        String msg = "导入完成，新增 " + inserted + " 条，更新 " + updated + " 条，失败 " + failed + " 条";
        return Result.success(msg, result);
    }

    // ===== 工时结算相关接口 =====

    @ApiOperation("查询可结算工时单（已审批且未结算）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:view')")
    @GetMapping("/settle-available")
    public Result<Page<TimesheetVO>> settleAvailable(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        TimesheetQueryDTO dto = new TimesheetQueryDTO();
        dto.setPageNum(pageNum);
        dto.setPageSize(pageSize);
        dto.setProjectId(projectId);
        dto.setKeyword(keyword);
        dto.setStartDate(startDate);
        dto.setEndDate(endDate);
        dto.setApprovalStatus("LOCKED");
        dto.setSettlementStatus(0);
        dto.setSettleOnly(true);
        Page<TimesheetVO> page = timesheetService.pageList(dto);
        return Result.success(page);
    }

    @ApiOperation("查询某结算批次下的工时单")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:view')")
    @GetMapping("/settle-batch-items")
    public Result<Page<TimesheetVO>> settleBatchItems(
            @RequestParam Long batchId,
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) Long projectId,
            @RequestParam(required = false) String keyword) {
        TimesheetQueryDTO dto = new TimesheetQueryDTO();
        dto.setPageNum(pageNum);
        dto.setPageSize(pageSize);
        dto.setSettlementBatchId(batchId);
        dto.setProjectId(projectId);
        dto.setKeyword(keyword);
        Page<TimesheetVO> page = timesheetService.pageList(dto);
        return Result.success(page);
    }

    @ApiOperation("批量结算工时（将已审批工时加入结算批次）")
    // 支持两种权限：旧版 pmt:timesheet:settle（工时模块内结算）、新版 pmt:settlement:settle（结算管理页面批量结算）
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:settle','pmt:settlement:settle')")
    @PostMapping("/batch-settle")
    @OperationLog("批量结算工时")
    public Result<Integer> batchSettle(@RequestBody Map<String, Object> body) {
        List<Long> ids = toLongList(body.get("ids"));
        Long batchId = body.get("batchId") == null ? null : Long.valueOf(body.get("batchId").toString());
        if (ids == null || ids.isEmpty()) {
            return Result.success(0);
        }
        int count = timesheetService.batchSettle(ids, batchId);
        return Result.success(count);
    }

    @ApiOperation("取消结算（将已结算工时恢复为已审批）")
    // 同时接受结算模块「取消结算」权限（前端菜单分配：pmt:settlement:cancel-settle）与工时模块旧权限（pmt:timesheet:settle），保持前后端一致与历史兼容
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:settlement:cancel-settle','pmt:timesheet:settle')")
    @PostMapping("/cancel-settle")
    @OperationLog("取消工时结算")
    public Result<Integer> cancelSettle(@RequestBody Map<String, Object> body) {
        List<Long> ids = toLongList(body.get("ids"));
        if (ids == null || ids.isEmpty()) {
            return Result.success(0);
        }
        int count = timesheetService.cancelSettle(ids);
        return Result.success(count);
    }

    @ApiOperation("按月份创建结算批次并结算该月所有已审批工时")
    // 支持两种权限：旧版 pmt:timesheet:settle（工时模块内结算）、新版 pmt:settlement:settle（结算管理页面按月份结算）
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:timesheet:settle','pmt:settlement:settle')")
    @PostMapping("/settle-by-month")
    @OperationLog("按月结算工时")
    public Result<Map<String, Object>> settleByMonth(@RequestBody Map<String, Object> body) {
        String month = (String) body.get("month"); // yyyy-MM
        String batchName = (String) body.get("batchName");
        Long projectId = body.get("projectId") == null ? null : Long.valueOf(body.get("projectId").toString());
        if (month == null || month.isEmpty()) {
            return Result.error("请选择结算月份");
        }
        if (projectId == null) {
            return Result.error("请选择结算项目");
        }
        Map<String, Object> result = timesheetService.settleByMonth(month, batchName, projectId);
        return Result.success(result);
    }
}
