package com.enterprise.pmt.common;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ResultCode {

    SUCCESS(200, "操作成功"),
    ERROR(500, "系统错误"),

    UNAUTHORIZED(401, "未授权或认证失败"),
    FORBIDDEN(403, "没有权限访问"),
    LOGIN_FAIL(1001, "用户名或密码错误"),
    USER_NOT_EXIST(1002, "用户不存在"),
    ACCOUNT_LOCKED(1003, "账号已锁定"),
    TOKEN_EXPIRED(1004, "登录已过期，请重新登录"),
    TOKEN_INVALID(1005, "Token无效"),

    PARAM_ERROR(2000, "参数错误"),
    PARAM_MISSING(2001, "参数缺失"),
    PARAM_FORMAT_ERROR(2002, "参数格式错误"),
    VALIDATE_FAILED(2003, "参数校验失败"),

    DATA_NOT_FOUND(3000, "数据不存在"),
    DATA_DUPLICATE(3001, "数据已存在"),
    DATA_IN_USE(3002, "数据被引用，无法删除"),
    DATA_OPERATION_FAILED(3003, "数据操作失败"),
    DATA_VERSION_OUTDATED(3004, "数据版本已过期，请刷新后重试");

    private final Integer code;
    private final String message;
}
