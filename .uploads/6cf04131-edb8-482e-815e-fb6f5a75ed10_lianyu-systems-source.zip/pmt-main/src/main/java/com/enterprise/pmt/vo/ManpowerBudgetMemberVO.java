package com.enterprise.pmt.vo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ManpowerBudgetMemberVO {

    private Long memberId;

    private String memberName;

    private String jobNumber;

    private String roleInProject;

    /** 工时性质：SETTLE / NON_SETTLE */
    private String workNature;

    /** 成员预算工时（天） */
    private BigDecimal budgetDays;

    /** 已用工时（小时，截至当天已审批） */
    private BigDecimal usedHours;

    /** 阶段周期数 */
    private Integer periodCount;
}
