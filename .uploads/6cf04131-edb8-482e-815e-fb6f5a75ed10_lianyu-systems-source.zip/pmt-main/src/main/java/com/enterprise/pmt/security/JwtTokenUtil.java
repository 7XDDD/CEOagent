package com.enterprise.pmt.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
public class JwtTokenUtil {

    @Value("${pmt.security.jwt.secret}")
    private String secret;

    @Value("${pmt.security.jwt.expiration}")
    private Long expiration;

    @Value("${pmt.security.jwt.header}")
    private String header;

    @Value("${pmt.security.jwt.prefix}")
    private String prefix;

    private SecretKey getSecretKey() {
        byte[] keyBytes = secret.getBytes(StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    public String generateToken(Long userId, String username, Long orgId,
                                List<String> roles, List<String> permissions) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("userId", userId);
        claims.put("username", username);
        claims.put("orgId", orgId);
        if (roles != null && !roles.isEmpty()) {
            claims.put("roles", String.join(",", roles));
        }
        if (permissions != null && !permissions.isEmpty()) {
            claims.put("permissions", String.join(",", permissions));
        }

        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + expiration * 1000);

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(username)
                .setIssuedAt(now)
                .setExpiration(expiryDate)
                .signWith(getSecretKey(), SignatureAlgorithm.HS512)
                .compact();
    }

    public String generateToken(Long userId, String username, Long orgId, List<String> roles) {
        return generateToken(userId, username, orgId, roles, Collections.emptyList());
    }

    public String generateToken(Long userId, String username) {
        return generateToken(userId, username, null, Collections.singletonList("ROLE_USER"), Collections.emptyList());
    }

    public Claims parseToken(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(getSecretKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    public Claims getClaimsFromToken(String token) {
        try {
            return parseToken(token);
        } catch (Exception e) {
            log.warn("解析JWT Token失败: {}", e.getMessage());
            return null;
        }
    }

    public String getUsernameFromToken(String token) {
        Claims claims = getClaimsFromToken(token);
        return claims != null ? claims.getSubject() : null;
    }

    public Long getUserIdFromToken(String token) {
        Claims claims = getClaimsFromToken(token);
        if (claims != null) {
            Object userId = claims.get("userId");
            return userId != null ? Long.valueOf(userId.toString()) : null;
        }
        return null;
    }

    public Long getOrgIdFromToken(String token) {
        Claims claims = getClaimsFromToken(token);
        if (claims != null) {
            Object orgId = claims.get("orgId");
            return orgId != null ? Long.valueOf(orgId.toString()) : null;
        }
        return null;
    }

    public List<String> getRolesFromToken(String token) {
        Claims claims = getClaimsFromToken(token);
        if (claims != null) {
            Object roles = claims.get("roles");
            if (roles != null && roles.toString().length() > 0) {
                return Arrays.stream(roles.toString().split(","))
                        .map(String::trim)
                        .filter(s -> s.length() > 0)
                        .collect(Collectors.toList());
            }
        }
        return Collections.emptyList();
    }

    public List<String> getPermissionsFromToken(String token) {
        Claims claims = getClaimsFromToken(token);
        if (claims != null) {
            Object permissions = claims.get("permissions");
            if (permissions != null && permissions.toString().length() > 0) {
                return Arrays.stream(permissions.toString().split(","))
                        .map(String::trim)
                        .filter(s -> s.length() > 0)
                        .collect(Collectors.toList());
            }
        }
        return Collections.emptyList();
    }

    public Boolean validateToken(String token) {
        try {
            Claims claims = getClaimsFromToken(token);
            if (claims == null) {
                return false;
            }
            Date expiration = claims.getExpiration();
            return expiration.after(new Date());
        } catch (Exception e) {
            log.warn("Token验证失败: {}", e.getMessage());
            return false;
        }
    }

    public String getHeader() {
        return header;
    }

    public String getPrefix() {
        return prefix;
    }
}
