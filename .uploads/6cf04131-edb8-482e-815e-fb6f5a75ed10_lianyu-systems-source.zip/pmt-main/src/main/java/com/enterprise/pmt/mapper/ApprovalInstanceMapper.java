package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.ApprovalInstance;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface ApprovalInstanceMapper extends BaseMapper<ApprovalInstance> {

    @Select("SELECT * FROM pmt_approval_instance WHERE business_type = #{businessType} AND business_id = #{businessId} AND deleted = 0 ORDER BY id DESC LIMIT 1")
    ApprovalInstance selectByBusiness(@Param("businessType") String businessType, @Param("businessId") Long businessId);
}
