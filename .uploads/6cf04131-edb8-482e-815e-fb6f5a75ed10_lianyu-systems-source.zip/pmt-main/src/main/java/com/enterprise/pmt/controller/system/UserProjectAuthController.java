package com.enterprise.pmt.controller.system;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.annotation.OperationLog.OperationType;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.entity.PmtProject;
import com.enterprise.pmt.entity.PmtProjectManager;
import com.enterprise.pmt.entity.PmtProjectMember;
import com.enterprise.pmt.entity.User;
import com.enterprise.pmt.mapper.PmtProjectManagerMapper;
import com.enterprise.pmt.mapper.PmtProjectMapper;
import com.enterprise.pmt.mapper.PmtProjectMemberMapper;
import com.enterprise.pmt.mapper.UserMapper;
import com.enterprise.pmt.vo.UserProjectAuthVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 用户项目数据权限管理
 * <p>
 * 以项目为单位配置用户数据范围：
 * <ul>
 *   <li>普通成员（pmt_project_member）：默认只能看自己的数据</li>
 *   <li>项目管理人员（pmt_project_manager）：can_view_all=1 可看项目内所有成员数据</li>
 * </ul>
 * 功能权限（菜单/按钮/接口）由系统角色控制，与此处的数据范围正交。
 */
@Api(tags = "系统管理-用户项目数据权限")
@RestController
@RequestMapping("/system/user-project-auth")
@RequiredArgsConstructor
public class UserProjectAuthController {

    private final UserMapper userMapper;
    private final PmtProjectMapper projectMapper;
    private final PmtProjectMemberMapper projectMemberMapper;
    private final PmtProjectManagerMapper projectManagerMapper;

    @ApiOperation("查询用户的项目数据权限列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:assign-data')")
    @GetMapping("/list")
    public Result<List<UserProjectAuthVO>> list(@RequestParam Long userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            return Result.error("用户不存在");
        }

        // 所有有效项目
        List<PmtProject> projects = projectMapper.selectAllActive();

        // 用户参与的项目ID集合
        Set<Long> memberProjectIds = new HashSet<>(
                safeList(projectMemberMapper.selectMemberProjectIds(userId)));

        // 用户在 pmt_project_manager 中的记录（含 manager_type='PM' + project_id=0 的“全部项目”虚拟行）
        LambdaQueryWrapper<PmtProjectManager> pmWrapper = new LambdaQueryWrapper<>();
        pmWrapper.eq(PmtProjectManager::getUserId, userId)
                 .eq(PmtProjectManager::getManagerType, "PM")
                 .eq(PmtProjectManager::getDeleted, 0);
        List<PmtProjectManager> pmList = projectManagerMapper.selectList(pmWrapper);
        Map<Long, PmtProjectManager> pmMap = pmList.stream()
                .collect(Collectors.toMap(PmtProjectManager::getProjectId, p -> p, (a, b) -> a));

        List<UserProjectAuthVO> result = new ArrayList<>();

        // 0) “全部项目（含未来新增）”虚拟行：project_id = 0
        PmtProjectManager pmAll = pmMap.get(0L);
        UserProjectAuthVO allRow = new UserProjectAuthVO();
        allRow.setProjectId(0L);
        allRow.setProjectCode("*");
        allRow.setProjectName("全部项目（包括未来新增的项目）");
        allRow.setCustomerName("-");
        allRow.setMember(false);
        allRow.setCanViewAll(pmAll != null && Integer.valueOf(1).equals(pmAll.getCanViewAll()));
        allRow.setCanEdit(pmAll != null && Integer.valueOf(1).equals(pmAll.getCanEdit()));
        allRow.setCanApprove(pmAll != null && Integer.valueOf(1).equals(pmAll.getCanApprove()));
        result.add(allRow);

        // 1) 普通项目行
        for (PmtProject p : projects) {
            UserProjectAuthVO vo = new UserProjectAuthVO();
            vo.setProjectId(p.getId());
            vo.setProjectCode(p.getProjectCode());
            vo.setProjectName(p.getProjectName());
            vo.setCustomerName(p.getCustomerName());
            vo.setMember(memberProjectIds.contains(p.getId()));
            PmtProjectManager pm = pmMap.get(p.getId());
            vo.setCanViewAll(pm != null && Integer.valueOf(1).equals(pm.getCanViewAll()));
            vo.setCanEdit(pm != null && Integer.valueOf(1).equals(pm.getCanEdit()));
            vo.setCanApprove(pm != null && Integer.valueOf(1).equals(pm.getCanApprove()));
            result.add(vo);
        }
        return Result.success(result);
    }

    @ApiOperation("保存用户的项目数据权限（全量覆盖）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:assign-data')")
    @OperationLog(module = "用户数据权限", description = "保存用户项目数据权限", type = OperationType.UPDATE)
    @Transactional(rollbackFor = Exception.class)
    @PostMapping("/save")
    public Result<?> save(@RequestBody SaveDTO dto) {
        Long userId = dto.getUserId();
        User user = userMapper.selectById(userId);
        if (user == null) {
            return Result.error("用户不存在");
        }

        // 1) 按 projectId 对前端传入的 grants 去重（防御重复提交导致唯一索引冲突）
        Map<Long, GrantItem> grantMap = new LinkedHashMap<>();
        StringBuilder trace = new StringBuilder("[user-project-auth save] userId=" + userId + " grants_incoming=" + (dto.getGrants() == null ? 0 : dto.getGrants().size()) + " [");
        if (dto.getGrants() != null) {
            for (GrantItem g : dto.getGrants()) {
                if (g == null || g.getProjectId() == null) continue;
                boolean hasAny = truthy(g.getCanViewAll()) || truthy(g.getCanEdit()) || truthy(g.getCanApprove());
                trace.append("{pid=").append(g.getProjectId()).append(",v=").append(g.getCanViewAll()).append(",e=").append(g.getCanEdit()).append(",a=").append(g.getCanApprove()).append("},");
                if (!hasAny) continue;
                grantMap.putIfAbsent(g.getProjectId(), g);
            }
        }
        trace.append("] grants_effective=").append(grantMap.keySet());
        System.out.println(trace.toString());

        // 2) 查询该用户当前所有 deleted=0 的 pmt_project_manager (manager_type 固定写为 PM)
        LambdaQueryWrapper<PmtProjectManager> existWrapper = new LambdaQueryWrapper<>();
        existWrapper.eq(PmtProjectManager::getUserId, userId)
                    .eq(PmtProjectManager::getManagerType, "PM")
                    .eq(PmtProjectManager::getDeleted, 0);
        List<PmtProjectManager> existList = projectManagerMapper.selectList(existWrapper);
        Map<Long, PmtProjectManager> existMap = existList.stream()
                .collect(Collectors.toMap(PmtProjectManager::getProjectId, p -> p, (a, b) -> a));

        // 3) 新增或更新 grantMap 中存在的记录
        for (Map.Entry<Long, GrantItem> e : grantMap.entrySet()) {
            Long projectId = e.getKey();
            GrantItem g = e.getValue();
            PmtProjectManager exist = existMap.get(projectId);
            int canViewAll = Boolean.TRUE.equals(g.getCanViewAll()) ? 1 : 0;
            int canEdit = Boolean.TRUE.equals(g.getCanEdit()) ? 1 : 0;
            int canApprove = Boolean.TRUE.equals(g.getCanApprove()) ? 1 : 0;

            if (exist != null) {
                // 字段没变跳过，避免不必要的 update
                if (Objects.equals(exist.getCanViewAll(), canViewAll)
                        && Objects.equals(exist.getCanEdit(), canEdit)
                        && Objects.equals(exist.getCanApprove(), canApprove)
                        && Integer.valueOf(1).equals(exist.getStatus())) {
                    continue;
                }
                PmtProjectManager upd = new PmtProjectManager();
                upd.setId(exist.getId());
                upd.setCanViewAll(canViewAll);
                upd.setCanEdit(canEdit);
                upd.setCanApprove(canApprove);
                upd.setStatus(1);
                int updRows = projectManagerMapper.updateById(upd);
                System.out.println("[user-project-auth save] UPDATE pid=" + projectId + " rowCount=" + updRows + " v=" + canViewAll + " e=" + canEdit + " a=" + canApprove);
            } else {
                PmtProjectManager pm = new PmtProjectManager();
                pm.setProjectId(projectId);
                pm.setUserId(userId);
                pm.setEmployeeId(user.getEmployeeId());
                pm.setJobNumber(user.getEmployeeNo());
                pm.setManagerType("PM");
                pm.setCanViewAll(canViewAll);
                pm.setCanEdit(canEdit);
                pm.setCanApprove(canApprove);
                pm.setStatus(1);
                int ins = projectManagerMapper.insert(pm);
                System.out.println("[user-project-auth save] INSERT pid=" + projectId + " rowCount=" + ins + " canViewAll=" + canViewAll + " pmId=" + pm.getId());
            }
        }

        // 4) 对于 existMap 中存在、但 grantMap 里没有的项目（意味着用户取消了授权），执行逻辑删除
        Set<Long> toDeleteIds = new HashSet<>();
        for (Map.Entry<Long, PmtProjectManager> e : existMap.entrySet()) {
            if (!grantMap.containsKey(e.getKey())) {
                toDeleteIds.add(e.getValue().getId());
            }
        }
        if (!toDeleteIds.isEmpty()) {
            // 自定义逻辑删除：SET deleted = 毫秒时间戳高位 + id 低位，
            // 规避 MP 默认 "SET deleted=id" 与已存在 deleted=N 旧记录撞唯一索引的问题
            int delRows = projectManagerMapper.logicDeleteByIds(toDeleteIds);
            System.out.println("[user-project-auth save] LOGIC_DELETE ids=" + toDeleteIds + " rowCount=" + delRows);
        }

        return Result.success("保存成功");
    }

    private <T> List<T> safeList(List<T> list) {
        return list == null ? Collections.emptyList() : list;
    }

    /** 兼容 Boolean 三种态：null/Boolean.FALSE 视作 false，其余（TRUE）视作 true。 */
    private static boolean truthy(Boolean b) {
        return Boolean.TRUE.equals(b);
    }

    // ---- DTO ----

    @lombok.Data
    public static class SaveDTO {
        private Long userId;
        private List<GrantItem> grants = new ArrayList<>();
    }

    @lombok.Data
    public static class GrantItem {
        private Long projectId;
        private Boolean canViewAll;
        private Boolean canEdit;
        private Boolean canApprove;
    }
}
