package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.dto.system.RoleQueryDTO;
import com.enterprise.pmt.entity.Role;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RoleMapper extends BaseMapper<Role> {

    @Select("SELECT r.* FROM pmt_role r INNER JOIN pmt_user_role ur ON r.id = ur.role_id WHERE ur.user_id = #{userId} AND r.deleted = 0")
    List<Role> findRolesByUserId(@Param("userId") Long userId);

    @Select("SELECT * FROM pmt_role WHERE role_code = #{roleCode} AND deleted = 0 LIMIT 1")
    Role findByRoleCode(@Param("roleCode") String roleCode);

    Page<Role> selectPageList(Page<Role> page, @Param("q") RoleQueryDTO query);

    List<Role> selectListByCondition(@Param("q") RoleQueryDTO query);
}
