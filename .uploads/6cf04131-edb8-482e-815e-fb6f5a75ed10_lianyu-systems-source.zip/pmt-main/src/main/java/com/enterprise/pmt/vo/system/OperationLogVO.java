package com.enterprise.pmt.vo.system;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class OperationLogVO {
    private Long id;
    private String systemType;
    private String module;
    private String description;
    @JsonIgnore
    private String type;
    private String requestMethod;
    private String username;
    private String realName;
    private String ip;
    private String requestUrl;
    private String requestParams;
    private String responseResult;
    private String errorMsg;
    @JsonIgnore
    private Long duration;
    private Integer status;
    private String method;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    /** 前端期望字段：操作人姓名 */
    public String getOperatorName() {
        if (realName != null && !realName.isEmpty()) return realName;
        return username;
    }

    /** 前端期望字段：操作类型（统一大写） */
    public String getOperationType() {
        if (type == null) return null;
        String t = type.toUpperCase();
        if ("INSERT".equals(t)) return "CREATE";
        return t;
    }

    /** 前端期望字段：耗时ms */
    public Long getCostTime() {
        return duration;
    }

    /** 状态文本 */
    public String getStatusText() {
        return status != null && status == 1 ? "成功" : "失败";
    }
}
