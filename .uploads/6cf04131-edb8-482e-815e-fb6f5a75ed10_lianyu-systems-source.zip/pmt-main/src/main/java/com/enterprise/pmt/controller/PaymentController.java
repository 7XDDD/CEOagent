package com.enterprise.pmt.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.common.BusinessException;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.ResultCode;
import com.enterprise.pmt.entity.PmtPaymentReceipt;
import com.enterprise.pmt.mapper.PmtPaymentReceiptMapper;
import com.enterprise.pmt.service.PaymentReceiptService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(tags = "回款管理")
@RestController
@RequestMapping("/payments")
public class PaymentController {

    private final PaymentReceiptService paymentReceiptService;
    private final PmtPaymentReceiptMapper receiptMapper;

    public PaymentController(PaymentReceiptService paymentReceiptService, PmtPaymentReceiptMapper receiptMapper) {
        this.paymentReceiptService = paymentReceiptService;
        this.receiptMapper = receiptMapper;
    }

    @ApiOperation("回款统计")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:payment:view')")
    @GetMapping("/stats")
    public Result<Map<String, Object>> stats() {
        Map<String, Object> data = new HashMap<>();
        try {
            data.put("totalCount", receiptMapper.countAll());
            data.put("totalAmount", receiptMapper.sumReceiptAmountCny());
            data.put("pendingCount", receiptMapper.countByStatus("PENDING"));
            data.put("receivedCount", receiptMapper.countByStatus("CONFIRMED"));
            LocalDate now = LocalDate.now();
            data.put("monthlyCount", receiptMapper.countMonthlyReceipts(now.getYear(), now.getMonthValue()));
            data.put("monthlyAmount", receiptMapper.sumMonthlyReceiptAmountCny(now.getYear(), now.getMonthValue()));
        } catch (Exception e) {
            data.put("totalCount", 0L);
            data.put("totalAmount", BigDecimal.ZERO);
            data.put("pendingCount", 0L);
            data.put("receivedCount", 0L);
            data.put("monthlyCount", 0L);
            data.put("monthlyAmount", BigDecimal.ZERO);
        }
        return Result.success(data);
    }

    @ApiOperation("分页查询回款(GET)")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:payment:view')")
    @GetMapping("/page")
    public Result<Page<PmtPaymentReceipt>> pageGet(@RequestParam(defaultValue = "1") int pageNum,
                                                   @RequestParam(defaultValue = "10") int pageSize,
                                                   @RequestParam(required = false) Long contractId,
                                                   @RequestParam(required = false) Long customerId,
                                                   @RequestParam(required = false) String keyword,
                                                   @RequestParam(required = false) String receiptStatus) {
        Page<PmtPaymentReceipt> page = new Page<>(pageNum, pageSize);
        return Result.success(receiptMapper.selectPageList(page, contractId, customerId, keyword, receiptStatus));
    }

    @ApiOperation("获取所有回款")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:payment:view')")
    @GetMapping("/list")
    public Result<List<PmtPaymentReceipt>> listAll(@RequestParam(required = false) Long contractId,
                                                   @RequestParam(required = false) Long customerId) {
        return Result.success(receiptMapper.selectListByCondition(contractId, customerId));
    }

    @ApiOperation("获取回款详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:payment:view')")
    @GetMapping("/{id:\\d+}")
    public Result<PmtPaymentReceipt> getDetail(@PathVariable Long id) {
        PmtPaymentReceipt receipt = receiptMapper.selectById(id);
        if (receipt == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        return Result.success(receipt);
    }

    @ApiOperation("创建回款")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:payment:create')")
    @PostMapping
    @OperationLog("创建回款")
    @Transactional(rollbackFor = Exception.class)
    public Result<Long> create(@RequestBody PmtPaymentReceipt receipt) {
        receiptMapper.insert(receipt);
        return Result.success(receipt.getId());
    }

    @ApiOperation("更新回款")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:payment:update')")
    @PutMapping("/{id}")
    @OperationLog("更新回款")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> update(@PathVariable Long id, @RequestBody PmtPaymentReceipt receipt) {
        PmtPaymentReceipt exist = receiptMapper.selectById(id);
        if (exist == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        receipt.setId(id);
        return Result.success(receiptMapper.updateById(receipt) > 0);
    }

    @ApiOperation("删除回款")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:payment:delete')")
    @DeleteMapping("/{id:\\d+}")
    @OperationLog("删除回款")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> delete(@PathVariable Long id) {
        PmtPaymentReceipt receipt = receiptMapper.selectById(id);
        if (receipt == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        receiptMapper.softDeleteById(id);
        return Result.success(true);
    }

    @ApiOperation("导出回款")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:payment:export')")
    @GetMapping("/export")
    @OperationLog("导出回款")
    public void export(HttpServletResponse response) throws Exception {
        paymentReceiptService.exportPayments(response);
    }

    @ApiOperation("下载回款导入模板")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:payment:import')")
    @GetMapping("/template")
    public void downloadTemplate(HttpServletResponse response) throws Exception {
        paymentReceiptService.downloadImportTemplate(response);
    }
}
