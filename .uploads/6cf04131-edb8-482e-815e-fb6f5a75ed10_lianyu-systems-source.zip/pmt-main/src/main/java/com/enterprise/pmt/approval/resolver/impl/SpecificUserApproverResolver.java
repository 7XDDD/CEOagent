package com.enterprise.pmt.approval.resolver.impl;

import com.enterprise.pmt.approval.resolver.ApproverResolver;
import com.enterprise.pmt.entity.ApprovalNode;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 指定用户审批人解析器
 */
@Component
public class SpecificUserApproverResolver implements ApproverResolver {

    @Override
    public String getSupportedType() {
        return "SPECIFIC_USER";
    }

    @Override
    public List<Long> resolveApproverIds(ApprovalNode node, Long applicantId, Long projectId, Long deptId) {
        String approverUserIds = node.getApproverUserIds();
        if (approverUserIds == null || approverUserIds.trim().isEmpty()) {
            return Collections.emptyList();
        }
        return Arrays.stream(approverUserIds.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .map(Long::parseLong)
                .collect(Collectors.toList());
    }
}
