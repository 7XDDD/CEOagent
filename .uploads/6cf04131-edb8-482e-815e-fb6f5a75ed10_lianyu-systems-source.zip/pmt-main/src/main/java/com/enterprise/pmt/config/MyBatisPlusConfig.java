package com.enterprise.pmt.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.OptimisticLockerInnerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyBatisPlusConfig {

    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        // 关闭 optimizeJoin：
        // 待审批/已审批等分页 SQL 含关联子查询与多个 EXISTS，
        // JSqlParser 解析此类 SQL 会回溯卡死 40s+；而 MySQL 对 COUNT(原SQL) 执行仅几毫秒，
        // 直接用原 SQL 包 COUNT 即可，无需解析优化。
        // 注意：MyBatis-Plus 3.5.3.1 无 setOptimizeCountSql 方法，COUNT 优化走默认 autoCountSql，
        // 解析失败时自动降级为 lowLevelCountSql（原SQL外包COUNT）。
        PaginationInnerInterceptor pagination = new PaginationInnerInterceptor(DbType.MYSQL);
        pagination.setOptimizeJoin(false);
        interceptor.addInnerInterceptor(pagination);
        interceptor.addInnerInterceptor(new OptimisticLockerInnerInterceptor());
        return interceptor;
    }
}
