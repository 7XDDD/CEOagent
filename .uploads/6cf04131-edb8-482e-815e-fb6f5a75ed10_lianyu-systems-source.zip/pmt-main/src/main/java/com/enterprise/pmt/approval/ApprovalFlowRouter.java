package com.enterprise.pmt.approval;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.enterprise.pmt.entity.ApprovalBusinessType;
import com.enterprise.pmt.entity.ApprovalFlow;
import com.enterprise.pmt.entity.ApprovalFlowBinding;
import com.enterprise.pmt.mapper.ApprovalBusinessTypeMapper;
import com.enterprise.pmt.mapper.ApprovalFlowBindingMapper;
import com.enterprise.pmt.mapper.ApprovalFlowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 统一审批流程路由器
 * 按优先级自动匹配最合适的审批流程：项目级 > 部门级 > 组织级 > 全局默认
 * 业务代码只需调用resolveFlow()，无需自己实现查找逻辑
 */
@Component
public class ApprovalFlowRouter {

    @Autowired
    private ApprovalFlowBindingMapper bindingMapper;

    @Autowired
    private ApprovalFlowMapper flowMapper;

    @Autowired
    private ApprovalBusinessTypeMapper businessTypeMapper;

    /**
     * 路由结果
     */
    public static class RouteResult {
        private final ApprovalFlow flow;
        private final ApprovalBusinessType businessType;
        private final String matchScope;

        public RouteResult(ApprovalFlow flow, ApprovalBusinessType businessType, String matchScope) {
            this.flow = flow;
            this.businessType = businessType;
            this.matchScope = matchScope;
        }

        public ApprovalFlow getFlow() { return flow; }
        public ApprovalBusinessType getBusinessType() { return businessType; }
        public String getMatchScope() { return matchScope; }
        public boolean isFound() { return flow != null; }
    }

    /**
     * 解析审批流程（核心入口）
     * @param businessTypeCode 业务类型编码（如TIMESHEET）
     * @param projectId 项目ID（可选）
     * @param deptId 部门ID（可选）
     * @param orgId 组织ID（可选）
     * @return 路由结果
     */
    public RouteResult resolveFlow(String businessTypeCode, Long projectId, Long deptId, Long orgId) {
        // 1. 验证业务类型已注册
        ApprovalBusinessType businessType = businessTypeMapper.selectByCode(businessTypeCode);
        if (businessType == null || businessType.getStatus() != 1) {
            return new RouteResult(null, null, "BUSINESS_TYPE_NOT_FOUND");
        }

        // 2. 按优先级查找绑定：PROJECT > DEPT > ORG > GLOBAL（必须配置，无兜底）
        ApprovalFlowBinding binding = bindingMapper.findBestMatching(businessTypeCode, projectId, deptId, orgId);
        
        if (binding != null) {
            ApprovalFlow flow = flowMapper.selectById(binding.getFlowId());
            if (flow != null && flow.getStatus() == 1 && (flow.getIsPublished() == null || flow.getIsPublished() == 1)) {
                return new RouteResult(flow, businessType, binding.getScopeType());
            }
        }

        // 无兜底：必须配置流程绑定，否则报错
        return new RouteResult(null, businessType, "NO_FLOW_BOUND");
    }

    /**
     * 简化入口：只传业务类型和项目ID
     */
    public RouteResult resolveFlow(String businessTypeCode, Long projectId) {
        return resolveFlow(businessTypeCode, projectId, null, null);
    }

    /**
     * 简化入口：只传业务类型
     */
    public RouteResult resolveFlow(String businessTypeCode) {
        return resolveFlow(businessTypeCode, null, null, null);
    }

    /**
     * 全局设置某业务类型的默认流程
     */
    public void setGlobalDefault(String businessTypeCode, Long flowId, Long operatorId) {
        setBinding(businessTypeCode, ApprovalFlowBinding.SCOPE_GLOBAL, null, flowId, 0, operatorId);
    }

    /**
     * 设置项目级流程
     */
    public void setProjectFlow(String businessTypeCode, Long projectId, Long flowId, Long operatorId) {
        setBinding(businessTypeCode, ApprovalFlowBinding.SCOPE_PROJECT, projectId, flowId, 100, operatorId);
    }

    /**
     * 设置部门级流程
     */
    public void setDeptFlow(String businessTypeCode, Long deptId, Long flowId, Long operatorId) {
        setBinding(businessTypeCode, ApprovalFlowBinding.SCOPE_DEPT, deptId, flowId, 50, operatorId);
    }

    private void setBinding(String businessTypeCode, String scopeType, Long scopeId, Long flowId, int priority, Long operatorId) {
        LambdaQueryWrapper<ApprovalFlowBinding> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ApprovalFlowBinding::getBusinessType, businessTypeCode)
               .eq(ApprovalFlowBinding::getScopeType, scopeType)
               .eq(scopeId != null, ApprovalFlowBinding::getScopeId, scopeId)
               .isNull(scopeId == null, ApprovalFlowBinding::getScopeId)
               .eq(ApprovalFlowBinding::getDeleted, 0);
        
        ApprovalFlowBinding existing = bindingMapper.selectOne(wrapper);
        if (existing != null) {
            existing.setFlowId(flowId);
            existing.setEnabled(1);
            existing.setUpdatedBy(operatorId);
            bindingMapper.updateById(existing);
        } else {
            ApprovalFlowBinding binding = new ApprovalFlowBinding();
            binding.setBusinessType(businessTypeCode);
            binding.setScopeType(scopeType);
            binding.setScopeId(scopeId);
            binding.setFlowId(flowId);
            binding.setPriority(priority);
            binding.setEnabled(1);
            binding.setCreatedBy(operatorId);
            binding.setUpdatedBy(operatorId);
            bindingMapper.insert(binding);
        }
    }

    /**
     * 设置绑定（支持scopeIds多项目）
     */
    private void setBindingWithScopeIds(String businessTypeCode, String scopeType, Long scopeId, String scopeIds, Long flowId, int priority, Long operatorId) {
        LambdaQueryWrapper<ApprovalFlowBinding> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(ApprovalFlowBinding::getBusinessType, businessTypeCode)
               .eq(ApprovalFlowBinding::getScopeType, scopeType)
               .eq(ApprovalFlowBinding::getDeleted, 0);

        if (org.springframework.util.StringUtils.hasText(scopeIds)) {
            wrapper.eq(ApprovalFlowBinding::getScopeIds, scopeIds);
        } else if (scopeId != null) {
            wrapper.eq(ApprovalFlowBinding::getScopeId, scopeId);
        } else {
            wrapper.isNull(ApprovalFlowBinding::getScopeId);
        }

        ApprovalFlowBinding existing = bindingMapper.selectOne(wrapper);
        if (existing != null) {
            existing.setFlowId(flowId);
            existing.setEnabled(1);
            existing.setScopeIds(scopeIds);
            existing.setUpdatedBy(operatorId);
            bindingMapper.updateById(existing);
        } else {
            ApprovalFlowBinding binding = new ApprovalFlowBinding();
            binding.setBusinessType(businessTypeCode);
            binding.setScopeType(scopeType);
            binding.setScopeId(scopeId);
            binding.setScopeIds(scopeIds);
            binding.setFlowId(flowId);
            binding.setPriority(priority);
            binding.setEnabled(1);
            binding.setCreatedBy(operatorId);
            binding.setUpdatedBy(operatorId);
            bindingMapper.insert(binding);
        }
    }

    /**
     * 设置多个项目的审批流程绑定
     */
    public void setProjectsFlow(String businessTypeCode, List<Long> projectIds, Long flowId, Long operatorId) {
        if (projectIds == null || projectIds.isEmpty()) return;
        String scopeIds = projectIds.stream().map(String::valueOf).reduce((a, b) -> a + "," + b).orElse("");
        Long firstId = projectIds.get(0);
        setBindingWithScopeIds(businessTypeCode, ApprovalFlowBinding.SCOPE_PROJECT, firstId, scopeIds, flowId, 100, operatorId);
    }
}
