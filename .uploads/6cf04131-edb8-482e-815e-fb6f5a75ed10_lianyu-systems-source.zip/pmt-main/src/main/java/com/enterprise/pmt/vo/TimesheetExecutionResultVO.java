package com.enterprise.pmt.vo;

import lombok.Data;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 工时执行状态：整体结果（矩阵+表头+汇总），整体一次返回给前端
 */
@Data
public class TimesheetExecutionResultVO {
    /** 表头：周列顺序 */
    private List<ExecutionWeekHeaderVO> weekHeaders;
    /** 数据行：员工-项目 粒度 */
    private List<ExecutionRowVO> rows;
    /** 分页元数据：总记录数、当前页、页大小（执行页默认全量） */
    private Long total;
    private Integer pageNum;
    private Integer pageSize;
    /** 底部整体汇总：周列合计数字 */
    private Map<String, BigDecimal> weekPlannedTotals = new LinkedHashMap<>();
    /** 底部整体汇总：周列加班合计 */
    private Map<String, BigDecimal> weekOvertimeTotals = new LinkedHashMap<>();
    /** 底部整体汇总：周列请假合计（员工维度，每人每周只计一次） */
    private Map<String, BigDecimal> weekLeaveTotals = new LinkedHashMap<>();
    /** 底部整体汇总：追加 5 列 */
    private ExecutionSummaryVO summaryTotals;
}
