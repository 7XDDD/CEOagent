package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtContractLine;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtContractLineMapper extends BaseMapper<PmtContractLine> {

    List<PmtContractLine> selectByContractId(@Param("contractId") Long contractId);

    int deleteByContractId(@Param("contractId") Long contractId);
}
