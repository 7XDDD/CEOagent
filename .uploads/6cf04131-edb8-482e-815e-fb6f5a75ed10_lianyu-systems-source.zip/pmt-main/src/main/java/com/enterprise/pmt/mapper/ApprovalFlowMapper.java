package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.ApprovalFlow;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface ApprovalFlowMapper extends BaseMapper<ApprovalFlow> {

    @Select("SELECT * FROM pmt_approval_flow WHERE business_type = #{businessType} AND deleted = 0 AND status = 1 LIMIT 1")
    ApprovalFlow findByBusinessType(@Param("businessType") String businessType);

    @Update("UPDATE pmt_approval_flow SET deleted = #{id} WHERE deleted = 0 AND id = #{id}")
    int softDeleteById(@Param("id") Long id);

    /**
     * 查询指定用户被配置为「项目经理主管审批人」的已发布流程ID集合。
     * 用于工时管理/工时审批主管可见域的 Java 端预计算，避免 SQL 关联 EXISTS 拖垮优化器。
     */
    @Select("SELECT id FROM pmt_approval_flow " +
            "WHERE deleted = 0 AND status = 1 AND (is_published IS NULL OR is_published = 1) " +
            "AND pm_approver_enabled = 1 AND FIND_IN_SET(#{userId}, pm_approver_user_ids)")
    List<Long> selectPmApproverFlowIds(@Param("userId") Long userId);
}
