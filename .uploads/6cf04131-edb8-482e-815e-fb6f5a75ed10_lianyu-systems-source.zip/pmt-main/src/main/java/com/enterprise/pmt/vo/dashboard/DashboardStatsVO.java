package com.enterprise.pmt.vo.dashboard;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Data
public class DashboardStatsVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long projectCount;

    private Long activeProjectCount;

    private Long contractCount;

    private BigDecimal totalContractAmount;

    private BigDecimal totalInvoiceAmount;

    private BigDecimal totalReceiptAmount;

    private Long pendingTimesheetCount;

    private Long pendingApprovalCount;

    private List<Map<String, Object>> projectProgress;

    private List<Map<String, Object>> monthlyRevenue;

    private List<Map<String, Object>> recentTimesheets;

    private List<Map<String, Object>> upcomingMilestones;
}
