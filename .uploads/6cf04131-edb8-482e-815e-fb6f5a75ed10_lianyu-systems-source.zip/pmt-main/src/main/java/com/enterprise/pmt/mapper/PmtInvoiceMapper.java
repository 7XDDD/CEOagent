package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.PmtInvoice;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtInvoiceMapper extends BaseMapper<PmtInvoice> {

    Page<PmtInvoice> selectPageList(Page<PmtInvoice> page,
                                    @Param("projectId") Long projectId,
                                    @Param("customerId") Long customerId,
                                    @Param("contractId") Long contractId,
                                    @Param("keyword") String keyword,
                                    @Param("invoiceStatus") String invoiceStatus);

    List<PmtInvoice> selectListByCondition(@Param("contractId") Long contractId,
                                           @Param("customerId") Long customerId);

    int softDeleteById(@Param("id") Long id);

    Long countAll();

    Long countByStatus(@Param("invoiceStatus") String invoiceStatus);

    java.math.BigDecimal sumInvoiceAmount();

    java.math.BigDecimal sumMonthlyInvoiceAmount(@Param("year") int year, @Param("month") int month);

    Long countMonthlyInvoices(@Param("year") int year, @Param("month") int month);
}
