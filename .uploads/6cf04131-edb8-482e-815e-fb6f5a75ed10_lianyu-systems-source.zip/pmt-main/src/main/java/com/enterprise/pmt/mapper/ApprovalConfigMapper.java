package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.ApprovalConfig;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface ApprovalConfigMapper extends BaseMapper<ApprovalConfig> {

    @Select("SELECT * FROM pmt_approval_config WHERE config_name = #{configName} AND deleted = 0 LIMIT 1")
    ApprovalConfig findByConfigName(@Param("configName") String configName);

    @Select("SELECT * FROM pmt_approval_config WHERE approval_type = #{approvalType} AND deleted = 0 AND status = 1 LIMIT 1")
    ApprovalConfig findByApprovalType(@Param("approvalType") String approvalType);

    Page<ApprovalConfig> selectPageList(Page<ApprovalConfig> page, @Param("keyword") String keyword, @Param("status") Integer status);
}
