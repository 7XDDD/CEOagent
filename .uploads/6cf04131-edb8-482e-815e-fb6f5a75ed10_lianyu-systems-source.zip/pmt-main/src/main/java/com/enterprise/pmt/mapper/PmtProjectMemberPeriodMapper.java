package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtProjectMemberPeriod;
import com.enterprise.pmt.vo.MemberPeriodProjectVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.util.List;

@Mapper
public interface PmtProjectMemberPeriodMapper extends BaseMapper<PmtProjectMemberPeriod> {

    List<PmtProjectMemberPeriod> selectByMemberId(@Param("memberId") Long memberId);

    List<PmtProjectMemberPeriod> selectByMemberIds(@Param("memberIds") List<Long> memberIds);

    int deleteByMemberId(@Param("memberId") Long memberId);

    /**
     * 批量逻辑删除指定成员列表下的所有时间段
     */
    int deleteByMemberIds(@Param("memberIds") List<Long> memberIds);

    /**
     * 查询员工在指定日期范围内处于活跃期的项目时间段
     * 用于工时填报时给出默认工时
     *
     * @param employeeId 员工ID（pmt_employee.id）
     * @param weekStart  周起始日（周一）
     * @param weekEnd    周结束日（周日）
     */
    List<MemberPeriodProjectVO> selectActiveProjectsForWeek(@Param("employeeId") Long employeeId,
                                                            @Param("weekStart") LocalDate weekStart,
                                                            @Param("weekEnd") LocalDate weekEnd);

    /**
     * 查询员工参与的全部项目（只要在项目成员表中存在即返回，不按周/投入时间段/工时计划过滤）。
     * 用于工时填报：只要有项目就可以填报，默认工时仍由 {@link #selectActiveProjectsForWeek} 计算。
     *
     * @param employeeId 员工ID（pmt_employee.id）
     */
    List<MemberPeriodProjectVO> selectMemberProjects(@Param("employeeId") Long employeeId);
}
