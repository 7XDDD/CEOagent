package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.dto.system.LoginLogQueryDTO;
import com.enterprise.pmt.entity.LoginLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface LoginLogMapper extends BaseMapper<LoginLog> {

    Page<LoginLog> selectPageList(Page<LoginLog> page, @Param("q") LoginLogQueryDTO query);

    @Select("SELECT COUNT(*) FROM pmt_login_log WHERE user_id = #{userId} AND login_result = 'SUCCESS'")
    long countSuccessByUser(@Param("userId") Long userId);
}
