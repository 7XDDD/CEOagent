package com.enterprise.pmt.controller.system;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.annotation.OperationLog.OperationType;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.service.ApprovalFlowService;
import com.enterprise.pmt.vo.ApprovalFlowVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "系统管理-审批流程配置")
@RestController
@RequestMapping("/system/approval-config")
public class ApprovalFlowController {

    @Autowired
    private ApprovalFlowService approvalFlowService;

    @ApiOperation("分页查询审批流程")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:view')")
    @GetMapping("/page")
    public Result<Page<ApprovalFlowVO>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "100") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer status) {
        return Result.success(approvalFlowService.pageList(pageNum, pageSize, keyword, status));
    }

    @ApiOperation("获取所有流程配置")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:view')")
    @GetMapping("/list")
    public Result<List<ApprovalFlowVO>> list() {
        return Result.success(approvalFlowService.listAll());
    }

    @ApiOperation("获取流程详情（含节点）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:view')")
    @GetMapping("/{id:\\d+}")
    public Result<ApprovalFlowVO> getDetail(@PathVariable Long id) {
        return Result.success(approvalFlowService.getDetail(id));
    }

    @ApiOperation("新增流程配置（同时保存节点）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:create')")
    @OperationLog(module = "审批流程", description = "新增审批流程", type = OperationType.INSERT)
    @PostMapping
    public Result<ApprovalFlowVO> create(@RequestBody ApprovalFlowVO flowVO) {
        return Result.success(approvalFlowService.create(flowVO));
    }

    @ApiOperation("更新流程配置（支持部分更新如状态切换）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:update')")
    @OperationLog(module = "审批流程", description = "修改审批流程", type = OperationType.UPDATE)
    @PutMapping
    public Result<ApprovalFlowVO> update(@RequestBody ApprovalFlowVO flowVO) {
        return Result.success(approvalFlowService.update(flowVO));
    }

    @ApiOperation("更新流程配置（路径参数ID）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:update')")
    @OperationLog(module = "审批流程", description = "修改审批流程", type = OperationType.UPDATE)
    @PutMapping("/{id}")
    public Result<ApprovalFlowVO> updateById(@PathVariable Long id, @RequestBody ApprovalFlowVO flowVO) {
        return Result.success(approvalFlowService.update(id, flowVO));
    }

    @ApiOperation("删除流程（同时删节点）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:delete')")
    @OperationLog(module = "审批流程", description = "删除审批流程", type = OperationType.DELETE)
    @DeleteMapping("/{id:\\d+}")
    public Result<?> delete(@PathVariable Long id) {
        approvalFlowService.delete(id);
        return Result.success("删除成功");
    }

    @ApiOperation("按业务类型获取流程")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow:view')")
    @GetMapping("/business-type/{businessType}")
    public Result<ApprovalFlowVO> getByBusinessType(@PathVariable String businessType) {
        return Result.success(approvalFlowService.getByBusinessType(businessType));
    }
}
