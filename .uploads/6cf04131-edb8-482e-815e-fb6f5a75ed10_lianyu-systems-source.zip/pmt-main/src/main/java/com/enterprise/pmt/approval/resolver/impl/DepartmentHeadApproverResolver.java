package com.enterprise.pmt.approval.resolver.impl;

import com.enterprise.pmt.approval.resolver.ApproverResolver;
import com.enterprise.pmt.entity.ApprovalNode;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

/**
 * 部门负责人审批人解析器
 * 可根据部门表的leader字段解析，后续完善
 */
@Component
public class DepartmentHeadApproverResolver implements ApproverResolver {

    @Override
    public String getSupportedType() {
        return "DEPARTMENT_HEAD";
    }

    @Override
    public List<Long> resolveApproverIds(ApprovalNode node, Long applicantId, Long projectId, Long deptId) {
        // TODO: 根据申请人所属部门解析部门负责人
        return Collections.emptyList();
    }
}
