package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.dto.system.DictQueryDTO;
import com.enterprise.pmt.entity.Dict;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface DictMapper extends BaseMapper<Dict> {

    Page<Dict> selectPageList(Page<Dict> page, @Param("q") DictQueryDTO query);

    @Select("SELECT * FROM pmt_dict WHERE dict_code = #{dictCode} AND deleted = 0 LIMIT 1")
    Dict findByDictCode(@Param("dictCode") String dictCode);

    @Select("SELECT * FROM pmt_dict WHERE dict_code = #{dictCode} AND system_type = #{systemType} AND deleted = 0 LIMIT 1")
    Dict findByDictCodeAndSystemType(@Param("dictCode") String dictCode, @Param("systemType") String systemType);

    @Select("SELECT * FROM pmt_dict WHERE dict_type = #{dictType} AND deleted = 0 ORDER BY sort_order ASC")
    List<Dict> findByDictType(@Param("dictType") String dictType);

    int softDeleteById(@Param("id") Long id);
}
