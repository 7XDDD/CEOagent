package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.PmtCostActual;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtCostActualMapper extends BaseMapper<PmtCostActual> {

    Page<PmtCostActual> selectPageList(Page<PmtCostActual> page,
                                       @Param("projectId") Long projectId,
                                       @Param("categoryId") Long categoryId,
                                       @Param("keyword") String keyword,
                                       @Param("costStatus") String costStatus);

    List<PmtCostActual> selectListByProjectId(@Param("projectId") Long projectId);

    java.math.BigDecimal sumTotalActual();

    java.math.BigDecimal sumMonthlyActual(@Param("year") int year, @Param("month") int month);
}
