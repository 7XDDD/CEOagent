package com.enterprise.pmt.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.common.BusinessException;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.ResultCode;
import com.enterprise.pmt.entity.PmtMilestone;
import com.enterprise.pmt.mapper.PmtMilestoneMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "里程碑管理")
@RestController
@RequestMapping("/milestones")
public class MilestoneController {

    private final PmtMilestoneMapper milestoneMapper;

    public MilestoneController(PmtMilestoneMapper milestoneMapper) {
        this.milestoneMapper = milestoneMapper;
    }

    @ApiOperation("分页查询里程碑(GET)")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:milestone:view')")
    @GetMapping("/page")
    public Result<Page<PmtMilestone>> pageGet(@RequestParam(defaultValue = "1") int pageNum,
                                              @RequestParam(defaultValue = "10") int pageSize,
                                              @RequestParam(required = false) Long projectId,
                                              @RequestParam(required = false) Long contractId,
                                              @RequestParam(required = false) String keyword,
                                              @RequestParam(required = false) String milestoneStatus) {
        Page<PmtMilestone> page = new Page<>(pageNum, pageSize);
        return Result.success(milestoneMapper.selectPageList(page, projectId, contractId, keyword, milestoneStatus));
    }

    @ApiOperation("获取所有里程碑")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:milestone:view')")
    @GetMapping("/list")
    public Result<List<PmtMilestone>> listAll(@RequestParam(required = false) Long contractId) {
        if (contractId != null) {
            return Result.success(milestoneMapper.selectByContractId(contractId));
        }
        return Result.success(milestoneMapper.selectByProjectId(null));
    }

    @ApiOperation("获取里程碑详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:milestone:view')")
    @GetMapping("/{id:\\d+}")
    public Result<PmtMilestone> getDetail(@PathVariable Long id) {
        PmtMilestone milestone = milestoneMapper.selectById(id);
        if (milestone == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        return Result.success(milestone);
    }

    @ApiOperation("按项目查询里程碑")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:milestone:view')")
    @GetMapping("/project/{projectId}")
    public Result<List<PmtMilestone>> getByProject(@PathVariable Long projectId) {
        return Result.success(milestoneMapper.selectByProjectId(projectId));
    }

    @ApiOperation("创建里程碑")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:milestone:create')")
    @PostMapping
    @OperationLog("创建里程碑")
    public Result<Long> create(@RequestBody PmtMilestone milestone) {
        milestoneMapper.insert(milestone);
        return Result.success(milestone.getId());
    }

    @ApiOperation("更新里程碑")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:milestone:update')")
    @PutMapping("/{id}")
    @OperationLog("更新里程碑")
    public Result<Boolean> update(@PathVariable Long id, @RequestBody PmtMilestone milestone) {
        PmtMilestone exist = milestoneMapper.selectById(id);
        if (exist == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        milestone.setId(id);
        return Result.success(milestoneMapper.updateById(milestone) > 0);
    }

    @ApiOperation("删除里程碑")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:milestone:delete')")
    @DeleteMapping("/{id}")
    @OperationLog("删除里程碑")
    public Result<Boolean> delete(@PathVariable Long id) {
        PmtMilestone milestone = milestoneMapper.selectById(id);
        if (milestone == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        milestoneMapper.softDeleteById(id);
        return Result.success(true);
    }
}
