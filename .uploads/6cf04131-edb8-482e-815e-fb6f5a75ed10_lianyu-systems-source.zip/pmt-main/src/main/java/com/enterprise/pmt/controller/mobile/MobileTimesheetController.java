package com.enterprise.pmt.controller.mobile;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.SecurityContextUtil;
import com.enterprise.pmt.dto.*;
import com.enterprise.pmt.service.TimesheetService;
import com.enterprise.pmt.vo.TimesheetVO;
import com.enterprise.pmt.vo.TimesheetWeekDefaultsVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@Api(tags = "移动端工时接口")
@RestController
@RequestMapping("/m/timesheet")
public class MobileTimesheetController {

    private final TimesheetService timesheetService;

    public MobileTimesheetController(TimesheetService timesheetService) {
        this.timesheetService = timesheetService;
    }

    @ApiOperation("移动端-我的工时列表")
    @GetMapping("/list")
    public Result<List<TimesheetVO>> myTimesheets() {
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(timesheetService.myTimesheets(userId));
    }

    @ApiOperation("移动端-我的工时列表(分页)")
    @GetMapping("/my-list")
    public Result<Page<TimesheetVO>> myList(@RequestParam(defaultValue = "1") Integer pageNum,
                                            @RequestParam(defaultValue = "10") Integer pageSize,
                                            @RequestParam(required = false) String status) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        TimesheetQueryDTO queryDTO = new TimesheetQueryDTO();
        queryDTO.setPageNum(pageNum);
        queryDTO.setPageSize(pageSize);
        queryDTO.setUserId(userId);
        queryDTO.setApprovalStatus(status);
        return Result.success(timesheetService.pageList(queryDTO));
    }

    @ApiOperation("移动端-获取当前周工时列表")
    @GetMapping("/current-week")
    public Result<List<TimesheetVO>> getCurrentWeek(@RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekStartDate) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(timesheetService.myTimesheets(userId).stream()
                .filter(vo -> weekStartDate.equals(vo.getWeekStartDate()))
                .collect(java.util.stream.Collectors.toList()));
    }

    @ApiOperation("移动端-保存工时(草稿)")
    @PostMapping("/save")
    public Result<Long> save(@RequestBody TimesheetSaveDTO saveDTO) {
        saveDTO.setSource("MOBILE");
        return Result.success(timesheetService.saveTimesheet(saveDTO));
    }

    @ApiOperation("移动端-保存并提交工时")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:submit')")
    @PostMapping("/save-and-submit")
    public Result<List<Long>> saveAndSubmit(@RequestBody TimesheetSaveDTO saveDTO) {
        saveDTO.setSource("MOBILE");
        timesheetService.saveTimesheet(saveDTO);
        Long userId = SecurityContextUtil.getCurrentUserId();
        List<Long> submittedIds = timesheetService.submitTimesheetByWeek(userId, saveDTO.getWeekStartDate());
        return Result.success(submittedIds);
    }

    @ApiOperation("移动端-提交单个工时单")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:submit')")
    @PostMapping("/{id}/submit")
    public Result<Boolean> submit(@PathVariable Long id) {
        return Result.success(timesheetService.submitTimesheet(id));
    }

    @ApiOperation("移动端-工时详情")
    @GetMapping("/{id:\\d+}")
    public Result<TimesheetVO> getDetail(@PathVariable Long id) {
        return Result.success(timesheetService.getDetail(id));
    }

    @ApiOperation("移动端-待审批列表")
    @PostMapping("/pending")
    public Result<Page<TimesheetVO>> pendingList(@RequestBody TimesheetQueryDTO queryDTO) {
        queryDTO.setApprovalStatus("PENDING");
        queryDTO.setApproverId(SecurityContextUtil.getCurrentUserId());
        queryDTO.setStrictApprovalScope(true);
        return Result.success(timesheetService.pageList(queryDTO));
    }

    @ApiOperation("移动端-待审批列表(GET)")
    @GetMapping("/pending")
    public Result<Page<TimesheetVO>> pendingListGet(@RequestParam(defaultValue = "1") Integer pageNum,
                                                     @RequestParam(defaultValue = "10") Integer pageSize) {
        TimesheetQueryDTO queryDTO = new TimesheetQueryDTO();
        queryDTO.setPageNum(pageNum);
        queryDTO.setPageSize(pageSize);
        queryDTO.setApprovalStatus("PENDING");
        queryDTO.setApproverId(SecurityContextUtil.getCurrentUserId());
        queryDTO.setStrictApprovalScope(true);
        return Result.success(timesheetService.pageList(queryDTO));
    }

    @ApiOperation("移动端-审批通过")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:approve')")
    @PostMapping("/{id}/approve")
    public Result<Boolean> approve(@PathVariable Long id, @RequestBody TimesheetApprovalDTO approvalDTO) {
        return Result.success(timesheetService.approveTimesheet(id, approvalDTO));
    }

    @ApiOperation("移动端-审批驳回")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet:reject')")
    @PostMapping("/{id}/reject")
    public Result<Boolean> reject(@PathVariable Long id, @RequestBody TimesheetApprovalDTO approvalDTO) {
        return Result.success(timesheetService.rejectTimesheet(id, approvalDTO));
    }

    @ApiOperation("移动端-撤回")
    @PostMapping("/{id}/withdraw")
    public Result<Boolean> withdraw(@PathVariable Long id) {
        return Result.success(timesheetService.withdrawTimesheet(id));
    }

    @ApiOperation("移动端-获取指定周默认工时（按项目投入占比自动推荐）")
    @GetMapping("/week-defaults")
    public Result<TimesheetWeekDefaultsVO> weekDefaults(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate weekStartDate) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(timesheetService.getWeekDefaults(userId, weekStartDate));
    }
}
