package com.enterprise.pmt.vo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class TimesheetItemVO implements Serializable {
    private Long id;
    private LocalDate workDate;
    private Long projectId;
    private String projectName;
    private String taskName;
    private String workType;
    private BigDecimal hours;
    private BigDecimal billableHours;
}
