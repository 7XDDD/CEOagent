package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtPaymentReceiptLine;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtPaymentReceiptLineMapper extends BaseMapper<PmtPaymentReceiptLine> {

    List<PmtPaymentReceiptLine> selectByReceiptId(@Param("receiptId") Long receiptId);
}
