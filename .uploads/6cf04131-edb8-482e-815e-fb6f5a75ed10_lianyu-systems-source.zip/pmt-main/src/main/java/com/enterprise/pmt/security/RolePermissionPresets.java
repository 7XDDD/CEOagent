package com.enterprise.pmt.security;

import java.util.*;

/**
 * 5 个核心业务角色（PMT_PM / PMT_MANAGER / PMT_FINANCE / PMT_MEMBER / PMT_EMPLOYEE）
 * 的**严格最小**预设权限码映射。
 *
 * 设计原则（对齐用户 2026-08-21 诉求 + router/index.js 可见菜单 + 页面依赖）：
 *  1. admin/PMT_ADMIN 拥有全部权限，不在本兜底范围。
 *  2. 预设内容必须与 sql/pmt20260821_strict_role_permissions.sql 中 5 角色最终 INSERT 结果 1:1 对齐。
 *  3. 兜底触发条件：DB 返回 null 或空集合（= 无权限记录/未执行补丁）时按 roleCodes 注入预设；
 *     当 DB 返回非空集合时（哪怕只有 1 条记录），严格尊重 DB 配置，不私自膨胀权限。
 *     注意：MyBatis Mapper 永远不会返回 null（空表返回空列表），因此空集合也视为"缺数据"。
 *  4. 财务（PMT_FINANCE）兜底仅授予"结算管理"相关权限 + 结算页面所需的接口依赖
 *     （pmt:timesheet:view / pmt:timesheet:settle），绝不授予会触发左侧菜单越界显示的权限，
 *     包括 pmt:my-timesheet:view、pmt:dashboard:view、pmt:project:view、pmt:customer:view、
 *     pmt:approval:view、pmt:timesheet:manage 等。
 *     若财务员工本人也需要报工时，请在角色管理中额外勾选"我的工时"菜单，
 *     或直接为该员工同时分配 PMT_EMPLOYEE + PMT_FINANCE 双角色。
 *  5. 本文件与 pmt-front/src/stores/user.js permissionMap 的 5 条角色条目保持一致。
 */
public final class RolePermissionPresets {

    private RolePermissionPresets() {}

    private static final Map<String, Set<String>> ROLE_PERMS = new LinkedHashMap<>();

    private static final Set<String> EMPLOYEE = new LinkedHashSet<>(Arrays.asList(
            "pmt:my-timesheet:view",
            "pmt:timesheet:save", "pmt:timesheet:submit", "pmt:timesheet:withdraw",
            "pmt:timesheet:m-fill", "pmt:timesheet:week-defaults", "pmt:timesheet:detail"
    ));

    private static final Set<String> MEMBER = new LinkedHashSet<>(Arrays.asList(
            "pmt:project:my",
            "pmt:my-timesheet:view",
            "pmt:timesheet:save", "pmt:timesheet:submit", "pmt:timesheet:withdraw",
            "pmt:timesheet:m-fill", "pmt:timesheet:week-defaults", "pmt:timesheet:detail",
            "pmt:milestone:view", "pmt:material:view",
            "pmt:timesheet-budget:view",
            "pmt:timesheet-execution:view"
    ));

    private static final Set<String> PM = new LinkedHashSet<>(Arrays.asList(
            "pmt:dashboard:view", "pmt:dashboard:stats",
            "pmt:customer:view", "pmt:customer:create", "pmt:customer:update", "pmt:customer:delete",
            "pmt:customer:import", "pmt:customer:export",
            "pmt:org:view", "pmt:org:create", "pmt:org:update", "pmt:org:delete",
            "pmt:org:import", "pmt:org:export",
            "pmt:employee:view", "pmt:employee:create", "pmt:employee:update", "pmt:employee:delete",
            "pmt:employee:import", "pmt:employee:export",
            "pmt:attendance:view", "pmt:attendance:create", "pmt:attendance:update", "pmt:attendance:import",
            "pmt:overtime:view", "pmt:overtime:create", "pmt:overtime:update", "pmt:overtime:import",
            "pmt:leave:view", "pmt:leave:create", "pmt:leave:update", "pmt:leave:import",
            "pmt:project:view", "pmt:project:create", "pmt:project:update", "pmt:project:delete",
            "pmt:project:import", "pmt:project:export", "pmt:project:member", "pmt:project:my",
            "pmt:milestone:view", "pmt:milestone:create", "pmt:milestone:update", "pmt:milestone:delete",
            "pmt:material:view", "pmt:material:create", "pmt:material:update", "pmt:material:delete",
            "pmt:timesheet-budget:view", "pmt:timesheet-budget:import", "pmt:timesheet-budget:export",
            "pmt:timesheet-execution:view", "pmt:timesheet-execution:export",
            "pmt:my-timesheet:view",
            "pmt:timesheet:save", "pmt:timesheet:submit", "pmt:timesheet:withdraw",
            "pmt:timesheet:m-fill", "pmt:timesheet:week-defaults", "pmt:timesheet:detail",
            "pmt:approval:view",
            "pmt:timesheet:approve", "pmt:timesheet:reject",
            "pmt:timesheet:approve-list", "pmt:timesheet:approved-list",
            "pmt:timesheet:view", "pmt:timesheet:manage",
            "pmt:timesheet:batch-approve", "pmt:timesheet:batch-reject",
            "pmt:timesheet:lock", "pmt:timesheet:unlock", "pmt:timesheet:settle",
            "pmt:timesheet:anomaly-check", "pmt:timesheet:anomaly-resolve", "pmt:timesheet:anomaly-manage",
            "pmt:timesheet:stats", "pmt:timesheet:export", "pmt:timesheet:import",
            "pmt:settlement:view", "pmt:settlement:settle", "pmt:settlement:cancel-settle",
            "pmt:approval-instance:view",
            "pmt:approval-flow:view", "pmt:approval-flow:create", "pmt:approval-flow:update",
            "pmt:approval-flow:delete", "pmt:approval-flow:toggle"
    ));

    private static final Set<String> MANAGER = PM;

    private static final Set<String> FINANCE = new LinkedHashSet<>(Arrays.asList(
            "pmt:settlement:view", "pmt:settlement:create", "pmt:settlement:update",
            "pmt:settlement:delete", "pmt:settlement:settle", "pmt:settlement:cancel-settle",
            "pmt:settlement:stats", "pmt:settlement:export",
            "pmt:timesheet:view", "pmt:timesheet:settle"
    ));

    static {
        ROLE_PERMS.put("PMT_PM",       Collections.unmodifiableSet(PM));
        ROLE_PERMS.put("PMT_MANAGER",  Collections.unmodifiableSet(MANAGER));
        ROLE_PERMS.put("PMT_FINANCE",  Collections.unmodifiableSet(FINANCE));
        ROLE_PERMS.put("PMT_MEMBER",   Collections.unmodifiableSet(MEMBER));
        ROLE_PERMS.put("PMT_EMPLOYEE", Collections.unmodifiableSet(EMPLOYEE));
    }

    /**
     * 合并角色预设权限。
     * 严格策略（RolePermissionPresetsStrictTest 约束）：
     * - permissions 为 null 或空集合（DB 无权限记录）→ 按 roleCodes 注入预设兜底
     * - permissions 非空（至少 1 条）→ 严格尊重 DB 配置，仅去重，不私自注入
     */
    public static Set<String> mergeRolePresets(Collection<String> roleCodes,
                                               Collection<String> permissions) {
        Set<String> result = new LinkedHashSet<>();
        boolean dbEmpty = (permissions == null) || permissions.isEmpty();
        if (dbEmpty) {
            if (roleCodes != null) {
                for (String rc : roleCodes) {
                    if (rc == null) continue;
                    Set<String> preset = ROLE_PERMS.get(rc);
                    if (preset != null) result.addAll(preset);
                }
            }
            return result;
        }
        result.addAll(permissions);
        return result;
    }

    public static Set<String> presetRoleCodes() {
        return Collections.unmodifiableSet(ROLE_PERMS.keySet());
    }
}