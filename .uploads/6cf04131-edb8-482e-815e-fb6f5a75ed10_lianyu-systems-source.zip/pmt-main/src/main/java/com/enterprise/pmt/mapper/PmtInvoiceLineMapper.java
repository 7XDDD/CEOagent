package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtInvoiceLine;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtInvoiceLineMapper extends BaseMapper<PmtInvoiceLine> {

    List<PmtInvoiceLine> selectByInvoiceId(@Param("invoiceId") Long invoiceId);

    int deleteByInvoiceId(@Param("invoiceId") Long invoiceId);
}
