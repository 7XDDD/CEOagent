package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.Region;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface RegionMapper extends BaseMapper<Region> {

    @Select("SELECT * FROM pmt_region WHERE parent_id = #{parentId} AND deleted = 0 ORDER BY sort_order ASC, id ASC")
    List<Region> findByParentId(@Param("parentId") Long parentId);

    @Select("SELECT * FROM pmt_region WHERE level = #{level} AND deleted = 0 ORDER BY sort_order ASC, id ASC")
    List<Region> findByLevel(@Param("level") Integer level);
}
