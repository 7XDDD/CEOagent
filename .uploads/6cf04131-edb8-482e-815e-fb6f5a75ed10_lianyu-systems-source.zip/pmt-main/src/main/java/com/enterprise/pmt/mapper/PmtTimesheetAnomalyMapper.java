package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtTimesheetAnomaly;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtTimesheetAnomalyMapper extends BaseMapper<PmtTimesheetAnomaly> {

    List<PmtTimesheetAnomaly> selectByTimesheetId(@Param("timesheetId") Long timesheetId);

    List<PmtTimesheetAnomaly> selectOpenByTimesheetIds(@Param("ids") List<Long> ids);
}
