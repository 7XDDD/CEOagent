package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.PmtTimesheetBudget;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Delete;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface PmtTimesheetBudgetMapper extends BaseMapper<PmtTimesheetBudget> {

    @Select("SELECT DISTINCT week_start_date, week_label FROM pmt_timesheet_budget " +
            "WHERE deleted = 0 AND week_start_date IS NOT NULL " +
            "ORDER BY week_start_date")
    List<Map<String, Object>> selectDistinctWeeks();

    @Select("SELECT DISTINCT project_code, project_name FROM pmt_timesheet_budget " +
            "WHERE deleted = 0 AND project_code IS NOT NULL " +
            "ORDER BY project_code")
    List<Map<String, Object>> selectDistinctProjects();

    /** 最新(非空)版本号；若全是 NULL 返回 NULL */
    @Select("SELECT MAX(budget_version) FROM pmt_timesheet_budget WHERE deleted = 0 AND budget_version IS NOT NULL")
    String selectMaxBudgetVersion();

    /**
     * 按项目查询各自最新(非空)版本号。
     * projectCodes=null → 全部项目；非空集合 → 仅这些项目；空集合 → 无结果（调用方应自行短路）。
     * 只有历史 NULL 版本数据的项目不会出现在结果中，由调用方按 NULL 版本兜底。
     */
    @Select("<script>" +
            "SELECT project_code AS projectCode, MAX(budget_version) AS maxVersion " +
            "FROM pmt_timesheet_budget " +
            "WHERE deleted = 0 AND budget_version IS NOT NULL " +
            "<if test='projectCodes != null'>" +
            "  AND project_code IN " +
            "  <foreach collection='projectCodes' item='pc' open='(' separator=',' close=')'>#{pc}</foreach>" +
            "</if>" +
            "GROUP BY project_code" +
            "</script>")
    List<Map<String, Object>> selectMaxVersionByProject(@Param("projectCodes") java.util.Collection<String> projectCodes);

    /**
     * 版本分组统计：
     * - budget_version IS NULL → 单独一条 legacy，后续接口合并成"历史旧数据"
     * - 按 version DESC
     * projectCodes=null → 全部项目；非空集合 → 仅统计这些项目
     */
    @Select("<script>" +
            "SELECT budget_version AS version, COUNT(*) AS rowCount " +
            "FROM pmt_timesheet_budget " +
            "WHERE deleted = 0 " +
            "<if test='projectCodes != null'>" +
            "  AND project_code IN " +
            "  <foreach collection='projectCodes' item='pc' open='(' separator=',' close=')'>#{pc}</foreach>" +
            "</if>" +
            "GROUP BY budget_version " +
            "ORDER BY budget_version DESC" +
            "</script>")
    List<Map<String, Object>> selectVersionStats(@Param("projectCodes") java.util.Collection<String> projectCodes);

    @Select("SELECT t.employee_no, t.employee_name, t.employee_status, t.project_role, " +
            "t.project_code, t.project_name, " +
            "SUM(CASE WHEN t.week_start_date < #{weekStart} THEN t.planned_hours ELSE 0 END) as total_planned_before, " +
            "SUM(CASE WHEN t.week_start_date < #{weekStart} THEN t.actual_hours ELSE 0 END) as total_actual_before, " +
            "SUM(CASE WHEN t.week_start_date >= #{weekStart} THEN t.planned_hours ELSE 0 END) as total_planned_after, " +
            "SUM(CASE WHEN t.week_start_date >= #{weekStart} THEN t.actual_hours ELSE 0 END) as total_actual_after " +
            "FROM pmt_timesheet_budget t " +
            "WHERE t.deleted = 0 " +
            "GROUP BY t.employee_no, t.project_code, t.employee_name, t.employee_status, t.project_role, t.project_name " +
            "ORDER BY t.project_code, t.employee_no")
    List<Map<String, Object>> selectSummaryByWeek(@Param("weekStart") LocalDate weekStart);

    @Select("SELECT SUM(planned_hours) as total_planned, SUM(actual_hours) as total_actual " +
            "FROM pmt_timesheet_budget " +
            "WHERE deleted = 0 AND employee_no = #{employeeNo} AND project_code = #{projectCode}")
    Map<String, BigDecimal> selectTotalsByEmployeeProject(@Param("employeeNo") String employeeNo,
                                                           @Param("projectCode") String projectCode);

    /**
     * 物理删除同日/同项目覆盖的预算数据（同日同一项目只保留最新一次导入结果）。
     * 精确删除条件：budget_version = #{version} AND project_code IN (#{projectCodes})
     *
     *  设计要点：
     *  - 不走 MyBatis-Plus @TableLogic 逻辑删除（逻辑删改 deleted=1 后仍会命中老的唯一索引导致重复键异常）；
     *  - 只按「版本号 + 项目编码」删，不影响当天已导入成功的"其他项目"预算（项目间彼此隔离）；
     *  - 版本号 = YYYYMMDD（和业务一致）。
     */
    @Delete("<script>" +
            "DELETE FROM pmt_timesheet_budget " +
            " WHERE budget_version = #{version} " +
            "   AND project_code IN " +
            "   <foreach collection='projectCodes' item='pc' open='(' separator=',' close=')'>#{pc}</foreach>" +
            "</script>")
    int physicalDeleteSameVersionAndProjects(@Param("version") String version,
                                              @Param("projectCodes") List<String> projectCodes);
}
