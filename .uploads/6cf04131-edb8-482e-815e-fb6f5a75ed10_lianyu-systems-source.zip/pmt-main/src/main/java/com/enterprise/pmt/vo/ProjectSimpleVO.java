package com.enterprise.pmt.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class ProjectSimpleVO implements Serializable {
    private Long id;
    private String projectCode;
    private String projectName;
    private String projectStatus;
}
