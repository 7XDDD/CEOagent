package com.enterprise.pmt.controller;

import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.service.TimesheetBudgetService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Api(tags = "工时预算管理")
@RequestMapping("/timesheet-budget")
@RestController
public class TimesheetBudgetController {

    @Autowired
    private TimesheetBudgetService timesheetBudgetService;

    @ApiOperation("查询工时预算列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-budget:view')")
    @GetMapping("/list")
    public Result<Map<String, Object>> list(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String projectCode,
            @RequestParam(required = false) String employeeNo,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) String budgetVersion,
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "20") int pageSize) {
        Map<String, Object> data = timesheetBudgetService.getBudgetList(
                keyword, projectCode, employeeNo, startDate, endDate, budgetVersion, pageNum, pageSize);
        return Result.success(data);
    }

    @ApiOperation("获取周列表")
    @GetMapping("/weeks")
    public Result<?> weeks() {
        return Result.success(timesheetBudgetService.getDistinctWeeks());
    }

    @ApiOperation("获取项目列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-budget:view')")
    @GetMapping("/projects")
    public Result<?> projects() {
        return Result.success(timesheetBudgetService.getDistinctProjects());
    }

    @ApiOperation("获取预算版本列表（可按项目过滤）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-budget:view')")
    @GetMapping("/versions")
    public Result<?> versions(@RequestParam(required = false) String projectCode) {
        return Result.success(timesheetBudgetService.getBudgetVersions(projectCode));
    }

    @ApiOperation("导入工时预算")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-budget:import')")
    @PostMapping("/import")
    public Result<Map<String, Object>> importExcel(@RequestParam("file") MultipartFile file) {
        Map<String, Object> result = timesheetBudgetService.importExcel(file);
        int inserted = (int) result.getOrDefault("inserted", 0);
        int updated = (int) result.getOrDefault("updated", 0);
        int failed = (int) result.getOrDefault("failed", 0);
        int memberAdded = (int) result.getOrDefault("memberAdded", 0);
        Object ver = result.get("budgetVersion");
        StringBuilder msg = new StringBuilder("导入完成");
        if (ver != null) msg.append("(版本").append(ver).append(")");
        msg.append("，新增 ").append(inserted).append(" 条，更新 ").append(updated)
           .append(" 条，失败 ").append(failed).append(" 条，项目成员新增 ").append(memberAdded).append(" 条");
        return Result.success(msg.toString(), result);
    }

    @ApiOperation("下载导入模板")
    @GetMapping("/template")
    public void downloadTemplate(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) String projectCode,
            HttpServletResponse response) throws Exception {
        timesheetBudgetService.downloadImportTemplate(response, startDate, endDate, projectCode);
    }

    @ApiOperation("导出工时预算")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-budget:export')")
    @GetMapping("/export")
    public void export(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String projectCode,
            @RequestParam(required = false) String employeeNo,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) String budgetVersion,
            HttpServletResponse response) throws Exception {
        timesheetBudgetService.exportBudget(keyword, projectCode, employeeNo, startDate, endDate, budgetVersion, response);
    }

    @ApiOperation("刷新实际工时")
    @PostMapping("/refresh-actual")
    public Result<String> refreshActual() {
        timesheetBudgetService.refreshActualHours();
        return Result.success("刷新成功");
    }

    @ApiOperation("历史工时导入信息（是否已导入/截止周/允许的最大周）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-budget:import')")
    @GetMapping("/history-import-info")
    public Result<Map<String, Object>> historyImportInfo() {
        return Result.success(timesheetBudgetService.getHistoryImportInfo());
    }

    @ApiOperation("下载历史工时模板")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-budget:import')")
    @GetMapping("/history-template")
    public void downloadHistoryTemplate(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) String projectCode,
            HttpServletResponse response) throws Exception {
        timesheetBudgetService.downloadHistoryTemplate(response, startDate, projectCode);
    }

    @ApiOperation("导入历史工时数据（生成已审批工时单）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:timesheet-budget:import')")
    @PostMapping("/import-history")
    public Result<Map<String, Object>> importHistory(@RequestParam("file") MultipartFile file) {
        Map<String, Object> result = timesheetBudgetService.importHistory(file);
        int inserted = (int) result.getOrDefault("inserted", 0);
        int updated = (int) result.getOrDefault("updated", 0);
        int skipped = (int) result.getOrDefault("skipped", 0);
        int failed = (int) result.getOrDefault("failed", 0);
        StringBuilder msg = new StringBuilder("历史工时导入完成，新增工时单 ")
                .append(inserted).append(" 条，更新 ").append(updated)
                .append(" 条，跳过 ").append(skipped)
                .append(" 条，失败 ").append(failed).append(" 条");
        Object firstProjects = result.get("firstProjects");
        if (firstProjects instanceof List && !((List<?>) firstProjects).isEmpty()) {
            msg.append("；以下项目为第一次导入，最后周已分别锁定：");
            for (Object o : (List<?>) firstProjects) {
                if (o instanceof Map) {
                    Map<?, ?> m = (Map<?, ?>) o;
                    msg.append(m.get("projectName")).append("→").append(m.get("endDate")).append("；");
                }
            }
        }
        return Result.success(msg.toString(), result);
    }
}
