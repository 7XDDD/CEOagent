package com.enterprise.pmt.controller.system;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.annotation.OperationLog.OperationType;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.dto.system.AddUserFromEmployeeDTO;
import com.enterprise.pmt.dto.system.UserCreateDTO;
import com.enterprise.pmt.dto.system.UserQueryDTO;
import com.enterprise.pmt.dto.system.UserUpdateDTO;
import com.enterprise.pmt.service.UserService;
import com.enterprise.pmt.vo.system.UserVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(tags = "系统管理-用户管理")
@RestController
@RequestMapping("/system/user")
public class UserController {

    @Autowired
    private UserService userService;

    @ApiOperation("分页查询用户列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:view')")
    @GetMapping("/page")
    public Result<Page<Map<String, Object>>> page(UserQueryDTO query) {
        return Result.success(userService.pageList(query));
    }

    @ApiOperation("获取用户列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:view')")
    @GetMapping("/list")
    public Result<List<Map<String, Object>>> list(UserQueryDTO query) {
        return Result.success(userService.list(query));
    }

    @ApiOperation("获取用户详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:view')")
    @GetMapping("/{id}")
    public Result<UserVO> getDetail(@PathVariable Long id) {
        return Result.success(userService.getDetail(id));
    }

    @ApiOperation("获取用户详情（包含角色信息）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:view')")
    @GetMapping("/with-roles/{userId}")
    public Result<Map<String, Object>> getUserWithRoles(@PathVariable Long userId) {
        return Result.success(userService.getUserWithRoles(userId));
    }

    @ApiOperation("新增用户")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:create')")
    @OperationLog(module = "用户管理", description = "新增用户", type = OperationType.INSERT)
    @PostMapping
    public Result<?> create(@Validated @RequestBody UserCreateDTO dto) {
        userService.create(dto);
        return Result.success("创建成功");
    }

    @ApiOperation("为用户分配角色")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:assign-roles')")
    @OperationLog(module = "用户管理", description = "分配用户角色", type = OperationType.UPDATE)
    @PostMapping("/assign-roles/{userId}")
    public Result<?> assignRoles(@PathVariable Long userId, @RequestBody Map<String, List<Long>> body) {
        userService.assignRoles(userId, body.get("roleIds"));
        return Result.success("分配角色成功");
    }

    @ApiOperation("为用户分配角色（REST风格）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:assign-roles')")
    @OperationLog(module = "用户管理", description = "分配用户角色", type = OperationType.UPDATE)
    @PutMapping("/{userId}/roles")
    public Result<?> assignRolesRest(@PathVariable Long userId, @RequestBody List<Long> roleIds) {
        userService.assignRoles(userId, roleIds);
        return Result.success("分配角色成功");
    }

    @ApiOperation("修改用户状态")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:update')")
    @OperationLog(module = "用户管理", description = "修改用户", type = OperationType.UPDATE)
    @PostMapping("/change-status/{id}")
    public Result<?> changeStatus(@PathVariable Long id, @RequestParam Integer status) {
        userService.changeStatus(id, status);
        return Result.success("状态修改成功");
    }

    @ApiOperation("修改用户状态（REST风格）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:update')")
    @OperationLog(module = "用户管理", description = "修改用户", type = OperationType.UPDATE)
    @PutMapping("/{id}/status")
    public Result<?> changeStatusRest(@PathVariable Long id, @RequestParam Integer status) {
        userService.changeStatus(id, status);
        return Result.success("状态修改成功");
    }

    @ApiOperation("修改用户")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:update')")
    @OperationLog(module = "用户管理", description = "修改用户", type = OperationType.UPDATE)
    @PutMapping("/{id}")
    public Result<?> update(@PathVariable Long id, @RequestBody UserUpdateDTO dto) {
        userService.update(id, dto);
        return Result.success("修改成功");
    }

    @ApiOperation("修改用户（无路径ID）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:update')")
    @OperationLog(module = "用户管理", description = "修改用户", type = OperationType.UPDATE)
    @PutMapping
    public Result<?> update(@RequestBody UserUpdateDTO dto) {
        userService.update(dto);
        return Result.success("修改成功");
    }

    @ApiOperation("删除用户")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:delete')")
    @OperationLog(module = "用户管理", description = "删除用户", type = OperationType.DELETE)
    @DeleteMapping("/{id:\\d+}")
    public Result<?> delete(@PathVariable Long id) {
        userService.delete(id);
        return Result.success("删除成功");
    }

    @ApiOperation("批量删除用户")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:delete')")
    @OperationLog(module = "用户管理", description = "删除用户", type = OperationType.DELETE)
    @DeleteMapping("/batch")
    public Result<?> deleteBatch(@RequestBody List<Long> ids) {
        userService.deleteBatch(ids);
        return Result.success("删除成功");
    }

    @ApiOperation("重置密码")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:reset-pwd')")
    @OperationLog(module = "用户管理", description = "重置用户密码", type = OperationType.UPDATE)
    @PutMapping("/{id}/reset-password")
    public Result<Map<String, String>> resetPassword(@PathVariable Long id, @RequestBody(required = false) Map<String, String> body) {
        String inputPassword = null;
        if (body != null && body.get("password") != null && !body.get("password").trim().isEmpty()) {
            inputPassword = body.get("password");
        }
        // 不传密码时由后端自动生成强密码
        String newPassword = userService.resetPassword(id, inputPassword);
        Map<String, String> data = new HashMap<>();
        data.put("password", newPassword);
        data.put("username", "");
        return Result.success("密码重置成功，新密码为：" + newPassword, data);
    }

    @ApiOperation("查询可选择的员工列表（未关联账号）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:view')")
    @GetMapping("/employees")
    public Result<List<Map<String, Object>>> getAvailableEmployees(@RequestParam(required = false) String keyword) {
        List<Map<String, Object>> list = userService.getAvailableEmployees();
        if (keyword != null && !keyword.trim().isEmpty()) {
            String kw = keyword.trim().toLowerCase();
            list = list.stream().filter(m -> {
                String name = m.get("realName") != null ? m.get("realName").toString().toLowerCase() : "";
                String no = m.get("employeeNo") != null ? m.get("employeeNo").toString().toLowerCase() : "";
                return name.contains(kw) || no.contains(kw);
            }).collect(java.util.stream.Collectors.toList());
        }
        return Result.success(list);
    }

    @ApiOperation("从员工创建用户")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:create')")
    @OperationLog(module = "用户管理", description = "新增用户", type = OperationType.INSERT)
    @PostMapping("/add-from-employee")
    public Result<?> addFromEmployee(@Validated @RequestBody AddUserFromEmployeeDTO dto) {
        userService.addFromEmployee(dto);
        return Result.success("创建用户成功，初始密码为123456");
    }

    @ApiOperation("从员工创建用户(兼容路径)")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:user:create')")
    @OperationLog(module = "用户管理", description = "新增用户", type = OperationType.INSERT)
    @PostMapping("/create-from-employee")
    public Result<?> createFromEmployee(@RequestBody Map<String, Object> body) {
        AddUserFromEmployeeDTO dto = new AddUserFromEmployeeDTO();
        if (body.get("employeeId") != null) dto.setEmployeeId(Long.valueOf(body.get("employeeId").toString()));
        userService.addFromEmployee(dto);
        return Result.success("创建用户成功，初始密码为123456");
    }
}
