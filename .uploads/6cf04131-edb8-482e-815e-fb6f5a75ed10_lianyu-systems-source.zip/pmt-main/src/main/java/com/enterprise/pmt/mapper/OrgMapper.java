package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.Org;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

@Mapper
public interface OrgMapper extends BaseMapper<Org> {

    /**
     * 检测当前库中 pmt_org 表是否存在指定列名（用于安全兼容新老库 schema 差异）。
     * 数据库名字段从 connection 取当前 catalog；information_schema 匹配不到表示列不存在。
     */
    @Select("SELECT COUNT(*) FROM information_schema.COLUMNS " +
            "WHERE TABLE_SCHEMA = DATABASE() " +
            "AND TABLE_NAME = 'pmt_org' " +
            "AND COLUMN_NAME = #{columnName}")
    int countOrgColumn(@Param("columnName") String columnName);

    /**
     * 仅在 manager 列存在时，把单个 org 的 manager 姓名写入 pmt_org。
     * 在旧库（无manager列）时本方法返回 0，相当于 no-op。
     * 注意：这里直接用原生 SQL，不走 MyBatis-Plus entity 映射，保证兼容性。
     */
    @Update("<script>" +
            "UPDATE pmt_org SET manager = #{manager} WHERE id = #{id}" +
            "</script>")
    int updateManagerName(@Param("id") Long id, @Param("manager") String manager);

    /**
     * 批量查询所有 org 的 manager 姓名（manager 列存在时）。
     * 返回 Map(id, managerName) 便于 service 层组装。
     * 列不存在时返回空 Map，不会抛错。
     */
    @Select("<script>" +
            "SELECT id, manager AS mgr_name FROM pmt_org WHERE deleted = 0 " +
            "</script>")
    List<Map<String, Object>> selectAllManagerNames();
}
