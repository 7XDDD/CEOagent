package com.enterprise.pmt.vo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class ProjectMemberVO implements Serializable {
    private Long id;
    private Long projectId;
    private Long userId;
    private String userName;
    private String roleInProject;
    private BigDecimal hourRate;
    private BigDecimal workload;
    private Integer status;
}
