package com.enterprise.pmt.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.entity.PmtCostActual;
import com.enterprise.pmt.entity.PmtCostBudget;
import com.enterprise.pmt.entity.PmtCostBudgetItem;
import com.enterprise.pmt.entity.PmtCostCategory;
import com.enterprise.pmt.mapper.PmtCostActualMapper;
import com.enterprise.pmt.mapper.PmtCostBudgetMapper;
import com.enterprise.pmt.mapper.PmtCostCategoryMapper;
import com.enterprise.pmt.service.CostService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(tags = "成本管理")
@RestController
@RequestMapping("/costs")
public class CostController {

    private final CostService costService;
    private final PmtCostCategoryMapper categoryMapper;
    private final PmtCostBudgetMapper budgetMapper;
    private final PmtCostActualMapper actualMapper;

    public CostController(CostService costService,
                          PmtCostCategoryMapper categoryMapper,
                          PmtCostBudgetMapper budgetMapper,
                          PmtCostActualMapper actualMapper) {
        this.costService = costService;
        this.categoryMapper = categoryMapper;
        this.budgetMapper = budgetMapper;
        this.actualMapper = actualMapper;
    }

    @ApiOperation("成本统计")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:view')")
    @GetMapping("/stats")
    public Result<Map<String, Object>> stats() {
        Map<String, Object> data = new HashMap<>();
        try {
            data.put("totalCategories", categoryMapper.countAllActive());
            data.put("totalBudgets", budgetMapper.countAll());
            data.put("totalBudgetAmount", budgetMapper.sumTotalBudget());
            data.put("totalActualAmount", actualMapper.sumTotalActual());
            LocalDate now = LocalDate.now();
            data.put("monthlyBudgetAmount", budgetMapper.sumMonthlyBudget(now.getYear(), now.getMonthValue()));
            data.put("monthlyActualAmount", actualMapper.sumMonthlyActual(now.getYear(), now.getMonthValue()));
        } catch (Exception e) {
            data.put("totalCategories", 0L);
            data.put("totalBudgets", 0L);
            data.put("totalBudgetAmount", BigDecimal.ZERO);
            data.put("totalActualAmount", BigDecimal.ZERO);
            data.put("monthlyBudgetAmount", BigDecimal.ZERO);
            data.put("monthlyActualAmount", BigDecimal.ZERO);
        }
        return Result.success(data);
    }

    @ApiOperation("分页查询成本分类")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:view')")
    @GetMapping("/categories/page")
    public Result<Page<PmtCostCategory>> pageCategories(@RequestParam(defaultValue = "1") int pageNum,
                                                        @RequestParam(defaultValue = "10") int pageSize,
                                                        @RequestParam(required = false) String keyword,
                                                        @RequestParam(required = false) Integer status) {
        return Result.success(costService.pageCategory(pageNum, pageSize, keyword, status));
    }

    @ApiOperation("获取所有成本分类")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:view')")
    @GetMapping("/categories/list")
    public Result<List<PmtCostCategory>> listCategories() {
        return Result.success(costService.listCategory());
    }

    @ApiOperation("获取成本分类详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:view')")
    @GetMapping("/categories/{id}")
    public Result<PmtCostCategory> getCategoryDetail(@PathVariable Long id) {
        return Result.success(costService.getCategoryById(id));
    }

    @ApiOperation("创建成本分类")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:create')")
    @PostMapping("/categories")
    @OperationLog("创建成本分类")
    public Result<Long> createCategory(@RequestBody PmtCostCategory category) {
        return Result.success(costService.createCategory(category));
    }

    @ApiOperation("更新成本分类")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:update')")
    @PutMapping("/categories/{id:\\d+}")
    @OperationLog("更新成本分类")
    public Result<Boolean> updateCategory(@PathVariable Long id, @RequestBody PmtCostCategory category) {
        return Result.success(costService.updateCategory(id, category));
    }

    @ApiOperation("删除成本分类")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:delete')")
    @DeleteMapping("/categories/{id}")
    @OperationLog("删除成本分类")
    public Result<Boolean> deleteCategory(@PathVariable Long id) {
        return Result.success(costService.deleteCategory(id));
    }

    @ApiOperation("分页查询成本预算")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:view')")
    @GetMapping("/budgets/page")
    public Result<Page<PmtCostBudget>> pageBudgets(@RequestParam(defaultValue = "1") int pageNum,
                                                   @RequestParam(defaultValue = "10") int pageSize,
                                                   @RequestParam(required = false) Long projectId,
                                                   @RequestParam(required = false) String keyword,
                                                   @RequestParam(required = false) String budgetStatus) {
        return Result.success(costService.pageBudget(pageNum, pageSize, projectId, keyword, budgetStatus));
    }

    @ApiOperation("获取所有成本预算")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:view')")
    @GetMapping("/budgets/list")
    public Result<List<PmtCostBudget>> listBudgets(@RequestParam(required = false) Long projectId) {
        return Result.success(costService.listBudget(projectId));
    }

    @ApiOperation("获取成本预算详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:view')")
    @GetMapping("/budgets/{id:\\d+}")
    public Result<PmtCostBudget> getBudgetDetail(@PathVariable Long id) {
        return Result.success(costService.getBudgetById(id));
    }

    @ApiOperation("创建成本预算")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:create')")
    @PostMapping("/budgets")
    @OperationLog("创建成本预算")
    public Result<Long> createBudget(@RequestBody PmtCostBudget budget) {
        return Result.success(costService.createBudget(budget));
    }

    @ApiOperation("更新成本预算")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:update')")
    @PutMapping("/budgets/{id:\\d+}")
    @OperationLog("更新成本预算")
    public Result<Boolean> updateBudget(@PathVariable Long id, @RequestBody PmtCostBudget budget) {
        return Result.success(costService.updateBudget(id, budget));
    }

    @ApiOperation("删除成本预算")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:delete')")
    @DeleteMapping("/budgets/{id}")
    @OperationLog("删除成本预算")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> deleteBudget(@PathVariable Long id) {
        return Result.success(costService.deleteBudget(id));
    }

    @ApiOperation("获取预算明细")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:view')")
    @GetMapping("/budgets/{id}/items")
    public Result<List<PmtCostBudgetItem>> getBudgetItems(@PathVariable Long id) {
        return Result.success(costService.getBudgetItems(id));
    }

    @ApiOperation("保存预算明细")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:create')")
    @PostMapping("/budgets/{id}/items")
    @OperationLog("保存预算明细")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> saveBudgetItems(@PathVariable Long id, @RequestBody List<PmtCostBudgetItem> items) {
        return Result.success(costService.saveBudgetItems(id, items));
    }

    @ApiOperation("分页查询实际成本")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:view')")
    @GetMapping("/actual/page")
    public Result<Page<PmtCostActual>> pageActual(@RequestParam(defaultValue = "1") int pageNum,
                                                  @RequestParam(defaultValue = "10") int pageSize,
                                                  @RequestParam(required = false) Long projectId,
                                                  @RequestParam(required = false) Long categoryId,
                                                  @RequestParam(required = false) String keyword,
                                                  @RequestParam(required = false) String costStatus) {
        return Result.success(costService.pageActual(pageNum, pageSize, projectId, categoryId, keyword, costStatus));
    }

    @ApiOperation("获取所有实际成本")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:view')")
    @GetMapping("/actual/list")
    public Result<List<PmtCostActual>> listActual(@RequestParam(required = false) Long projectId) {
        return Result.success(costService.listActual(projectId));
    }

    @ApiOperation("获取实际成本详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:view')")
    @GetMapping("/actual/{id}")
    public Result<PmtCostActual> getActualDetail(@PathVariable Long id) {
        return Result.success(costService.getActualById(id));
    }

    @ApiOperation("创建实际成本")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:create')")
    @PostMapping("/actual")
    @OperationLog("创建实际成本")
    public Result<Long> createActual(@RequestBody PmtCostActual actual) {
        return Result.success(costService.createActual(actual));
    }

    @ApiOperation("更新实际成本")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:update')")
    @PutMapping("/actual/{id}")
    @OperationLog("更新实际成本")
    public Result<Boolean> updateActual(@PathVariable Long id, @RequestBody PmtCostActual actual) {
        return Result.success(costService.updateActual(id, actual));
    }

    @ApiOperation("删除实际成本")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:cost:delete')")
    @DeleteMapping("/actual/{id:\\d+}")
    @OperationLog("删除实际成本")
    public Result<Boolean> deleteActual(@PathVariable Long id) {
        return Result.success(costService.deleteActual(id));
    }
}
