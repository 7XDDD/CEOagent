package com.enterprise.pmt.approval.resolver.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.enterprise.pmt.approval.resolver.ApproverResolver;
import com.enterprise.pmt.entity.ApprovalNode;
import com.enterprise.pmt.entity.PmtProjectMember;
import com.enterprise.pmt.mapper.PmtProjectManagerMapper;
import com.enterprise.pmt.mapper.PmtProjectMemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 项目经理审批人解析器
 * <p>
 * 合并两个来源：
 * <ol>
 *   <li>项目成员表中角色为 PM 的人员（传统项目经理）</li>
 *   <li>pmt_project_manager 中 can_approve=1 的人员（含 PM、APPROVER），
 *       支持将不在项目成员中的高管/指定审批人配置为审批人</li>
 * </ol>
 */
@Component
public class ProjectManagerApproverResolver implements ApproverResolver {

    @Autowired
    private PmtProjectMemberMapper projectMemberMapper;

    @Autowired
    private PmtProjectManagerMapper projectManagerMapper;

    @Override
    public String getSupportedType() {
        return "PROJECT_MANAGER";
    }

    @Override
    public List<Long> resolveApproverIds(ApprovalNode node, Long applicantId, Long projectId, Long deptId) {
        if (projectId == null) {
            return Collections.emptyList();
        }
        Set<Long> approverIds = new LinkedHashSet<>();

        // 1. 项目成员表中的 PM
        LambdaQueryWrapper<PmtProjectMember> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(PmtProjectMember::getProjectId, projectId)
               .eq(PmtProjectMember::getRoleInProject, "PM")
               .eq(PmtProjectMember::getDeleted, 0);
        List<PmtProjectMember> members = projectMemberMapper.selectList(wrapper);
        approverIds.addAll(members.stream()
                .map(PmtProjectMember::getUserId)
                .filter(java.util.Objects::nonNull)
                .collect(Collectors.toList()));

        // 2. pmt_project_manager 中具备审批权限的人员（PM/APPROVER，含非项目成员的指定审批人）
        List<Long> designatedApprovers = projectManagerMapper.selectApproverUserIds(projectId);
        if (designatedApprovers != null) {
            approverIds.addAll(designatedApprovers);
        }

        // 3. 全局审批人：开启"全部项目（含未来新增）审批"总开关（project_id=0 & can_approve=1）
        List<Long> globalApprovers = projectManagerMapper.selectGlobalApproverUserIds();
        if (globalApprovers != null) {
            approverIds.addAll(globalApprovers);
        }

        return approverIds.stream().distinct().collect(Collectors.toList());
    }
}
