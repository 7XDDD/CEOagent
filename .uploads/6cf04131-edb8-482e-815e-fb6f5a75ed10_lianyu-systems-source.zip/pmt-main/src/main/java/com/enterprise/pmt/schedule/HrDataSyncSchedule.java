package com.enterprise.pmt.schedule;

import com.enterprise.pmt.config.HrProperties;
import com.enterprise.pmt.entity.SyncTaskConfig;
import com.enterprise.pmt.service.SyncConfigService;
import com.enterprise.pmt.service.SyncTaskExecutor;
import com.enterprise.pmt.service.SyncTaskExecutor.SyncExecutionResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledFuture;

@Slf4j
@Component
@RequiredArgsConstructor
public class HrDataSyncSchedule {

    private final TaskScheduler taskScheduler;
    private final SyncConfigService syncConfigService;
    private final SyncTaskExecutor syncTaskExecutor;
    private final HrProperties hrProperties;

    private final Map<Long, ScheduledFuture<?>> scheduledTasks = new ConcurrentHashMap<>();

    @EventListener(ApplicationReadyEvent.class)
    public void onAppReady() {
        refreshAllTasks();
        log.info("数据同步定时任务已初始化，HR集成启用状态：{}", hrProperties.isEnabled());
    }

    public synchronized void refreshAllTasks() {
        for (ScheduledFuture<?> f : scheduledTasks.values()) {
            f.cancel(false);
        }
        scheduledTasks.clear();

        if (!hrProperties.isEnabled()) {
            log.info("HR集成未启用(pmt.hr.enabled=false)，跳过定时任务注册。");
            return;
        }

        List<SyncTaskConfig> tasks = syncConfigService.listTasks();
        for (SyncTaskConfig t : tasks) {
            if (t.getEnabled() != null && t.getEnabled() == 1 && t.getCron() != null && !t.getCron().isEmpty()) {
                scheduleTask(t);
            }
        }
        log.info("已注册{}个数据同步定时任务", scheduledTasks.size());
    }

    public synchronized void refreshTask(Long taskId) {
        cancelTask(taskId);
        SyncTaskConfig t = syncConfigService.getById(taskId);
        if (t != null && t.getEnabled() != null && t.getEnabled() == 1
                && t.getCron() != null && !t.getCron().isEmpty()
                && hrProperties.isEnabled()) {
            scheduleTask(t);
        }
    }

    private void scheduleTask(SyncTaskConfig t) {
        try {
            CronTrigger trigger = new CronTrigger(t.getCron());
            ScheduledFuture<?> future = taskScheduler.schedule(
                    () -> executeTask(t.getId(), "SCHEDULED"),
                    trigger
            );
            scheduledTasks.put(t.getId(), future);
            log.info("已注册定时任务[{}]({})，cron={}", t.getTaskName(), t.getTaskKey(), t.getCron());
        } catch (Exception e) {
            log.error("注册定时任务[{}]失败：{}", t.getTaskName(), e.getMessage());
        }
    }

    private void cancelTask(Long taskId) {
        ScheduledFuture<?> f = scheduledTasks.remove(taskId);
        if (f != null) {
            f.cancel(false);
        }
    }

    public void executeTask(Long taskId, String triggerType) {
        SyncTaskConfig t = syncConfigService.getById(taskId);
        if (t == null) {
            log.warn("任务ID={}不存在，无法执行", taskId);
            return;
        }
        if (t.getEnabled() == null || t.getEnabled() != 1) {
            log.info("任务[{}]已禁用，跳过执行", t.getTaskName());
            return;
        }
        String syncType = t.getSyncType() != null ? t.getSyncType() : t.getTaskKey();
        boolean isHrBuiltin = ("org".equals(syncType) || "employee".equals(syncType)
                || "overtime".equals(syncType) || "attendance".equals(syncType));
        if (isHrBuiltin && !hrProperties.isEnabled()) {
            log.info("HR集成未启用，跳过HR定时任务[{}]", t.getTaskName());
            return;
        }

        Instant start = Instant.now();
        log.info("开始执行数据同步任务[{}]({})，触发方式：{}", t.getTaskName(), t.getTaskKey(), triggerType);
        try {
            SyncExecutionResult result = syncTaskExecutor.execute(t, triggerType);
            long duration = Duration.between(start, Instant.now()).toMillis();
            if ("http".equals(syncType)) {
                syncConfigService.logHttpSync(t.getTaskKey(), t.getTaskName(), triggerType,
                        result.isSuccess(), result.getMessage(),
                        result.getHttpStatus() == null ? 0 : result.getHttpStatus(),
                        result.getResponseBody(),
                        duration, result.isSuccess() ? null : result.getErrorMsg());
            } else {
                syncConfigService.logSync(t.getTaskKey(), t.getTaskName(), triggerType,
                        result.isSuccess(), result.getMessage(),
                        result.getAdded(), result.getUpdated(), result.getDeleted(), result.getTotal(),
                        duration, result.isSuccess() ? null : result.getErrorMsg());
            }
            log.info("数据同步任务[{}]执行完成：{}，耗时{}ms", t.getTaskName(), result.getMessage(), duration);
        } catch (Exception e) {
            long duration = Duration.between(start, Instant.now()).toMillis();
            log.error("数据同步任务[{}]执行异常：{}", t.getTaskName(), e.getMessage(), e);
            if ("http".equals(syncType)) {
                syncConfigService.logHttpSync(t.getTaskKey(), t.getTaskName(), triggerType,
                        false, "执行异常：" + e.getMessage(), 0, null,
                        duration, e.getMessage());
            } else {
                syncConfigService.logSync(t.getTaskKey(), t.getTaskName(), triggerType,
                        false, "执行异常：" + e.getMessage(), 0, 0, 0, 0,
                        duration, e.getMessage());
            }
        }
    }
}
