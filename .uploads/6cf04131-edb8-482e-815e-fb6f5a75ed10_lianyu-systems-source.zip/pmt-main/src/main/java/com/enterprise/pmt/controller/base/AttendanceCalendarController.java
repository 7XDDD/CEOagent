package com.enterprise.pmt.controller.base;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.annotation.OperationLog.OperationType;
import com.enterprise.pmt.common.BusinessException;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.ResultCode;
import com.enterprise.pmt.config.HrProperties;
import com.enterprise.pmt.entity.PmtAttendanceCalendar;
import com.enterprise.pmt.mapper.PmtAttendanceCalendarMapper;
import com.enterprise.pmt.service.HrDataService;
import com.enterprise.pmt.vo.AttendanceCalendarVO;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/base/attendance-calendar")
@RequiredArgsConstructor
public class AttendanceCalendarController {

    private final HrDataService hrDataService;
    private final HrProperties hrProperties;
    private final PmtAttendanceCalendarMapper calendarMapper;

    @PreAuthorize("@permissionChecker.hasPermission('pmt:attendance:view')")
    @GetMapping("/month")
    public Result<List<AttendanceCalendarVO>> listByMonth(
            @RequestParam(required = false) Integer year,
            @RequestParam(required = false) Integer month) {
        LocalDate now = LocalDate.now();
        int y = year != null ? year : now.getYear();
        int m = month != null ? month : now.getMonthValue();
        return Result.success(hrDataService.listAttendanceCalendar(y, m));
    }

    @GetMapping("/range")
    public Result<List<AttendanceCalendarVO>> listByRange(
            @RequestParam String startDate,
            @RequestParam String endDate) {
        return Result.success(hrDataService.listAttendanceCalendarByRange(startDate, endDate));
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:attendance:view')")
    @GetMapping("/{id:\\d+}")
    public Result<PmtAttendanceCalendar> getById(@PathVariable Long id) {
        return Result.success(calendarMapper.selectById(id));
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:attendance:view')")
    @GetMapping("/by-date")
    public Result<PmtAttendanceCalendar> getByDate(@RequestParam String date) {
        LocalDate calDate = LocalDate.parse(date);
        LambdaQueryWrapper<PmtAttendanceCalendar> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(PmtAttendanceCalendar::getCalDate, calDate);
        return Result.success(calendarMapper.selectOne(wrapper));
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:attendance:view')")
    @GetMapping("/hr-mode")
    public Result<Map<String, Object>> getHrMode() {
        Map<String, Object> result = new HashMap<>();
        result.put("hrMode", hrProperties.isEnabled());
        result.put("readOnly", hrProperties.isEnabled());
        return Result.success(result);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:attendance:create')")
    @OperationLog(module = "考勤日历", description = "HR同步考勤", type = OperationType.OTHER)
    @PostMapping("/sync")
    public Result<Integer> syncFromHr() {
        checkHrEnabled();
        int count = hrDataService.syncAttendanceCalendar();
        return Result.success("同步成功，共同步" + count + "条考勤日历数据", count);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:attendance:create')")
    @OperationLog(module = "考勤日历", description = "新增考勤日历", type = OperationType.INSERT)
    @PostMapping
    public Result<PmtAttendanceCalendar> save(@RequestBody PmtAttendanceCalendar entity) {
        LocalDate calDate = entity.getCalDate();
        if (calDate == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "日期不能为空");
        }
        if (entity.getDayType() == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "日期类型不能为空");
        }
        entity.setCalYear(calDate.getYear());
        entity.setCalMonth(calDate.getMonthValue());

        if (entity.getId() != null) {
            calendarMapper.updateById(entity);
        } else {
            LambdaQueryWrapper<PmtAttendanceCalendar> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(PmtAttendanceCalendar::getCalDate, calDate);
            PmtAttendanceCalendar existing = calendarMapper.selectOne(wrapper);
            if (existing != null) {
                entity.setId(existing.getId());
                calendarMapper.updateById(entity);
            } else {
                calendarMapper.insert(entity);
            }
        }
        return Result.success(entity);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:attendance:delete')")
    @OperationLog(module = "考勤日历", description = "删除考勤日历", type = OperationType.DELETE)
    @DeleteMapping("/{id:\\d+}")
    public Result<Void> delete(@PathVariable Long id) {
        calendarMapper.deleteById(id);
        return Result.success();
    }

    private void checkHrEnabled() {
        if (!hrProperties.isEnabled()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR系统集成未启用（pmt.hr.enabled=false），无法执行同步操作");
        }
    }
}
