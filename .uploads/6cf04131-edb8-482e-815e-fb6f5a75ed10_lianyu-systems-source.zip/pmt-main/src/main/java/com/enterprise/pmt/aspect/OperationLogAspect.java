package com.enterprise.pmt.aspect;

import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.SecurityContextUtil;
import com.enterprise.pmt.entity.User;
import com.enterprise.pmt.mapper.UserMapper;
import com.enterprise.pmt.service.OperationLogService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

@Slf4j
@Aspect
@Component
public class OperationLogAspect {

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private OperationLogService operationLogService;

    @Autowired
    private UserMapper userMapper;

    @Pointcut("@annotation(com.enterprise.pmt.annotation.OperationLog)")
    public void operationLogPointcut() {
    }

    @Around("operationLogPointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object result = null;
        Exception exception = null;

        try {
            result = joinPoint.proceed();
            return result;
        } catch (Exception e) {
            exception = e;
            throw e;
        } finally {
            long costTime = System.currentTimeMillis() - startTime;
            try {
                saveOperationLog(joinPoint, result, exception, costTime);
            } catch (Exception e) {
                log.error("记录操作日志失败", e);
            }
        }
    }

    private void saveOperationLog(ProceedingJoinPoint joinPoint, Object result, Exception exception, long costTime) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        OperationLog operationLogAnnotation = method.getAnnotation(OperationLog.class);

        if (operationLogAnnotation == null) {
            return;
        }

        String username = getCurrentUsername();
        Long userId = getCurrentUserId();
        String realName = resolveRealName(userId, username);
        HttpServletRequest request = getCurrentRequest();
        String ip = request != null ? getIpAddress(request) : "unknown";
        String requestUri = request != null ? request.getRequestURI() : "";
        String requestMethod = request != null ? request.getMethod() : "";
        String methodName = signature.getDeclaringType().getSimpleName() + "." + signature.getName();

        String operationDesc = buildOperationDescription(joinPoint, operationLogAnnotation, requestUri);
        String module = resolveModule(operationLogAnnotation.module(), requestUri, signature);

        com.enterprise.pmt.entity.OperationLog opLog = new com.enterprise.pmt.entity.OperationLog();
        opLog.setSystemType("PMT");
        opLog.setModule(module);
        opLog.setType(operationLogAnnotation.type().name());
        opLog.setDescription(operationDesc);
        opLog.setRequestMethod(requestMethod);
        opLog.setUsername(username);
        opLog.setRealName(realName);
        opLog.setIp(ip);
        opLog.setRequestUrl(requestUri);
        opLog.setMethod(methodName);
        opLog.setDuration(costTime);
        opLog.setStatus(exception != null ? 0 : (result instanceof Result && ((Result<?>) result).getCode() != 200 ? 0 : 1));
        opLog.setCreatedBy(userId);

        if (operationLogAnnotation.recordParams()) {
            String params = getParamsJson(joinPoint, signature);
            opLog.setRequestParams(params.length() > 4000 ? params.substring(0, 4000) : params);
        }

        if (operationLogAnnotation.recordResult() && result != null) {
            String resultJson = toJson(result);
            opLog.setResponseResult(resultJson.length() > 4000 ? resultJson.substring(0, 4000) : resultJson);
        }

        if (exception != null) {
            String errMsg = exception.getMessage();
            opLog.setErrorMsg(errMsg != null && errMsg.length() > 2000 ? errMsg.substring(0, 2000) : errMsg);
        }

        operationLogService.saveLog(opLog);
    }

    private String resolveRealName(Long userId, String fallback) {
        if (userId == null) return fallback;
        try {
            User u = userMapper.selectById(userId);
            if (u != null && u.getRealName() != null && !u.getRealName().isEmpty()) {
                return u.getRealName();
            }
        } catch (Exception e) {
            log.debug("查询用户真实姓名失败 userId={}", userId, e);
        }
        return fallback;
    }

    /**
     * 推断模块名：优先使用注解中配置的module；否则从请求URI中推断
     * 如 /pmt/base/employees/save -> 员工管理；/timesheets/save -> 工时管理
     */
    private String resolveModule(String annotationModule, String requestUri, MethodSignature signature) {
        if (annotationModule != null && !annotationModule.isEmpty()) {
            return annotationModule;
        }
        if (requestUri == null) return "其他";
        String uri = requestUri;
        // 去掉context-path
        if (uri.startsWith("/api")) uri = uri.substring(4);
        String[] parts = uri.split("/");
        if (parts.length >= 3) {
            String module = parts[2];
            // 基础映射
            switch (module) {
                case "employees": return "员工管理";
                case "org": case "organization": return "组织架构";
                case "projects": return "项目管理";
                case "customers": return "客户管理";
                case "timesheets": return "工时管理";
                case "timesheet": return "工时管理";
                case "contracts": return "合同管理";
                case "invoices": return "发票管理";
                case "materials": return "物料管理";
                case "milestones": return "里程碑";
                case "costs": return "成本管理";
                case "settlement": return "结算管理";
                case "payments": return "付款管理";
                case "sync-config": return "数据同步";
                case "leaves": case "leave": return "请假数据";
                case "overtime": return "加班数据";
                case "attendance": return "考勤日历";
                case "users": return "用户管理";
                case "roles": return "角色管理";
                case "permissions": return "权限管理";
                case "dicts": return "业务字典";
                case "approval-flows": return "审批流程";
                case "dashboard": return "仪表盘";
                case "login": case "auth": return "认证";
                case "operation-logs": return "操作日志";
                case "login-logs": return "登录日志";
                default: return module;
            }
        }
        return "其他";
    }

    private String buildOperationDescription(ProceedingJoinPoint joinPoint, OperationLog annotation, String requestUri) {
        StringBuilder desc = new StringBuilder();
        String description = annotation.description();
        if (description == null || description.isEmpty()) {
            description = annotation.value();
        }
        desc.append(description);

        String targetInfo = extractTargetInfo(joinPoint, requestUri);
        if (!targetInfo.isEmpty()) {
            desc.append(" [").append(targetInfo).append("]");
        }

        return desc.toString();
    }

    private String extractTargetInfo(ProceedingJoinPoint joinPoint, String requestUri) {
        StringBuilder info = new StringBuilder();

        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Parameter[] parameters = signature.getMethod().getParameters();
        Object[] args = joinPoint.getArgs();

        for (int i = 0; i < parameters.length; i++) {
            Object arg = args[i];
            if (arg == null) continue;

            String paramName = parameters[i].getName();
            if ("id".equalsIgnoreCase(paramName)) {
                if (info.length() > 0) info.append(" ");
                info.append("ID=").append(arg);
            } else if (arg instanceof Long && paramName.toLowerCase().endsWith("id")) {
                if (info.length() > 0) info.append(" ");
                info.append(paramName).append("=").append(arg);
            } else if (paramName.contains("ids") || paramName.contains("Ids")) {
                if (info.length() > 0) info.append(" ");
                info.append(paramName).append("=").append(toJson(arg));
            }
        }

        return info.toString();
    }

    private String getCurrentUsername() {
        try {
            return SecurityContextUtil.getCurrentUsername();
        } catch (Exception e) {
            return "unknown";
        }
    }

    private Long getCurrentUserId() {
        try {
            return SecurityContextUtil.getCurrentUserId();
        } catch (Exception e) {
            return null;
        }
    }

    private HttpServletRequest getCurrentRequest() {
        try {
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            return attributes != null ? attributes.getRequest() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private String getIpAddress(HttpServletRequest request) {
        if (request == null) {
            return "unknown";
        }
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        return ip;
    }

    private String getParamsJson(ProceedingJoinPoint joinPoint, MethodSignature signature) {
        Object[] args = joinPoint.getArgs();
        Parameter[] parameters = signature.getMethod().getParameters();

        if (args == null || args.length == 0 || parameters == null || parameters.length == 0) {
            return "";
        }

        StringBuilder params = new StringBuilder("{");
        for (int i = 0; i < parameters.length; i++) {
            if (i > 0) params.append(", ");
            params.append("\"").append(parameters[i].getName()).append("\":");

            Object arg = args[i];
            if (arg == null) {
                params.append("null");
            } else if (arg instanceof String || arg instanceof Number || arg instanceof Boolean) {
                params.append(toJson(arg));
            } else {
                String json = toJson(arg);
                params.append(json.length() > 500 ? "\"数据对象\"" : json);
            }
        }
        params.append("}");

        return params.toString();
    }

    private String toJson(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            return "序列化失败";
        }
    }
}
