package com.enterprise.pmt.vo;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class PaymentReceiptVO {
    private Long id;
    private String receiptNo;
    private Long contractId;
    private String contractNo;
    private Long customerId;
    private String customerName;
    private LocalDate receiptDate;
    private BigDecimal receiptAmount;
    private String currency;
    private BigDecimal receiptAmountCny;
    private String paymentMethod;
    private String receiptStatus;
    private String remark;
    private LocalDateTime createTime;
}
