package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.SysRoleProject;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface SysRoleProjectMapper extends BaseMapper<SysRoleProject> {

    List<Long> findProjectIdsByRoleId(@Param("roleId") Long roleId);

    int deleteByRoleId(@Param("roleId") Long roleId);
}
