package com.enterprise.pmt.vo;

import com.enterprise.pmt.entity.PmtTimesheetAnomaly;
import com.enterprise.pmt.entity.PmtTimesheetApprovalLog;
import com.enterprise.pmt.entity.PmtTimesheetItem;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class TimesheetVO implements Serializable {
    private Long id;
    private String timesheetNo;
    private Long userId;
    private Long employeeId;
    private String jobNumber;
    private String userName;
    private String employeeName;
    private String departmentName;

    private LocalDate weekStartDate;
    private LocalDate weekEndDate;
    private Integer weekYear;
    private Integer weekOfYear;

    private Long projectId;
    private String projectCode;
    private String projectName;

    private BigDecimal totalHours;
    private BigDecimal totalDays;

    /** DRAFT/PENDING/APPROVED/REJECTED  —— 仅审批流状态，锁定/结算见 locked / settled */
    private String status;

    /** 0 未锁定 / 1 已锁定（仅 APPROVED + 结算性质成员才能锁定） */
    private Integer locked;

    /** 0 未结算 / 1 已结算 / 2 部分结算（按天结算粒度） */
    private Integer settled;

    /** 未结算工时数（非持久化，列表展示用） */
    private java.math.BigDecimal unsettledHours;

    /** 已结算工时数（非持久化，列表展示用） */
    private java.math.BigDecimal settledHours;

    private Long currentNodeId;
    private String currentNodeName;
    private Long flowId;

    private LocalDateTime submitTime;
    private LocalDateTime approveTime;
    private LocalDateTime rejectTime;
    private String rejectReason;

    private Integer isSettlement;
    private Long settlementBatchId;
    private String settlementBatchNo;
    private LocalDateTime settlementTime;
    private String source;
    private String remark;

    /** 任务描述 */
    private String taskDescription;

    /** 工时不足原因 */
    private String shortageReason;

    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    /** 关联的工时明细 */
    private List<PmtTimesheetItem> items;

    /** 审批记录 */
    private List<PmtTimesheetApprovalLog> approvalLogs;

    /** 异常列表（未消除） */
    private List<PmtTimesheetAnomaly> anomalies;

    /** 异常数量（用于列表展示） */
    private Integer anomalyCount;

    /** 是否存在异常 */
    private Boolean hasAnomaly;

    /** 审批实例ID */
    private Long approvalInstanceId;

    /** 是否可以撤回 */
    private Boolean canWithdraw;

    /** 是否可以审批 */
    private Boolean canApprove;

    /**
     * 「当前登录用户」在该审批单下的最后一条动作意见。
     * - 用于「已审批列表」显示的「审批意见」列：展示当前审批人自己填的 remark，
     *   而不是单上其他人（尤其是上一轮被驳回的 E010 / E005）的 rejectReason，
     *   避免会签 / 多轮审批 下"我明明点了同意，列表还显示别人的驳回意见"。
     * - 若当前人对该单没有任何 APPROVE/REJECT 记录，则此字段为 null。
     */
    private String approverComment;

    /**
     * 当前登录用户在该单上的最后一次操作结果（APPROVE/REJECT），
     * 供前端区分「我已通过 / 我已驳回」时不依赖整单 status。
     */
    private String approverActionResult;

    /** 工时性质汇总（列表展示用） */
    private String workNatureText;

    /** 项目成员工时性质：SETTLE=结算，NON_SETTLE=不结算 */
    private String memberWorkNature;

    /** 审批链节点列表 */
    private List<ApprovalNodeVO> approvalNodes;

    /** 是否工时不足（动态计算：总工时<标准工时） */
    private Boolean underHours;

    /** 异常原因汇总（tooltip用） */
    private String anomalyReasons;

    /**
     * 会签/审批进度文字摘要（列表页显示，如："E005 已通过，待 E010、E007 审批（1/3）"）。
     * - APPROVED/REJECTED 节点：显示所有通过/驳回者姓名
     * - RUNNING/PENDING 中间态（含 AND 会签未集齐）：区分已签与待签，显示 x/y 进度
     * - DRAFT 或没有审批实例：null
     */
    private String approvalProgressText;

    /** 当前节点（或当前会签组）的已签/待签详情，供前端 status 列 tooltip 和 my-timesheet/approval 等页面使用。
     *  等价于 approvalNodes 中「仍停在 PENDING 的节点组」的简化表示，列表页不再需要额外解析 approvalNodes。 */
    private String currentNodeSignerTip;
}
