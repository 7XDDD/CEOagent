package com.enterprise.pmt.controller;

import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.SecurityContextUtil;
import com.enterprise.pmt.service.ProjectService;
import com.enterprise.pmt.vo.ProjectVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Api(tags = "项目API（工时模块用）")
@RestController
@RequestMapping("/projects")
public class ProjectApiController {

    private final ProjectService projectService;

    public ProjectApiController(ProjectService projectService) {
        this.projectService = projectService;
    }

    @ApiOperation("查询我参与的项目")
    @GetMapping("/my")
    public Result<List<ProjectVO>> myProjects() {
        Long userId = SecurityContextUtil.getCurrentUserId();
        return Result.success(projectService.listMyProjects(userId));
    }
}
