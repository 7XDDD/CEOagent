package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.dto.EmployeeQueryDTO;
import com.enterprise.pmt.entity.PmtEmployee;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtEmployeeMapper extends BaseMapper<PmtEmployee> {

    Page<PmtEmployee> selectPageList(Page<PmtEmployee> page, @Param("query") EmployeeQueryDTO queryDTO);

    List<PmtEmployee> selectListByCondition(@Param("query") EmployeeQueryDTO queryDTO);

    PmtEmployee selectByJobNumber(@Param("jobNumber") String jobNumber);

    List<PmtEmployee> selectAllActive();
}
