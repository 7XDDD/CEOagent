package com.enterprise.pmt.controller;

import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.security.JwtTokenUtil;
import com.enterprise.pmt.security.LoginUser;
import com.enterprise.pmt.security.SecurityUtils;
import com.enterprise.pmt.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(tags = "认证接口")
@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    private final JwtTokenUtil jwtTokenUtil;

    @Value("${pmt.jwt.header:Authorization}")
    private String tokenHeader;

    @Value("${pmt.jwt.token-prefix:Bearer }")
    private String tokenPrefix;

    public AuthController(JwtTokenUtil jwtTokenUtil) {
        this.jwtTokenUtil = jwtTokenUtil;
    }

    @ApiOperation("登录")
    @PostMapping("/login")
    public Result<Map<String, Object>> login(@RequestBody Map<String, String> loginRequest, HttpServletRequest request) {
        String username = loginRequest.get("username");
        String password = loginRequest.get("password");
        String captchaKey = loginRequest.get("captchaKey");
        String captchaCode = loginRequest.get("captchaCode");
        String clientIp = getClientIp(request);
        String userAgent = request.getHeader("User-Agent");

        UserService.LoginResult loginResult = userService.login(username, password, captchaKey, captchaCode, clientIp, userAgent);
        if (!loginResult.isSuccess()) {
            return Result.error(loginResult.getCode(), loginResult.getMessage());
        }

        Long userId = loginResult.getUser().getId();
        String uname = loginResult.getUser().getUsername();
        List<String> roles = loginResult.getRoles();
        List<String> permissions = loginResult.getPermissions();
        String token = jwtTokenUtil.generateToken(userId, uname, null, roles, permissions);
        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("tokenPrefix", tokenPrefix);
        data.put("needChangePassword", loginResult.getUser().getNeedChangePassword() != null && loginResult.getUser().getNeedChangePassword() == 1);
        Map<String, Object> userInfo = userService.getCurrentUserInfo(userId);
        data.put("userInfo", userInfo);
        return Result.success(data);
    }

    @ApiOperation("获取当前用户信息")
    @GetMapping("/info")
    public Result<Map<String, Object>> getUserInfo(HttpServletRequest request) {
        LoginUser currentUser = SecurityUtils.getCurrentUser();
        if (currentUser == null) {
            return Result.error(401, "未登录");
        }
        Map<String, Object> userInfo = userService.getCurrentUserInfo(currentUser.getUserId());
        return Result.success(userInfo);
    }

    @ApiOperation("登出")
    @PostMapping("/logout")
    public Result<Void> logout() {
        return Result.success();
    }

    @ApiOperation("更新个人信息（姓名/邮箱/手机号）")
    @PutMapping("/profile")
    public Result<?> updateProfile(@RequestBody Map<String, String> body) {
        LoginUser currentUser = SecurityUtils.getCurrentUser();
        if (currentUser == null) {
            return Result.error(401, "未登录");
        }
        boolean ok = userService.updateProfile(currentUser.getUserId(), body);
        if (!ok) {
            return Result.error("用户不存在");
        }
        return Result.success("保存成功");
    }

    @ApiOperation("修改密码（首次登录/普通改密）")
    @PostMapping("/change-password")
    public Result<?> changePassword(@RequestBody Map<String, String> body) {
        LoginUser currentUser = SecurityUtils.getCurrentUser();
        if (currentUser == null) {
            return Result.error(401, "未登录");
        }
        String oldPassword = body.get("oldPassword");
        String newPassword = body.get("newPassword");
        String err = userService.changePassword(currentUser.getUserId(), oldPassword, newPassword);
        if (err != null) {
            return Result.error(err);
        }
        return Result.success("密码修改成功");
    }

    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        return ip;
    }
}
