package com.enterprise.pmt.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * 工时保存/提交DTO（一次提交整周数据，后端按项目拆分多张工时单）
 */
@Data
public class TimesheetSaveDTO {
    /** 若为空则新建；非空则更新对应周次数据（会按项目重新拆分） */
    private List<Long> timesheetIds;
    private LocalDate weekStartDate;
    private LocalDate weekEndDate;
    private String remark;
    private String source;
    /** 工时不足原因（一周工时少于标准工时时必填） */
    private String shortageReason;
    /** 按项目分组的工时数据 */
    private List<ProjectEntry> projects;

    @Data
    public static class ProjectEntry {
        private Long projectId;
        private String projectName;
        private String projectCode;
        private Long milestoneId;
        private String milestoneName;
        /** 长度7，周一~周日，每格工时(0-8) */
        private List<BigDecimal> hours;
        /** 长度7，对应每天的 workNature，默认BILLABLE */
        private List<String> workNatures;
        /** 长度7，对应每天的工作内容 */
        private List<String> workContents;
        /** 长度7，对应每天是否远程 1=远程 0=现场，默认1 */
        private List<Integer> remoteFlags;
        /** 任务描述 */
        private String taskDescription;
        private String remark;
    }
}
