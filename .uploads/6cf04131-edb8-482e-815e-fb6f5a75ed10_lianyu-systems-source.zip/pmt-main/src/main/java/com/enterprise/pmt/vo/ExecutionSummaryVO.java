package com.enterprise.pmt.vo;

import lombok.Data;

import java.math.BigDecimal;

/**
 * 执行状态矩阵：每个员工行的 5 项汇总指标
 */
@Data
public class ExecutionSummaryVO {
    /** 预算工时 = 显示周范围内该成员+项目最新版本各周预算合计 */
    private BigDecimal budgetHours;
    /** 已使用 = 过去周 APPROVED 实际工时合计 */
    private BigDecimal usedHours;
    /** 已使用（含加班）= usedHours + 过去周已审批加班净小时 */
    private BigDecimal usedHoursWithOvertime;
    /** 剩余工时 = budgetHours - usedHours */
    private BigDecimal remainingHours;
    /** 已分配预算 = 当前周 + 未来周预算合计 */
    private BigDecimal allocatedBudgetHours;
}
