package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtCostBudgetItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtCostBudgetItemMapper extends BaseMapper<PmtCostBudgetItem> {

    List<PmtCostBudgetItem> selectByBudgetId(@Param("budgetId") Long budgetId);

    int deleteByBudgetId(@Param("budgetId") Long budgetId);
}
