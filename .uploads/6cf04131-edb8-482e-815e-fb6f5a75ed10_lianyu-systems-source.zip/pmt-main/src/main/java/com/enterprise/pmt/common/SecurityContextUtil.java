package com.enterprise.pmt.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Slf4j
public class SecurityContextUtil {

    private static final String KEY_USER_ID = "userId";
    private static final String KEY_ORG_ID = "orgId";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_ROLES = "roles";
    private static final String KEY_PERMISSIONS = "permissions";

    private static Map<String, Object> getUserContext() {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth != null && auth.getPrincipal() instanceof Map) {
                return (Map<String, Object>) auth.getPrincipal();
            }
        } catch (Exception e) {
            log.warn("获取用户上下文失败: {}", e.getMessage());
        }
        return Collections.emptyMap();
    }

    public static Long getCurrentUserId() {
        Object val = getUserContext().get(KEY_USER_ID);
        return val != null ? Long.valueOf(val.toString()) : null;
    }

    public static Long getCurrentOrgId() {
        Object val = getUserContext().get(KEY_ORG_ID);
        return val != null ? Long.valueOf(val.toString()) : null;
    }

    public static String getCurrentUsername() {
        Object val = getUserContext().get(KEY_USERNAME);
        return val != null ? val.toString() : null;
    }

    @SuppressWarnings("unchecked")
    public static List<String> getCurrentRoles() {
        Object val = getUserContext().get(KEY_ROLES);
        return val instanceof List ? (List<String>) val : Collections.emptyList();
    }

    @SuppressWarnings("unchecked")
    public static List<String> getCurrentPermissions() {
        Object val = getUserContext().get(KEY_PERMISSIONS);
        return val instanceof List ? (List<String>) val : Collections.emptyList();
    }

    public static boolean hasRole(String role) {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth == null) return false;
            String expected = role.startsWith("ROLE_") ? role : "ROLE_" + role;
            return auth.getAuthorities().stream()
                    .anyMatch(a -> expected.equalsIgnoreCase(a.getAuthority()));
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean hasAnyRole(List<String> roles) {
        if (roles == null || roles.isEmpty()) return false;
        return roles.stream().anyMatch(SecurityContextUtil::hasRole);
    }

    public static boolean hasPermission(String permissionCode) {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            if (auth == null) return false;
            return auth.getAuthorities().stream()
                    .anyMatch(a -> permissionCode.equalsIgnoreCase(a.getAuthority()));
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean hasAnyPermission(List<String> permissions) {
        if (permissions == null || permissions.isEmpty()) return false;
        return permissions.stream().anyMatch(SecurityContextUtil::hasPermission);
    }
}
