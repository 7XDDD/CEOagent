package com.enterprise.pmt.controller.base;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.common.BusinessException;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.ResultCode;
import com.enterprise.pmt.entity.PmtMaterial;
import com.enterprise.pmt.service.MaterialService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "物料管理")
@RestController
@RequestMapping("/base/materials")
public class MaterialController {

    private final MaterialService materialService;

    public MaterialController(MaterialService materialService) {
        this.materialService = materialService;
    }

    @ApiOperation("分页查询物料")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:material:view')")
    @GetMapping("/page")
    public Result<Page<PmtMaterial>> page(@RequestParam(defaultValue = "1") int pageNum,
                                          @RequestParam(defaultValue = "10") int pageSize,
                                          @RequestParam(required = false) String keyword,
                                          @RequestParam(required = false) String materialType,
                                          @RequestParam(required = false) Integer isActive) {
        Page<PmtMaterial> page = new Page<>(pageNum, pageSize);
        return Result.success(materialService.page(page, keyword, materialType, isActive));
    }

    @ApiOperation("获取所有物料")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:material:view')")
    @GetMapping("/list")
    public Result<List<PmtMaterial>> listAll() {
        return Result.success(materialService.listAll());
    }

    @ApiOperation("获取物料详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:material:view')")
    @GetMapping("/{id:\\d+}")
    public Result<PmtMaterial> getDetail(@PathVariable Long id) {
        PmtMaterial material = materialService.getById(id);
        if (material == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        return Result.success(material);
    }

    @ApiOperation("创建物料")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:material:create')")
    @PostMapping
    @OperationLog("创建物料")
    public Result<Long> create(@RequestBody PmtMaterial material) {
        materialService.save(material);
        return Result.success(material.getId());
    }

    @ApiOperation("更新物料")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:material:update')")
    @PutMapping("/{id}")
    @OperationLog("更新物料")
    public Result<Boolean> update(@PathVariable Long id, @RequestBody PmtMaterial material) {
        PmtMaterial exist = materialService.getById(id);
        if (exist == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        material.setId(id);
        return Result.success(materialService.updateById(material));
    }

    @ApiOperation("删除物料")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:material:delete')")
    @DeleteMapping("/{id}")
    @OperationLog("删除物料")
    public Result<Boolean> delete(@PathVariable Long id) {
        PmtMaterial material = materialService.getById(id);
        if (material == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        return Result.success(materialService.removeById(id));
    }
}
