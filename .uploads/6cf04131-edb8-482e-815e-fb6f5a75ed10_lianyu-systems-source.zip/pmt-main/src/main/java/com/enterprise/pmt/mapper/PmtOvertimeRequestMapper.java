package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.common.UserDataScope;
import com.enterprise.pmt.entity.PmtOvertimeRequest;
import com.enterprise.pmt.vo.OvertimeVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtOvertimeRequestMapper extends BaseMapper<PmtOvertimeRequest> {

    List<OvertimeVO> selectPageList(Page<OvertimeVO> page,
                                     @Param("keyword") String keyword,
                                     @Param("status") String status,
                                     @Param("overtimeType") String overtimeType,
                                     @Param("employeeId") Long employeeId,
                                     @Param("projectId") Long projectId,
                                     @Param("startDate") String startDate,
                                     @Param("endDate") String endDate,
                                     @Param("scope") UserDataScope scope);
}
