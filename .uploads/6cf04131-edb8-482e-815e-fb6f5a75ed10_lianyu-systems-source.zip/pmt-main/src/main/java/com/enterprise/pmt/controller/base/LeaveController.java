package com.enterprise.pmt.controller.base;

import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.annotation.OperationLog.OperationType;
import com.enterprise.pmt.common.BusinessException;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.ResultCode;
import com.enterprise.pmt.config.HrProperties;
import com.enterprise.pmt.entity.PmtEmployee;
import com.enterprise.pmt.entity.PmtLeaveRequest;
import com.enterprise.pmt.mapper.PmtEmployeeMapper;
import com.enterprise.pmt.mapper.PmtLeaveRequestMapper;
import com.enterprise.pmt.service.HrDataService;
import com.enterprise.pmt.service.DataScopeService;
import com.enterprise.pmt.service.WorkdayCalendarService;
import com.enterprise.pmt.vo.LeaveVO;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@RestController
@RequestMapping("/base/leave")
@RequiredArgsConstructor
public class LeaveController {

    private final HrDataService hrDataService;
    private final DataScopeService dataScopeService;
    private final HrProperties hrProperties;
    private final PmtLeaveRequestMapper leaveMapper;
    private final PmtEmployeeMapper employeeMapper;
    private final WorkdayCalendarService workdayCalendarService;

    private static final DateTimeFormatter DT_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private static final int WORK_START = 9 * 60;
    private static final int WORK_END = 18 * 60;
    private static final int LUNCH_START = 12 * 60;
    private static final int LUNCH_END = 13 * 60;
    private static final int MAX_DAILY_MINUTES = 8 * 60;

    @PreAuthorize("@permissionChecker.hasPermission('pmt:leave:view')")
    @GetMapping("/page")
    public Result<Page<LeaveVO>> page(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String leaveType,
            @RequestParam(required = false) Long employeeId,
            @RequestParam(required = false) String startDate,
            @RequestParam(required = false) String endDate) {
        return Result.success(hrDataService.pageLeave(pageNum, pageSize, keyword, status, leaveType, employeeId, startDate, endDate, dataScopeService.resolveCurrentUserScope()));
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:leave:view')")
    @GetMapping("/{id:\\d+}")
    public Result<PmtLeaveRequest> getById(@PathVariable Long id) {
        return Result.success(leaveMapper.selectById(id));
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:leave:view')")
    @GetMapping("/hr-mode")
    public Result<Map<String, Object>> getHrMode() {
        Map<String, Object> result = new HashMap<>();
        result.put("hrMode", hrProperties.isEnabled());
        result.put("readOnly", hrProperties.isEnabled());
        return Result.success(result);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:leave:update')")
    @PostMapping("/sync")
    public Result<Integer> syncFromHr() {
        checkHrEnabled();
        int count = hrDataService.syncLeave();
        return Result.success("同步成功，共同步" + count + "条请假数据", count);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:leave:create')")
    @OperationLog(module = "请假管理", description = "新增请假申请", type = OperationType.INSERT)
    @PostMapping
    public Result<PmtLeaveRequest> save(@RequestBody PmtLeaveRequest entity) {
        if (entity.getEmployeeId() == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请选择员工");
        }
        if (entity.getStartTime() == null || entity.getEndTime() == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "开始时间和结束时间不能为空");
        }
        if (entity.getEndTime().isBefore(entity.getStartTime())) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "结束时间不能早于开始时间");
        }
        if (entity.getLeaveType() == null) {
            entity.setLeaveType("personal");
        }
        if (entity.getApprovalStatus() == null) {
            entity.setApprovalStatus("APPROVED");
        }
        if (entity.getApplyTime() == null) {
            entity.setApplyTime(LocalDateTime.now());
        }
        if (entity.getApprovalNo() == null || entity.getApprovalNo().isEmpty()) {
            entity.setApprovalNo("LV" + System.currentTimeMillis());
        }

        BigDecimal[] duration = calcLeaveDuration(entity.getStartTime(), entity.getEndTime());
        entity.setDurationHours(duration[0]);
        if (entity.getDurationDays() == null) {
            entity.setDurationDays(duration[1]);
        }

        if (entity.getId() != null) {
            leaveMapper.updateById(entity);
        } else {
            leaveMapper.insert(entity);
        }
        return Result.success(entity);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:leave:delete')")
    @OperationLog(module = "请假管理", description = "删除请假记录", type = OperationType.DELETE)
    @DeleteMapping("/{id:\\d+}")
    public Result<Void> delete(@PathVariable Long id) {
        leaveMapper.deleteById(id);
        return Result.success();
    }

    // ==================== 导入导出 ====================

    @PreAuthorize("@permissionChecker.hasPermission('pmt:leave:view')")
    @GetMapping("/import-template")
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        ExcelWriter writer = ExcelUtil.getWriter();

        List<Map<String, Object>> demo = new ArrayList<>();
        Map<String, Object> row1 = new LinkedHashMap<>();
        row1.put("工号*", "E010");
        row1.put("员工姓名", "张三");
        row1.put("请假类型*", "事假");
        row1.put("开始时间*(yyyy-MM-dd HH:mm:ss)", "2026-08-11 09:00:00");
        row1.put("结束时间*(yyyy-MM-dd HH:mm:ss)", "2026-08-11 18:00:00");
        row1.put("审批状态", "已通过");
        row1.put("请假原因*", "个人事务");
        row1.put("备注", "");
        demo.add(row1);

        writer.write(demo, true);

        Workbook wb = writer.getWorkbook();
        Sheet sheet = wb.getSheetAt(0);
        wb.setSheetName(0, "请假数据导入");

        CellStyle textStyle = wb.createCellStyle();
        DataFormat fmt = wb.createDataFormat();
        textStyle.setDataFormat(fmt.getFormat("@"));
        textStyle.setBorderTop(BorderStyle.THIN);
        textStyle.setBorderBottom(BorderStyle.THIN);
        textStyle.setBorderLeft(BorderStyle.THIN);
        textStyle.setBorderRight(BorderStyle.THIN);

        int colCount = 8;
        for (int col = 0; col < colCount; col++) {
            sheet.setDefaultColumnStyle(col, textStyle);
            sheet.setColumnWidth(col, 22 * 256);
        }
        sheet.setColumnWidth(6, 30 * 256);

        Sheet noteSheet = wb.createSheet("填写说明");
        String[] notes = {
                "请假数据导入模板填写说明：",
                "",
                "1. 带*号的列为必填项",
                "2. 工号必须已在员工管理中存在",
                "3. 请假类型可选：年假、事假、病假、婚假、产假、陪产假、丧假、调休、其他",
                "   （或 annual/personal/sick/marriage/maternity/paternity/bereavement/compensatory/other）",
                "4. 开始时间和结束时间格式：yyyy-MM-dd HH:mm:ss",
                "5. 审批状态可选：草稿、审批中、已通过、已驳回、已撤销（默认已通过）",
                "6. 系统自动计算请假天数和小时数",
                "",
                "提示：从其他Excel拷贝数据时，请使用「选择性粘贴 → 仅粘贴值」。"
        };
        for (int i = 0; i < notes.length; i++) {
            Row nr = noteSheet.createRow(i);
            Cell nc = nr.createCell(0);
            nc.setCellValue(notes[i]);
        }
        noteSheet.setColumnWidth(0, 90 * 256);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode("请假数据导入模板.xlsx", "UTF-8"));
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:leave:create')")
    @OperationLog(module = "请假管理", description = "导入请假数据", type = OperationType.IMPORT)
    @PostMapping("/import-excel")
    public Result<Map<String, Object>> importExcel(@RequestParam("file") MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BusinessException("请选择要导入的文件");
        }

        int inserted = 0;
        int failed = 0;
        List<String> errors = new ArrayList<>();

        List<List<Object>> rows;
        try {
            ExcelReader reader = ExcelUtil.getReader(file.getInputStream());
            rows = reader.read();
            reader.close();
        } catch (Exception e) {
            throw new BusinessException("Excel 解析失败: " + e.getMessage());
        }

        if (rows == null || rows.size() <= 1) {
            Map<String, Object> result = new HashMap<>();
            result.put("inserted", 0);
            result.put("failed", 0);
            result.put("errors", Collections.singletonList("文件为空或没有数据"));
            return Result.success(result);
        }

        for (int i = 1; i < rows.size(); i++) {
            List<Object> row = rows.get(i);
            if (row == null || row.isEmpty() || isRowEmpty(row)) {
                continue;
            }
            try {
                String jobNumber = getCellStringValue(row, 0);
                String leaveTypeStr = getCellStringValue(row, 2);
                String startTimeStr = getCellStringValue(row, 3);
                String endTimeStr = getCellStringValue(row, 4);
                String statusStr = getCellStringValue(row, 5);
                String reason = getCellStringValue(row, 6);
                String remark = getCellStringValue(row, 7);

                StringBuilder errMsg = new StringBuilder();
                if (jobNumber == null) errMsg.append("工号不能为空; ");
                if (startTimeStr == null) errMsg.append("开始时间不能为空; ");
                if (endTimeStr == null) errMsg.append("结束时间不能为空; ");
                if (reason == null) errMsg.append("请假原因不能为空; ");

                if (errMsg.length() > 0) {
                    failed++;
                    errors.add("第" + (i + 1) + "行: " + errMsg.toString());
                    continue;
                }

                PmtEmployee employee = employeeMapper.selectOne(new LambdaQueryWrapper<PmtEmployee>()
                        .eq(PmtEmployee::getJobNumber, jobNumber.trim())
                        .eq(PmtEmployee::getDeleted, 0)
                        .last("LIMIT 1"));
                if (employee == null) {
                    failed++;
                    errors.add("第" + (i + 1) + "行: 工号[" + jobNumber + "]不存在");
                    continue;
                }

                String leaveType = parseLeaveType(leaveTypeStr);
                String approvalStatus = parseStatus(statusStr);

                LocalDateTime startTime;
                LocalDateTime endTime;
                try {
                    startTime = LocalDateTime.parse(startTimeStr.trim(), DT_FMT);
                    endTime = LocalDateTime.parse(endTimeStr.trim(), DT_FMT);
                } catch (Exception e) {
                    failed++;
                    errors.add("第" + (i + 1) + "行: 时间格式错误，应为 yyyy-MM-dd HH:mm:ss");
                    continue;
                }

                if (endTime.isBefore(startTime)) {
                    failed++;
                    errors.add("第" + (i + 1) + "行: 结束时间不能早于开始时间");
                    continue;
                }

                BigDecimal[] duration = calcLeaveDuration(startTime, endTime);

                PmtLeaveRequest entity = new PmtLeaveRequest();
                entity.setApprovalNo("LV" + System.currentTimeMillis() + (int)(Math.random() * 1000));
                entity.setEmployeeId(employee.getId());
                entity.setLeaveType(leaveType);
                entity.setStartTime(startTime);
                entity.setEndTime(endTime);
                entity.setApplyTime(LocalDateTime.now());
                entity.setDurationHours(duration[0]);
                entity.setDurationDays(duration[1]);
                entity.setReason(reason);
                entity.setApprovalStatus(approvalStatus);
                entity.setRemark(remark);

                leaveMapper.insert(entity);
                inserted++;

            } catch (Exception e) {
                failed++;
                errors.add("第" + (i + 1) + "行: 处理失败 - " + e.getMessage());
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("inserted", inserted);
        result.put("failed", failed);
        result.put("errors", errors.size() > 50 ? errors.subList(0, 50) : errors);
        result.put("totalErrors", errors.size());
        return Result.success(result);
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:leave:view')")
    @OperationLog(module = "请假管理", description = "导出请假数据", type = OperationType.EXPORT)
    @PostMapping("/export")
    public void export(@RequestBody(required = false) Map<String, Object> params, HttpServletResponse response) throws Exception {
        String keyword = params != null ? (String) params.get("keyword") : null;
        String status = params != null ? (String) params.get("status") : null;
        String leaveType = params != null ? (String) params.get("leaveType") : null;
        Long employeeId = params != null && params.get("employeeId") != null ? Long.valueOf(params.get("employeeId").toString()) : null;
        String startDate = params != null ? (String) params.get("startDate") : null;
        String endDate = params != null ? (String) params.get("endDate") : null;

        Page<LeaveVO> page = hrDataService.pageLeave(1, 10000, keyword, status, leaveType, employeeId, startDate, endDate, dataScopeService.resolveCurrentUserScope());
        List<LeaveVO> list = page.getRecords();

        ExcelWriter writer = ExcelUtil.getWriter();

        List<Map<String, Object>> exportData = new ArrayList<>();
        for (LeaveVO vo : list) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("审批单号", vo.getApprovalNo());
            row.put("工号", vo.getJobNumber());
            row.put("姓名", vo.getEmployeeName());
            row.put("部门", vo.getDepartmentName());
            row.put("请假类型", vo.getLeaveTypeText());
            row.put("开始时间", vo.getStartTime() != null ? vo.getStartTime().format(DT_FMT) : "");
            row.put("结束时间", vo.getEndTime() != null ? vo.getEndTime().format(DT_FMT) : "");
            row.put("天数(d)", vo.getDurationDays());
            row.put("小时(h)", vo.getDurationHours());
            row.put("申请时间", vo.getApplyTime() != null ? vo.getApplyTime().format(DT_FMT) : "");
            row.put("审批状态", vo.getApprovalStatusText());
            row.put("请假原因", vo.getReason());
            row.put("备注", vo.getRemark());
            exportData.add(row);
        }

        writer.write(exportData, true);
        writer.setColumnWidth(0, 18);
        writer.setColumnWidth(1, 10);
        writer.setColumnWidth(2, 10);
        writer.setColumnWidth(3, 16);
        writer.setColumnWidth(11, 30);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode("请假数据.xlsx", "UTF-8"));
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    // ==================== 私有方法 ====================

    private boolean isRowEmpty(List<Object> row) {
        for (Object cell : row) {
            if (cell != null && cell.toString().trim().length() > 0) {
                return false;
            }
        }
        return true;
    }

    private String getCellStringValue(List<Object> row, int index) {
        if (index >= row.size()) return null;
        Object val = row.get(index);
        if (val == null) return null;
        String s = val.toString().trim();
        return s.isEmpty() ? null : s;
    }

    private String parseLeaveType(String s) {
        if (s == null || s.trim().isEmpty()) return "personal";
        s = s.trim();
        if (s.contains("年假") || "annual".equalsIgnoreCase(s)) return "annual";
        if (s.contains("事假") || "personal".equalsIgnoreCase(s)) return "personal";
        if (s.contains("病假") || "sick".equalsIgnoreCase(s)) return "sick";
        if (s.contains("婚假") || "marriage".equalsIgnoreCase(s)) return "marriage";
        if (s.contains("产假") || "maternity".equalsIgnoreCase(s)) return "maternity";
        if (s.contains("陪产假") || "paternity".equalsIgnoreCase(s)) return "paternity";
        if (s.contains("丧假") || "bereavement".equalsIgnoreCase(s)) return "bereavement";
        if (s.contains("调休") || "compensatory".equalsIgnoreCase(s)) return "compensatory";
        if (s.contains("其他") || "other".equalsIgnoreCase(s)) return "other";
        return "personal";
    }

    private String parseStatus(String s) {
        if (s == null || s.trim().isEmpty()) return "APPROVED";
        s = s.trim();
        if (s.contains("草稿") || "DRAFT".equalsIgnoreCase(s)) return "DRAFT";
        if (s.contains("审批中") || "PENDING".equalsIgnoreCase(s)) return "PENDING";
        if (s.contains("通过") || "APPROVED".equalsIgnoreCase(s)) return "APPROVED";
        if (s.contains("驳回") || "REJECTED".equalsIgnoreCase(s)) return "REJECTED";
        if (s.contains("撤销") || "CANCELED".equalsIgnoreCase(s)) return "CANCELED";
        return "APPROVED";
    }

    private void checkHrEnabled() {
        if (!hrProperties.isEnabled()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR系统集成未启用（pmt.hr.enabled=false），无法执行同步操作");
        }
    }

    private int calcDayWorkMinutes(int startMin, int endMin) {
        int s = Math.max(startMin, WORK_START);
        int e = Math.min(endMin, WORK_END);
        if (e <= s) return 0;
        int minutes = 0;
        int morningEnd = Math.min(e, LUNCH_START);
        if (morningEnd > s) minutes += morningEnd - s;
        int afternoonStart = Math.max(s, LUNCH_END);
        if (e > afternoonStart) minutes += e - afternoonStart;
        return Math.min(minutes, MAX_DAILY_MINUTES);
    }

    /** 按起止时间预估请假时长（只计工作日），供新增/编辑弹窗实时展示，口径与保存时一致 */
    @PreAuthorize("@permissionChecker.hasPermission('pmt:leave:view')")
    @GetMapping("/calc-duration")
    public Result<Map<String, Object>> calcDuration(@RequestParam String startTime,
                                                    @RequestParam String endTime) {
        LocalDateTime start;
        LocalDateTime end;
        try {
            start = LocalDateTime.parse(startTime.trim().replace(' ', 'T'));
            end = LocalDateTime.parse(endTime.trim().replace(' ', 'T'));
        } catch (Exception e) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "时间格式错误，应为 yyyy-MM-dd HH:mm:ss");
        }
        if (end.isBefore(start)) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "结束时间不能早于开始时间");
        }
        BigDecimal[] duration = calcLeaveDuration(start, end);
        Map<String, Object> result = new HashMap<>();
        result.put("durationHours", duration[0]);
        result.put("durationDays", duration[1]);
        return Result.success(result);
    }

    /**
     * 计算请假时长：逐天统计工作时段（9:00-12:00、13:00-18:00，每天封顶8h），
     * 仅统计工作日（考勤日历 1工作日/4调休上班；无日历数据时周一~周五），休息日与法定节假日不计。
     */
    private BigDecimal[] calcLeaveDuration(LocalDateTime startTime, LocalDateTime endTime) {
        Map<LocalDate, Integer> dayTypeMap =
                workdayCalendarService.loadDayTypeMap(startTime.toLocalDate(), endTime.toLocalDate());
        int totalMinutes = 0;
        LocalDate curDate = startTime.toLocalDate();
        LocalDate endDate = endTime.toLocalDate();
        while (!curDate.isAfter(endDate)) {
            if (!workdayCalendarService.isWorkday(curDate, dayTypeMap)) {
                curDate = curDate.plusDays(1);
                continue;
            }
            int startMin = 0;
            int endMin = 24 * 60;
            if (curDate.equals(startTime.toLocalDate())) {
                startMin = startTime.getHour() * 60 + startTime.getMinute();
            }
            if (curDate.equals(endTime.toLocalDate())) {
                endMin = endTime.getHour() * 60 + endTime.getMinute();
            }
            totalMinutes += calcDayWorkMinutes(startMin, endMin);
            curDate = curDate.plusDays(1);
        }
        BigDecimal hours = BigDecimal.valueOf(totalMinutes)
                .divide(BigDecimal.valueOf(60), 1, RoundingMode.HALF_UP);
        BigDecimal days = hours.divide(BigDecimal.valueOf(8), 2, RoundingMode.HALF_UP);
        return new BigDecimal[]{hours, days};
    }
}
