package com.enterprise.pmt.approval.resolver;

import com.enterprise.pmt.entity.ApprovalNode;

import java.util.List;

/**
 * 审批人解析策略接口
 * 使用策略模式，每种审批人类型一个实现类
 * 新增审批人类型只需添加新的实现类，无需修改审批引擎核心代码
 */
public interface ApproverResolver {

    /**
     * 获取此解析器支持的审批人类型
     * 对应 ApprovalNode.approverType 的值
     */
    String getSupportedType();

    /**
     * 解析审批人ID列表
     * @param node 审批节点定义
     * @param applicantId 申请人ID
     * @param projectId 项目ID（可选）
     * @param deptId 部门ID（可选）
     * @return 审批人用户ID列表
     */
    List<Long> resolveApproverIds(ApprovalNode node, Long applicantId, Long projectId, Long deptId);

    /**
     * 获取解析后的审批人名称（用于显示）
     */
    default String resolveApproverNames(ApprovalNode node, Long applicantId, Long projectId, Long deptId) {
        return null;
    }
}
