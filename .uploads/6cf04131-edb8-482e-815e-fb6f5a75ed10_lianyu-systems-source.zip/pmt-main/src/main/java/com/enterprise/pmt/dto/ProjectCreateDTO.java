package com.enterprise.pmt.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class ProjectCreateDTO {
    private String projectCode;
    private String projectName;
    private Long signedCompanyId;
    private String signedCompany;
    private String customerCode;
    private String customerName;
    private Long customerId;
    private String projectType;
    private String projectLevel;
    private Long parentId;
    private String parentProjectCode;
    private String projectStatus;
    private Long pmId;
    private String pmName;
    private Long salesId;
    private String salesName;
    private Long orgId;
    private String orgCode;
    private String orgName;
    private LocalDate plannedStartDate;
    private LocalDate plannedEndDate;
    private LocalDate actualStartDate;
    private LocalDate actualEndDate;
    private BigDecimal plannedDays;
    private BigDecimal actualDays;
    private BigDecimal estimatedWorkDays;
    private String projectAddress;
    private BigDecimal budgetAmount;
    private String remark;
}
