package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.UserRole;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserRoleMapper extends BaseMapper<UserRole> {

    @Select("SELECT role_id FROM pmt_user_role WHERE user_id = #{userId} AND deleted = 0")
    List<Long> findRoleIdsByUserId(@Param("userId") Long userId);

    /** 判断用户是否拥有指定 role_code 的系统角色 */
    @Select("SELECT COUNT(1) FROM pmt_user_role ur " +
            "JOIN pmt_role r ON ur.role_id = r.id " +
            "WHERE ur.user_id = #{userId} AND ur.deleted = 0 AND r.deleted = 0 AND r.role_code = #{roleCode}")
    int countUserRoleByCode(@Param("userId") Long userId, @Param("roleCode") String roleCode);

    /** 查询拥有指定 role_code 的所有用户ID（主管可见域预计算用） */
    @Select("SELECT ur.user_id FROM pmt_user_role ur " +
            "JOIN pmt_role r ON ur.role_id = r.id " +
            "WHERE ur.deleted = 0 AND r.deleted = 0 AND r.role_code = #{roleCode}")
    List<Long> selectUserIdsByRoleCode(@Param("roleCode") String roleCode);

    int deleteByUserId(@Param("userId") Long userId);
}
