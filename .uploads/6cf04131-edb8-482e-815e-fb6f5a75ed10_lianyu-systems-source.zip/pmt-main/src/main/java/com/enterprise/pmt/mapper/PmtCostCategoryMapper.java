package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.entity.PmtCostCategory;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtCostCategoryMapper extends BaseMapper<PmtCostCategory> {

    Page<PmtCostCategory> selectPageList(Page<PmtCostCategory> page,
                                         @Param("keyword") String keyword,
                                         @Param("status") Integer status);

    List<PmtCostCategory> selectAllActive();

    Long countAllActive();
}
