package com.enterprise.pmt.controller.system;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.annotation.OperationLog.OperationType;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.entity.DataPermission;
import com.enterprise.pmt.mapper.DataPermissionMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 通用数据权限管理
 * <p>
 * 管理 通用数据权限表 pmt_data_permission 的授权记录，
 * 支持按 用户(USER)/角色(ROLE) 对 项目(PROJECT)/合同(CONTRACT) 等资源授予 查看/编辑/审批 权限。
 */
@Api(tags = "系统管理-数据权限")
@RestController
@RequestMapping("/system/data-permission")
public class DataPermissionController {

    @Autowired
    private DataPermissionMapper dataPermissionMapper;

    @ApiOperation("查询某主体在某类资源上的授权列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:role:assign-data')")
    @GetMapping("/list")
    public Result<List<DataPermission>> list(@RequestParam String subjectType,
                                             @RequestParam Long subjectId,
                                             @RequestParam(required = false) String resourceType) {
        LambdaQueryWrapper<DataPermission> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(DataPermission::getSubjectType, subjectType)
               .eq(DataPermission::getSubjectId, subjectId)
               .eq(DataPermission::getDeleted, 0);
        if (resourceType != null && !resourceType.isEmpty()) {
            wrapper.eq(DataPermission::getResourceType, resourceType);
        }
        wrapper.orderByDesc(DataPermission::getId);
        return Result.success(dataPermissionMapper.selectList(wrapper));
    }

    @ApiOperation("批量保存某主体在某类资源上的授权（全量覆盖）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:role:assign-data')")
    @OperationLog(module = "数据权限", description = "批量保存数据权限", type = OperationType.UPDATE)
    @PostMapping("/batch-save")
    public Result<?> batchSave(@RequestBody BatchSaveDTO dto) {
        if (dto.getSubjectType() == null || dto.getSubjectId() == null || dto.getResourceType() == null) {
            return Result.error("subjectType / subjectId / resourceType 不能为空");
        }
        // 删除该主体在该资源类型下的旧授权
        LambdaQueryWrapper<DataPermission> deleteWrapper = new LambdaQueryWrapper<>();
        deleteWrapper.eq(DataPermission::getSubjectType, dto.getSubjectType())
                     .eq(DataPermission::getSubjectId, dto.getSubjectId())
                     .eq(DataPermission::getResourceType, dto.getResourceType())
                     .eq(DataPermission::getDeleted, 0);
        List<DataPermission> old = dataPermissionMapper.selectList(deleteWrapper);
        if (old != null && !old.isEmpty()) {
            dataPermissionMapper.deleteBatchIds(old.stream().map(DataPermission::getId).collect(Collectors.toList()));
        }
        // 插入新授权
        if (dto.getGrants() != null) {
            for (GrantItem item : dto.getGrants()) {
                if (item.getResourceId() == null) continue;
                // 没有任何权限时不插入
                boolean hasAny = (item.getCanView() != null && item.getCanView() == 1)
                        || (item.getCanEdit() != null && item.getCanEdit() == 1)
                        || (item.getCanApprove() != null && item.getCanApprove() == 1);
                if (!hasAny) continue;
                DataPermission dp = new DataPermission();
                dp.setSubjectType(dto.getSubjectType());
                dp.setSubjectId(dto.getSubjectId());
                dp.setResourceType(dto.getResourceType());
                dp.setResourceId(item.getResourceId());
                dp.setCanView(item.getCanView() != null ? item.getCanView() : 0);
                dp.setCanEdit(item.getCanEdit() != null ? item.getCanEdit() : 0);
                dp.setCanApprove(item.getCanApprove() != null ? item.getCanApprove() : 0);
                dp.setRemark(item.getRemark());
                dp.setStatus(1);
                dataPermissionMapper.insert(dp);
            }
        }
        return Result.success("保存成功");
    }

    @ApiOperation("新增单条数据权限授权")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:role:assign-data')")
    @OperationLog(module = "数据权限", description = "新增数据权限", type = OperationType.INSERT)
    @PostMapping
    public Result<?> add(@RequestBody DataPermission dataPermission) {
        dataPermission.setId(null);
        if (dataPermission.getStatus() == null) dataPermission.setStatus(1);
        dataPermissionMapper.insert(dataPermission);
        return Result.success("授权成功");
    }

    @ApiOperation("删除单条数据权限授权")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:role:assign-data')")
    @OperationLog(module = "数据权限", description = "删除数据权限", type = OperationType.DELETE)
    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id) {
        dataPermissionMapper.deleteById(id);
        return Result.success("删除成功");
    }

    // ---- DTO ----

    public static class BatchSaveDTO {
        private String subjectType;
        private Long subjectId;
        private String resourceType;
        private List<GrantItem> grants = new ArrayList<>();

        public String getSubjectType() { return subjectType; }
        public void setSubjectType(String subjectType) { this.subjectType = subjectType; }
        public Long getSubjectId() { return subjectId; }
        public void setSubjectId(Long subjectId) { this.subjectId = subjectId; }
        public String getResourceType() { return resourceType; }
        public void setResourceType(String resourceType) { this.resourceType = resourceType; }
        public List<GrantItem> getGrants() { return grants; }
        public void setGrants(List<GrantItem> grants) { this.grants = grants; }
    }

    public static class GrantItem {
        private Long resourceId;
        private Integer canView;
        private Integer canEdit;
        private Integer canApprove;
        private String remark;

        public Long getResourceId() { return resourceId; }
        public void setResourceId(Long resourceId) { this.resourceId = resourceId; }
        public Integer getCanView() { return canView; }
        public void setCanView(Integer canView) { this.canView = canView; }
        public Integer getCanEdit() { return canEdit; }
        public void setCanEdit(Integer canEdit) { this.canEdit = canEdit; }
        public Integer getCanApprove() { return canApprove; }
        public void setCanApprove(Integer canApprove) { this.canApprove = canApprove; }
        public String getRemark() { return remark; }
        public void setRemark(String remark) { this.remark = remark; }
    }
}
