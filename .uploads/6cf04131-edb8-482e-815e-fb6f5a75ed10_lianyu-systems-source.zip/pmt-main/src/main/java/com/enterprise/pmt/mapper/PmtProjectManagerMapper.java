package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtProjectManager;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Collection;
import java.util.List;

@Mapper
public interface PmtProjectManagerMapper extends BaseMapper<PmtProjectManager> {
    /** 查询用户可管理的项目ID列表（含PM/审批人/观察者） */
    List<Long> selectManagedProjectIds(@Param("userId") Long userId);

    /**
     * 查询用户在 pmt_project_manager 中具备指定动作权限的项目ID列表
     * @param actionColumn 白名单：can_view_all / can_edit / can_approve
     */
    List<Long> selectProjectIdsByAction(@Param("userId") Long userId,
                                        @Param("actionColumn") String actionColumn);

    /**
     * 查询某项目下具备审批权限的人员( can_approve=1，含PM/APPROVER )
     */
    List<Long> selectApproverUserIds(@Param("projectId") Long projectId);

    /**
     * 查询开启了"全部项目(含未来新增)审批权限"的全局审批人（project_id=0 & can_approve=1）
     */
    List<Long> selectGlobalApproverUserIds();

    /**
     * 自定义逻辑删除（兼容"deleted 列入唯一索引"的场景）：
     * 将 deleted 置为一个全局单调、永不重复的 bigint 值，
     * 避免 MyBatis-Plus 默认 "SET deleted = id" 策略下
     * 同一业务键 (project_id, user_id) 多次逻辑删除时互相撞唯一索引。
     *
     * 算法：deleted = (currentTimeMillis - 1700000000000L) * 100000 + (id % 100000)
     *   - 高位：距 2023-11-14 的毫秒数（约可用到 2091 年）
     *   - 低位：id 末 5 位（保证同一毫秒内 10w 条 id 不撞）
     */
    int logicDeleteByIds(@Param("ids") Collection<Long> ids);

    /**
     * 查询全部「项目内所有成员」授权记录（can_view_all=1），返回 user_id + project_id。
     * 用于主管可见域中判定提交人是否为某项目的项目经理（project_id=0 表示全部项目）。
     */
    @Select("SELECT user_id, project_id FROM pmt_project_manager " +
            "WHERE deleted = 0 AND status = 1 AND can_view_all = 1")
    List<PmtProjectManager> selectAllCanViewAllGrants();
}
