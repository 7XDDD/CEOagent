package com.enterprise.pmt.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Mapper
public interface DashboardMapper {

    Long countProjects(@Param("status") String status);

    Long countActiveProjects();

    Long countContracts();

    BigDecimal sumContractAmount();

    BigDecimal sumInvoiceAmount();

    BigDecimal sumReceiptAmount();

    BigDecimal sumMonthlyContractAmount(@Param("year") int year, @Param("month") int month);

    BigDecimal sumMonthlyReceiptAmount(@Param("year") int year, @Param("month") int month);

    Long countPendingTimesheets(@Param("userId") Long userId);

    Long countPendingApprovals(@Param("userId") Long userId);

    BigDecimal sumDailyHours(@Param("userId") Long userId, @Param("date") LocalDate date);

    List<Map<String, Object>> selectRecentProjects(@Param("limit") int limit);

    List<Map<String, Object>> selectTodoList(@Param("userId") Long userId);

    List<Map<String, Object>> selectProjectProgress();

    List<Map<String, Object>> selectMonthlyRevenue(@Param("year") Integer year);

    List<Map<String, Object>> selectUpcomingMilestones(@Param("days") int days, @Param("userId") Long userId, @Param("projectId") Long projectId);

    Map<String, Object> selectTimesheetOverview(@Param("projectId") Long projectId, @Param("projectIds") List<Long> projectIds);
    List<Map<String, Object>> selectProjectHoursProgress(@Param("projectId") Long projectId, @Param("projectIds") List<Long> projectIds);
    List<Map<String, Object>> selectMonthlyHoursTrend(@Param("months") int months, @Param("projectId") Long projectId, @Param("projectIds") List<Long> projectIds);
    List<Map<String, Object>> selectDailyHoursThisMonth(@Param("projectId") Long projectId, @Param("projectIds") List<Long> projectIds);
    List<Map<String, Object>> selectHoursStatusDistribution(@Param("projectId") Long projectId, @Param("projectIds") List<Long> projectIds);
    List<Map<String, Object>> selectOvertimeEmployees(@Param("projectId") Long projectId, @Param("projectIds") List<Long> projectIds);
    List<Map<String, Object>> selectWeekUnsubmittedUsers(@Param("projectId") Long projectId, @Param("projectIds") List<Long> projectIds);
    Map<String, Object> selectSettlementStats(@Param("projectId") Long projectId, @Param("projectIds") List<Long> projectIds);
}
