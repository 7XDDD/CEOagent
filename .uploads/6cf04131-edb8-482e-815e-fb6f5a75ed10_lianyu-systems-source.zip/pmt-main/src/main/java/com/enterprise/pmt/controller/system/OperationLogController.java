package com.enterprise.pmt.controller.system;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.dto.system.OperationLogQueryDTO;
import com.enterprise.pmt.service.OperationLogService;
import com.enterprise.pmt.vo.system.OperationLogVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = "系统管理-操作日志")
@RestController
@RequestMapping("/system/operation-log")
public class OperationLogController {

    @Autowired
    private OperationLogService operationLogService;

    @ApiOperation("分页查询操作日志")
    // 与角色管理「操作日志-查看」按钮权限码（橙色标签 pmt:log:operation:view）对齐；菜单级权限仅控制侧边栏入口显示
    // 主权限：与角色管理「操作日志-查看」橙色标签对齐（pmt:log:operation:view）；同时兼容旧配置的模块级编码（pmt:log:operation），避免历史/中间节点权限遗漏
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:log:operation:view','pmt:log:operation')")
    @GetMapping("/page")
    public Result<Page<OperationLogVO>> page(OperationLogQueryDTO query) {
        return Result.success(operationLogService.pageList(query));
    }
}
