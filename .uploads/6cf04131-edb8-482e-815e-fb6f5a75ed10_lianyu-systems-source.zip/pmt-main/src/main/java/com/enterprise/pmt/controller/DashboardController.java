package com.enterprise.pmt.controller;

import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.SecurityContextUtil;
import com.enterprise.pmt.mapper.DashboardMapper;
import com.enterprise.pmt.service.DataScopeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(tags = "仪表盘统计")
@RestController
@RequestMapping("/dashboard")
public class DashboardController {

    private final DashboardMapper dashboardMapper;
    private final DataScopeService dataScopeService;

    public DashboardController(DashboardMapper dashboardMapper, DataScopeService dataScopeService) {
        this.dashboardMapper = dashboardMapper;
        this.dataScopeService = dataScopeService;
    }

    @ApiOperation("获取统计数据")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/stats")
    public Result<Map<String, Object>> stats() {
        Long userId = SecurityContextUtil.getCurrentUserId();
        LocalDate now = LocalDate.now();
        int year = now.getYear();
        int month = now.getMonthValue();

        Map<String, Object> data = new HashMap<>();
        data.put("ongoingProjects", dashboardMapper.countActiveProjects());
        data.put("monthlyContractAmount", dashboardMapper.sumMonthlyContractAmount(year, month));
        data.put("pendingApprovals", dashboardMapper.countPendingTimesheets(null));
        data.put("monthlyPayment", dashboardMapper.sumMonthlyReceiptAmount(year, month));
        return Result.success(data);
    }

    @ApiOperation("获取财务统计")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/finance-stats")
    public Result<Map<String, Object>> financeStats() {
        Map<String, Object> data = new HashMap<>();
        data.put("totalContractAmount", dashboardMapper.sumContractAmount() != null ? dashboardMapper.sumContractAmount() : 0);
        data.put("totalInvoiced", dashboardMapper.sumInvoiceAmount() != null ? dashboardMapper.sumInvoiceAmount() : 0);
        data.put("totalPaid", dashboardMapper.sumReceiptAmount() != null ? dashboardMapper.sumReceiptAmount() : 0);
        data.put("pendingPayment", ((Number) data.getOrDefault("totalInvoiced", 0)).doubleValue() - ((Number) data.getOrDefault("totalPaid", 0)).doubleValue());
        return Result.success(data);
    }

    @ApiOperation("获取工时趋势")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/hours-trend")
    public Result<List<Map<String, Object>>> hoursTrend() {
        Long userId = SecurityContextUtil.getCurrentUserId();
        LocalDate today = LocalDate.now();
        LocalDate monday = today.with(DayOfWeek.MONDAY);
        
        List<Map<String, Object>> result = new ArrayList<>();
        String[] labels = {"周一", "周二", "周三", "周四", "周五", "周六", "周日"};
        
        for (int i = 0; i < 7; i++) {
            LocalDate date = monday.plusDays(i);
            Map<String, Object> dayData = new HashMap<>();
            dayData.put("label", labels[i]);
            dayData.put("date", date.format(DateTimeFormatter.ISO_LOCAL_DATE));
            dayData.put("hours", dashboardMapper.sumDailyHours(userId, date) != null ? dashboardMapper.sumDailyHours(userId, date) : 0);
            result.add(dayData);
        }
        return Result.success(result);
    }

    @ApiOperation("获取统计概览")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:home:view')")
    @GetMapping("/overview")
    public Result<Map<String, Object>> overview() {
        Long userId = SecurityContextUtil.getCurrentUserId();
        Map<String, Object> data = new HashMap<>();
        data.put("totalProjects", dashboardMapper.countProjects(null));
        data.put("activeProjects", dashboardMapper.countActiveProjects());
        data.put("totalContracts", dashboardMapper.countContracts());
        data.put("totalContractAmount", dashboardMapper.sumContractAmount());
        data.put("totalInvoiceAmount", dashboardMapper.sumInvoiceAmount());
        data.put("totalReceiptAmount", dashboardMapper.sumReceiptAmount());
        data.put("myPendingTimesheets", dashboardMapper.countPendingTimesheets(userId));
        data.put("pendingApprovals", dashboardMapper.countPendingApprovals(userId));
        return Result.success(data);
    }

    @ApiOperation("项目进度统计")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/project-progress")
    public Result<List<Map<String, Object>>> projectProgress() {
        return Result.success(dashboardMapper.selectProjectProgress());
    }

    @ApiOperation("月度收入统计")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/monthly-revenue")
    public Result<List<Map<String, Object>>> monthlyRevenue(@RequestParam(required = false) Integer year) {
        return Result.success(dashboardMapper.selectMonthlyRevenue(year));
    }

    @ApiOperation("即将到期里程碑")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/upcoming-milestones")
    public Result<List<Map<String, Object>>> upcomingMilestones(@RequestParam(defaultValue = "30") int days,
                                                                 @RequestParam(required = false) Long projectId) {
        return Result.success(dashboardMapper.selectUpcomingMilestones(days, null, projectId));
    }

    @ApiOperation("最近项目列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:home:view')")
    @GetMapping("/recent-projects")
    public Result<List<Map<String, Object>>> recentProjects(@RequestParam(defaultValue = "8") int limit) {
        return Result.success(dashboardMapper.selectRecentProjects(limit));
    }

    @ApiOperation("待办事项列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:home:view')")
    @GetMapping("/todo-list")
    public Result<Map<String, Object>> todoList(@RequestParam(defaultValue = "1") int pageNum,
                                                 @RequestParam(defaultValue = "10") int pageSize) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        List<Map<String, Object>> list = dashboardMapper.selectTodoList(userId);
        Map<String, Object> result = new HashMap<>();
        result.put("list", list);
        result.put("total", (long) list.size());
        return Result.success(result);
    }

    /**
     * 获取数据权限范围：管理员返回null（不过滤），非管理员返回可查看项目ID列表
     */
    private List<Long> getDataScopeProjectIds() {
        return dataScopeService.getViewableProjectIds();
    }

    @ApiOperation("工时看板总览统计")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/timesheet-overview")
    public Result<Map<String, Object>> timesheetOverview(@RequestParam(required = false) Long projectId) {
        List<Long> projectIds = getDataScopeProjectIds();
        // 非管理员且指定了projectId，校验权限
        if (projectIds != null && (projectIds.isEmpty() || (projectId != null && !projectIds.contains(projectId)))) {
            return Result.success(new HashMap<>());
        }
        Map<String, Object> data = dashboardMapper.selectTimesheetOverview(projectId, projectIds);
        if (data == null) data = new HashMap<>();
        
        BigDecimal usedHours = toBd(data.get("usedHours"));
        BigDecimal overtimeHours = toBd(data.get("overtimeHours"));
        BigDecimal settledHours = toBd(data.get("settledHours"));
        BigDecimal pendingHours = toBd(data.get("pendingHours"));
        BigDecimal totalBudget = toBd(data.get("totalBudgetHours"));
        
        BigDecimal unsettledHours = usedHours.subtract(settledHours).max(BigDecimal.ZERO);
        BigDecimal remainingHours = totalBudget.subtract(usedHours).max(BigDecimal.ZERO);
        BigDecimal usedWithoutOvertime = usedHours.subtract(overtimeHours).max(BigDecimal.ZERO);

        data.put("remainingHours", remainingHours);
        data.put("usedHoursWithOvertime", usedHours);
        data.put("usedHoursWithoutOvertime", usedWithoutOvertime);
        data.put("pendingApprovals", data.getOrDefault("pendingCount", 0));
        data.put("abnormalHoursCount", data.getOrDefault("anomalyCount", 0));
        data.put("weekUnsubmitted", data.getOrDefault("weekUnsubmitted", 0));
        data.put("usageRate", totalBudget.compareTo(BigDecimal.ZERO) > 0
                ? usedHours.multiply(new BigDecimal(100)).divide(totalBudget, 1, RoundingMode.HALF_UP)
                : BigDecimal.ZERO);
        return Result.success(data);
    }

    @ApiOperation("项目工时进度列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/project-hours-progress")
    public Result<List<Map<String, Object>>> projectHoursProgress(@RequestParam(required = false) Long projectId) {
        List<Long> projectIds = getDataScopeProjectIds();
        if (projectIds != null && (projectIds.isEmpty() || (projectId != null && !projectIds.contains(projectId)))) {
            return Result.success(Collections.emptyList());
        }
        List<Map<String, Object>> list = dashboardMapper.selectProjectHoursProgress(projectId, projectIds);
        for (Map<String, Object> p : list) {
            BigDecimal budget = toBd(p.get("budgetHours"));
            BigDecimal used = toBd(p.get("usedHours"));
            BigDecimal settled = toBd(p.get("settledHours"));
            BigDecimal progress = budget.compareTo(BigDecimal.ZERO) > 0
                    ? used.multiply(new BigDecimal(100)).divide(budget, 1, RoundingMode.HALF_UP)
                    : BigDecimal.ZERO;
            p.put("remainingHours", budget.subtract(used).max(BigDecimal.ZERO));
            p.put("unsettledHours", used.subtract(settled).max(BigDecimal.ZERO));
            p.put("progress", progress);
            String warnLevel = "normal";
            if (progress.compareTo(new BigDecimal("100")) >= 0) warnLevel = "danger";
            else if (progress.compareTo(new BigDecimal("90")) >= 0) warnLevel = "danger";
            else if (progress.compareTo(new BigDecimal("75")) >= 0) warnLevel = "warning";
            p.put("warnLevel", warnLevel);
        }
        return Result.success(list);
    }

    @ApiOperation("近N月工时趋势")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/monthly-hours-trend")
    public Result<List<Map<String, Object>>> monthlyHoursTrend(@RequestParam(defaultValue = "6") int months,
                                                                 @RequestParam(required = false) Long projectId) {
        List<Long> projectIds = getDataScopeProjectIds();
        if (projectIds != null && (projectIds.isEmpty() || (projectId != null && !projectIds.contains(projectId)))) {
            return Result.success(Collections.emptyList());
        }
        return Result.success(dashboardMapper.selectMonthlyHoursTrend(months, projectId, projectIds));
    }

    @ApiOperation("本月每日工时")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/daily-hours-month")
    public Result<List<Map<String, Object>>> dailyHoursMonth(@RequestParam(required = false) Long projectId) {
        List<Long> projectIds = getDataScopeProjectIds();
        if (projectIds != null && (projectIds.isEmpty() || (projectId != null && !projectIds.contains(projectId)))) {
            return Result.success(Collections.emptyList());
        }
        return Result.success(dashboardMapper.selectDailyHoursThisMonth(projectId, projectIds));
    }

    @ApiOperation("工时状态分布")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/hours-status-dist")
    public Result<List<Map<String, Object>>> hoursStatusDist(@RequestParam(required = false) Long projectId) {
        List<Long> projectIds = getDataScopeProjectIds();
        if (projectIds != null && (projectIds.isEmpty() || (projectId != null && !projectIds.contains(projectId)))) {
            return Result.success(Collections.emptyList());
        }
        List<Map<String, Object>> list = dashboardMapper.selectHoursStatusDistribution(projectId, projectIds);
        for (Map<String, Object> item : list) {
            String s = (String) item.get("status");
            String name;
            if (s == null) s = "UNKNOWN";
            switch (s) {
                case "DRAFT": name = "草稿"; break;
                case "PENDING": name = "待审批"; break;
                case "SUBMITTED": name = "待审批"; break;
                case "APPROVED": name = "已审批"; break;
                case "REJECTED": name = "已驳回"; break;
                case "LOCKED": name = "已锁定"; break;
                case "SETTLED": name = "已结算"; break;
                default: name = s;
            }
            item.put("statusName", name);
            item.put("name", name);
        }
        return Result.success(list);
    }

    @ApiOperation("本周超时员工")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/overtime-employees")
    public Result<List<Map<String, Object>>> overtimeEmployees(@RequestParam(required = false) Long projectId) {
        List<Long> projectIds = getDataScopeProjectIds();
        if (projectIds != null && (projectIds.isEmpty() || (projectId != null && !projectIds.contains(projectId)))) {
            return Result.success(Collections.emptyList());
        }
        return Result.success(dashboardMapper.selectOvertimeEmployees(projectId, projectIds));
    }

    @ApiOperation("本周未填报人员")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/week-unsubmitted")
    public Result<List<Map<String, Object>>> weekUnsubmitted(@RequestParam(required = false) Long projectId) {
        List<Long> projectIds = getDataScopeProjectIds();
        if (projectIds != null && (projectIds.isEmpty() || (projectId != null && !projectIds.contains(projectId)))) {
            return Result.success(Collections.emptyList());
        }
        return Result.success(dashboardMapper.selectWeekUnsubmittedUsers(projectId, projectIds));
    }

    @ApiOperation("结算统计")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:dashboard:stats')")
    @GetMapping("/settlement-stats")
    public Result<Map<String, Object>> settlementStats(@RequestParam(required = false) Long projectId) {
        List<Long> projectIds = getDataScopeProjectIds();
        if (projectIds != null && (projectIds.isEmpty() || (projectId != null && !projectIds.contains(projectId)))) {
            return Result.success(new HashMap<>());
        }
        return Result.success(dashboardMapper.selectSettlementStats(projectId, projectIds));
    }

    private BigDecimal toBd(Object v) {
        if (v == null) return BigDecimal.ZERO;
        if (v instanceof BigDecimal) return (BigDecimal) v;
        try { return new BigDecimal(v.toString()); } catch (Exception e) { return BigDecimal.ZERO; }
    }
}
