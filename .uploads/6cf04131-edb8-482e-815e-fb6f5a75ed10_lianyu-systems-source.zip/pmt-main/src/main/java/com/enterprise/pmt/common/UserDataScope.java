package com.enterprise.pmt.common;

import java.util.Collections;
import java.util.List;

/**
 * 当前用户的数据范围上下文。
 * <p>
 * 由 DataScopeService 解析后传给业务查询，业务层据此拼接过滤条件：
 * <ul>
 *   <li>{@code allData=true}：管理员，不加任何条件</li>
 *   <li>{@code managedProjectIds}：用户作为项目经理（can_view_all=1）的项目，可见项目内所有成员数据</li>
 *   <li>{@code memberProjectIds}：用户作为普通成员参与的项目，仅可见自己的数据</li>
 *   <li>{@code visibleEmployeeIds}：自己 + 所管理项目下的所有成员ID（用于请假等无 project_id 的数据）</li>
 * </ul>
 */
public class UserDataScope {

    private final boolean allData;
    private final Long selfEmployeeId;
    private final List<Long> managedProjectIds;
    private final List<Long> memberProjectIds;
    private final List<Long> visibleEmployeeIds;

    private UserDataScope(boolean allData, Long selfEmployeeId,
                          List<Long> managedProjectIds, List<Long> memberProjectIds,
                          List<Long> visibleEmployeeIds) {
        this.allData = allData;
        this.selfEmployeeId = selfEmployeeId;
        this.managedProjectIds = managedProjectIds;
        this.memberProjectIds = memberProjectIds;
        this.visibleEmployeeIds = visibleEmployeeIds;
    }

    public static UserDataScope all() {
        return new UserDataScope(true, null, null, null, null);
    }

    public static UserDataScope of(Long selfEmployeeId,
                                   List<Long> managedProjectIds,
                                   List<Long> memberProjectIds,
                                   List<Long> visibleEmployeeIds) {
        return new UserDataScope(false, selfEmployeeId,
                managedProjectIds == null ? Collections.emptyList() : managedProjectIds,
                memberProjectIds == null ? Collections.emptyList() : memberProjectIds,
                visibleEmployeeIds == null ? Collections.emptyList() : visibleEmployeeIds);
    }

    public boolean isAllData() { return allData; }
    public Long getSelfEmployeeId() { return selfEmployeeId; }
    public List<Long> getManagedProjectIds() { return managedProjectIds; }
    public List<Long> getMemberProjectIds() { return memberProjectIds; }
    public List<Long> getVisibleEmployeeIds() { return visibleEmployeeIds; }

    /**
     * 是否无任何可见数据（非管理员，且没有参与/管理任何项目）
     */
    public boolean isEmpty() {
        if (allData) return false;
        return managedProjectIds.isEmpty() && memberProjectIds.isEmpty();
    }
}
