package com.enterprise.pmt.vo;

import com.enterprise.pmt.entity.PmtCustomerAddress;
import com.enterprise.pmt.entity.PmtCustomerContact;
import com.enterprise.pmt.entity.PmtCustomerFollower;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class CustomerVO implements Serializable {
    private Long id;
    private String customerCode;
    private String customerName;
    private String customerShortName;
    private String customerType;
    private String customerClassify;
    private String customerScale;
    private String customerIndustry;
    private String industry;
    private String unifiedSocialCredit;
    private String website;
    private String taxNumber;
    private String contactPerson;
    private String contactPhone;
    private String contactEmail;
    private String address;
    private String registerAddress;
    private Long parentId;
    private String creditLevel;
    private String bankName;
    private String bankAccount;
    private String status;
    private String dataStatus;
    private Integer statusValue;
    private String remark;
    private String createdBy;
    private String updatedBy;
    private java.time.LocalDateTime createTime;
    private java.time.LocalDateTime updateTime;

    private List<PmtCustomerAddress> addresses;
    private List<PmtCustomerContact> contacts;
    private List<PmtCustomerFollower> followers;

    public void setStatus(String status) {
        this.status = status;
        if ("ACTIVE".equals(status)) {
            this.statusValue = 1;
        } else if ("INACTIVE".equals(status)) {
            this.statusValue = 0;
        } else {
            this.statusValue = null;
        }
    }

    @JsonIgnore
    public String getStatusForDb() {
        if (this.statusValue != null) {
            return this.statusValue == 1 ? "ACTIVE" : "INACTIVE";
        }
        return this.status;
    }
}
