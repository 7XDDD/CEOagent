package com.enterprise.pmt.vo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class MonthlyBudgetVO {

    /** 月份，格式 yyyy-MM */
    private String month;

    /** 月度预算工时（小时，由成员周期推导） */
    private BigDecimal budgetHours;

    /** 月度实际工时（小时，已审批） */
    private BigDecimal actualHours;

    /** 累计预算工时（小时） */
    private BigDecimal cumulativeBudget;

    /** 累计实际工时（小时） */
    private BigDecimal cumulativeActual;
}
