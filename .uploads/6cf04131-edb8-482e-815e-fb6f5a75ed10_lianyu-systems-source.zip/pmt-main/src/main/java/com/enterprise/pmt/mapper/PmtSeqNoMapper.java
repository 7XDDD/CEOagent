package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtSeqNo;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PmtSeqNoMapper extends BaseMapper<PmtSeqNo> {
}
