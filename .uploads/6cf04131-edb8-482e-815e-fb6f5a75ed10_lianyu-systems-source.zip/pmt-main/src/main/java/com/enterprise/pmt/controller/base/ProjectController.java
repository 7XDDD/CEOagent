package com.enterprise.pmt.controller.base;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.dto.ProjectCreateDTO;
import com.enterprise.pmt.dto.ProjectMemberDTO;
import com.enterprise.pmt.dto.ProjectQueryDTO;
import com.enterprise.pmt.dto.ProjectUpdateDTO;
import com.enterprise.pmt.entity.PmtProjectMember;
import com.enterprise.pmt.service.ProjectService;
import com.enterprise.pmt.vo.ProjectVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

@Api(tags = "项目管理")
@RestController
@RequestMapping("/base/project")
public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @ApiOperation("分页查询项目列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:view')")
    @PostMapping("/page")
    public Result<Page<ProjectVO>> page(@RequestBody ProjectQueryDTO query) {
        return Result.success(projectService.pageList(query));
    }

    @ApiOperation("查询所有项目列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:view')")
    @GetMapping("/list")
    public Result<List<ProjectVO>> list() {
        return Result.success(projectService.listAll());
    }

    @ApiOperation("查询我参与的项目")
    @GetMapping("/my")
    public Result<List<ProjectVO>> myProjects(@RequestParam(required = false) Long userId) {
        return Result.success(projectService.listMyProjects(userId));
    }

    /**
     * 结算管理 / PM看板 / 工时管理等场景专用的"项目下拉"接口。
     * 业务背景：PMT_FINANCE 等角色持有 pmt:settlement:view 权限，但不应持有 pmt:project:view
     * （否则左侧会越界显示"项目管理→项目信息"菜单），而结算/看板页面仍需按"数据权限"
     * 列出用户能操作的项目下拉。
     * 鉴权：持有 settlement|timesheet|dashboard|budget|execution|approval|overtime|cost 任一页面 view 权限即可。
     * 数据范围：同 listAll()，走 dataScopeService.getAnyAccessibleProjectIds()（view/edit/approve 显式授权任一维度）。
     * 注意：项目成员身份不在此集合内；"我的工时"填报参与项目走 /base/project/my。
     */
    @ApiOperation("项目下拉列表（按数据权限 / 结算&看板等场景专用）")
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:settlement:view','pmt:settlement:settle'," +
            "'pmt:timesheet:view','pmt:timesheet:manage'," +
            "'pmt:dashboard:view','pmt:timesheet-budget:view','pmt:timesheet-execution:view','pmt:approval:view'," +
            "'pmt:overtime:view','pmt:cost:view')")
    @GetMapping("/list-scoped")
    public Result<List<ProjectVO>> listScoped() {
        return Result.success(projectService.listAll());
    }

    @ApiOperation("获取项目详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:view')")
    @GetMapping("/{id}")
    public Result<ProjectVO> getDetail(@PathVariable Long id) {
        return Result.success(projectService.getDetail(id));
    }

    @ApiOperation("创建项目")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:create')")
    @PostMapping
    @OperationLog("创建项目")
    public Result<Long> create(@RequestBody ProjectCreateDTO createDTO) {
        Long id = projectService.createProject(createDTO);
        return Result.success(id);
    }

    @ApiOperation("更新项目")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:update')")
    @PutMapping("/{id}")
    @OperationLog("更新项目")
    public Result<Void> update(@PathVariable Long id, @RequestBody ProjectUpdateDTO updateDTO) {
        projectService.updateProject(id, updateDTO);
        return Result.success();
    }

    @ApiOperation("删除项目")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:delete')")
    @DeleteMapping("/{id:\\d+}")
    @OperationLog("删除项目")
    public Result<Void> delete(@PathVariable Long id) {
        projectService.deleteProject(id);
        return Result.success();
    }

    @ApiOperation("分页查询项目成员")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:view')")
    @GetMapping("/{id}/members/page")
    public Result<Page<PmtProjectMember>> pageMembers(@PathVariable Long id,
                                                       @RequestParam(defaultValue = "1") Integer pageNum,
                                                       @RequestParam(defaultValue = "10") Integer pageSize,
                                                       @RequestParam(required = false) String keyword,
                                                       @RequestParam(required = false) String roleInProject) {
        return Result.success(projectService.pageMembers(id, pageNum, pageSize, keyword, roleInProject));
    }

    @ApiOperation("获取项目成员列表")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:view')")
    @GetMapping("/{id}/members")
    public Result<List<PmtProjectMember>> getMembers(@PathVariable Long id) {
        return Result.success(projectService.getProjectMembers(id));
    }

    @ApiOperation("获取项目下实际存在的项目角色集合（按成员实际角色去重，用于前端筛选下拉）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:view')")
    @GetMapping("/{id}/members/roles")
    public Result<List<String>> listMemberRoles(@PathVariable Long id) {
        return Result.success(projectService.listMemberRoles(id));
    }

    @ApiOperation("添加项目成员")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:member')")
    @PostMapping("/{id}/members")
    @OperationLog("添加项目成员")
    public Result<Void> addMember(@PathVariable Long id, @RequestBody ProjectMemberDTO memberDTO) {
        projectService.addProjectMember(id, memberDTO);
        return Result.success();
    }

    @ApiOperation("更新项目成员")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:member')")
    @PutMapping("/{id}/members/{memberId}")
    @OperationLog("更新项目成员")
    public Result<Void> updateMember(@PathVariable Long id, @PathVariable Long memberId, @RequestBody ProjectMemberDTO memberDTO) {
        projectService.updateProjectMember(id, memberId, memberDTO);
        return Result.success();
    }

    @ApiOperation("删除项目成员")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:member')")
    @DeleteMapping("/{id}/members/{memberId}")
    @OperationLog("删除项目成员")
    public Result<Void> deleteMember(@PathVariable Long id, @PathVariable Long memberId) {
        projectService.deleteProjectMember(id, memberId);
        return Result.success();
    }

    @ApiOperation("批量保存项目成员")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:member')")
    @PostMapping("/{id}/members/batch")
    @OperationLog("批量保存项目成员")
    public Result<Void> saveMembers(@PathVariable Long id, @RequestBody List<ProjectMemberDTO> members) {
        projectService.saveProjectMembers(id, members);
        return Result.success();
    }

    @ApiOperation("导出项目数据")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:export')")
    @PostMapping("/export")
    public void export(@RequestBody(required = false) ProjectQueryDTO query, HttpServletResponse response) {
        try {
            projectService.exportProjects(query, response);
        } catch (Exception e) {
            throw new RuntimeException("导出失败", e);
        }
    }

    @ApiOperation("下载项目导入模板")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:import')")
    @GetMapping("/template")
    public void downloadTemplate(HttpServletResponse response) {
        try {
            projectService.downloadImportTemplate(response);
        } catch (Exception e) {
            throw new RuntimeException("下载模板失败", e);
        }
    }

    @ApiOperation("导入项目数据")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:import')")
    @PostMapping("/import")
    public Result<Map<String, Object>> importExcel(@RequestParam("file") MultipartFile file) {
        return Result.success(projectService.importExcel(file));
    }

    @ApiOperation("导出项目成员")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:export')")
    @GetMapping("/{id}/members/export")
    public void exportMembers(@PathVariable Long id, HttpServletResponse response) {
        try {
            projectService.exportProjectMembers(id, response);
        } catch (Exception e) {
            throw new RuntimeException("导出成员失败", e);
        }
    }

    @ApiOperation("下载项目成员导入模板")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:import')")
    @GetMapping("/members/template")
    public void downloadMemberTemplate(HttpServletResponse response) {
        try {
            projectService.downloadMemberTemplate(response);
        } catch (Exception e) {
            throw new RuntimeException("下载成员模板失败", e);
        }
    }

    @ApiOperation("导入项目成员")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:project:import')")
    @PostMapping("/{id}/members/import")
    public Result<Map<String, Object>> importMembers(@PathVariable Long id, @RequestParam("file") MultipartFile file) {
        return Result.success(projectService.importProjectMembers(id, file));
    }
}
