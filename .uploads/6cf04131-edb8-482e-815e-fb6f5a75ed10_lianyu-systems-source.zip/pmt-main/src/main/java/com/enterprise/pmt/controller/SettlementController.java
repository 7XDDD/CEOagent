package com.enterprise.pmt.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.common.BusinessException;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.common.ResultCode;
import com.enterprise.pmt.common.SecurityContextUtil;
import com.enterprise.pmt.entity.PmtSettlementBatch;
import com.enterprise.pmt.entity.PmtSettlementOrder;
import com.enterprise.pmt.entity.PmtSettlementOrderItem;
import com.enterprise.pmt.entity.User;
import com.enterprise.pmt.mapper.PmtProjectMemberMapper;
import com.enterprise.pmt.mapper.PmtSettlementBatchMapper;
import com.enterprise.pmt.mapper.PmtSettlementOrderItemMapper;
import com.enterprise.pmt.mapper.PmtSettlementOrderMapper;
import com.enterprise.pmt.mapper.PmtTimesheetMapper;
import com.enterprise.pmt.mapper.UserMapper;
import com.enterprise.pmt.service.DataScopeService;
import com.enterprise.pmt.service.TimesheetService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Api(tags = "结算管理")
@RestController
@RequestMapping("/settlements")
public class SettlementController {

    private final PmtSettlementBatchMapper batchMapper;
    private final PmtSettlementOrderMapper orderMapper;
    private final PmtSettlementOrderItemMapper orderItemMapper;

    @Resource
    private UserMapper userMapper;
    @Resource
    private TimesheetService timesheetService;
    @Resource
    private DataScopeService dataScopeService;
    @Resource
    private PmtTimesheetMapper timesheetMapper;
    @Resource
    private PmtProjectMemberMapper projectMemberMapper;

    public SettlementController(PmtSettlementBatchMapper batchMapper,
                                PmtSettlementOrderMapper orderMapper,
                                PmtSettlementOrderItemMapper orderItemMapper) {
        this.batchMapper = batchMapper;
        this.orderMapper = orderMapper;
        this.orderItemMapper = orderItemMapper;
    }

    @ApiOperation("分页查询结算批次")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:view')")
    @GetMapping("/batches/page")
    public Result<Page<PmtSettlementBatch>> pageBatches(@RequestParam(defaultValue = "1") int pageNum,
                                                        @RequestParam(defaultValue = "10") int pageSize,
                                                        @RequestParam(required = false) String keyword,
                                                        @RequestParam(required = false) String batchStatus) {
        Page<PmtSettlementBatch> page = new Page<>(pageNum, pageSize);
        return Result.success(batchMapper.selectPageList(page, keyword, batchStatus));
    }

    @ApiOperation("获取所有结算批次")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:view')")
    @GetMapping("/batches/list")
    public Result<List<PmtSettlementBatch>> listBatches() {
        return Result.success(batchMapper.selectListAll());
    }

    @ApiOperation("获取结算批次详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:view')")
    @GetMapping("/batches/{id}")
    public Result<PmtSettlementBatch> getBatchDetail(@PathVariable Long id) {
        PmtSettlementBatch batch = batchMapper.selectById(id);
        if (batch == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        return Result.success(batch);
    }

    /**
     * 结算管理主页的「全局统计」：不依赖列表筛选条件。
     * <ul>
     *   <li>settledCount：当前用户数据权限项目范围内 已结算工时单数</li>
     *   <li>unsettledCount：当前用户数据权限项目范围内 可结算(已锁定+未结算+SETTLE性质)工时单数</li>
     *   <li>batchesCount：结算批次总数（用于右上角筛选说明）</li>
     * </ul>
     * 未结算列表 Tab 页签展示用这个口径，而不是分页 total（分页 total 会受项目/日期筛选影响）。
     */
    @ApiOperation("结算全局统计（Tab label 数量）")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:view')")
    @GetMapping("/stats")
    public Result<Map<String, Object>> getSettlementStats() {
        List<Long> projectIds = dataScopeService.getAnyAccessibleProjectIds(); // null = 全部项目

        // 已结算：settled=1 OR isSettlement=1 OR status='SETTLED'（兼容历史）
        LambdaQueryWrapper<com.enterprise.pmt.entity.PmtTimesheet> sq = new LambdaQueryWrapper<>();
        sq.eq(com.enterprise.pmt.entity.PmtTimesheet::getDeleted, 0)
                .and(w -> w.eq(com.enterprise.pmt.entity.PmtTimesheet::getSettled, 1)
                        .or().eq(com.enterprise.pmt.entity.PmtTimesheet::getIsSettlement, 1)
                        .or().eq(com.enterprise.pmt.entity.PmtTimesheet::getStatus, "SETTLED"));
        if (projectIds != null) {
            if (projectIds.isEmpty()) {
                sq.in(com.enterprise.pmt.entity.PmtTimesheet::getProjectId, Collections.singleton(-1L));
            } else {
                sq.in(com.enterprise.pmt.entity.PmtTimesheet::getProjectId, projectIds);
            }
        }
        Long settledCount = timesheetMapper.selectCount(sq);

        // 未结算：(settled IS NULL OR settled!=1) AND (isSettlement IS NULL OR isSettlement!=1) AND (locked=1 OR status='LOCKED')
        // 且成员 workNature=SETTLE
        LambdaQueryWrapper<com.enterprise.pmt.entity.PmtTimesheet> uq = new LambdaQueryWrapper<>();
        uq.eq(com.enterprise.pmt.entity.PmtTimesheet::getDeleted, 0)
                .and(w -> w.and(w1 -> w1.isNull(com.enterprise.pmt.entity.PmtTimesheet::getSettled)
                                .or().ne(com.enterprise.pmt.entity.PmtTimesheet::getSettled, 1))
                        .and(w2 -> w2.isNull(com.enterprise.pmt.entity.PmtTimesheet::getIsSettlement)
                                .or().ne(com.enterprise.pmt.entity.PmtTimesheet::getIsSettlement, 1)))
                .and(w -> w.eq(com.enterprise.pmt.entity.PmtTimesheet::getLocked, 1)
                        .or().eq(com.enterprise.pmt.entity.PmtTimesheet::getStatus, "LOCKED"));
        if (projectIds != null) {
            if (projectIds.isEmpty()) {
                uq.in(com.enterprise.pmt.entity.PmtTimesheet::getProjectId, Collections.singleton(-1L));
            } else {
                uq.in(com.enterprise.pmt.entity.PmtTimesheet::getProjectId, projectIds);
            }
        }
        List<com.enterprise.pmt.entity.PmtTimesheet> unsettledCandidates = timesheetMapper.selectList(uq);
        int unsettledCount = 0;
        if (!CollectionUtils.isEmpty(unsettledCandidates)) {
            Map<String, Boolean> cache = new HashMap<>();
            for (com.enterprise.pmt.entity.PmtTimesheet s : unsettledCandidates) {
                String key = s.getProjectId() + "|" + s.getUserId() + "|" + s.getEmployeeId();
                Boolean ok = cache.get(key);
                if (ok == null) {
                    LambdaQueryWrapper<com.enterprise.pmt.entity.PmtProjectMember> mw = new LambdaQueryWrapper<>();
                    mw.eq(com.enterprise.pmt.entity.PmtProjectMember::getProjectId, s.getProjectId())
                            .eq(com.enterprise.pmt.entity.PmtProjectMember::getDeleted, 0)
                            .and(w -> w.eq(com.enterprise.pmt.entity.PmtProjectMember::getUserId, s.getUserId())
                                    .or().eq(com.enterprise.pmt.entity.PmtProjectMember::getEmployeeId, s.getEmployeeId()))
                            .last("LIMIT 1");
                    com.enterprise.pmt.entity.PmtProjectMember m = projectMemberMapper.selectOne(mw);
                    ok = (m != null && "SETTLE".equals(m.getWorkNature()));
                    cache.put(key, ok);
                }
                if (Boolean.TRUE.equals(ok)) unsettledCount++;
            }
        }

        LambdaQueryWrapper<PmtSettlementBatch> bq = new LambdaQueryWrapper<>();
        bq.eq(PmtSettlementBatch::getDeleted, 0);
        Long batchesCount = batchMapper.selectCount(bq);

        Map<String, Object> ret = new HashMap<>();
        ret.put("settledCount", settledCount == null ? 0 : settledCount);
        ret.put("unsettledCount", unsettledCount);
        ret.put("batchesCount", batchesCount == null ? 0 : batchesCount);
        return Result.success(ret);
    }

    @ApiOperation("创建结算批次")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:create')")
    @PostMapping("/batches")
    @OperationLog("创建结算批次")
    @Transactional(rollbackFor = Exception.class)
    public Result<Long> createBatch(@RequestBody PmtSettlementBatch batch) {
        fillCreator(batch);
        applyDefaults(batch);
        ensureBatchNo(batch);
        batchMapper.insert(batch);
        return Result.success(batch.getId());
    }

    /**
     * 创建结算批次并立即结算工时单（两种模式，二选一）。
     * <ol>
     *   <li><b>指定 ids 模式</b>：body.timesheetIds 非空 → 仅结算这些工时单（对应前端"批量结算-新建批次"）</li>
     *   <li><b>按范围自动捞</b>：body.timesheetIds 为空/不传 → 按弹窗里的 结算周期(startDate,endDate) + 结算月份 + 关联项目(可选)
     *   + 当前用户<b>所有有数据权限的项目</b>(getAnyAccessibleProjectIds) → 自动找 已锁定+未结算+工时性质=SETTLE 的工时单结算。</li>
     * </ol>
     * 前端「新建批次」→「创建并结算」按钮就是按第 2 种模式走，无需用户先在表格勾选。
     */
    @ApiOperation("创建结算批次并立即结算指定工时单")
    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:settlement:create','pmt:settlement:settle')")
    @PostMapping("/batches/create-and-settle")
    @OperationLog("创建批次并结算工时")
    @Transactional(rollbackFor = Exception.class)
    public Result<Map<String, Object>> createBatchAndSettle(@RequestBody Map<String, Object> body) {
        PmtSettlementBatch batch = buildBatchFromBody(body);
        fillCreator(batch);
        applyDefaults(batch);
        ensureBatchNo(batch);
        batchMapper.insert(batch);

        Object rawIds = body.get("timesheetIds");
        List<Long> ids = rawIds instanceof List ? toLongList((List<?>) rawIds) : null;
        int settledCount;

        if (!CollectionUtils.isEmpty(ids)) {
            // 模式1：显式指定 ids（批量结算弹框"新建批次"模式）
            settledCount = timesheetService.batchSettle(ids, batch.getId());
        } else {
            // 模式2：按 周期 + 项目权限 自动结算周期内所有未结算明细天（按天结算，支持跨月周）
            LocalDate start = batch.getStartDate();
            LocalDate end = batch.getEndDate();
            if (start == null || end == null) {
                throw new BusinessException("缺少结算周期");
            }
            // 解析项目范围
            List<Long> allAccessible = dataScopeService.getAnyAccessibleProjectIds();
            List<Long> projectIds;
            if (batch.getProjectId() != null) {
                boolean ok = allAccessible == null || allAccessible.contains(batch.getProjectId());
                if (!ok) {
                    throw new BusinessException("您没有所选关联项目的结算权限");
                }
                projectIds = Collections.singletonList(batch.getProjectId());
            } else {
                if (allAccessible == null) {
                    projectIds = null; // 全部项目
                } else if (allAccessible.isEmpty()) {
                    throw new BusinessException("您当前没有任何项目的结算权限，请先分配数据权限");
                } else {
                    projectIds = new ArrayList<>(allAccessible);
                }
            }
            settledCount = timesheetService.batchSettleByDateRange(start, end, projectIds, batch.getId());
            if (settledCount == 0) {
                throw new BusinessException("所选范围内没有可结算的工时明细（需为已锁定、未结算、工时性质=结算）");
            }
        }

        Map<String, Object> ret = new HashMap<>();
        ret.put("batchId", batch.getId());
        ret.put("batchNo", batch.getBatchNo());
        ret.put("settledCount", settledCount);
        return Result.success(ret);
    }

    /**
     * 按"结算周期 + 项目范围"捞取可结算的工时单ID：
     * <pre>
     * 项目集合 = [用户显式指定的关联项目 batch.projectId 若有] ∪ [getAnyAccessibleProjectIds 全权限项目集合]
     *        若 batch.projectId == null 且 用户有"全部项目总开关权限" → 项目集合 = 所有有效项目（null）
     * 筛选 = weekStartDate ∈ [startDate, endDate]
     *      AND deleted = 0
     *      AND (locked = 1 OR status = 'LOCKED')
     *      AND (settled IS NULL OR settled != 1)
     *      AND (isSettlement IS NULL OR isSettlement != 1)
     *      AND (project_id, user_id) 对应的 project_member.work_nature = 'SETTLE'
     * </pre>
     */
    private List<Long> resolveSettleableByScope(PmtSettlementBatch batch) {
        // 1) 项目范围
        List<Long> allAccessible = dataScopeService.getAnyAccessibleProjectIds(); // null = 全部项目权限
        Set<Long> projectSet = new HashSet<>();
        if (batch.getProjectId() != null) {
            // 弹窗里显式选了"关联项目" → 只对这个项目结算；但也要校验用户有这个项目权限
            boolean ok = allAccessible == null || allAccessible.contains(batch.getProjectId());
            if (!ok) {
                throw new BusinessException("您没有所选关联项目的结算权限");
            }
            projectSet.add(batch.getProjectId());
        } else {
            // 未选关联项目 → 对所有有数据权限的项目结算
            if (allAccessible == null) {
                projectSet = null; // null 表示全部（不过滤项目）
            } else {
                projectSet.addAll(allAccessible);
            }
        }
        if (projectSet != null && projectSet.isEmpty()) {
            throw new BusinessException("您当前没有任何项目的结算权限，请先分配数据权限");
        }

        LocalDate start = batch.getStartDate();
        LocalDate end = batch.getEndDate();
        if (start == null || end == null) {
            throw new BusinessException("缺少结算周期");
        }

        // 2) 拉工时单
        LambdaQueryWrapper<com.enterprise.pmt.entity.PmtTimesheet> qw = new LambdaQueryWrapper<>();
        qw.eq(com.enterprise.pmt.entity.PmtTimesheet::getDeleted, 0)
                .ge(com.enterprise.pmt.entity.PmtTimesheet::getWeekStartDate, start)
                .le(com.enterprise.pmt.entity.PmtTimesheet::getWeekStartDate, end)
                .and(w -> w.eq(com.enterprise.pmt.entity.PmtTimesheet::getLocked, 1)
                        .or().eq(com.enterprise.pmt.entity.PmtTimesheet::getStatus, "LOCKED"))
                .and(w -> w.and(w1 -> w1.isNull(com.enterprise.pmt.entity.PmtTimesheet::getSettled)
                                .or().ne(com.enterprise.pmt.entity.PmtTimesheet::getSettled, 1))
                        .and(w2 -> w2.isNull(com.enterprise.pmt.entity.PmtTimesheet::getIsSettlement)
                                .or().ne(com.enterprise.pmt.entity.PmtTimesheet::getIsSettlement, 1)));
        if (projectSet != null) {
            qw.in(com.enterprise.pmt.entity.PmtTimesheet::getProjectId, projectSet);
        }
        List<com.enterprise.pmt.entity.PmtTimesheet> sheets = timesheetMapper.selectList(qw);
        if (sheets == null || sheets.isEmpty()) return Collections.emptyList();

        // 3) 过滤：成员 workNature = SETTLE（对同一 project_id+user_id/employee_id 查一次）
        List<Long> out = new ArrayList<>(sheets.size());
        Map<String, Boolean> natureCache = new HashMap<>();
        for (com.enterprise.pmt.entity.PmtTimesheet s : sheets) {
            String key = s.getProjectId() + "|" + s.getUserId() + "|" + s.getEmployeeId();
            Boolean ok = natureCache.get(key);
            if (ok == null) {
                LambdaQueryWrapper<com.enterprise.pmt.entity.PmtProjectMember> mw = new LambdaQueryWrapper<>();
                mw.eq(com.enterprise.pmt.entity.PmtProjectMember::getProjectId, s.getProjectId())
                        .eq(com.enterprise.pmt.entity.PmtProjectMember::getDeleted, 0)
                        .and(w -> w.eq(com.enterprise.pmt.entity.PmtProjectMember::getUserId, s.getUserId())
                                .or().eq(com.enterprise.pmt.entity.PmtProjectMember::getEmployeeId, s.getEmployeeId()))
                        .last("LIMIT 1");
                com.enterprise.pmt.entity.PmtProjectMember m = projectMemberMapper.selectOne(mw);
                ok = (m != null && "SETTLE".equals(m.getWorkNature()));
                natureCache.put(key, ok);
            }
            if (Boolean.TRUE.equals(ok)) out.add(s.getId());
        }
        return out;
    }

    private PmtSettlementBatch buildBatchFromBody(Map<String, Object> body) {
        PmtSettlementBatch b = new PmtSettlementBatch();
        b.setBatchName(getStr(body, "batchName"));
        b.setSettlementMonth(getStr(body, "settlementMonth"));
        b.setWorkMonth(getStr(body, "workMonth"));
        b.setBatchType(getStr(body, "batchType"));
        b.setBatchStatus(getStr(body, "batchStatus"));
        b.setRemark(getStr(body, "remark"));
        Object pid = body.get("projectId");
        if (pid != null) {
            try { b.setProjectId(Long.valueOf(pid.toString())); } catch (Exception ignore) {}
        }
        Object s = body.get("startDate");
        Object e = body.get("endDate");
        if (s != null && StringUtils.hasText(s.toString())) {
            try { b.setStartDate(LocalDate.parse(s.toString(), DateTimeFormatter.ISO_LOCAL_DATE)); } catch (Exception ignore) {}
        }
        if (e != null && StringUtils.hasText(e.toString())) {
            try { b.setEndDate(LocalDate.parse(e.toString(), DateTimeFormatter.ISO_LOCAL_DATE)); } catch (Exception ignore) {}
        }
        if (b.getTotalWorkDays() == null) b.setTotalWorkDays(BigDecimal.ZERO);
        if (b.getTotalAmount() == null) b.setTotalAmount(BigDecimal.ZERO);
        return b;
    }

    private static String getStr(Map<String, Object> m, String k) {
        Object v = m.get(k);
        return v == null ? null : (StringUtils.hasText(v.toString()) ? v.toString() : null);
    }

    private static List<Long> toLongList(List<?> list) {
        if (list == null) return null;
        java.util.ArrayList<Long> out = new java.util.ArrayList<>(list.size());
        for (Object o : list) {
            if (o == null) continue;
            try { out.add(Long.valueOf(o.toString())); } catch (Exception ignore) {}
        }
        return out;
    }

    private void fillCreator(PmtSettlementBatch batch) {
        Long uid = SecurityContextUtil.getCurrentUserId();
        if (uid != null) {
            batch.setCreatorId(uid);
            User u = userMapper.selectById(uid);
            if (u != null) batch.setCreatorName(u.getRealName());
        }
    }

    private void applyDefaults(PmtSettlementBatch batch) {
        if (!StringUtils.hasText(batch.getBatchName())) {
            throw new BusinessException("批次名称不能为空");
        }
        if (!StringUtils.hasText(batch.getBatchType())) {
            batch.setBatchType("MONTHLY");
        }
        if (!StringUtils.hasText(batch.getBatchStatus())) {
            batch.setBatchStatus("DRAFT");
        }
        if (batch.getTotalWorkDays() == null) batch.setTotalWorkDays(BigDecimal.ZERO);
        if (batch.getTotalAmount() == null) batch.setTotalAmount(BigDecimal.ZERO);

        // 缺省月份/周期：优先取 settlementMonth / workMonth，否则按当前月
        String month = StringUtils.hasText(batch.getSettlementMonth())
                ? batch.getSettlementMonth()
                : (StringUtils.hasText(batch.getWorkMonth()) ? batch.getWorkMonth() : null);
        if (month == null) {
            YearMonth ym = YearMonth.now();
            month = ym.toString();
            batch.setSettlementMonth(month);
            batch.setWorkMonth(month);
        } else {
            if (!StringUtils.hasText(batch.getSettlementMonth())) batch.setSettlementMonth(month);
            if (!StringUtils.hasText(batch.getWorkMonth())) batch.setWorkMonth(month);
        }
        if (batch.getStartDate() == null || batch.getEndDate() == null) {
            YearMonth ym = YearMonth.parse(month, DateTimeFormatter.ofPattern("yyyy-MM"));
            batch.setStartDate(ym.atDay(1));
            batch.setEndDate(ym.atEndOfMonth());
        }
    }

    private void ensureBatchNo(PmtSettlementBatch batch) {
        if (StringUtils.hasText(batch.getBatchNo())) return;
        String ym = batch.getSettlementMonth() != null ? batch.getSettlementMonth().replace("-", "") :
                YearMonth.now().format(DateTimeFormatter.ofPattern("yyyyMM"));
        String prefix = "JS" + ym;
        Long n = batchMapper.countByPrefix(prefix + "%");
        String seq = String.format("%04d", (n == null ? 0 : n) + 1);
        batch.setBatchNo(prefix + seq);
    }

    @ApiOperation("更新结算批次")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:update')")
    @PutMapping("/batches/{id}")
    @OperationLog("更新结算批次")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> updateBatch(@PathVariable Long id, @RequestBody PmtSettlementBatch batch) {
        PmtSettlementBatch exist = batchMapper.selectById(id);
        if (exist == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        batch.setId(id);
        return Result.success(batchMapper.updateById(batch) > 0);
    }

    @ApiOperation("删除结算批次")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:delete')")
    @DeleteMapping("/batches/{id:\\d+}")
    @OperationLog("删除结算批次")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> deleteBatch(@PathVariable Long id) {
        PmtSettlementBatch batch = batchMapper.selectById(id);
        if (batch == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        batchMapper.deleteById(id);
        return Result.success(true);
    }

    @ApiOperation("分页查询结算单")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:view')")
    @GetMapping("/orders/page")
    public Result<Page<PmtSettlementOrder>> pageOrders(@RequestParam(defaultValue = "1") int pageNum,
                                                       @RequestParam(defaultValue = "10") int pageSize,
                                                       @RequestParam(required = false) Long batchId,
                                                       @RequestParam(required = false) Long projectId,
                                                       @RequestParam(required = false) String keyword,
                                                       @RequestParam(required = false) String orderStatus) {
        Page<PmtSettlementOrder> page = new Page<>(pageNum, pageSize);
        return Result.success(orderMapper.selectPageList(page, batchId, projectId, keyword, orderStatus));
    }

    @ApiOperation("获取所有结算单")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:view')")
    @GetMapping("/orders/list")
    public Result<List<PmtSettlementOrder>> listOrders(@RequestParam(required = false) Long projectId) {
        return Result.success(orderMapper.selectListByProjectId(projectId));
    }

    @ApiOperation("获取结算单详情")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:view')")
    @GetMapping("/orders/{id:\\d+}")
    public Result<PmtSettlementOrder> getOrderDetail(@PathVariable Long id) {
        PmtSettlementOrder order = orderMapper.selectById(id);
        if (order == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        return Result.success(order);
    }

    @ApiOperation("创建结算单")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:create')")
    @PostMapping("/orders")
    @OperationLog("创建结算单")
    @Transactional(rollbackFor = Exception.class)
    public Result<Long> createOrder(@RequestBody PmtSettlementOrder order) {
        orderMapper.insert(order);
        return Result.success(order.getId());
    }

    @ApiOperation("更新结算单")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:update')")
    @PutMapping("/orders/{id}")
    @OperationLog("更新结算单")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> updateOrder(@PathVariable Long id, @RequestBody PmtSettlementOrder order) {
        PmtSettlementOrder exist = orderMapper.selectById(id);
        if (exist == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        order.setId(id);
        return Result.success(orderMapper.updateById(order) > 0);
    }

    @ApiOperation("删除结算单")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:delete')")
    @DeleteMapping("/orders/{id}")
    @OperationLog("删除结算单")
    @Transactional(rollbackFor = Exception.class)
    public Result<Boolean> deleteOrder(@PathVariable Long id) {
        PmtSettlementOrder order = orderMapper.selectById(id);
        if (order == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        orderItemMapper.deleteByOrderId(id);
        orderMapper.deleteById(id);
        return Result.success(true);
    }

    @ApiOperation("获取结算单明细")
    @PreAuthorize("@permissionChecker.hasPermission('pmt:settlement:view')")
    @GetMapping("/orders/{id}/items")
    public Result<List<PmtSettlementOrderItem>> getOrderItems(@PathVariable Long id) {
        return Result.success(orderItemMapper.selectByOrderId(id));
    }
}
