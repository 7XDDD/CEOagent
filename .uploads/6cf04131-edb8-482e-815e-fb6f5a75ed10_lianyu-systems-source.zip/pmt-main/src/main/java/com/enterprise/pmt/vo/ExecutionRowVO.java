package com.enterprise.pmt.vo;

import lombok.Data;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 执行状态矩阵：一行 = 一个员工 + 一个项目
 */
@Data
public class ExecutionRowVO {
    private String employeeNo;
    private String employeeName;
    /** 项目角色（来自预算） */
    private String roleInProject;
    /** 工时性质：SETTLE/NON_SETTLE → 前端映射成 结算/不结算 */
    private String workNature;
    /** 成员状态（在职/离职） */
    private String employeeStatus;
    private String projectCode;
    private String projectName;
    /** 关联 ID（仅用于前端定位/调试） */
    private Long projectId;
    private Long employeeId;

    /** 周单元格：key = weekStart.toString()（yyyy-MM-dd 格式字符串，与 ExecutionWeekHeaderVO.weekStart 对应） */
    private Map<String, ExecutionWeekCellVO> weekValues = new LinkedHashMap<>();

    /** 该员工-项目 5 项汇总指标 */
    private ExecutionSummaryVO summary = new ExecutionSummaryVO();
}
