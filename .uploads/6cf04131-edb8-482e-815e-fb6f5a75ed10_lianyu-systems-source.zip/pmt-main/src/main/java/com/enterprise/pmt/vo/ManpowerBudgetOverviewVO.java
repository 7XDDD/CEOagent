package com.enterprise.pmt.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class ManpowerBudgetOverviewVO {

    private Long projectId;

    private Long parentId;

    private String projectCode;

    private String projectName;

    private String pmName;

    private String status;

    private String projectType;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate plannedStartDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate plannedEndDate;

    /** 项目预算工时（天） */
    private BigDecimal budgetDays;

    /** 人力预算金额 */
    private BigDecimal budgetLaborAmount;

    /** 已分配工时（天，成员预计工时天之和） */
    private BigDecimal allocatedDays;

    /** 已用工时（小时，截至当天已审批） */
    private BigDecimal usedHours;
}
