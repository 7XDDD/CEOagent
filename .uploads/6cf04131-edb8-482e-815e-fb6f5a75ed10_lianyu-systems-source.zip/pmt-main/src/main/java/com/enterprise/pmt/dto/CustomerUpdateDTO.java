package com.enterprise.pmt.dto;

import lombok.Data;

@Data
public class CustomerUpdateDTO {
    private String customerCode;
    private String customerName;
    private String customerShortName;
    private String customerType;
    private String customerClassify;
    private String customerScale;
    private String customerIndustry;
    private String industry;
    private String unifiedSocialCredit;
    private String website;
    private String taxNumber;
    private String contactPerson;
    private String contactPhone;
    private String contactEmail;
    private String address;
    private String registerAddress;
    private String creditLevel;
    private String bankName;
    private String bankAccount;
    private Long parentId;
    private String status;
    private String dataStatus;
    private String remark;
}
