package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtCustomerAddress;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtCustomerAddressMapper extends BaseMapper<PmtCustomerAddress> {

    List<PmtCustomerAddress> selectByCustomerId(@Param("customerId") Long customerId);

    List<PmtCustomerAddress> selectByCustomerIds(@Param("customerIds") List<Long> customerIds);

    PmtCustomerAddress selectAddressById(@Param("id") Long id);

    int insertAddress(PmtCustomerAddress address);

    int updateAddress(PmtCustomerAddress address);

    int deleteByCustomerId(@Param("customerId") Long customerId);

    int deleteByCustomerIds(@Param("customerIds") List<Long> customerIds);

    int deleteAddressById(@Param("id") Long id);

    int clearDefaultByCustomerId(@Param("customerId") Long customerId);
}
