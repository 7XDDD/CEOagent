package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtAttendanceCalendar;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtAttendanceCalendarMapper extends BaseMapper<PmtAttendanceCalendar> {

    List<PmtAttendanceCalendar> selectByMonth(@Param("year") Integer year, @Param("month") Integer month);

    List<PmtAttendanceCalendar> selectByDateRange(@Param("startDate") String startDate, @Param("endDate") String endDate);
}
