package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.ApprovalBusinessType;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface ApprovalBusinessTypeMapper extends BaseMapper<ApprovalBusinessType> {

    @Select("SELECT * FROM pmt_approval_business_type WHERE deleted = 0 AND status = 1 ORDER BY sort_order ASC, code ASC")
    List<ApprovalBusinessType> selectAllEnabled();

    @Select("SELECT * FROM pmt_approval_business_type WHERE deleted = 0 ORDER BY sort_order ASC, code ASC")
    List<ApprovalBusinessType> selectAll();

    @Select("SELECT * FROM pmt_approval_business_type WHERE code = #{code} AND deleted = 0 LIMIT 1")
    ApprovalBusinessType selectByCode(@Param("code") String code);
}
