package com.enterprise.pmt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.enterprise.pmt.entity.PmtCustomerContact;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtCustomerContactMapper extends BaseMapper<PmtCustomerContact> {

    List<PmtCustomerContact> selectByCustomerId(@Param("customerId") Long customerId);

    List<PmtCustomerContact> selectByCustomerIds(@Param("customerIds") List<Long> customerIds);

    PmtCustomerContact selectContactById(@Param("id") Long id);

    int insertContact(PmtCustomerContact contact);

    int updateContact(PmtCustomerContact contact);

    int deleteByCustomerId(@Param("customerId") Long customerId);

    int deleteByCustomerIds(@Param("customerIds") List<Long> customerIds);

    int deleteContactById(@Param("id") Long id);

    int clearPrimaryByCustomerId(@Param("customerId") Long customerId);
}
