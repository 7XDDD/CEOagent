package com.enterprise.pmt.vo;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * 工时填报周默认值响应
 * 按项目分组，给出该周每天的默认工时数
 */
@Data
public class TimesheetWeekDefaultsVO {

    private String weekStartDate;
    private String weekEndDate;
    /** 周一~周日，共7天 */
    private List<DayInfo> weekDays;
    /** 该周可填报的项目列表（含每日默认工时） */
    private List<ProjectDefault> projects;
    /** 当日所有项目默认工时合计（供前端判断是否超8小时） */
    private List<BigDecimal> dailyTotals;
    /** 当日请假小时数（审批通过的请假），长度7 */
    private List<BigDecimal> dailyLeaveHours;
    /** 当日可用工时（8 - 请假小时），长度7，最小0 */
    private List<BigDecimal> dailyAvailableHours;

    @Data
    public static class DayInfo {
        /** 0=周一 ... 6=周日 */
        private int dayIndex;
        private String date;
        private String weekDayName;
        /** 当日请假小时数 */
        private BigDecimal leaveHours;
        /** 是否整天请假（请假>=8小时） */
        private Boolean fullDayLeave;
        /** 当日可用工时 = 8 - leaveHours，最小0 */
        private BigDecimal availableHours;
    }

    @Data
    public static class ProjectDefault {
        private Long projectId;
        private String projectCode;
        private String projectName;
        private Long memberId;
        /** 长度7，对应周一到周日，值为每日默认工时（小时），当天无时间段则为null */
        private List<BigDecimal> defaultHours;
        /** 长度7，标记该天是否是请假日（灰色提示） */
        private List<Boolean> leaveFlags;
        /** 项目成员工时性质：SETTLE=结算，NON_SETTLE=不结算 */
        private String workNature;
    }
}
