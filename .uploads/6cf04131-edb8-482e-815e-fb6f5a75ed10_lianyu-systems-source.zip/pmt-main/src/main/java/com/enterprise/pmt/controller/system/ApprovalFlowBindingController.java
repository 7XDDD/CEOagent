package com.enterprise.pmt.controller.system;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.enterprise.pmt.annotation.OperationLog;
import com.enterprise.pmt.annotation.OperationLog.OperationType;
import com.enterprise.pmt.common.Result;
import com.enterprise.pmt.entity.*;
import com.enterprise.pmt.mapper.*;
import com.enterprise.pmt.security.SecurityUtils;
import com.enterprise.pmt.service.ApprovalFlowBindingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/approval-flow-bindings")
public class ApprovalFlowBindingController {

    @Autowired
    private ApprovalFlowBindingService bindingService;
    @Autowired
    private ApprovalFlowMapper flowMapper;
    @Autowired
    private ApprovalBusinessTypeMapper businessTypeMapper;
    @Autowired
    private PmtProjectMapper projectMapper;

    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow-binding:view')")
    @GetMapping("/page")
    public Result<IPage<Map<String, Object>>> pageBindings(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String businessType,
            @RequestParam(required = false) String scopeType) {
        
        Page<ApprovalFlowBinding> page = new Page<>(pageNum, pageSize);
        IPage<ApprovalFlowBinding> resultPage = bindingService.pageBindings(page, businessType, scopeType, null);
        
        // 转换并填充关联名称
        IPage<Map<String, Object>> voPage = resultPage.convert(binding -> {
            Map<String, Object> vo = new HashMap<>();
            vo.put("id", binding.getId());
            vo.put("businessType", binding.getBusinessType());
            vo.put("scopeType", binding.getScopeType());
            vo.put("scopeId", binding.getScopeId());
            vo.put("scopeIds", binding.getScopeIds());
            vo.put("flowId", binding.getFlowId());
            vo.put("priority", binding.getPriority());
            vo.put("enabled", binding.getEnabled());
            vo.put("remark", binding.getRemark());
            vo.put("createTime", binding.getCreateTime());
            
            // 业务类型名称
            ApprovalBusinessType bt = businessTypeMapper.selectByCode(binding.getBusinessType());
            vo.put("businessTypeName", bt != null ? bt.getName() : binding.getBusinessType());
            
            // 流程名称
            ApprovalFlow flow = flowMapper.selectById(binding.getFlowId());
            vo.put("flowName", flow != null ? flow.getFlowName() : "流程已删除");
            
            // 范围名称
            String scopeName = "";
            if ("GLOBAL".equals(binding.getScopeType())) {
                scopeName = "全局默认";
            } else if ("PROJECT".equals(binding.getScopeType())) {
                if (binding.getScopeId() != null && binding.getScopeIds() == null) {
                    PmtProject proj = projectMapper.selectById(binding.getScopeId());
                    scopeName = proj != null ? proj.getProjectName() : "项目ID:" + binding.getScopeId();
                } else if (binding.getScopeIds() != null && !binding.getScopeIds().isEmpty()) {
                    String[] idArr = binding.getScopeIds().split(",");
                    StringBuilder sb = new StringBuilder();
                    int limit = 3;
                    int count = 0;
                    for (String idStr : idArr) {
                        if (count >= limit) { sb.append(" 等").append(idArr.length).append("个项目"); break; }
                        try {
                            Long pid = Long.parseLong(idStr.trim());
                            PmtProject proj = projectMapper.selectById(pid);
                            if (proj != null) {
                                if (count > 0) sb.append("、");
                                sb.append(proj.getProjectName());
                            }
                        } catch (NumberFormatException ignored) {}
                        count++;
                    }
                    scopeName = sb.toString();
                } else if (binding.getScopeId() != null) {
                    PmtProject proj = projectMapper.selectById(binding.getScopeId());
                    scopeName = proj != null ? proj.getProjectName() : "项目ID:" + binding.getScopeId();
                }
            } else if ("DEPT".equals(binding.getScopeType()) && binding.getScopeId() != null) {
                scopeName = "部门ID:" + binding.getScopeId();
            } else if ("ORG".equals(binding.getScopeType()) && binding.getScopeId() != null) {
                scopeName = "组织ID:" + binding.getScopeId();
            }
            vo.put("scopeName", scopeName);
            
            // 范围类型显示
            Map<String, String> scopeTypeMap = new HashMap<>();
            scopeTypeMap.put("GLOBAL", "全局");
            scopeTypeMap.put("ORG", "组织");
            scopeTypeMap.put("DEPT", "部门");
            scopeTypeMap.put("PROJECT", "项目");
            vo.put("scopeTypeName", scopeTypeMap.getOrDefault(binding.getScopeType(), binding.getScopeType()));
            
            return vo;
        });
        
        return Result.success(voPage);
    }

    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:approval-flow-binding:create', 'pmt:approval-flow-binding:update')")
    @OperationLog(module = "审批流程绑定", description = "绑定审批流程", type = OperationType.INSERT)
    @PostMapping
    public Result<Void> saveOrUpdate(@RequestBody ApprovalFlowBinding binding) {
        Long currentUserId = SecurityUtils.getCurrentUserId();
        bindingService.saveOrUpdateBinding(binding, currentUserId);
        return Result.success();
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow-binding:view')")
    @GetMapping("/scope/{scopeType}/{scopeId}")
    public Result<List<ApprovalFlowBinding>> listByScope(
            @PathVariable String scopeType,
            @PathVariable Long scopeId) {
        return Result.success(bindingService.listByScope(scopeType, scopeId));
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow-binding:view')")
    @GetMapping("/business-type/{businessType}")
    public Result<List<ApprovalFlowBinding>> listByBusinessType(@PathVariable String businessType) {
        return Result.success(bindingService.listByBusinessType(businessType));
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow-binding:view')")
    @GetMapping("/project/{projectId}")
    public Result<Map<String, Long>> getProjectBindings(@PathVariable Long projectId) {
        return Result.success(bindingService.getProjectBindings(projectId));
    }

    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:approval-flow-binding:create', 'pmt:approval-flow-binding:update')")
    @OperationLog(module = "审批流程绑定", description = "绑定审批流程", type = OperationType.INSERT)
    @PostMapping("/project/{projectId}")
    public Result<Void> saveProjectBindings(
            @PathVariable Long projectId,
            @RequestBody Map<String, Long> bindings) {
        Long currentUserId = SecurityUtils.getCurrentUserId();
        bindingService.saveProjectBindings(projectId, bindings, currentUserId);
        return Result.success();
    }

    @PreAuthorize("@permissionChecker.hasAnyPermission('pmt:approval-flow-binding:create', 'pmt:approval-flow-binding:update')")
    @OperationLog(module = "审批流程绑定", description = "绑定审批流程", type = OperationType.INSERT)
    @PostMapping("/global")
    public Result<Void> saveGlobalBinding(@RequestBody Map<String, Object> body) {
        Long currentUserId = SecurityUtils.getCurrentUserId();
        String businessType = body.get("businessType").toString();
        Long flowId = Long.valueOf(body.get("flowId").toString());
        bindingService.saveGlobalBinding(businessType, flowId, currentUserId);
        return Result.success();
    }

    @PreAuthorize("@permissionChecker.hasPermission('pmt:approval-flow-binding:delete')")
    @OperationLog(module = "审批流程绑定", description = "解绑审批流程", type = OperationType.DELETE)
    @DeleteMapping("/{id:\\d+}")
    public Result<Void> delete(@PathVariable Long id) {
        Long currentUserId = SecurityUtils.getCurrentUserId();
        bindingService.deleteBinding(id, currentUserId);
        return Result.success();
    }
}
