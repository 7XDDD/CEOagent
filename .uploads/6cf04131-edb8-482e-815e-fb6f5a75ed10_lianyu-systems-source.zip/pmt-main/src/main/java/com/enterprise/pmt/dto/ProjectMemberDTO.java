package com.enterprise.pmt.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
public class ProjectMemberDTO {
    private Long id;
    private Long employeeId;
    private String jobNumber;
    private String memberName;
    private String roleInProject;
    private String workDuty;
    /** 工时性质：SETTLE=结算，NON_SETTLE=不结算 */
    private String workNature;
    private BigDecimal estimatedWorkDays;
    private Boolean createUser;

    private List<MemberPeriodDTO> periods;

    // ========== 向后兼容：单时间段字段，未传periods时使用 ==========
    private LocalDate plannedJoinDate;
    private LocalDate plannedLeaveDate;
    private LocalDate actualJoinDate;
    private LocalDate actualLeaveDate;
    private BigDecimal workloadRatio;
    private Integer isActive;
    private String remark;

    @Data
    public static class MemberPeriodDTO {
        private Long id;
        private LocalDate plannedJoinDate;
        private LocalDate plannedLeaveDate;
        private LocalDate actualJoinDate;
        private LocalDate actualLeaveDate;
        private BigDecimal workloadRatio;
        private BigDecimal estimatedWorkDays;
        private Integer isActive;
        private String remark;
        private Integer periodOrder;
    }
}
