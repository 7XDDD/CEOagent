package com.enterprise.pmt.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class TimesheetItemDTO {
    private LocalDate workDate;
    private Long projectId;
    private String projectName;
    private Long contractId;
    private String taskName;
    private String workType;
    private BigDecimal hours;
    private BigDecimal billableHours;
    private BigDecimal hourRate;
    private Integer isBillable;
    private Integer progress;
    private String workDescription;
    private String remark;
}
