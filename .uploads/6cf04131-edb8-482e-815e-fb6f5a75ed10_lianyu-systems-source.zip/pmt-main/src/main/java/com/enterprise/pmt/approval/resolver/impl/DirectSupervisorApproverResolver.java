package com.enterprise.pmt.approval.resolver.impl;

import com.enterprise.pmt.approval.resolver.ApproverResolver;
import com.enterprise.pmt.entity.ApprovalNode;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

/**
 * 直属上级审批人解析器
 * 可根据用户表的leader_id字段解析，后续完善
 */
@Component
public class DirectSupervisorApproverResolver implements ApproverResolver {

    @Override
    public String getSupportedType() {
        return "DIRECT_SUPERVISOR";
    }

    @Override
    public List<Long> resolveApproverIds(ApprovalNode node, Long applicantId, Long projectId, Long deptId) {
        // TODO: 根据用户汇报关系解析直属上级，先返回空列表，后续完善
        // 可从SysUser.leaderId获取
        return Collections.emptyList();
    }
}
