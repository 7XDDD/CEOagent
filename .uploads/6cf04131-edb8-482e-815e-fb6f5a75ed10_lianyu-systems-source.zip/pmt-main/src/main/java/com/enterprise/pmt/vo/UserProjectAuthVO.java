package com.enterprise.pmt.vo;

import lombok.Data;

/**
 * 用户项目授权行VO（用户管理-数据权限弹窗用）
 */
@Data
public class UserProjectAuthVO {
    private Long projectId;
    private String projectCode;
    private String projectName;
    private String customerName;
    /** 是否项目成员（来自 pmt_project_member） */
    private Boolean member;
    /** 是否可查看项目所有成员数据（来自 pmt_project_manager.can_view_all） */
    private Boolean canViewAll;
    /** 是否可编辑（can_edit） */
    private Boolean canEdit;
    /** 是否可审批（can_approve） */
    private Boolean canApprove;
}
