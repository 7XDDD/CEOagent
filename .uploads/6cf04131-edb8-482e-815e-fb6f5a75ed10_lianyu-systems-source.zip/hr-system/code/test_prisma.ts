import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function run() {
  const emp = await prisma.employee.findFirst({ where: { status: 'ACTIVE' }});
  if (!emp) {
    console.log("No active employee");
    return;
  }
  console.log("Found emp:", emp.id);
  try {
    const res = await prisma.consultantBaseline.upsert({
      where: {
        employeeId_year: {
          employeeId: emp.id,
          year: 2026
        }
      },
      update: { baselineDays: 120 },
      create: {
        employeeId: emp.id,
        year: 2026,
        baselineDays: 120
      }
    });
    console.log("Upsert Success:", res);
  } catch(e) {
    console.error("Upsert Error:", e);
  }
}
run();
