import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  try {
    const lisi = await prisma.employee.findFirst({
      where: { name: '李四' }
    });
    console.log('Employee 李四:', lisi);

    if (lisi) {
      const summary = await prisma.monthlyAttendanceSummary.findFirst({
        where: { name: '李四', month: '2026-05' }
      });
      console.log('MonthlyAttendanceSummary (2026-05):', summary);
    }
  } catch (e) {
    console.error(e);
  } finally {
    await prisma.$disconnect();
  }
}

main();
