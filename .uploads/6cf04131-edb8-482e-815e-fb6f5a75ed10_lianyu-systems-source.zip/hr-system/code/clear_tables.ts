import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

async function main() {
  await prisma.importedOvertime.deleteMany({})
  await prisma.importedLeave.deleteMany({})
  await prisma.importedTravel.deleteMany({})
}
main().then(() => console.log('cleared')).catch(console.error)
