import { saveConsultantBaseline } from './src/actions/pmo';
async function test() {
  const res = await saveConsultantBaseline('test-emp-id', 2026, 120);
  console.log(res);
}
test();
