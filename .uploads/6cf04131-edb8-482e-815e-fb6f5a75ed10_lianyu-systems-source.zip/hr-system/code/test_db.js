const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const fields = await prisma.customField.findMany();
  console.log("Custom Fields:", fields);
  
  const emp = await prisma.employee.findFirst({ where: { name: '李四' }});
  console.log("李四:", emp);
}

main()
  .catch(e => console.error(e))
  .finally(async () => {
    await prisma.$disconnect();
  });
