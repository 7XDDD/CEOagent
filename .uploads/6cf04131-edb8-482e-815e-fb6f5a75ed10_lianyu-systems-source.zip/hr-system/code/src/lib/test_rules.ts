import { prisma } from './prisma';
import { 
  consolidateEmployeeAttendance, 
  submitAnomalyAppeal, 
  approveAnomalyAppeal, 
  createMakeUpApproval
} from '../actions/attendance';
import { 
  saveConsultantBaseline,
  saveProjectConsultantMapping,
  saveProjectMonthlyData,
  getPMOEfficiencyReport 
} from '../actions/pmo';

async function runTests() {
  console.log('--- Starting System Verification Tests ---');

  // Let's create a test employee. If they exist, delete first.
  const testJobNum = 'EMP-TEST-99';
  let emp = await prisma.employee.findUnique({
    where: { jobNumber: testJobNum }
  });
  if (emp) {
    await prisma.employee.delete({
      where: { id: emp.id }
    });
  }

  // Create test employee
  emp = await prisma.employee.create({
    data: {
      jobNumber: testJobNum,
      idCard: '110101199003072337', // Birth date: 1990-03-07, Gender: male
      name: '测试员张三',
      gender: 'MALE',
      birthday: new Date('1990-03-07'),
      status: 'ACTIVE',
      exemptAttendance: false,
      hireDate: new Date('2026-06-05'),
      probationMonths: 3,
      contractType: 'STANDARD',
      contractStartDate: new Date('2026-06-05'),
      contractEndDate: new Date('2030-06-04'),
      extInfo: { workLocation: '北京', department: '交付部', position: '顾问' }
    }
  });
  console.log('Step 1: Created test employee:', emp.name);

  // Set up mock calendar for 2026-06
  console.log('Step 2: Preparing calendar for 2026-06...');
  const calendarMap = new Map<string, string>();
  for (let d = 1; d <= 30; d++) {
    const dateStr = `2026-06-${String(d).padStart(2, '0')}`;
    const dateObj = new Date(dateStr);
    const dayOfWeek = dateObj.getDay();
    const isW = dayOfWeek !== 0 && dayOfWeek !== 6;
    const type = isW ? 'WORKDAY' : 'WEEKEND';
    calendarMap.set(dateStr, type);

    // Upsert into DB
    await prisma.attendanceCalendar.upsert({
      where: { date: dateObj },
      update: { type },
      create: { date: dateObj, type }
    });
  }

  // --- Rule Verification 1: 周末出差排异 ---
  console.log('Step 3: Testing travel weekend exclusion...');
  // Delete existing travels for this employee
  await prisma.importedTravel.deleteMany({ where: { jobNumber: testJobNum } });
  // Add a travel: covers 2026-06-05 (Fri) to 2026-06-08 (Mon)
  await prisma.importedTravel.create({
    data: {
      approvalNumber: 'TRV-MOCK-01',
      name: emp.name,
      jobNumber: testJobNum,
      reason: '项目出差',
      startTime: new Date('2026-06-05 09:00:00'),
      endTime: new Date('2026-06-08 18:00:00'),
      duration: 32.0 // hours
    }
  });

  // --- Rule Verification 2: 应出勤及缺勤切分 ---
  // Resign date: 2026-06-25
  await prisma.employee.update({
    where: { id: emp.id },
    data: {
      status: 'RESIGNED',
      extInfo: {
        workLocation: '北京',
        department: '交付部',
        position: '顾问',
        resignedAt: '2026-06-25T09:00:00.000Z'
      }
    }
  });

  // We re-query the updated employee to pass to calculation
  const updatedEmp = await prisma.employee.findUnique({
    where: { id: emp.id }
  });

  // --- Rule Verification 3: 阶梯迟到算薪 & 缺卡 & 旷工 ---
  // Clean old clockings
  await prisma.importedClocking.deleteMany({ where: { jobNumber: testJobNum } });

  // Add clockings for test:
  // June 9: Check in at 09:03 (Late 3 mins, deduct 0.5h)
  // June 10: Check in at 09:12 (Late 12 mins, deduct 1.0h)
  // June 11: Check in at 09:25 (Late 25 mins, deduct 4.0h)
  // June 12: Check in at 09:00, check out null (Missed check, deduct 4.0h)
  // June 15: Check in null, check out 18:00 (Missed check, deduct 4.0h)
  // June 16: Check in null, check out null (0 check-in, Absent 1 day, deduct 8.0h)
  // June 17: Check in only (no check out) -> Missed check
  // June 18: Check in only (no check out) -> Missed check
  // June 19: Check in only (no check out) -> Missed check
  const clockingsData = [
    { date: new Date('2026-06-09'), checkIn: '09:03', checkOut: '18:00' },
    { date: new Date('2026-06-10'), checkIn: '09:12', checkOut: '18:00' },
    { date: new Date('2026-06-11'), checkIn: '09:25', checkOut: '18:00' },
    { date: new Date('2026-06-12'), checkIn: '09:00', checkOut: null },
    { date: new Date('2026-06-15'), checkIn: null, checkOut: '18:00' },
    // June 16 is absent (no record)
    { date: new Date('2026-06-17'), checkIn: '09:00', checkOut: null },
    { date: new Date('2026-06-18'), checkIn: '09:00', checkOut: null },
    { date: new Date('2026-06-19'), checkIn: '09:00', checkOut: null },
  ];

  for (const clock of clockingsData) {
    await prisma.importedClocking.create({
      data: {
        date: clock.date,
        name: updatedEmp!.name,
        jobNumber: testJobNum,
        checkIn: clock.checkIn,
        checkOut: clock.checkOut,
        result: '正常'
      }
    });
  }

  // --- Rule Verification 4: 免费补卡豁免 4 次对冲 ---
  // Create 5 approved make up card approvals for June
  await prisma.makeUpCardApproval.deleteMany({ where: { employeeId: emp.id } });
  for (let i = 12; i <= 16; i++) { // Let's make 5 make up cards
    await prisma.makeUpCardApproval.create({
      data: {
        employeeId: emp.id,
        date: new Date(`2026-06-${i}`),
        status: 'APPROVED'
      }
    });
  }

  // Run Monthly calculation
  console.log('Step 4: Running consolidateEmployeeAttendance...');
  const startDate = new Date('2026-06-01');
  const endDate = new Date('2026-06-30 23:59:59');
  const shouldWorkDays = 22; // 22 workdays in June 2026

  await consolidateEmployeeAttendance(
    updatedEmp,
    '2026-06',
    startDate,
    endDate,
    calendarMap
  );

  // Read summary and anomalies from DB
  const summary = await prisma.monthlyAttendanceSummary.findFirst({
    where: { jobNumber: testJobNum, month: '2026-06' }
  });

  const anomalies = await prisma.attendanceAnomaly.findMany({
    where: { employeeId: emp.id },
    orderBy: { date: 'asc' }
  });

  console.log('\n--- Calculated Attendance Summary ---');
  console.log('Name:', summary?.name);
  console.log('Workdays in Calendar:', summary?.shouldWorkDays);
  console.log('Pre/Post-Hire/Resign Absent Days:', summary?.absentDays); // Expect: 4 days (June 1-4) + 3 days (June 26,29,30) = 7 days
  console.log('Travel Days (Weekend Excluded):', summary?.travelDays); // Expect: 2 days (June 5, 8). Weekend June 6-7 excluded.
  console.log('Late/Missed Card Count (Active):', summary?.lateEarlyCount);
  console.log('Late/Missed Card Deduct Hours:', summary?.lateEarlyDeductHours);
  console.log('Absenteeism Days (旷工):', summary?.absenteeismDays);

  console.log('\n--- Anomalies Details ---');
  anomalies.forEach(a => {
    console.log(`- Date: ${a.date.toISOString().split('T')[0]}, Type: ${a.type}, Deduct: -${a.deductHours}h, Status: ${a.appealStatus}, Comment: ${a.managerComment}`);
  });

  if (summary?.absentDays === 7) {
    console.log('✓ SUCCESS: Pre/post-hire slicing matches expectations (7 days absent).');
  } else {
    console.error('✗ ERROR: Slicing failed! Expected 7 days, got', summary?.absentDays);
  }

  if (summary?.travelDays === 2) {
    console.log('✓ SUCCESS: Weekend travel days excluded successfully (2 days travel).');
  } else {
    console.error('✗ ERROR: Travel days count failed! Expected 2 days, got', summary?.travelDays);
  }

  const approvedMissedCount = anomalies.filter(a => a.type === 'MISSED_CARD' && a.appealStatus === 'APPROVED').length;
  const pendingMissedCount = anomalies.filter(a => a.type === 'MISSED_CARD' && a.appealStatus === 'NONE').length;
  if (approvedMissedCount === 4 && pendingMissedCount === 1) {
    console.log('✓ SUCCESS: Maximum 4 free make-up card exemptions enforced and offset correctly.');
  } else {
    console.error(`✗ ERROR: Exemption count mismatch! Approved: ${approvedMissedCount}, Remaining: ${pendingMissedCount}`);
  }

  // --- Rule Verification 5: 3天限期自助申诉与重新计算 ---
  console.log('\nStep 5: Testing 3-day appeal restriction...');
  
  // Create an anomaly with older date (e.g. 6 days ago) and recent date (e.g. 1 day ago)
  const oldDate = new Date('2026-06-02'); // 6 days ago
  const recentDate = new Date('2026-06-07'); // 1 day ago

  const oldAnomaly = await prisma.attendanceAnomaly.create({
    data: {
      employeeId: emp.id,
      date: oldDate,
      type: 'LATE',
      details: '迟到 09:12 (扣除1.0h)',
      deductHours: 1.0,
      appealStatus: 'NONE'
    }
  });

  const recentAnomaly = await prisma.attendanceAnomaly.create({
    data: {
      employeeId: emp.id,
      date: recentDate,
      type: 'LATE',
      details: '迟到 09:03 (扣除0.5h)',
      deductHours: 0.5,
      appealStatus: 'NONE'
    }
  });

  // Try to submit appeal for old anomaly -> Expect Failure (over 3 days)
  console.log('Appealing 6-day old anomaly...');
  const appealOldRes = await submitAnomalyAppeal(oldAnomaly.id, '拜访客户', 'http://voucher');
  console.log('Result:', appealOldRes.message);
  if (!appealOldRes.success && appealOldRes.message?.includes('超过 3 天申诉期限制')) {
    console.log('✓ SUCCESS: Older anomaly appeal successfully blocked.');
  } else {
    console.error('✗ ERROR: Allowed appeal for older anomaly!', appealOldRes);
  }

  // Try to submit appeal for recent anomaly -> Expect Success (within 3 days)
  console.log('Appealing 1-day old anomaly...');
  const appealRecentRes = await submitAnomalyAppeal(recentAnomaly.id, '外勤迟到', 'http://voucher');
  console.log('Result:', appealRecentRes.success ? 'Success' : 'Failed');
  if (appealRecentRes.success) {
    console.log('✓ SUCCESS: Recent anomaly appeal allowed.');
  } else {
    console.error('✗ ERROR: Recent anomaly appeal blocked!', appealRecentRes);
  }

  // Manager approves the appeal
  console.log('Approving recent anomaly appeal...');
  const approveRes = await approveAnomalyAppeal(recentAnomaly.id, '同意，按正常考勤');
  console.log('Approve result:', approveRes.success ? 'Success' : 'Failed');
  
  // Verify that the anomaly is approved and deductHours is set to 0
  const checkAnomaly = await prisma.attendanceAnomaly.findUnique({
    where: { id: recentAnomaly.id }
  });
  if (checkAnomaly?.appealStatus === 'APPROVED' && checkAnomaly?.deductHours === 0.0) {
    console.log('✓ SUCCESS: Anomaly marked APPROVED and deduction offset to 0.');
  } else {
    console.error('✗ ERROR: Anomaly status/deduction not updated!', checkAnomaly);
  }

  // --- Rule Verification 6: PMO project effectiveness & three-segment values ---
  console.log('\nStep 6: Testing PMO three-segment values & heatmap Saturation report...');

  // Setup PMO mappings
  const prjId = 'PRJ-XYZ';
  await prisma.projectConsultantMapping.deleteMany({ where: { projectId: prjId } });
  await saveProjectConsultantMapping(prjId, emp.id, 'John-Test-Alias');
  
  // Save baseline
  await saveConsultantBaseline(emp.id, 2026, 120);

  // Setup plan and actual human days
  // 1. Past Month (May 2026): actual = 5, planned = 8. Expect = 5
  await saveProjectMonthlyData(prjId, emp.id, '2026-05', 8, 5);

  // 2. Current Month (June 2026): actual = 8, planned = 10. Expect = MAX(10, 8) = 10
  await saveProjectMonthlyData(prjId, emp.id, '2026-06', 10, 8);

  // 3. Future Month (July 2026): actual = 0, planned = 12. Expect = 12
  await saveProjectMonthlyData(prjId, emp.id, '2026-07', 12, 0);

  // Run the report generator
  const reportRes = await getPMOEfficiencyReport(2026, prjId);
  const repRow = reportRes.data?.[0];

  console.log('\n--- Calculated PMO Report ---');
  console.log('Consultant Alias:', repRow?.consultantName);
  console.log('Baseline Days:', repRow?.baselineDays);
  console.log('Total Actual Days (May + June):', repRow?.totalActualDays); // May(5) + June(8) = 13.
  console.log('Attainment Rate:', repRow?.attainmentRate); // (13/120)*100 = 10.8%
  
  const mayVal = repRow?.months.find(m => m.month === '2026-05');
  const junVal = repRow?.months.find(m => m.month === '2026-06');
  const julVal = repRow?.months.find(m => m.month === '2026-07');

  console.log(`May 2026 (Past Month) finalDays: ${mayVal?.finalDays} (Expected: 5)`);
  console.log(`Jun 2026 (Current Month) finalDays: ${junVal?.finalDays} (Expected: 10)`);
  console.log(`Jul 2026 (Future Month) finalDays: ${julVal?.finalDays} (Expected: 12)`);

  if (mayVal?.finalDays === 5 && junVal?.finalDays === 10 && julVal?.finalDays === 12) {
    console.log('✓ SUCCESS: PMO Three-segment value selection logic is 100% correct.');
  } else {
    console.error('✗ ERROR: PMO Value selection logic failed!');
  }

  // Cleanup test data so we leave database clean
  console.log('\nCleaning up test data...');
  await prisma.projectConsultantMapping.deleteMany({ where: { projectId: prjId } });
  await prisma.consultantBaseline.deleteMany({ where: { employeeId: emp.id } });
  await prisma.projectSowPlan.deleteMany({ where: { employeeId: emp.id } });
  await prisma.projectActualOutput.deleteMany({ where: { employeeId: emp.id } });
  await prisma.attendanceAnomaly.deleteMany({ where: { employeeId: emp.id } });
  await prisma.makeUpCardApproval.deleteMany({ where: { employeeId: emp.id } });
  await prisma.importedClocking.deleteMany({ where: { jobNumber: testJobNum } });
  await prisma.importedTravel.deleteMany({ where: { jobNumber: testJobNum } });
  await prisma.monthlyAttendanceSummary.deleteMany({ where: { jobNumber: testJobNum } });
  await prisma.employee.delete({ where: { id: emp.id } });
  console.log('Cleanup complete.');

  console.log('--- All Tests Completed Successfully ---');
}

runTests().catch(console.error);
