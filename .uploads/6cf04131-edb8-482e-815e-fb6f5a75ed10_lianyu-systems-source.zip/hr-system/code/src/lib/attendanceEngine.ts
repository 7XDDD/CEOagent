import { prisma } from './prisma';

interface OvertimeCalculationResult {
  date: string;
  grossHours: number;
  netHours: number;
  isHoliday: boolean;
  warning?: string;
}

// 1. 日期拆分辅助函数：将跨天的加班区间拆分成以自然天为单位的数组
export function splitDateRangeByDay(startDate: Date, endDate: Date): { start: Date; end: Date; dateStr: string }[] {
  const ranges: { start: Date; end: Date; dateStr: string }[] = [];
  let current = new Date(startDate.getTime());

  while (current < endDate) {
    const year = current.getFullYear();
    const month = current.getMonth();
    const date = current.getDate();

    // 当天的 24:00 (即第二天的 00:00)
    const endOfDay = new Date(year, month, date + 1, 0, 0, 0, 0);
    const rangeEnd = endDate < endOfDay ? endDate : endOfDay;
    
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(date).padStart(2, '0')}`;
    
    ranges.push({
      start: new Date(current.getTime()),
      end: new Date(rangeEnd.getTime()),
      dateStr,
    });

    current = new Date(rangeEnd.getTime());
  }

  return ranges;
}

// 2. 餐补重合扣除核心算法
export function calculateMealOverlap(
  otStart: Date,
  otEnd: Date,
  location: string
): { lunchOverlap: number; dinnerOverlap: number } {
  const dateStr = otStart.toISOString().split('T')[0];
  
  // 定义餐点时间段 (大连 vs 其他)
  // 大连：午餐 11:30 - 13:00, 晚餐 18:00 - 19:00
  // 其他：午餐 12:00 - 13:30, 晚餐 18:00 - 19:00
  const isDalian = location.includes('大连');
  
  const lunchStart = new Date(`${dateStr}T${isDalian ? '11:30:00' : '12:00:00'}`);
  const lunchEnd = new Date(`${dateStr}T${isDalian ? '13:00:00' : '13:30:00'}`);
  const dinnerStart = new Date(`${dateStr}T18:00:00`);
  const dinnerEnd = new Date(`${dateStr}T19:00:00`);

  const getOverlapHours = (start1: Date, end1: Date, start2: Date, end2: Date): number => {
    const s = Math.max(start1.getTime(), start2.getTime());
    const e = Math.min(end1.getTime(), end2.getTime());
    if (s < e) {
      return (e - s) / (1000 * 60 * 60); // 转换为小时
    }
    return 0;
  };

  const lunchOverlap = getOverlapHours(otStart, otEnd, lunchStart, lunchEnd);
  const dinnerOverlap = getOverlapHours(otStart, otEnd, dinnerStart, dinnerEnd);

  return { lunchOverlap, dinnerOverlap };
}

// 3. 计算单条加班申请的有效工时 (包含事前拦截、工作日过滤、餐补扣减、取整与封顶)
export async function processOvertimeRecord(
  jobNumber: string,
  applyTime: Date,
  startTime: Date,
  endTime: Date,
  location: string,
  requestedDuration: number = 0
): Promise<OvertimeCalculationResult[]> {
  // 3.1 事前申请绝对拦截：开始时间早于申请时间
  if (startTime < applyTime) {
    // 违背事前申请，判定为事后补单，红色预警，时长清零
    return [{
      date: startTime.toISOString().split('T')[0],
      grossHours: (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60),
      netHours: 0,
      isHoliday: false,
      warning: 'LATE_APPLY:事后补单拦截',
    }];
  }

  // 3.2 跨天拆分
  const dailyRanges = splitDateRangeByDay(startTime, endTime);
  const results: OvertimeCalculationResult[] = [];

  let remainingRequested = requestedDuration;

  for (const range of dailyRanges) {
    const dateObj = new Date(range.dateStr);
    
    // 3.3 工作日拦截
    // 查询考勤日历判断是否为工作日
    const calendarDay = await prisma.attendanceCalendar.findUnique({
      where: { date: dateObj }
    });

    const isWorkday = calendarDay 
      ? calendarDay.type === 'WORKDAY'
      : (dateObj.getDay() !== 0 && dateObj.getDay() !== 6); // 默认周一至五为工作日

    const isHoliday = calendarDay ? calendarDay.type === 'HOLIDAY' : false;

    const grossHours = (range.end.getTime() - range.start.getTime()) / (1000 * 60 * 60);

    if (isWorkday) {
      // 工作日加班强制判定无效，清零
      results.push({
        date: range.dateStr,
        grossHours,
        netHours: 0,
        isHoliday,
        warning: 'WEEKDAY:工作日加班无效',
      });
      continue;
    }

    // 3.4 提取打卡记录，求取真实在岗加班区间的交集
    const clocking = await prisma.importedClocking.findFirst({
      where: {
        jobNumber,
        date: dateObj
      }
    });

    let effectiveStart = range.start;
    let effectiveEnd = range.end;
    let missingClock = false;

    if (!clocking || !clocking.checkIn || !clocking.checkOut) {
      missingClock = true;
    } else {
      const checkInTime = new Date(`${range.dateStr}T${clocking.checkIn}:00`);
      const checkOutTime = new Date(`${range.dateStr}T${clocking.checkOut}:00`);
      
      // 处理跨天打卡（例如次日凌晨签退）
      if (checkOutTime < checkInTime) {
        checkOutTime.setDate(checkOutTime.getDate() + 1);
      }

      const actualStart = Math.max(range.start.getTime(), checkInTime.getTime());
      const actualEnd = Math.min(range.end.getTime(), checkOutTime.getTime());

      if (actualStart >= actualEnd) {
        missingClock = true; // 虽有打卡，但完全未覆盖申请的时间段
      } else {
        effectiveStart = new Date(actualStart);
        effectiveEnd = new Date(actualEnd);
      }
    }

    if (missingClock) {
      results.push({
        date: range.dateStr,
        grossHours: grossHours,
        netHours: 0,
        isHoliday,
        warning: 'MISSING_CLOCK:打卡记录缺失或打卡时间未覆盖加班申请时间',
      });
      continue;
    }

    const effectiveGrossHours = (effectiveEnd.getTime() - effectiveStart.getTime()) / (1000 * 60 * 60);

    // 3.5 计算餐补重合扣减 (基于实际有效重合时间)
    const { lunchOverlap, dinnerOverlap } = calculateMealOverlap(effectiveStart, effectiveEnd, location);
    const netAfterMeals = Math.max(0, effectiveGrossHours - lunchOverlap - dinnerOverlap);

    // 3.6 截断向下取整与封顶限制 (单日封顶 8 小时)
    const truncatedHours = Math.floor(netAfterMeals);
    let finalHours = Math.min(8.0, truncatedHours);
    
    // 3.7 审核加班时长：是否申请多（按申请时长上限封顶）
    let capWarning = false;
    if (requestedDuration > 0) {
      if (finalHours > remainingRequested) capWarning = true;
      finalHours = Math.min(finalHours, remainingRequested);
      remainingRequested = Math.max(0, remainingRequested - finalHours);
    }

    results.push({
      date: range.dateStr,
      grossHours: effectiveGrossHours, // 这里保存交集后的有效原始时长
      netHours: finalHours,
      isHoliday,
      warning: capWarning ? 'CAP:受限于审批单申请总时长' : undefined,
    });
  }

  return results;
}

// 4. 请假顺序强规则校验前置拦截
export async function validateLeaveRequest(
  employeeId: string,
  leaveType: string,
  requestedHours: number
): Promise<{ allowed: boolean; message?: string }> {
  // 获取当前可用调休假期与年假
  const balance = await prisma.leaveBalance.findUnique({
    where: { employeeId },
  });

  const now = new Date();
  
  // 计算有效的调休余额 (未过期)
  const activeCompQuotas = await prisma.leaveQuota.findMany({
    where: {
      employeeId,
      leaveType: 'COMP_TIME',
      expireAt: { gte: now },
    }
  });
  
  const totalCompAvailable = activeCompQuotas.reduce((acc, q) => acc + (q.totalHours - q.usedHours), 0);
  const totalAnnualAvailable = balance ? balance.annual : 0; // 天

  // 1. 如果申请事假：必须先消耗完调休假与年假
  if (leaveType === '事假') {
    if (totalCompAvailable > 0) {
      return {
        allowed: false,
        message: `前置阻断：您当前还有未休完的调休假余额 (${totalCompAvailable}小时)，请优先申请调休！`,
      };
    }
    if (totalAnnualAvailable > 0) {
      return {
        allowed: false,
        message: `前置阻断：您当前还有未休完的年假余额 (${totalAnnualAvailable}天)，请优先申请年假！`,
      };
    }
  }

  // 2. 如果申请年假：必须先消耗完调休假
  if (leaveType === '年假') {
    if (totalCompAvailable > 0) {
      return {
        allowed: false,
        message: `前置阻断：您当前还有未休完的调休假余额 (${totalCompAvailable}小时)，请优先申请调休！`,
      };
    }
  }

  return { allowed: true };
}
