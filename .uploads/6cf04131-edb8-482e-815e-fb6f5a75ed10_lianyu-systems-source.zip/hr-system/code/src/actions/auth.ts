'use server';

import { prisma } from '@/lib/prisma';
import { createSession, deleteSession } from '@/lib/session';
import { redirect } from 'next/navigation';

export async function login(formData: FormData) {
  const username = formData.get('username') as string;
  const password = formData.get('password') as string;

  if (!username || !password) {
    return { success: false, message: '请输入用户名和密码' };
  }

  try {
    const user = await prisma.user.findUnique({
      where: { username },
      include: { role: true }
    });

    if (!user) {
      return { success: false, message: '用户名或密码错误' };
    }

    // In a real application, use bcrypt to compare passwords:
    // const isMatch = await bcrypt.compare(password, user.password);
    const isMatch = password === user.password; 

    if (!isMatch) {
      return { success: false, message: '用户名或密码错误' };
    }

    // Create session
    await createSession(user.id, user.role.code);
    
    return { success: true };
  } catch (error) {
    console.error('Login error:', error);
    return { success: false, message: '系统异常，请稍后再试' };
  }
}

export async function logout() {
  await deleteSession();
  redirect('/login');
}
