'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

export async function getCustomFields() {
  try {
    const fields = await prisma.customField.findMany({
      orderBy: { createdAt: 'asc' },
    });
    return { success: true, data: fields };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function createCustomField(data: {
  name: string;
  label: string;
  type: string;
  options?: string[];
  required: boolean;
}) {
  try {
    const field = await prisma.customField.create({
      data: {
        name: data.name,
        label: data.label,
        type: data.type,
        options: data.options || [],
        required: data.required,
      },
    });
    revalidatePath('/system/employees');
    return { success: true, data: field };
  } catch (error: any) {
    if (error.code === 'P2002') {
      return { success: false, message: '字段标识(Key)已存在' };
    }
    return { success: false, message: error.message };
  }
}

export async function deleteCustomField(id: string) {
  try {
    await prisma.customField.delete({
      where: { id },
    });
    revalidatePath('/system/employees');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}
