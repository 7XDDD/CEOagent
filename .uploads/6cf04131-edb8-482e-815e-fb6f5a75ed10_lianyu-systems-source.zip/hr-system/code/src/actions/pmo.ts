'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

// safeRevalidatePath allows calling actions outside Next.js request context safely
function safeRevalidatePath(path: string) {
  try {
    revalidatePath(path);
  } catch (e) {
    // Ignore error when run from scripts/tests
  }
}

// 1. 获取顾问年度人天基线列表
export async function getConsultantBaselines(year: number) {
  try {
    const employees = await prisma.employee.findMany({
      where: { status: 'ACTIVE' },
      include: {
        baselines: {
          where: { year }
        }
      },
      orderBy: { jobNumber: 'asc' }
    });

    const list = employees.map(emp => {
      const baseline = emp.baselines[0]?.baselineDays ?? 0;
      return {
        employeeId: emp.id,
        jobNumber: emp.jobNumber,
        name: emp.name,
        baselineDays: baseline,
        baselineId: emp.baselines[0]?.id || null
      };
    });

    return { success: true, data: list };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 2. 保存顾问人天基线 (HR填报)
export async function saveConsultantBaseline(employeeId: string, year: number, baselineDays: number) {
  try {
    await prisma.consultantBaseline.upsert({
      where: {
        employeeId_year: {
          employeeId,
          year
        }
      },
      update: { baselineDays },
      create: {
        employeeId,
        year,
        baselineDays
      }
    });

    safeRevalidatePath('/system/pmo');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 3. 获取项目顾问关联关系映射 (支持 PMO 数据隔离视域锁定)
export async function getProjectConsultantMappings(projectId?: string) {
  try {
    const mappings = await prisma.projectConsultantMapping.findMany({
      where: projectId ? { projectId } : undefined,
      include: {
        employee: true
      },
      orderBy: { projectId: 'asc' }
    });

    return { success: true, data: mappings };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 4. 新增或更新项目顾问关联 (HR授权建立关系)
export async function saveProjectConsultantMapping(projectId: string, employeeId: string, consultantName: string) {
  try {
    await prisma.projectConsultantMapping.upsert({
      where: {
        projectId_employeeId: {
          projectId,
          employeeId
        }
      },
      update: { consultantName },
      create: {
        projectId,
        employeeId,
        consultantName
      }
    });

    safeRevalidatePath('/system/pmo');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 删除关联关系
export async function deleteProjectConsultantMapping(id: string) {
  try {
    await prisma.projectConsultantMapping.delete({
      where: { id }
    });

    safeRevalidatePath('/system/pmo');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 5. PMO 录入及查询月度出勤计划/实际数据
export async function getProjectMonthlyData(monthStr: string, projectId?: string) {
  try {
    // 首先获取符合隔离条件的项目顾问授权映射列表
    const mappings = await prisma.projectConsultantMapping.findMany({
      where: projectId ? { projectId } : undefined,
      include: { employee: true }
    });

    const list = [];
    for (const map of mappings) {
      const sow = await prisma.projectSowPlan.findUnique({
        where: {
          projectId_employeeId_month: {
            projectId: map.projectId,
            employeeId: map.employeeId,
            month: monthStr
          }
        }
      });

      const actual = await prisma.projectActualOutput.findUnique({
        where: {
          projectId_employeeId_month: {
            projectId: map.projectId,
            employeeId: map.employeeId,
            month: monthStr
          }
        }
      });

      list.push({
        mappingId: map.id,
        projectId: map.projectId,
        employeeId: map.employeeId,
        jobNumber: map.employee.jobNumber,
        realName: map.employee.name,
        consultantName: map.consultantName,
        plannedDays: sow?.plannedDays ?? 0,
        actualDays: actual?.actualDays ?? 0,
        dailyLogs: actual?.dailyLogs ?? {}
      });
    }

    return { success: true, data: list };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 6. PMO 录入计划和实际人天
export async function saveProjectMonthlyData(
  projectId: string,
  employeeId: string,
  monthStr: string,
  plannedDays: number,
  actualDays: number,
  dailyLogs?: any
) {
  try {
    await prisma.$transaction([
      prisma.projectSowPlan.upsert({
        where: {
          projectId_employeeId_month: {
            projectId,
            employeeId,
            month: monthStr
          }
        },
        update: { plannedDays },
        create: { projectId, employeeId, month: monthStr, plannedDays }
      }),
      prisma.projectActualOutput.upsert({
        where: {
          projectId_employeeId_month: {
            projectId,
            employeeId,
            month: monthStr
          }
        },
        update: { actualDays, dailyLogs: dailyLogs || {} },
        create: { projectId, employeeId, month: monthStr, actualDays, dailyLogs: dailyLogs || {} }
      })
    ]);

    safeRevalidatePath('/system/pmo');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 7. PMO 项目人效与四色热力图三段值汇总报告
export async function getPMOEfficiencyReport(year: number, projectId?: string) {
  try {
    // 获取授权的顾问列表
    const mappings = await prisma.projectConsultantMapping.findMany({
      where: projectId ? { projectId } : undefined,
      include: {
        employee: {
          include: {
            baselines: { where: { year } }
          }
        }
      }
    });

    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonthVal = now.getMonth() + 1; // 1-indexed
    const currentMonthStr = `${currentYear}-${String(currentMonthVal).padStart(2, '0')}`;

    const report = [];

    for (const map of mappings) {
      const baseline = map.employee.baselines[0]?.baselineDays ?? 120; // 默认 120 天为基准分母
      const monthlyBreakdown = [];
      let totalAttainedDays = 0; // 累加全年的真实现场出勤数据（用于考核）

      // 遍历 12 个月计算三段值
      for (let m = 1; m <= 12; m++) {
        const monthKey = `${year}-${String(m).padStart(2, '0')}`;

        // 1. 查询 SOW 计划值
        const sow = await prisma.projectSowPlan.findUnique({
          where: {
            projectId_employeeId_month: {
              projectId: map.projectId,
              employeeId: map.employeeId,
              month: monthKey
            }
          }
        });
        const sowDays = sow?.plannedDays ?? 0;

        // 2. 查询 PMO 实际录入值
        const actual = await prisma.projectActualOutput.findUnique({
          where: {
            projectId_employeeId_month: {
              projectId: map.projectId,
              employeeId: map.employeeId,
              month: monthKey
            }
          }
        });
        const actualDays = actual?.actualDays ?? 0;

        // 3. 执行智能三段取值算法
        let finalDays = 0;
        let segmentType = '';

        if (monthKey < currentMonthStr) {
          // A. 过去月份：强制 100% 提取 PMO 真实现场出勤数据
          finalDays = actualDays;
          segmentType = 'PAST';
        } else if (monthKey === currentMonthStr) {
          // B. 当前当月：取当月SOW计划值与已录入实际值的最大值
          finalDays = Math.max(sowDays, actualDays);
          segmentType = 'CURRENT';
        } else {
          // C. 未来月份：提取 SOW 计划值铺底预测
          finalDays = sowDays;
          segmentType = 'FUTURE';
        }

        monthlyBreakdown.push({
          month: monthKey,
          planned: sowDays,
          actual: actualDays,
          finalDays,
          segmentType
        });

        // 真真实出勤（考核达标率分子，只计算实际发生的值或取过去月份出勤）
        totalAttainedDays += actualDays;
      }

      // 计算达标率
      const attainmentRate = baseline > 0 ? (totalAttainedDays / baseline) * 100 : 0;

      report.push({
        mappingId: map.id,
        projectId: map.projectId,
        employeeId: map.employeeId,
        jobNumber: map.employee.jobNumber,
        realName: map.employee.name,
        consultantName: map.consultantName,
        baselineDays: baseline,
        totalActualDays: totalAttainedDays,
        attainmentRate: parseFloat(attainmentRate.toFixed(1)),
        months: monthlyBreakdown
      });
    }

    return { success: true, data: report };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}
