'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';
import chineseDays from 'chinese-days';

// 查询指定年月的日历打标数据
export async function getCalendarDays(year: number, month: number) {
  try {
    const startStr = `${year}-${String(month).padStart(2, '0')}-01T00:00:00Z`;
    const startDate = new Date(startStr);
    
    const lastDay = new Date(year, month, 0).getDate();
    const endStr = `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}T23:59:59Z`;
    const endDate = new Date(endStr);

    const dbDays = await prisma.attendanceCalendar.findMany({
      where: {
        date: {
          gte: startDate,
          lte: endDate,
        },
      },
    });

    return { success: true, data: dbDays };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 保存/更新某一天的日历标签类型
export async function saveCalendarDay(dateStr: string, type: 'WORKDAY' | 'HOLIDAY' | 'MAKEUP' | 'REST', description?: string) {
  try {
    const targetDate = new Date(`${dateStr}T00:00:00Z`);

    const existing = await prisma.attendanceCalendar.findUnique({
      where: { date: targetDate },
    });

    if (existing) {
      await prisma.attendanceCalendar.update({
        where: { id: existing.id },
        data: {
          type,
          description: description || null,
        },
      });
    } else {
      await prisma.attendanceCalendar.create({
        data: {
          date: targetDate,
          type,
          description: description || null,
        },
      });
    }

    revalidatePath('/system/calendar');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 根据年份同步中国法定节假日和补班记录
export async function syncCalendarForYear(year: number) {
  try {
    const daysToUpsert = [];
    const weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    let current = new Date(`${year}-01-01T00:00:00Z`);
    const endDate = new Date(`${year}-12-31T00:00:00Z`);

    while (current <= endDate) {
      const dateStr = current.toISOString().split('T')[0];
      const detail = chineseDays.getDayDetail(dateStr);
      let type: 'WORKDAY' | 'HOLIDAY' | 'MAKEUP' | 'REST' = 'WORKDAY';
      let description = null;

      if (detail) {
        const isFestival = !weekdays.includes(detail.name);
        if (isFestival) {
          description = detail.name.split(',')[1] || detail.name;
          if (detail.work) {
            type = 'MAKEUP';
          } else {
            type = 'HOLIDAY';
          }
        } else {
          if (detail.work) {
            type = 'WORKDAY';
          } else {
            type = 'REST';
          }
        }
      }

      daysToUpsert.push({
        date: new Date(`${dateStr}T00:00:00Z`),
        type,
        description
      });
      
      current.setUTCDate(current.getUTCDate() + 1);
    }

    await prisma.$transaction(
      daysToUpsert.map(day => 
        prisma.attendanceCalendar.upsert({
          where: { date: day.date },
          update: { type: day.type, description: day.description },
          create: { date: day.date, type: day.type, description: day.description }
        })
      )
    );

    revalidatePath('/system/calendar');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}
