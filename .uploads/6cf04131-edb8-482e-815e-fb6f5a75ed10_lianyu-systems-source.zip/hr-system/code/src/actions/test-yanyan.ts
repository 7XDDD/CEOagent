import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const emp = await prisma.employee.findFirst({ where: { name: '燕燕' } });
  if (!emp) {
    console.log('Not found 燕燕');
    return;
  }
  console.log('Emp:', emp.name, 'HireDate:', emp.hireDate, 'Status:', emp.status, 'ExtInfo:', emp.extInfo);

  const summary = await prisma.monthlyAttendanceSummary.findFirst({
    where: { name: '燕燕', month: '2026-05' }
  });
  console.log('Summary 2026-05:', summary);
}
main().catch(console.error).finally(() => prisma.$disconnect());
