import { generateMonthlySummary } from './attendance';
import { prisma } from '../lib/prisma';

async function main() {
  console.log('Regenerating all employee summaries for 2026-05...');
  await generateMonthlySummary("2026-05");
  console.log('Done.');
}
main().catch(console.error).finally(() => prisma.$disconnect());
