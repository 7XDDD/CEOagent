'use server';

import { prisma } from '@/lib/prisma';
import { processOvertimeRecord } from '@/lib/attendanceEngine';
import { revalidatePath } from 'next/cache';

// safeRevalidatePath allows calling actions outside Next.js request context safely
function safeRevalidatePath(path: string) {
  try {
    revalidatePath(path);
  } catch (e) {
    // Ignore error when run from scripts/tests
  }
}

// 日期解析通用辅助工具
function parseExcelDate(val: any): Date {
  if (val instanceof Date) return val;
  if (typeof val === 'number') {
    // 处理 Excel 序列化数字日期 (以 1900-01-01 为起点)
    return new Date((val - 25569) * 86400 * 1000);
  }
  if (typeof val === 'string') {
    // 清理中文字符，例如 "2026/05/31 星期日" -> "2026/05/31"
    const cleanedStr = val.replace(/\s*星期./g, '').trim();
    const d = new Date(cleanedStr);
    if (!isNaN(d.getTime())) return d;
    
    // 退一步，尝试只截取空格前的部分
    const d2 = new Date(val.split(' ')[0]);
    if (!isNaN(d2.getTime())) return d2;
  }
  throw new Error(`无法解析日期值: ${val}`);
}

// 1. 批量导入上下班打卡明细
export async function importClockingRecords(records: any[]) {
  try {
    if (!records || records.length === 0) {
      return { success: false, message: '未检测到任何有效的真实数据行（请确认是否上传了空模板，或必填信息未填）' };
    }

    const dataToInsert = records.map(r => {
      const date = parseExcelDate(r.date);
      return {
        date,
        name: String(r.name),
        jobNumber: String(r.jobNumber),
        checkIn: r.checkIn ? String(r.checkIn) : null,
        checkOut: r.checkOut ? String(r.checkOut) : null,
        result: r.result ? String(r.result) : null,
        lateCount: parseInt(r.lateCount) || 0,
        lateMinutes: parseInt(r.lateMinutes) || 0,
        earlyCount: parseInt(r.earlyCount) || 0,
        earlyMinutes: parseInt(r.earlyMinutes) || 0,
        absentCount: parseInt(r.absentCount) || 0,
        missedCardCount: parseInt(r.missedCardCount) || 0,
      };
    });

    await prisma.$transaction([
      // 清理原同月份已导入的数据，防止重复导入
      // 通过范围删除
      prisma.importedClocking.deleteMany({
        where: {
          date: {
            gte: new Date(dataToInsert[0].date.getFullYear(), dataToInsert[0].date.getMonth(), 1),
            lte: new Date(dataToInsert[0].date.getFullYear(), dataToInsert[0].date.getMonth() + 1, 0, 23, 59, 59),
          }
        }
      }),
      prisma.importedClocking.createMany({ data: dataToInsert }),
    ]);

    safeRevalidatePath('/system/calendar/import');
    return { success: true, count: dataToInsert.length };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 2. 批量导入加班审批单并运行清洗引擎
export async function importOvertimeRecords(records: any[]) {
  try {
    if (!records || records.length === 0) {
      return { success: false, message: '未检测到任何有效的真实数据行（请确认是否上传了空模板，或审批编号未填）' };
    }
    const results = [];
    
    for (const r of records) {
      const startTime = parseExcelDate(r.startTime);
      const endTime = parseExcelDate(r.endTime);
      const applyTime = r.applyTime ? parseExcelDate(r.applyTime) : startTime;
      const finishTime = r.finishTime ? parseExcelDate(r.finishTime) : null;
      const jobNumber = String(r.jobNumber);
      const name = String(r.name);
      const approvalNumber = String(r.approvalNumber);
      const approvalDetails = r.approvalDetails ? String(r.approvalDetails) : null;
      const account = r.account ? String(r.account) : null;
      const department = r.department ? String(r.department) : null;
      const reason = r.reason ? String(r.reason) : null;
      const type = r.type ? String(r.type) : null;
      const attachment = r.attachment ? String(r.attachment) : null;
      const currentApprovalNode = r.currentApprovalNode ? String(r.currentApprovalNode) : null;
      const approvalProcess = r.approvalProcess ? String(r.approvalProcess) : null;
      const remarks = r.remarks ? String(r.remarks) : null;

      // 查询员工工作地点及主体
      const emp = await prisma.employee.findUnique({
        where: { idCard: r.idCard || undefined, jobNumber: jobNumber || undefined },
      });
      const location = emp ? (emp.extInfo as any)?.workLocation || '北京' : '北京';

      // 调用风控清洗引擎进行多日拆分、餐补扣除与限额计算
      const processedDays = await processOvertimeRecord(
        jobNumber,
        applyTime,
        startTime,
        endTime,
        location,
        parseFloat(r.duration) || 0
      );

      const approvalStatus = r.approvalStatus ? String(r.approvalStatus) : null;
      const isApproved = !approvalStatus || approvalStatus.includes('通过') || approvalStatus.includes('完成');

      // 将拆分计算后的明细插入/更新到数据库
      for (const day of processedDays) {
        const gross = day.grossHours;
        const net = isApproved ? day.netHours : 0;
        const isHoliday = day.isHoliday;
        const warning = isApproved ? (day.warning || null) : '单据未审批通过，时长不计入';

        const dataToSave = {
            approvalDetails,
            applyTime,
            finishTime,
            name,
            account,
            department,
            jobNumber,
            reason,
            type,
            startTime,
            endTime,
            grossDuration: gross,
            netDuration: net,
            status: net > 0 ? 'PROCESSED' : 'INVALID',
            warning,
            attachment,
            currentApprovalNode,
            approvalProcess,
            remarks,
            approvalStatus,
        };

        await prisma.importedOvertime.upsert({
          where: { approvalNumber: `${approvalNumber}-${day.date}` },
          update: dataToSave,
          create: {
            approvalNumber: `${approvalNumber}-${day.date}`,
            ...dataToSave
          }
        });

        // 如果是周末加班，且有效时长 > 0，则计入调休池 (滚动 12 个月过期)
        if (net > 0 && !isHoliday && emp) {
          const overtimeDate = new Date(day.date);
          const expireAt = new Date(overtimeDate);
          expireAt.setFullYear(expireAt.getFullYear() + 1);
          expireAt.setDate(expireAt.getDate() - 1); // 扣减一天
          expireAt.setHours(23, 59, 59, 999);

          await prisma.leaveQuota.create({
            data: {
              employeeId: emp.id,
              leaveType: 'COMP_TIME',
              totalHours: net,
              usedHours: 0,
              expireAt,
              sourceDate: overtimeDate,
            }
          });

          // 同时累加到 leaveBalance 调休假账户总额度中
          await prisma.leaveBalance.upsert({
            where: { employeeId: emp.id },
            update: { compensatory: { increment: net } },
            create: { employeeId: emp.id, compensatory: net }
          });
        }
        
        results.push({ approvalNumber, name, date: day.date, netHours: net, warning });
      }
    }

    safeRevalidatePath('/system/calendar/import');
    return { success: true, data: results };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 3. 批量请假单导入
export async function importLeaveRecords(records: any[]) {
  try {
    if (!records || records.length === 0) {
      return { success: false, message: '未检测到任何有效的真实数据行' };
    }
    const dataToInsert = records.map(r => {
      const startTime = parseExcelDate(r.startTime);
      const endTime = parseExcelDate(r.endTime);
      const applyTime = r.applyTime ? parseExcelDate(r.applyTime) : null;
      const finishTime = r.finishTime ? parseExcelDate(r.finishTime) : null;
      return {
        approvalNumber: String(r.approvalNumber),
        approvalDetails: r.approvalDetails ? String(r.approvalDetails) : null,
        name: String(r.name),
        department: r.department ? String(r.department) : null,
        jobNumber: String(r.jobNumber),
        account: r.account ? String(r.account) : null,
        leaveType: String(r.leaveType),
        applyTime,
        finishTime,
        startTime,
        endTime,
        duration: parseFloat(r.duration) || 0.0,
        reason: r.reason ? String(r.reason) : null,
        attachment: r.attachment ? String(r.attachment) : null,
        currentApprovalNode: r.currentApprovalNode ? String(r.currentApprovalNode) : null,
        approvalProcess: r.approvalProcess ? String(r.approvalProcess) : null,
        approvalStatus: r.approvalStatus ? String(r.approvalStatus) : null,
        remarks: r.remarks ? String(r.remarks) : null,
      };
    });

    let deductedNotes = 0;
    for (const data of dataToInsert) {
      const existing = await prisma.importedLeave.findUnique({
        where: { approvalNumber: data.approvalNumber }
      });

      const upsertedLeave = await prisma.importedLeave.upsert({
        where: { approvalNumber: data.approvalNumber },
        update: data,
        create: data,
      });

      // 自动对冲逻辑 (仅对新增的调休假生效，避免重复更新)
      if (!existing && (data.leaveType.includes('调休'))) {
        const emp = await prisma.employee.findUnique({ where: { jobNumber: data.jobNumber } });
        if (emp) {
          // 这里默认假设请假的 duration 跟额度池单位一致（通常为小时，如果是天可能需要 * 8）
          let amountToDeduct = data.duration; 

          // 查询可用调休池 (FIFO: 优先过期时间早的)
          const availableQuotas = await prisma.leaveQuota.findMany({
            where: {
              employeeId: emp.id,
              leaveType: 'COMP_TIME',
            },
            orderBy: { expireAt: 'asc' } // 升序：最早过期的排前面
          });

          // 过滤可用额度：未用完，且未过期
          const validQuotas = availableQuotas.filter(q => 
            (q.usedHours < q.totalHours) && 
            (!q.expireAt || q.expireAt >= data.startTime)
          );

          for (const quota of validQuotas) {
            if (amountToDeduct <= 0) break;
            const remainingInQuota = quota.totalHours - quota.usedHours;
            const deduct = Math.min(remainingInQuota, amountToDeduct);
            
            await prisma.$transaction([
              prisma.leaveQuota.update({
                where: { id: quota.id },
                data: { usedHours: quota.usedHours + deduct }
              }),
              prisma.leaveQuotaUsage.create({
                data: {
                  leaveQuotaId: quota.id,
                  importedLeaveId: upsertedLeave.id,
                  deductHours: deduct,
                  usedDate: data.startTime
                }
              })
            ]);
            amountToDeduct -= deduct;
          }
          // 若 amountToDeduct 仍 > 0，则说明透支了历史额度（记录在案/容错）
          deductedNotes++;
        }
      }
    }

    safeRevalidatePath('/system/calendar/import');
    return { success: true, count: dataToInsert.length, deductedNotes };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 3.5 历史加班额度导入 (注入调休池)
export async function importHistoricalOvertimeRecords(records: any[]) {
  try {
    if (!records || records.length === 0) {
      return { success: false, message: '未检测到数据' };
    }
    
    let count = 0;
    for (const r of records) {
      const jobNumber = String(r.jobNumber);
      const emp = await prisma.employee.findUnique({ where: { jobNumber } });
      if (!emp) continue; // 找不到对应员工则跳过
      
      const totalHours = parseFloat(r.totalHours) || 0;
      if (totalHours <= 0) continue;
      
      const expireAt = r.expireAt ? parseExcelDate(r.expireAt) : null;
      const sourceDate = r.generatedDate ? parseExcelDate(r.generatedDate) : new Date();
      
      await prisma.leaveQuota.create({
        data: {
          employeeId: emp.id,
          leaveType: 'COMP_TIME',
          totalHours: totalHours,
          usedHours: 0,
          expireAt: expireAt,
          sourceDate: sourceDate
        }
      });
      count++;
    }

    safeRevalidatePath('/system/calendar/import');
    return { success: true, count };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 4. 批量出差单导入
export async function importTravelRecords(records: any[]) {
  try {
    if (!records || records.length === 0) {
      return { success: false, message: '未检测到任何有效的真实数据行' };
    }
    const dataToInsert = records.map(r => {
      const startTime = parseExcelDate(r.startTime);
      const endTime = parseExcelDate(r.endTime);
      const applyTime = r.applyTime ? parseExcelDate(r.applyTime) : null;
      const finishTime = r.finishTime ? parseExcelDate(r.finishTime) : null;
      return {
        approvalNumber: String(r.approvalNumber),
        approvalDetails: r.approvalDetails ? String(r.approvalDetails) : null,
        applyTime,
        finishTime,
        name: String(r.name),
        account: r.account ? String(r.account) : null,
        department: r.department ? String(r.department) : null,
        jobNumber: String(r.jobNumber),
        reason: r.reason ? String(r.reason) : null,
        type: r.type ? String(r.type) : null,
        departure: r.departure ? String(r.departure) : null,
        destination: r.destination ? String(r.destination) : null,
        startTime,
        endTime,
        duration: parseFloat(r.duration) || 0.0,
        transportation: r.transportation ? String(r.transportation) : null,
        attachment: r.attachment ? String(r.attachment) : null,
        currentApprovalNode: r.currentApprovalNode ? String(r.currentApprovalNode) : null,
        approvalProcess: r.approvalProcess ? String(r.approvalProcess) : null,
        remarks: r.remarks ? String(r.remarks) : null,
        approvalStatus: r.approvalStatus ? String(r.approvalStatus) : null,
      };
    });

    for (const data of dataToInsert) {
      await prisma.importedTravel.upsert({
        where: { approvalNumber: data.approvalNumber },
        update: data,
        create: data,
      });
    }

    safeRevalidatePath('/system/calendar/import');
    return { success: true, count: dataToInsert.length };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function importExemptionRecords(dataToInsert: any[]) {
  try {
    let imported = 0;
    for (const data of dataToInsert) {
      if (data.approvalStatus && data.approvalStatus.includes('通过')) {
        await prisma.importedExemption.upsert({
          where: { approvalNumber: data.approvalNumber },
          update: data,
          create: data,
        });
        imported++;
      }
    }

    safeRevalidatePath('/system/calendar/import');
    return { success: true, count: imported };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 阶梯迟到算薪规则判定
function getLateDeduct(checkInStr: string): { deduct: number; label: string } | null {
  if (!checkInStr) return null;
  const parts = checkInStr.split(':').map(Number);
  if (parts.length < 2 || isNaN(parts[0]) || isNaN(parts[1])) return null;
  const mins = parts[0] * 60 + parts[1];
  const baseline = 9 * 60; // 09:00

  if (mins <= baseline) return null;

  const lateMins = mins - baseline;
  if (lateMins >= 1 && lateMins <= 5) {
    return { deduct: 0.5, label: "09:01-09:05 阶梯迟到" };
  } else if (lateMins >= 6 && lateMins <= 15) {
    return { deduct: 1.0, label: "09:06-09:15 阶梯迟到" };
  } else {
    return { deduct: 4.0, label: "09:16及以后 阶梯迟到" };
  }
}

// 核心单人考勤每日重估引擎
export async function consolidateEmployeeAttendance(
  emp: any,
  monthStr: string,
  startDate: Date,
  endDate: Date,
  calendarMap: Map<string, string>
) {
  const jobNum = emp.jobNumber;
  if (!jobNum) return;

  const [year, month] = monthStr.split('-').map(Number);
  const ext = emp.extInfo && typeof emp.extInfo === 'object' ? (emp.extInfo as any) : {};
  const hireDate = emp.hireDate ? new Date(emp.hireDate) : null;
  let resignedDate: Date | null = null;
  if (emp.status === 'RESIGNED') {
    if (ext.resignedAt) {
      resignedDate = new Date(ext.resignedAt);
    } else {
      resignedDate = new Date(emp.updatedAt);
    }
  }

  // 离职于本月之前的员工，不参与本月度考勤汇总
  if (resignedDate && resignedDate < startDate) {
    await prisma.monthlyAttendanceSummary.deleteMany({
      where: { jobNumber: jobNum, month: monthStr }
    });
    return;
  }
  // 入职于本月之后的员工，不参与本月度考勤汇总
  if (hireDate && hireDate > endDate) {
    await prisma.monthlyAttendanceSummary.deleteMany({
      where: { jobNumber: jobNum, month: monthStr }
    });
    return;
  }

  // 1. 清理当月尚未被最终裁决（NONE / PENDING）的异常，重新跑批
  await prisma.attendanceAnomaly.deleteMany({
    where: {
      employeeId: emp.id,
      date: { gte: startDate, lte: endDate },
      appealStatus: { in: ['NONE', 'PENDING'] }
    }
  });

  // 2. 查询该员工当月的所有数据
  const clockings = await prisma.importedClocking.findMany({
    where: { 
      OR: [
        { jobNumber: jobNum },
        { name: emp.name }
      ],
      date: { gte: startDate, lte: endDate } 
    }
  });
  const clockingsMap = new Map<string, any>();
  clockings.forEach(c => {
    const key = new Date(c.date).toISOString().split('T')[0];
    clockingsMap.set(key, c);
  });

  const travels = await prisma.importedTravel.findMany({
    where: { 
      OR: [
        { jobNumber: jobNum },
        { name: emp.name }
      ],
      startTime: { lte: endDate }, 
      endTime: { gte: startDate },
      AND: [
        {
          OR: [
            { approvalStatus: { contains: '通过' } },
            { approvalStatus: { contains: '完成' } },
            { approvalStatus: null }
          ]
        }
      ]
    }
  });

  const leaves = await prisma.importedLeave.findMany({
    where: { 
      OR: [
        { jobNumber: jobNum },
        { name: emp.name }
      ],
      startTime: { lte: endDate }, 
      endTime: { gte: startDate },
      AND: [
        {
          OR: [
            { approvalStatus: { contains: '通过' } },
            { approvalStatus: { contains: '完成' } },
            { approvalStatus: null }
          ]
        }
      ]
    }
  });

  const overtimes = await prisma.importedOvertime.findMany({
    where: { 
      OR: [
        { jobNumber: jobNum },
        { name: emp.name }
      ],
      approvalNumber: { contains: monthStr },
      status: 'PROCESSED'
    }
  });

  // 2.5 查询该员工当月已存在的申诉通过/拒绝等不能重新清洗的异常
  const existingAnomalies = await prisma.attendanceAnomaly.findMany({
    where: {
      employeeId: emp.id,
      date: { gte: startDate, lte: endDate }
    }
  });
  const existingAnomaliesMap = new Map<string, any>();
  existingAnomalies.forEach(a => {
    const key = `${new Date(a.date).toISOString().split('T')[0]}_${a.type}`;
    existingAnomaliesMap.set(key, a);
  });

  let travelDaysCount = 0;
  let overtimePayHoursCount = 0;
  let weekendOvertimeHoursCount = 0;
  
  let shouldWorkDays = 0;
  let totalEmployedShifts = 0;

  const lastDay = new Date(year, month, 0).getDate();

  // 3. 逐日处理打卡与分析
  for (let d = 1; d <= lastDay; d++) {
    const currentDate = new Date(year, month - 1, d);
    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const dayOfWeek = currentDate.getDay();
    const isMonToFri = dayOfWeek >= 1 && dayOfWeek <= 5;
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

    const calType = calendarMap.get(dateStr);
    const isWorkday = calType 
      ? (calType === 'WORKDAY' || calType === 'MAKEUP')
      : isMonToFri;
    const isHoliday = calType === 'HOLIDAY';

    const isBeforeHire = hireDate ? (currentDate < new Date(new Date(hireDate).setHours(0,0,0,0))) : false;
    const isAfterResign = resignedDate ? (currentDate > new Date(new Date(resignedDate).setHours(23,59,59,999))) : false;

    // 补充逻辑：员工从入职开始才纳入月度考勤表统计，不在入职日期内的考勤不统计
    if (isBeforeHire) {
      continue;
    }

    // A. 计算应出勤与有效在职班次
    // 应出勤（计薪基础天数）仅统计在职期间的星期一至星期五的总数
    if (isMonToFri) {
      shouldWorkDays += 1;
    }

    const isEmployed = !isAfterResign;

    if (isEmployed) {
      // 有效在职班次 = 员工在职期间的 (周一至周五且非调休休息日) + (周末的调休补班日)
      if (isMonToFri && calType !== 'REST') {
        totalEmployedShifts += 1;
      } else if (isWeekend && calType === 'MAKEUP') {
        totalEmployedShifts += 1;
      }
    } else {
      // 离职后的天数：不再计算任何考勤打卡和假期，仅仅用来充当未到岗天数差额
      continue;
    }

    // B. 出差与请假状态校验
    const onTravel = travels.some(t => {
      const s = new Date(t.startTime); s.setHours(0,0,0,0);
      const e = new Date(t.endTime); e.setHours(23,59,59,999);
      return currentDate >= s && currentDate <= e;
    });

    if (onTravel && isWorkday) {
      travelDaysCount += 1.0; // 周末出差排异
    }

    const activeLeave = leaves.find(l => {
      const s = new Date(l.startTime); s.setHours(0,0,0,0);
      const e = new Date(l.endTime); e.setHours(23,59,59,999);
      return currentDate >= s && currentDate <= e;
    });

    // C. 核心打卡分析 (在职工作日，且没有出差或请假)
    if (isWorkday && !emp.exemptAttendance && !onTravel && !activeLeave) {
      const clock = clockingsMap.get(dateStr);
      const checkIn = clock?.checkIn;
      const checkOut = clock?.checkOut;

      if (!checkIn && !checkOut) {
        // 0 打卡 -> 旷工 1 天
        const aKey = `${dateStr}_ABSENT`;
        if (!existingAnomaliesMap.has(aKey)) {
          await prisma.attendanceAnomaly.create({
            data: {
              employeeId: emp.id,
              date: currentDate,
              type: 'ABSENT',
              details: '旷工 1 天 (扣除 8.0h)',
              deductHours: 8.0,
              appealStatus: 'NONE'
            }
          });
        }
      } else if (!checkIn || !checkOut) {
        // 1 打卡 -> 缺卡 1 次
        const aKey = `${dateStr}_MISSED_CARD`;
        if (!existingAnomaliesMap.has(aKey)) {
          await prisma.attendanceAnomaly.create({
            data: {
              employeeId: emp.id,
              date: currentDate,
              type: 'MISSED_CARD',
              details: '缺卡 1 次 (待扣除 4.0h)',
              deductHours: 4.0,
              appealStatus: 'NONE'
            }
          });
        }
      } else {
        // 2 打卡 -> 阶梯迟到校验
        const lateDeduct = getLateDeduct(checkIn);
        if (lateDeduct) {
          const aKey = `${dateStr}_LATE`;
          if (!existingAnomaliesMap.has(aKey)) {
            await prisma.attendanceAnomaly.create({
              data: {
                employeeId: emp.id,
                date: currentDate,
                type: 'LATE',
                details: `迟到 (${checkIn}, 扣除${lateDeduct.deduct}h)`,
                deductHours: lateDeduct.deduct,
                appealStatus: 'NONE'
              }
            });
          }
        }
      }
    }

    // D. 加班台账分类累加
    const dailyOvertimes = overtimes.filter(o => o.approvalNumber.endsWith(`-${dateStr}`));
    const dailyOvertimeNet = dailyOvertimes.reduce((sum, o) => sum + o.netDuration, 0);

    if (dailyOvertimeNet > 0) {
      if (isHoliday) {
        overtimePayHoursCount += dailyOvertimeNet;
      } else if (!isWorkday) {
        weekendOvertimeHoursCount += dailyOvertimeNet;
      }
    }
  }

  // 4. 免费补打卡豁免抵扣机制 (每月最高 4 次)
  const approvedMakeUpCount = await prisma.importedExemption.count({
    where: {
      OR: [
        { jobNumber: emp.jobNumber },
        { name: emp.name }
      ],
      exemptionDate: { gte: startDate, lte: endDate },
      approvalStatus: { contains: '通过' }
    }
  });

  const missedCardAnomalies = await prisma.attendanceAnomaly.findMany({
    where: {
      employeeId: emp.id,
      date: { gte: startDate, lte: endDate },
      type: 'MISSED_CARD',
      appealStatus: 'NONE'
    },
    orderBy: { date: 'asc' }
  });

  const offsetCount = Math.min(missedCardAnomalies.length, approvedMakeUpCount, 4);
  for (let i = 0; i < offsetCount; i++) {
    const anomaly = missedCardAnomalies[i];
    await prisma.attendanceAnomaly.update({
      where: { id: anomaly.id },
      data: {
        appealStatus: 'APPROVED',
        deductHours: 0.0,
        managerComment: '系统自动免费补卡豁免冲抵'
      }
    });
  }

  // 5. 汇总异常状态
  const allAnomalies = await prisma.attendanceAnomaly.findMany({
    where: {
      employeeId: emp.id,
      date: { gte: startDate, lte: endDate }
    }
  });

  const activeAnomalies = allAnomalies.filter(a => a.appealStatus !== 'APPROVED');
  const lateEarlyCount = activeAnomalies.filter(a => a.type === 'LATE' || a.type === 'MISSED_CARD').length;
  const lateEarlyDeductHours = activeAnomalies.reduce((sum, a) => sum + a.deductHours, 0);
  const absenteeismDays = activeAnomalies.filter(a => a.type === 'ABSENT').length;

  // 6. 汇总请假时长
  const personalLeaveHours = leaves.filter(l => l.leaveType === '事假').reduce((sum, l) => sum + l.duration, 0);
  const sickLeaveDays = leaves.filter(l => l.leaveType === '病假').reduce((sum, l) => sum + l.duration, 0);
  const annualLeaveDays = leaves.filter(l => l.leaveType === '年假').reduce((sum, l) => sum + l.duration, 0);
  const compLeaveDays = leaves.filter(l => l.leaveType === '调休假').reduce((sum, l) => sum + l.duration, 0);
  const marriageLeaveDays = leaves.filter(l => l.leaveType === '婚假').reduce((sum, l) => sum + l.duration, 0);
  const maternityLeaveDays = leaves.filter(l => l.leaveType === '产假' || l.leaveType === '陪产假').reduce((sum, l) => sum + l.duration, 0);
  const maternityCheckDays = leaves.filter(l => l.leaveType === '产检假').reduce((sum, l) => sum + l.duration, 0);
  const bereavementLeaveDays = leaves.filter(l => l.leaveType === '丧假').reduce((sum, l) => sum + l.duration, 0);
  const wfhDays = leaves.filter(l => l.leaveType === '居家办公').reduce((sum, l) => sum + l.duration, 0);

  let absentDaysCount = Math.max(0, shouldWorkDays - totalEmployedShifts);

  // 未到岗天数：只统计当月入职、离职的员工
  const hiredThisMonth = hireDate && hireDate.getFullYear() === year && hireDate.getMonth() + 1 === month;
  const resignedThisMonth = resignedDate && resignedDate.getFullYear() === year && resignedDate.getMonth() + 1 === month;
  if (!hiredThisMonth && !resignedThisMonth) {
    absentDaysCount = 0;
  }

  const actualWorkDays = Math.max(0, 
    shouldWorkDays 
    - absentDaysCount
    - absenteeismDays 
    - (personalLeaveHours / 8) 
    - sickLeaveDays
  );

  await prisma.monthlyAttendanceSummary.upsert({
    where: {
      month_jobNumber: {
        month: monthStr,
        jobNumber: jobNum,
      }
    },
    update: {
      name: emp.name,
      department: ext.department || null,
      position: ext.position || null,
      hireDate: emp.hireDate,
      resignedDate: resignedDate,
      shouldWorkDays,
      absentDays: absentDaysCount,
      personalLeaveHours,
      sickLeaveDays,
      lateEarlyCount,
      lateEarlyDeductHours,
      absenteeismDays,
      annualLeaveDays,
      compLeaveDays,
      marriageLeaveDays,
      maternityLeaveDays,
      maternityCheckDays,
      bereavementLeaveDays,
      wfhDays,
      travelDays: travelDaysCount,
      overtimePayHours: overtimePayHoursCount,
      weekendOvertimeHours: weekendOvertimeHoursCount,
      actualWorkDays,
    },
    create: {
      month: monthStr,
      jobNumber: jobNum,
      name: emp.name,
      department: ext.department || null,
      position: ext.position || null,
      hireDate: emp.hireDate,
      resignedDate: resignedDate,
      shouldWorkDays,
      absentDays: absentDaysCount,
      personalLeaveHours,
      sickLeaveDays,
      lateEarlyCount,
      lateEarlyDeductHours,
      absenteeismDays,
      annualLeaveDays,
      compLeaveDays,
      marriageLeaveDays,
      maternityLeaveDays,
      maternityCheckDays,
      bereavementLeaveDays,
      wfhDays,
      travelDays: travelDaysCount,
      overtimePayHours: overtimePayHoursCount,
      weekendOvertimeHours: weekendOvertimeHoursCount,
      actualWorkDays,
    }
  });
}

// 5. 核心清洗引擎：根据已导入的打卡、请假、出差、加班明细，自动结算生成月度考勤表
export async function generateMonthlySummary(monthStr: string) {
  try {
    const [year, month] = monthStr.split('-').map(Number);
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0, 23, 59, 59, 999);

    // 查询该月的所有在职与离职员工
    const employees = await prisma.employee.findMany({
      where: {
        OR: [
          { status: 'ACTIVE' },
          { status: 'RESIGNED', updatedAt: { gte: startDate } }
        ]
      }
    });

    // 统计该月的应出勤天数
    const calendarDays = await prisma.attendanceCalendar.findMany({
      where: { date: { gte: startDate, lte: endDate } }
    });
    const calendarMap = new Map<string, string>();
    calendarDays.forEach(d => {
      calendarMap.set(d.date.toISOString().split('T')[0], d.type);
    });

    for (const emp of employees) {
      await consolidateEmployeeAttendance(emp, monthStr, startDate, endDate, calendarMap);
    }

    safeRevalidatePath('/system/calendar/summary');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 单个员工考勤汇总重跑
export async function generateMonthlySummaryForEmployee(jobNumber: string, monthStr: string) {
  try {
    const [year, month] = monthStr.split('-').map(Number);
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0, 23, 59, 59, 999);

    const emp = await prisma.employee.findUnique({
      where: { jobNumber }
    });
    if (!emp) return { success: false, message: '找不到对应员工' };

    const calendarDays = await prisma.attendanceCalendar.findMany({
      where: { date: { gte: startDate, lte: endDate } }
    });
    const calendarMap = new Map<string, string>();
    calendarDays.forEach(d => {
      calendarMap.set(d.date.toISOString().split('T')[0], d.type);
    });

    await consolidateEmployeeAttendance(emp, monthStr, startDate, endDate, calendarMap);
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 6. 获取某一月份的月度考勤表明细
export async function getMonthlySummaryList(monthStr: string) {
  try {
    const list = await prisma.monthlyAttendanceSummary.findMany({
      where: { month: monthStr },
      orderBy: { jobNumber: 'asc' },
    });
    return { success: true, data: list };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 7. 自助申诉 Server Actions
// 员工发起申诉 (申诉期 3 天限制)
export async function submitAnomalyAppeal(anomalyId: string, reason: string, voucher: string) {
  try {
    const anomaly = await prisma.attendanceAnomaly.findUnique({
      where: { id: anomalyId }
    });
    if (!anomaly) return { success: false, message: '未找到异常考勤数据' };

    const now = new Date();
    const diffTime = Math.abs(now.getTime() - new Date(anomaly.date).getTime());
    const diffDays = diffTime / (1000 * 60 * 60 * 24);
    if (diffDays > 3.0) {
      return { success: false, message: '前置阻断：已超过 3 天申诉期限制，不可发起申诉！' };
    }

    await prisma.attendanceAnomaly.update({
      where: { id: anomalyId },
      data: {
        appealStatus: 'PENDING',
        appealReason: reason,
        appealVoucher: voucher,
      }
    });

    safeRevalidatePath('/system/calendar/appeals');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 主管处理申诉 (批准冲抵)
export async function approveAnomalyAppeal(anomalyId: string, comment: string) {
  try {
    const anomaly = await prisma.attendanceAnomaly.update({
      where: { id: anomalyId },
      data: {
        appealStatus: 'APPROVED',
        deductHours: 0.0, // 冲抵异常扣减工时
        managerComment: comment
      },
      include: { employee: true }
    });

    // 重新跑批计算当月汇总
    const monthStr = anomaly.date.toISOString().slice(0, 7);
    await generateMonthlySummaryForEmployee(anomaly.employee.jobNumber!, monthStr);

    safeRevalidatePath('/system/calendar/appeals');
    safeRevalidatePath('/system/calendar/summary');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 主管拒绝申诉
export async function rejectAnomalyAppeal(anomalyId: string, comment: string) {
  try {
    const anomaly = await prisma.attendanceAnomaly.update({
      where: { id: anomalyId },
      data: {
        appealStatus: 'REJECTED',
        managerComment: comment
      },
      include: { employee: true }
    });

    safeRevalidatePath('/system/calendar/appeals');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 获取待审核申诉列表
export async function getPendingAppeals() {
  try {
    const list = await prisma.attendanceAnomaly.findMany({
      where: { appealStatus: 'PENDING' },
      include: { employee: true },
      orderBy: { date: 'asc' }
    });
    return { success: true, data: list };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 获取某个员工的所有异常
export async function getEmployeeAnomalies(employeeId: string, monthStr: string) {
  try {
    const [year, month] = monthStr.split('-').map(Number);
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0, 23, 59, 59, 999);

    const list = await prisma.attendanceAnomaly.findMany({
      where: {
        employeeId,
        date: { gte: startDate, lte: endDate }
      },
      orderBy: { date: 'asc' }
    });
    return { success: true, data: list };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 创建测试补卡通过审批单
export async function createMakeUpApproval(employeeId: string, dateStr: string) {
  try {
    const date = new Date(dateStr);
    const result = await prisma.makeUpCardApproval.create({
      data: {
        employeeId,
        date,
        status: 'APPROVED'
      }
    });
    return { success: true, data: result };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}
