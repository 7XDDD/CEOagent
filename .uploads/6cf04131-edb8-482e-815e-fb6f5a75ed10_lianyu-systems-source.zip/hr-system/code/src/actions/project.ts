'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

// safeRevalidatePath allows calling actions outside Next.js request context safely
function safeRevalidatePath(path: string) {
  try {
    revalidatePath(path);
  } catch (e) {
    // Ignore error when run from scripts/tests
  }
}

// 1. 获取所有项目列表
export async function getProjects() {
  try {
    const projects = await prisma.project.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        _count: {
          select: { mappings: true }
        }
      }
    });

    return { success: true, data: projects };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 2. 新增或更新项目主数据
export async function createOrUpdateProject(id: string | null, data: {
  code: string;
  name: string;
  signDate?: Date | null;
  startDate: Date;
  endDate: Date;
}) {
  try {
    if (id) {
      await prisma.project.update({
        where: { id },
        data
      });
    } else {
      await prisma.project.create({
        data
      });
    }

    safeRevalidatePath('/system/projects');
    safeRevalidatePath('/system/pmo');
    return { success: true };
  } catch (error: any) {
    // Provide user-friendly errors for duplicate code
    if (error.code === 'P2002' && error.meta?.target?.includes('code')) {
      return { success: false, message: '该项目编号已存在，请更换重试。' };
    }
    return { success: false, message: error.message };
  }
}

// 3. 删除项目
export async function deleteProject(id: string) {
  try {
    await prisma.project.delete({
      where: { id }
    });

    safeRevalidatePath('/system/projects');
    safeRevalidatePath('/system/pmo');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 4. 获取某项目下的所有已分配顾问及其排期(SOW)计划
export async function getProjectConsultantsAndSow(projectCode: string) {
  try {
    // Get mappings for this project
    const mappings = await prisma.projectConsultantMapping.findMany({
      where: { projectId: projectCode },
      include: {
        employee: true,
      }
    });

    // Get SOW plans for this project
    const sowPlans = await prisma.projectSowPlan.findMany({
      where: { projectId: projectCode }
    });

    // Format output
    const list = mappings.map(mapping => {
      // Find SOW entries for this specific mapping
      const consultantSows = sowPlans
        .filter(s => s.employeeId === mapping.employeeId)
        .map(s => ({
          month: s.month,
          plannedDays: s.plannedDays
        }));

      return {
        mappingId: mapping.id,
        employeeId: mapping.employeeId,
        jobNumber: mapping.employee.jobNumber,
        realName: mapping.employee.name,
        consultantName: mapping.consultantName,
        monthlySows: consultantSows
      };
    });

    return { success: true, data: list };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 5. 分配顾问到项目并批量规划各月 SOW (预估工时)
export async function allocateConsultantWithSow(
  projectCode: string,
  employeeId: string,
  consultantName: string,
  monthlySows: { month: string; plannedDays: number }[]
) {
  try {
    // 采用 transaction 保证一致性
    await prisma.$transaction(async (tx) => {
      // 1. 创建或更新顾问的映射关联
      await tx.projectConsultantMapping.upsert({
        where: {
          projectId_employeeId: {
            projectId: projectCode,
            employeeId: employeeId
          }
        },
        update: { consultantName },
        create: {
          projectId: projectCode,
          employeeId: employeeId,
          consultantName
        }
      });

      // 2. 批量处理月度预估工时 (SOW)
      for (const sow of monthlySows) {
        if (sow.plannedDays >= 0) { // Only update if valid
          await tx.projectSowPlan.upsert({
            where: {
              projectId_employeeId_month: {
                projectId: projectCode,
                employeeId: employeeId,
                month: sow.month
              }
            },
            update: { plannedDays: sow.plannedDays },
            create: {
              projectId: projectCode,
              employeeId: employeeId,
              month: sow.month,
              plannedDays: sow.plannedDays
            }
          });
        }
      }
    });

    safeRevalidatePath('/system/projects');
    safeRevalidatePath('/system/pmo');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}
