import { prisma } from '../lib/prisma';

async function main() {
  const emp = await prisma.employee.findFirst({ where: { name: '燕燕' } });
  
  const monthStr = '2026-05';
  const [year, month] = monthStr.split('-').map(Number);
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0, 23, 59, 59, 999);

  const calendarDays = await prisma.attendanceCalendar.findMany({
    where: { date: { gte: startDate, lte: endDate } },
    orderBy: { date: 'asc' }
  });
  const calendarMap = new Map<string, string>();
  calendarDays.forEach(d => {
    calendarMap.set(d.date.toISOString().split('T')[0], d.type);
  });

  let shouldWorkDays = 0;
  let totalEmployedShifts = 0;
  const lastDay = new Date(year, month, 0).getDate();

  const trace: any[] = [];

  for (let d = 1; d <= lastDay; d++) {
    const currentDate = new Date(year, month - 1, d);
    const dateStr = currentDate.toISOString().split('T')[0];
    const dayOfWeek = currentDate.getDay();
    const isMonToFri = dayOfWeek >= 1 && dayOfWeek <= 5;
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

    const calType = calendarMap.get(dateStr);

    let swdInc = 0;
    if (isMonToFri) {
      swdInc = 1;
      shouldWorkDays += 1;
    }

    let tesInc = 0;
    if (isMonToFri && calType !== 'REST') {
      tesInc = 1;
      totalEmployedShifts += 1;
    } else if (isWeekend && calType === 'MAKEUP') {
      tesInc = 1;
      totalEmployedShifts += 1;
    }
    
    trace.push({
      dateStr, dayOfWeek, calType, isMonToFri, isWeekend, swdInc, tesInc,
      shouldWorkDays, totalEmployedShifts
    });
  }
  
  console.table(trace);
}
main().catch(console.error).finally(() => prisma.$disconnect());
