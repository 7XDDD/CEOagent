'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

// 获取所有角色及其关联的权限
export async function getRoles() {
  try {
    const roles = await prisma.role.findMany({
      include: {
        permissions: {
          include: {
            permission: true,
          },
        },
      },
      orderBy: { code: 'asc' },
    });
    return { success: true, data: roles };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 创建新角色
export async function createRole(data: { code: string; name: string; description?: string }) {
  try {
    const newRole = await prisma.role.create({
      data: {
        code: data.code,
        name: data.name,
        description: data.description,
      },
    });
    revalidatePath('/system/roles');
    return { success: true, data: newRole };
  } catch (error: any) {
    if (error.code === 'P2002') {
      return { success: false, message: '角色编码已存在' };
    }
    return { success: false, message: error.message };
  }
}

// 删除角色
export async function deleteRole(id: string) {
  try {
    // Check if any users are using this role
    const usersWithRole = await prisma.user.count({ where: { roleId: id } });
    if (usersWithRole > 0) {
      return { success: false, message: '该角色下仍有用户，无法删除' };
    }

    // Delete role-permission relations first
    await prisma.rolePermission.deleteMany({ where: { roleId: id } });
    
    await prisma.role.delete({ where: { id } });
    revalidatePath('/system/roles');
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 获取所有系统权限列表
export async function getAllPermissions() {
  try {
    const permissions = await prisma.permission.findMany({
      orderBy: { code: 'asc' },
    });
    return { success: true, data: permissions };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}
