import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const dates = await prisma.attendanceCalendar.findMany({
    where: { date: { gte: new Date('2026-05-01'), lte: new Date('2026-05-31') } },
    orderBy: { date: 'asc' }
  });
  console.log(dates.map(d => `${d.date.toISOString().split('T')[0]}: ${d.type}`));
}
main().catch(console.error).finally(() => prisma.$disconnect());
