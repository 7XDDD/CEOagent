import { generateMonthlySummaryForEmployee } from './attendance';
import { prisma } from '../lib/prisma';

async function main() {
  await generateMonthlySummaryForEmployee("0001", "2026-05");
  const summary = await prisma.monthlyAttendanceSummary.findFirst({
    where: { name: '燕燕', month: '2026-05' }
  });
  console.log('After Fix Summary 2026-05:', summary);
}
main().catch(console.error).finally(() => prisma.$disconnect());
