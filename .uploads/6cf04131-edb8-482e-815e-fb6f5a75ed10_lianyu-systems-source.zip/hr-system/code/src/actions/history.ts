'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

function buildWhereClause(searchName?: string, searchDate?: string, dateField: string = 'date') {
  const where: any = {};
  if (searchName) {
    where.name = { contains: searchName };
  }
  if (searchDate) {
    const startOfDay = new Date(searchDate);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(searchDate);
    endOfDay.setHours(23, 59, 59, 999);
    
    if (dateField === 'date') {
      where.date = { gte: startOfDay, lte: endOfDay };
    } else {
      // For overtime, leave, travel: check if searchDate overlaps with startTime/endTime
      where.startTime = { lte: endOfDay };
      where.endTime = { gte: startOfDay };
    }
  }
  return where;
}

export async function getImportedClockings(page: number = 1, limit: number = 50, searchName?: string, searchDate?: string) {
  try {
    const skip = (page - 1) * limit;
    const where = buildWhereClause(searchName, searchDate, 'date');
    const [data, total] = await Promise.all([
      prisma.importedClocking.findMany({
        where,
        skip,
        take: limit,
        orderBy: { date: 'desc' }
      }),
      prisma.importedClocking.count({ where })
    ]);
    return { success: true, data, total };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function getImportedOvertimes(page: number = 1, limit: number = 50, searchName?: string, searchDate?: string) {
  try {
    const skip = (page - 1) * limit;
    const where = buildWhereClause(searchName, searchDate, 'range');
    const [data, total] = await Promise.all([
      prisma.importedOvertime.findMany({
        where,
        skip,
        take: limit,
        orderBy: { applyTime: 'desc' }
      }),
      prisma.importedOvertime.count({ where })
    ]);
    return { success: true, data, total };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function getImportedLeaves(page: number = 1, limit: number = 50, searchName?: string, searchDate?: string) {
  try {
    const skip = (page - 1) * limit;
    const where = buildWhereClause(searchName, searchDate, 'range');
    const [data, total] = await Promise.all([
      prisma.importedLeave.findMany({
        where,
        skip,
        take: limit,
        orderBy: { startTime: 'desc' }
      }),
      prisma.importedLeave.count({ where })
    ]);
    return { success: true, data, total };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function getImportedTravels(page: number = 1, limit: number = 50, searchName?: string, searchDate?: string) {
  try {
    const skip = (page - 1) * limit;
    const where = buildWhereClause(searchName, searchDate, 'range');
    const [data, total] = await Promise.all([
      prisma.importedTravel.findMany({
        where,
        skip,
        take: limit,
        orderBy: { startTime: 'desc' }
      }),
      prisma.importedTravel.count({ where })
    ]);
    return { success: true, data, total };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function getImportedExemptions(page: number = 1, limit: number = 50, searchName?: string, searchDate?: string) {
  try {
    const skip = (page - 1) * limit;
    const where = buildWhereClause(searchName, searchDate, 'exemptionDate');
    const [data, total] = await Promise.all([
      prisma.importedExemption.findMany({
        where,
        skip,
        take: limit,
        orderBy: { exemptionDate: 'desc' }
      }),
      prisma.importedExemption.count({ where })
    ]);
    return { success: true, data, total };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function getLeaveQuotasSummary(page: number = 1, limit: number = 50, searchName?: string) {
  try {
    const skip = (page - 1) * limit;
    
    const where: any = {
      leaveType: 'COMP_TIME',
    };
    
    if (searchName) {
      where.employee = {
        name: { contains: searchName, mode: 'insensitive' }
      };
    }

    // We fetch all matching quotas to aggregate by employeeId
    const allQuotas = await prisma.leaveQuota.findMany({
      where,
      include: { employee: true }
    });

    const summaryMap = new Map<string, any>();
    const now = new Date();

    for (const q of allQuotas) {
      if (!q.employee) continue;
      
      const empId = q.employeeId;
      if (!summaryMap.has(empId)) {
        summaryMap.set(empId, {
          employeeId: empId,
          name: q.employee.name,
          jobNumber: q.employee.jobNumber,
          total: 0,
          used: 0,
          expired: 0,
          remaining: 0
        });
      }

      const s = summaryMap.get(empId);
      s.total += q.totalHours;
      s.used += q.usedHours;

      if (q.expireAt && new Date(q.expireAt) < now) {
        // Only count unused portion as expired
        s.expired += Math.max(0, q.totalHours - q.usedHours);
      } else {
        s.remaining += Math.max(0, q.totalHours - q.usedHours);
      }
    }

    const aggregatedList = Array.from(summaryMap.values());
    const total = aggregatedList.length;
    const paginatedData = aggregatedList.slice(skip, skip + limit);

    return { success: true, data: paginatedData, total };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function getLeaveQuotasDetail(employeeId: string) {
  try {
    const details = await prisma.leaveQuota.findMany({
      where: {
        employeeId,
        leaveType: 'COMP_TIME'
      },
      include: {
        usages: true
      },
      orderBy: { sourceDate: 'desc' }
    });
    return { success: true, data: details };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function updateLeaveQuota(id: string, updates: { totalHours?: number, usedHours?: number, expireAt?: string | null }) {
  try {
    const quota = await prisma.leaveQuota.findUnique({ where: { id } });
    if (!quota) throw new Error('找不到该额度明细');

    const updated = await prisma.leaveQuota.update({
      where: { id },
      data: {
        totalHours: updates.totalHours !== undefined ? updates.totalHours : undefined,
        usedHours: updates.usedHours !== undefined ? updates.usedHours : undefined,
        expireAt: updates.expireAt !== undefined ? (updates.expireAt ? new Date(updates.expireAt) : null) : undefined,
      }
    });

    // 重新计算该员工的剩余调休余额
    await syncLeaveBalance(quota.employeeId);
    revalidatePath('/system/calendar/import/history');
    return { success: true, data: updated };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function addManualLeaveQuota(employeeId: string, data: { sourceDate: string, totalHours: number, expireAt: string | null }) {
  try {
    if (!employeeId) throw new Error("请选择员工");
    if (isNaN(data.totalHours)) throw new Error("请输入有效的额度");
    
    const sourceDateObj = new Date(data.sourceDate);
    if (isNaN(sourceDateObj.getTime())) throw new Error(`产生日期格式无效: ${data.sourceDate}`);
    
    let expireAtObj = null;
    if (data.expireAt) {
      expireAtObj = new Date(data.expireAt);
      if (isNaN(expireAtObj.getTime())) throw new Error(`过期时间格式无效: ${data.expireAt}`);
    }

    const created = await prisma.leaveQuota.create({
      data: {
        employeeId,
        leaveType: 'COMP_TIME',
        totalHours: data.totalHours,
        usedHours: 0,
        sourceDate: sourceDateObj,
        expireAt: expireAtObj
      }
    });

    await syncLeaveBalance(employeeId);
    revalidatePath('/system/calendar/import/history');
    return { success: true, data: created };
  } catch (error: any) {
    let msg = error.message || String(error);
    // 剔除 Prisma 报错中的代码片段和前面的冗长 invocation，只保留末尾的核心原因
    if (msg.includes('invocation:')) {
      msg = msg.split('invocation:')[1];
    }
    // 使用正则移除带有行号的代码行
    msg = msg.replace(/\n\s*\d+\s.*/g, '').replace(/\n\s*→.*/g, '').replace(/\n+/g, ' ').trim();
    return { success: false, message: msg };
  }
}

async function syncLeaveBalance(employeeId: string) {
  const quotas = await prisma.leaveQuota.findMany({
    where: { employeeId, leaveType: 'COMP_TIME' }
  });
  
  let remaining = 0;
  const now = new Date();
  for (const q of quotas) {
    if (!q.expireAt || q.expireAt >= now) {
      remaining += Math.max(0, q.totalHours - q.usedHours);
    }
  }

  await prisma.leaveBalance.upsert({
    where: { employeeId },
    update: { compensatory: remaining },
    create: { employeeId, compensatory: remaining, annual: 0 }
  });
}

export async function addManualOvertime(employeeId: string, data: { startTime: string, endTime: string, grossDuration: number, netDuration: number, reason: string }) {
  try {
    const emp = await prisma.employee.findUnique({ where: { id: employeeId } });
    if (!emp) throw new Error("员工不存在");
    
    const created = await prisma.importedOvertime.create({
      data: {
        approvalNumber: `MANUAL_OT_${Date.now()}`,
        name: emp.name,
        jobNumber: emp.jobNumber || '',
        startTime: new Date(data.startTime),
        endTime: new Date(data.endTime),
        grossDuration: data.grossDuration,
        netDuration: data.netDuration,
        reason: data.reason,
        status: 'PROCESSED',
        approvalStatus: '手工创建'
      }
    });
    revalidatePath('/system/calendar/import/history');
    return { success: true, data: created };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function addManualLeave(employeeId: string, data: { leaveType: string, startTime: string, endTime: string, duration: number, reason: string }) {
  try {
    const emp = await prisma.employee.findUnique({ where: { id: employeeId } });
    if (!emp) throw new Error("员工不存在");
    
    const created = await prisma.importedLeave.create({
      data: {
        approvalNumber: `MANUAL_LV_${Date.now()}`,
        name: emp.name,
        jobNumber: emp.jobNumber || '',
        leaveType: data.leaveType,
        startTime: new Date(data.startTime),
        endTime: new Date(data.endTime),
        duration: data.duration,
        reason: data.reason,
        approvalStatus: '手工创建'
      }
    });
    revalidatePath('/system/calendar/import/history');
    return { success: true, data: created };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function addManualTravel(employeeId: string, data: { startTime: string, endTime: string, duration: number, departure: string, destination: string, reason: string }) {
  try {
    const emp = await prisma.employee.findUnique({ where: { id: employeeId } });
    if (!emp) throw new Error("员工不存在");
    
    const created = await prisma.importedTravel.create({
      data: {
        approvalNumber: `MANUAL_TV_${Date.now()}`,
        name: emp.name,
        jobNumber: emp.jobNumber || '',
        startTime: new Date(data.startTime),
        endTime: new Date(data.endTime),
        duration: data.duration,
        departure: data.departure,
        destination: data.destination,
        reason: data.reason,
        approvalStatus: '手工创建'
      }
    });
    revalidatePath('/system/calendar/import/history');
    return { success: true, data: created };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

