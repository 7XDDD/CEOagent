'use server';

import { prisma } from '@/lib/prisma';

export async function syncOldOvertimesToQuota() {
  try {
    const overtimes = await prisma.importedOvertime.findMany({
      where: {
        status: 'PROCESSED',
        netDuration: { gt: 0 }
      }
    });

    let added = 0;
    let skipped = 0;

    for (const ot of overtimes) {
      const emp = await prisma.employee.findUnique({
        where: { jobNumber: ot.jobNumber }
      });

      if (!emp) {
        skipped++;
        continue;
      }

      const dateStr = ot.startTime.toISOString().split('T')[0];
      const dateObj = new Date(`${dateStr}T00:00:00.000Z`);
      
      const calendarDay = await prisma.attendanceCalendar.findFirst({
        where: {
          date: {
            gte: new Date(`${dateStr}T00:00:00.000Z`),
            lt: new Date(`${dateStr}T23:59:59.999Z`)
          }
        }
      });

      const isHoliday = calendarDay ? calendarDay.type === 'HOLIDAY' : false;
      if (isHoliday) {
        skipped++;
        continue;
      }

      const existing = await prisma.leaveQuota.findFirst({
        where: {
          employeeId: emp.id,
          leaveType: 'COMP_TIME',
          totalHours: ot.netDuration,
          sourceDate: {
            gte: new Date(`${dateStr}T00:00:00.000Z`),
            lt: new Date(`${dateStr}T23:59:59.999Z`)
          }
        }
      });

      if (existing) {
        skipped++;
        continue;
      }

      const expireAt = new Date(dateObj);
      expireAt.setFullYear(expireAt.getFullYear() + 1);
      expireAt.setDate(expireAt.getDate() - 1);
      expireAt.setHours(23, 59, 59, 999);

      await prisma.leaveQuota.create({
        data: {
          employeeId: emp.id,
          leaveType: 'COMP_TIME',
          totalHours: ot.netDuration,
          usedHours: 0,
          expireAt: expireAt,
          sourceDate: dateObj
        }
      });

      await prisma.leaveBalance.upsert({
        where: { employeeId: emp.id },
        update: { compensatory: { increment: ot.netDuration } },
        create: { employeeId: emp.id, compensatory: ot.netDuration }
      });

      added++;
    }

    return { success: true, added, skipped };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}
