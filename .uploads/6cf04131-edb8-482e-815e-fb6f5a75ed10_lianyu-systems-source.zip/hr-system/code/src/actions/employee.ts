'use server';

import { prisma } from '@/lib/prisma';
import { revalidatePath } from 'next/cache';

// 身份证智能解析逻辑 (中国大陆 18 位身份证)
export async function parseIdCard(idCard: string) {
  const regex = /^[1-9]\d{5}(19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx]$/;
  
  if (!regex.test(idCard)) {
    return { success: false, message: '身份证格式不正确' };
  }

  const birthStr = idCard.substring(6, 14);
  const year = birthStr.substring(0, 4);
  const month = birthStr.substring(4, 6);
  const day = birthStr.substring(6, 8);
  const birthday = new Date(`${year}-${month}-${day}`);

  const genderChar = idCard.charAt(16);
  const isOdd = parseInt(genderChar) % 2 !== 0;
  const gender = isOdd ? 'MALE' : 'FEMALE';

  return {
    success: true,
    data: {
      birthday: birthday.toISOString(),
      gender,
      birthdayFormatted: `${year}-${month}-${day}`,
      genderFormatted: isOdd ? '男' : '女',
    }
  };
}

// 获取所有员工列表
export async function getEmployees() {
  try {
    const employees = await prisma.employee.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        user: {
          select: { username: true, email: true }
        }
      }
    });
    return { success: true, data: employees };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 新增员工 (支持第一类核心字段与动态 extInfo)
export async function createEmployee(data: any) {
  try {
    const parseResult = await parseIdCard(data.idCard);
    if (!parseResult.success) {
      return { success: false, message: parseResult.message };
    }
    const { birthday, gender } = parseResult.data!;

    // 默认生成工号 (如果前端未传入)
    const jobNumber = data.jobNumber || `EMP-${Date.now().toString().slice(-6)}`;

    // 创建员工与调休假账户（默认初始化 0 小时）
    const newEmployee = await prisma.$transaction(async (tx) => {
      const emp = await tx.employee.create({
        data: {
          jobNumber: jobNumber,
          idCard: data.idCard,
          name: data.name,
          gender: gender,
          birthday: new Date(birthday),
          status: 'ACTIVE',
          exemptAttendance: data.exemptAttendance ?? false,
          hireDate: data.hireDate ? new Date(data.hireDate) : null,
          probationMonths: data.probationMonths ? parseInt(data.probationMonths) : 3,
          contractType: data.contractType || null,
          contractStartDate: data.contractStartDate ? new Date(data.contractStartDate) : null,
          contractEndDate: data.contractEndDate ? new Date(data.contractEndDate) : null,
          extInfo: data.extInfo || {},
        },
      });

      // 初始化假账本
      await tx.leaveBalance.create({
        data: {
          employeeId: emp.id,
          compensatory: 12.0, // 为了演示1:1离职结算，默认赠送12小时调休额度
          annual: 5.0,
        }
      });

      return emp;
    });

    revalidatePath('/system/employees');
    return { success: true, data: newEmployee };
  } catch (error: any) {
    if (error.code === 'P2002') {
      return { success: false, message: '工号或身份证号已存在' };
    }
    return { success: false, message: error.message };
  }
}

// 编辑更新员工
export async function updateEmployee(id: string, data: any) {
  try {
    const parseResult = await parseIdCard(data.idCard);
    if (!parseResult.success) {
      return { success: false, message: parseResult.message };
    }
    const { birthday, gender } = parseResult.data!;

    // 注意：唯一标识 jobNumber 和 idCard 理论上只读，更新时我们只更新可更改的内容
    const updatedEmployee = await prisma.employee.update({
      where: { id },
      data: {
        name: data.name,
        gender: gender,
        birthday: new Date(birthday),
        exemptAttendance: data.exemptAttendance ?? false,
        hireDate: data.hireDate ? new Date(data.hireDate) : null,
        probationMonths: data.probationMonths ? parseInt(data.probationMonths) : 3,
        contractType: data.contractType || null,
        contractStartDate: data.contractStartDate ? new Date(data.contractStartDate) : null,
        contractEndDate: data.contractEndDate ? new Date(data.contractEndDate) : null,
        extInfo: data.extInfo || {},
      },
    });

    revalidatePath('/system/employees');
    return { success: true, data: updatedEmployee };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 员工离职办理 (包含事务处理与全量历史快照写入)
export async function resignEmployee(employeeId: string, resignationData: {
  resignedAt: string;
  resignationType: string;
  resignationReason: string;
  hasCompensation: string;
  submittedFiles: string[];
}) {
  try {
    const result = await prisma.$transaction(async (tx) => {
      // 1. 获取当前员工及其假账本
      const emp = await tx.employee.findUnique({
        where: { id: employeeId },
        include: { leaveBalance: true }
      });
      if (!emp) {
        throw new Error('找不到该员工');
      }

      // 计算调休结算：如果含有调休假，1:1输出流水账单
      const compHours = emp.leaveBalance?.compensatory || 0;
      
      // 2. 更新 extInfo 加入离职及调休折现明细
      const currentExtInfo = emp.extInfo && typeof emp.extInfo === 'object' ? (emp.extInfo as any) : {};
      const updatedExtInfo = {
        ...currentExtInfo,
        resignedAt: resignationData.resignedAt,
        resignationType: resignationData.resignationType,
        resignationReason: resignationData.resignationReason,
        hasCompensation: resignationData.hasCompensation,
        submittedFiles: resignationData.submittedFiles,
        settledCompensatoryHours: compHours,
        settledCompensationStatus: compHours > 0 ? `1:1工资折算 (共 ${compHours} 小时待发放)` : '无调休假待折算'
      };

      // 3. 更新员工状态为 RESIGNED
      const updatedEmployee = await tx.employee.update({
        where: { id: employeeId },
        data: {
          status: 'RESIGNED',
          extInfo: updatedExtInfo,
        }
      });

      // 4. 清空调休额度（完成结算）
      if (emp.leaveBalance) {
        await tx.leaveBalance.update({
          where: { employeeId },
          data: { compensatory: 0.0 }
        });
      }

      // 5. 写入全量离职快照
      await tx.employeeSnapshot.create({
        data: {
          employeeId: employeeId,
          snapshotData: JSON.parse(JSON.stringify(updatedEmployee)),
          reason: resignationData.resignationReason,
          resignedAt: new Date(resignationData.resignedAt),
        }
      });

      return { success: true };
    });

    revalidatePath('/system/employees');
    return result;
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function importEmployeesBatch(payload: any[], isConsultant: boolean) {
  try {
    let imported = 0;
    for (const data of payload) {
      if (!data.idCard && !data.jobNumber) continue; // Skip invalid

      const whereClause = data.idCard 
        ? { idCard: String(data.idCard) } 
        : { jobNumber: String(data.jobNumber) };
        
      if (isConsultant) {
        data.exemptAttendance = true;
        data.extInfo = { ...(data.extInfo || {}), '顾问': '是' };
      }

      await prisma.employee.upsert({
        where: whereClause,
        update: {
          name: data.name,
          gender: data.gender,
          email: data.email,
          jobNumber: data.jobNumber ? String(data.jobNumber) : null,
          idCard: data.idCard ? String(data.idCard) : undefined,
          companyId: data.companyId || null,
          birthday: data.birthday ? new Date(data.birthday) : null,
          hireDate: data.hireDate ? new Date(data.hireDate) : null,
          probationMonths: data.probationMonths ? Number(data.probationMonths) : 3,
          contractType: data.contractType || null,
          contractStartDate: data.contractStartDate ? new Date(data.contractStartDate) : null,
          contractEndDate: data.contractEndDate ? new Date(data.contractEndDate) : null,
          status: data.status || 'ACTIVE',
          exemptAttendance: data.exemptAttendance || false,
          extInfo: data.extInfo || {},
        },
        create: {
          name: data.name,
          gender: data.gender,
          email: data.email,
          jobNumber: data.jobNumber ? String(data.jobNumber) : null,
          idCard: data.idCard ? String(data.idCard) : '',
          companyId: data.companyId || null,
          birthday: data.birthday ? new Date(data.birthday) : null,
          hireDate: data.hireDate ? new Date(data.hireDate) : null,
          probationMonths: data.probationMonths ? Number(data.probationMonths) : 3,
          contractType: data.contractType || null,
          contractStartDate: data.contractStartDate ? new Date(data.contractStartDate) : null,
          contractEndDate: data.contractEndDate ? new Date(data.contractEndDate) : null,
          status: data.status || 'ACTIVE',
          exemptAttendance: data.exemptAttendance || false,
          extInfo: data.extInfo || {},
        }
      });
      imported++;
    }

    revalidatePath('/system/employees');
    revalidatePath('/system/pmo');
    return { success: true, count: imported };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}
