import { getCalendarDays } from '@/actions/calendar';
import CalendarClient from './CalendarClient';

export const metadata = {
  title: '全局考勤日历配置 - 智能化HR系统',
};

export default async function CalendarPage() {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth() + 1; // 1-indexed

  const result = await getCalendarDays(year, month);
  const initialDays = result.success ? (result.data ?? []) : [];

  return (
    <CalendarClient 
      initialYear={year} 
      initialMonth={month} 
      initialDays={initialDays} 
    />
  );
}
