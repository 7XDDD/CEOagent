'use client';

import { useState, useEffect } from 'react';
import { parseIdCard, createEmployee, updateEmployee } from '@/actions/employee';
import { useRouter } from 'next/navigation';

interface EmployeeFormProps {
  customFields: any[];
  initialEmployee?: any; // 如果传入代表编辑模式
  onSuccess: () => void;
  isConsultant?: boolean;
}

export default function EmployeeForm({ customFields, initialEmployee, onSuccess, isConsultant }: EmployeeFormProps) {
  const router = useRouter();
  const isEdit = !!initialEmployee;
  
  // 1. 本地字段状态
  const [formData, setFormData] = useState({
    name: '',
    idCard: '',
    jobNumber: '',
    exemptAttendance: false,
    hireDate: '',
    probationMonths: 3,
    contractType: '新签',
    contractStartDate: '',
    contractEndDate: '',
    
    // 扩展字段 (存储在 extInfo JSONB 中)
    phone: '',
    workLocation: '',
    department: '',
    position: isConsultant ? '顾问' : '',
    employeeType: isConsultant ? '外部合作' : '全职',
    contractCompany: '',
    maritalStatus: '',
    politicalStatus: '',
    nativePlace: '',
    ethnicity: '',
    email: '',
    hukouAddress: '',
    homeAddress: '',
    emergencyContactName: '',
    emergencyContactPhone: '',
    bankName: '',
    bankAccount: '',
  });

  const consultantField = customFields.find(f => f.label === '顾问');
  const consultantFieldName = consultantField ? consultantField.name : '顾问';

  // 动态自定义字段状态
  const [dynamicValues, setDynamicValues] = useState<Record<string, any>>({
    [consultantFieldName]: isConsultant ? '是' : undefined
  });
  const [parsedData, setParsedData] = useState({ gender: '', birthday: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // 2. 初始化回显数据 (编辑模式)
  useEffect(() => {
    if (isEdit && initialEmployee) {
      const ext = typeof initialEmployee.extInfo === 'string' 
        ? JSON.parse(initialEmployee.extInfo) 
        : (initialEmployee.extInfo || {});

      setFormData({
        name: initialEmployee.name || '',
        idCard: initialEmployee.idCard || '',
        jobNumber: initialEmployee.jobNumber || '',
        exemptAttendance: initialEmployee.exemptAttendance ?? false,
        hireDate: initialEmployee.hireDate ? new Date(initialEmployee.hireDate).toISOString().split('T')[0] : '',
        probationMonths: initialEmployee.probationMonths ?? 3,
        contractType: initialEmployee.contractType || '新签',
        contractStartDate: initialEmployee.contractStartDate ? new Date(initialEmployee.contractStartDate).toISOString().split('T')[0] : '',
        contractEndDate: initialEmployee.contractEndDate ? new Date(initialEmployee.contractEndDate).toISOString().split('T')[0] : '',
        
        phone: ext.phone || '',
        workLocation: ext.workLocation || '',
        department: ext.department || '',
        position: ext.position || '',
        employeeType: ext.employeeType || (isConsultant ? '外部合作' : '全职'),
        contractCompany: ext.contractCompany || '',
        maritalStatus: ext.maritalStatus || '',
        politicalStatus: ext.politicalStatus || '',
        nativePlace: ext.nativePlace || '',
        ethnicity: ext.ethnicity || '',
        email: ext.email || '',
        hukouAddress: ext.hukouAddress || '',
        homeAddress: ext.homeAddress || '',
        emergencyContactName: ext.emergencyContactName || '',
        emergencyContactPhone: ext.emergencyContactPhone || '',
        bankName: ext.bankName || '',
        bankAccount: ext.bankAccount || '',
      });

      // 初始化自定义字段的回显
      const dyns: Record<string, any> = {};
      customFields.forEach(f => {
        if (ext[f.name] !== undefined) {
          dyns[f.name] = ext[f.name];
        }
      });
      setDynamicValues(dyns);

      // 初始化身份证解析回显
      setParsedData({
        gender: initialEmployee.gender === 'MALE' ? '男' : '女',
        birthday: initialEmployee.birthday ? new Date(initialEmployee.birthday).toISOString().split('T')[0] : '',
      });
    }
  }, [isEdit, initialEmployee, customFields]);

  // 3. 身份证智能解析
  const handleIdCardBlur = async (e: React.FocusEvent<HTMLInputElement>) => {
    const idCard = e.target.value;
    if (idCard.length === 18) {
      const result = await parseIdCard(idCard);
      if (result.success && result.data) {
        setParsedData({
          gender: result.data.genderFormatted,
          birthday: result.data.birthdayFormatted,
        });
        setError('');
      } else {
        setParsedData({ gender: '', birthday: '' });
        setError(result.message || '身份证解析失败');
      }
    }
  };

  // 4. 合同周期强规则计算
  const calculateContractEndDate = (startDate: string, type: string) => {
    if (!startDate) return '';
    const date = new Date(startDate);
    const years = type === '新签' ? 4 : 5;
    date.setFullYear(date.getFullYear() + years);
    date.setDate(date.getDate() - 1); // 周期结算减一天
    return date.toISOString().split('T')[0];
  };

  const handleContractStartDateChange = (val: string) => {
    setFormData(prev => ({
      ...prev,
      contractStartDate: val,
      contractEndDate: calculateContractEndDate(val, prev.contractType)
    }));
  };

  const handleContractTypeChange = (val: string) => {
    setFormData(prev => ({
      ...prev,
      contractType: val,
      contractEndDate: calculateContractEndDate(prev.contractStartDate, val)
    }));
  };

  // 5. 提交表单
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // 安全检查：如果有后台将历史选填项改为必填，在此处进行前置拦截
    for (const f of customFields) {
      if (f.required && !dynamicValues[f.name]) {
        setError(`请填写必填的自定义字段: [${f.label}]`);
        setLoading(false);
        return;
      }
    }

    if (!parsedData.gender) {
      setError('请输入有效的 18 位身份证号码');
      setLoading(false);
      return;
    }

    // 组合数据负载
    const payload = {
      name: formData.name,
      idCard: formData.idCard,
      jobNumber: isEdit ? initialEmployee.jobNumber : formData.jobNumber, // 编辑时使用原工号
      exemptAttendance: formData.exemptAttendance,
      hireDate: formData.hireDate,
      probationMonths: formData.probationMonths,
      contractType: formData.contractType,
      contractStartDate: formData.contractStartDate,
      contractEndDate: formData.contractEndDate,
      
      // 其他字段及自定义字段归入 extInfo
      extInfo: {
        phone: formData.phone,
        workLocation: formData.workLocation,
        department: formData.department,
        position: formData.position,
        employeeType: formData.employeeType,
        contractCompany: formData.contractCompany,
        maritalStatus: formData.maritalStatus,
        politicalStatus: formData.politicalStatus,
        nativePlace: formData.nativePlace,
        ethnicity: formData.ethnicity,
        email: formData.email,
        hukouAddress: formData.hukouAddress,
        homeAddress: formData.homeAddress,
        emergencyContactName: formData.emergencyContactName,
        emergencyContactPhone: formData.emergencyContactPhone,
        bankName: formData.bankName,
        bankAccount: formData.bankAccount,
        ...dynamicValues, // 挂载HR动态配置的字段
      }
    };

    const result = isEdit 
      ? await updateEmployee(initialEmployee.id, payload)
      : await createEmployee(payload);

    if (result.success) {
      onSuccess();
      router.refresh();
    } else {
      setError(result.message || '保存失败');
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-h-[70vh] overflow-y-auto pr-2">
      {error && <div className="text-red-500 text-sm p-3 bg-red-50 border border-red-200 rounded sticky top-0 z-10 shadow-sm">{error}</div>}
      
      {/* 1. 核心必填身份信息 */}
      <div>
        <h4 className="text-sm font-semibold text-indigo-600 border-b pb-2 mb-4">核心身份信息</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">工号 {isEdit ? '' : <span className="text-red-500">*</span>}</label>
            <input 
              type="text" 
              required={!isEdit}
              disabled={isEdit}
              value={formData.jobNumber} 
              onChange={e => setFormData({...formData, jobNumber: e.target.value})} 
              placeholder={isEdit ? '' : "不填将自动生成"}
              className={`mt-1 block w-full rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 ${
                isEdit ? 'bg-gray-150 text-gray-400 border-gray-200 cursor-not-allowed' : 'bg-yellow-50 border-gray-300'
              }`}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">姓名 <span className="text-red-500">*</span></label>
            <input type="text" required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">身份证号 <span className="text-red-500">*</span></label>
            <input 
              type="text" 
              required 
              maxLength={18} 
              disabled={isEdit}
              value={formData.idCard} 
              onChange={e => setFormData({...formData, idCard: e.target.value})} 
              onBlur={handleIdCardBlur} 
              placeholder="请输入18位身份证号" 
              className={`mt-1 block w-full rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 ${
                isEdit ? 'bg-gray-150 text-gray-400 border-gray-200 cursor-not-allowed' : 'bg-yellow-50 border-gray-300'
              }`} 
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">免考勤白名单员工</label>
            <div className="mt-3 flex items-center space-x-2">
              <input 
                type="checkbox" 
                id="exemptAttendance"
                checked={formData.exemptAttendance}
                onChange={e => setFormData({ ...formData, exemptAttendance: e.target.checked })}
                className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 h-4 w-4 cursor-pointer"
              />
              <label htmlFor="exemptAttendance" className="text-sm text-gray-600 cursor-pointer">是（后续自动豁免缺卡迟到罚金）</label>
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500">智能解析性别</label>
            <div className="mt-1 text-sm text-gray-900 font-semibold bg-gray-100 p-2 rounded border border-gray-200">{parsedData.gender || '输入身份证后自动生成'}</div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500">智能解析出生日期</label>
            <div className="mt-1 text-sm text-gray-900 font-semibold bg-gray-100 p-2 rounded border border-gray-200">{parsedData.birthday || '输入身份证后自动生成'}</div>
          </div>
        </div>
      </div>

      {/* 2. 入职与合同周期强规则 */}
      <div>
        <h4 className="text-sm font-semibold text-indigo-600 border-b pb-2 mb-4">入职与合同强规则</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">入职时间 <span className="text-red-500">*</span></label>
            <input type="date" required value={formData.hireDate} onChange={e => setFormData({...formData, hireDate: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">试用期时长(月) <span className="text-red-500">*</span></label>
            <input type="number" min={0} required value={formData.probationMonths} onChange={e => setFormData({...formData, probationMonths: parseInt(e.target.value) || 0})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" />
          </div>
          
          {/* 合同强关联部分 */}
          <div>
            <label className="block text-sm font-medium text-gray-700">劳动合同签署类型 <span className="text-red-500">*</span></label>
            <select 
              value={formData.contractType} 
              onChange={e => handleContractTypeChange(e.target.value)} 
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50"
            >
              <option value="新签">新签合同 (默认4年周期)</option>
              <option value="续签">续签合同 (默认5年周期)</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">合同起始日期 <span className="text-red-500">*</span></label>
            <input 
              type="date" required 
              value={formData.contractStartDate} 
              onChange={e => handleContractStartDateChange(e.target.value)} 
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" 
            />
          </div>
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700">合同结束时间 (强关联自动推导) <span className="text-red-500">*</span></label>
            <input 
              type="date" required 
              value={formData.contractEndDate} 
              onChange={e => setFormData({...formData, contractEndDate: e.target.value})} 
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" 
            />
            <p className="mt-1 text-xs text-gray-400">已应用规则: 新签自动计算4年，续签自动计算5年（首尾算满前一日）。可手动微调。</p>
          </div>
        </div>
      </div>

      {/* 3. 标准基本信息 */}
      <div>
        <h4 className="text-sm font-semibold text-indigo-600 border-b pb-2 mb-4">基本资料与财务</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">联系电话 <span className="text-red-500">*</span></label>
            <input type="text" required value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">工作地 <span className="text-red-500">*</span></label>
            <input type="text" required value={formData.workLocation} onChange={e => setFormData({...formData, workLocation: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">所属部门 <span className="text-red-500">*</span></label>
            <input type="text" required value={formData.department} onChange={e => setFormData({...formData, department: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">岗位 <span className="text-red-500">*</span></label>
            <input 
              type="text" 
              required 
              value={formData.position} 
              onChange={e => setFormData({...formData, position: e.target.value})} 
              readOnly={isConsultant}
              className={`mt-1 block w-full rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 ${
                isConsultant ? 'bg-gray-100 text-gray-500 cursor-not-allowed' : 'border-gray-300 bg-yellow-50'
              }`}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">劳动合同单位 <span className="text-red-500">*</span></label>
            <input type="text" required value={formData.contractCompany} onChange={e => setFormData({...formData, contractCompany: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">员工类型 <span className="text-red-500">*</span></label>
            <select value={formData.employeeType} onChange={e => setFormData({...formData, employeeType: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50">
              <option value="全职">全职</option>
              <option value="实习">实习</option>
              <option value="兼职">兼职</option>
              <option value="劳务派遣">劳务派遣</option>
              <option value="外部合作">外部合作</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">婚姻状况</label>
            <select value={formData.maritalStatus} onChange={e => setFormData({...formData, maritalStatus: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2">
              <option value="">请选择</option>
              <option value="未婚">未婚</option>
              <option value="已婚">已婚</option>
              <option value="离异">离异</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">政治面貌</label>
            <input type="text" value={formData.politicalStatus} onChange={e => setFormData({...formData, politicalStatus: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">民族</label>
            <input type="text" value={formData.ethnicity} onChange={e => setFormData({...formData, ethnicity: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">籍贯</label>
            <input type="text" value={formData.nativePlace} onChange={e => setFormData({...formData, nativePlace: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">个人邮箱</label>
            <input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">家庭居住地址</label>
            <input type="text" value={formData.homeAddress} onChange={e => setFormData({...formData, homeAddress: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">户口所在地地址</label>
            <input type="text" value={formData.hukouAddress} onChange={e => setFormData({...formData, hukouAddress: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">紧急联系人姓名</label>
            <input type="text" value={formData.emergencyContactName} onChange={e => setFormData({...formData, emergencyContactName: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">紧急联系人电话</label>
            <input type="text" value={formData.emergencyContactPhone} onChange={e => setFormData({...formData, emergencyContactPhone: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">开户银行</label>
            <input type="text" value={formData.bankName} onChange={e => setFormData({...formData, bankName: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">银行卡号</label>
            <input type="text" value={formData.bankAccount} onChange={e => setFormData({...formData, bankAccount: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2" />
          </div>
        </div>
      </div>

      {/* 4. 动态同源编辑区域 */}
      {customFields.length > 0 && (
        <div>
          <h4 className="text-sm font-semibold text-indigo-600 border-b pb-2 mb-4">HR 自定义字段列表 (实时生效)</h4>
          <div className="grid grid-cols-2 gap-4">
            {customFields.map(f => {
              const val = dynamicValues[f.name] || '';
              return (
                <div key={f.id}>
                  <label className="block text-sm font-medium text-gray-700">
                    {f.label} {f.required && <span className="text-red-500">*</span>}
                  </label>
                  {f.type === 'SELECT' ? (
                    <select
                      required={f.required}
                      value={val}
                      onChange={e => setDynamicValues({ ...dynamicValues, [f.name]: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50"
                    >
                      <option value="">请选择</option>
                      {(Array.isArray(f.options) ? f.options : []).map((opt: string) => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  ) : f.type === 'DATE' ? (
                    <input 
                      type="date"
                      required={f.required}
                      value={val}
                      onChange={e => setDynamicValues({ ...dynamicValues, [f.name]: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50"
                    />
                  ) : f.type === 'NUMBER' ? (
                    <input 
                      type="number"
                      required={f.required}
                      value={val}
                      onChange={e => setDynamicValues({ ...dynamicValues, [f.name]: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50"
                    />
                  ) : (
                    <input 
                      type="text"
                      required={f.required}
                      value={val}
                      onChange={e => setDynamicValues({ ...dynamicValues, [f.name]: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50"
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 底部按钮组 */}
      <div className="mt-6 flex justify-end pt-4 border-t border-gray-200 bg-white sticky bottom-0 z-10">
        <button type="button" onClick={onSuccess} className="mr-3 px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none">
          取消
        </button>
        <button type="submit" disabled={loading} className="px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none disabled:opacity-50">
          {loading ? '保存中...' : isEdit ? '保存修改' : '确认并录入'}
        </button>
      </div>
    </form>
  );
}
