'use client';

import React, { useState, useEffect } from 'react';
import {
  saveConsultantBaseline,
  saveProjectConsultantMapping,
  deleteProjectConsultantMapping,
  getProjectMonthlyData,
  saveProjectMonthlyData,
  getPMOEfficiencyReport
} from '@/actions/pmo';
import ConsultantForm from './ConsultantForm';
import * as XLSX from 'xlsx';
import { importEmployeesBatch } from '@/actions/employee';

interface Employee {
  id: string;
  name: string;
  jobNumber: string;
  status: string;
  [key: string]: any;
}

interface Mapping {
  id: string;
  projectId: string;
  employeeId: string;
  consultantName: string;
  employee: Employee;
}

interface Baseline {
  employeeId: string;
  jobNumber: string;
  name: string;
  baselineDays: number;
  baselineId: string | null;
}

interface MonthlyDataRow {
  mappingId: string;
  projectId: string;
  employeeId: string;
  jobNumber: string;
  realName: string;
  consultantName: string;
  plannedDays: number;
  actualDays: number;
  dailyLogs?: Record<string, number>;
}

interface ReportRow {
  mappingId: string;
  projectId: string;
  employeeId: string;
  jobNumber: string;
  realName: string;
  consultantName: string;
  baselineDays: number;
  totalActualDays: number;
  attainmentRate: number;
  months: {
    month: string;
    planned: number;
    actual: number;
    finalDays: number;
    segmentType: 'PAST' | 'CURRENT' | 'FUTURE';
  }[];
}

interface PmoClientProps {
  employees: Employee[];
  initialBaselines: Baseline[];
  initialMappings: Mapping[];
  initialReport: ReportRow[];
  initialYear: number;
  customFields: any[];
}

export default function PmoClient({
  employees,
  initialBaselines,
  initialMappings,
  initialReport,
  initialYear,
  customFields
}: PmoClientProps) {
  const [activeTab, setActiveTab] = useState<'report' | 'fill' | 'hr-config' | 'consultants'>('report');
  const [reportDimension, setReportDimension] = useState<'project' | 'consultant'>('project');
  const [year, setYear] = useState<number>(initialYear);
  const [projectIdFilter, setProjectIdFilter] = useState<string>('');
  
  // Lists
  const [mappings, setMappings] = useState<Mapping[]>(initialMappings);
  const [baselines, setBaselines] = useState<Baseline[]>(initialBaselines);
  const [report, setReport] = useState<ReportRow[]>(initialReport);
  
  // Loading & Messages
  const [loading, setLoading] = useState<boolean>(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Mappings Form State
  const [newProjectId, setNewProjectId] = useState<string>('');
  const [newEmployeeId, setNewEmployeeId] = useState<string>('');
  const [newConsultantName, setNewConsultantName] = useState<string>('');
  const [savingMapping, setSavingMapping] = useState<boolean>(false);

  // Baselines Form State
  const [baselineEmpId, setBaselineEmpId] = useState<string>('');
  const [baselineDaysVal, setBaselineDaysVal] = useState<number>(120);
  const [savingBaseline, setSavingBaseline] = useState<boolean>(false);

  // PMO Data Entry Form State
  const [entryProjectId, setEntryProjectId] = useState<string>('');
  const [entryMonth, setEntryMonth] = useState<string>('2026-06');
  const [entryRows, setEntryRows] = useState<MonthlyDataRow[]>([]);
  const [loadingEntry, setLoadingEntry] = useState<boolean>(false);
  const [savingEntry, setSavingEntry] = useState<boolean>(false);

  // Daily Grid Modal State
  const [dailyModalOpen, setDailyModalOpen] = useState<boolean>(false);
  const [selectedDailyIndex, setSelectedDailyIndex] = useState<number | null>(null);

  // Consultants Roster State
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editConsultant, setEditConsultant] = useState<any | null>(null);
  const [viewConsultant, setViewConsultant] = useState<any | null>(null);

  const [importingConsultants, setImportingConsultants] = useState(false);
  const consultantFileInputRef = React.useRef<HTMLInputElement>(null);

  const consultantField = customFields.find(f => f.label === '顾问');
  const consultantFieldName = consultantField ? consultantField.name : '顾问';

  const clientNameField = customFields.find(f => f.label === '客户侧姓名');
  const clientNameFieldName = clientNameField ? clientNameField.name : '客户侧姓名';

  // Helper
  const isConsultant = (emp: any) => {
    const ext = typeof emp.extInfo === 'string' ? JSON.parse(emp.extInfo) : (emp.extInfo || {});
    return ext?.[consultantFieldName] === '是';
  };
  const consultantEmployees = employees.filter(emp => isConsultant(emp) && emp.status === 'ACTIVE');

  const handleExportConsultants = () => {
    const exportData = consultantEmployees.map(emp => {
      const extInfo = typeof emp.extInfo === 'string' ? JSON.parse(emp.extInfo) : (emp.extInfo || {});
      return {
        '工号': emp.jobNumber || '',
        '姓名': emp.name || '',
        '身份证': emp.idCard || '',
        '性别': emp.gender === 'MALE' ? '男' : emp.gender === 'FEMALE' ? '女' : '',
        '入职时间': emp.hireDate ? new Date(emp.hireDate).toISOString().split('T')[0] : '',
        '试用期(月)': emp.probationMonths || 3,
        '合同类型': emp.contractType || '',
        '合同开始时间': emp.contractStartDate ? new Date(emp.contractStartDate).toISOString().split('T')[0] : '',
        '合同结束时间': emp.contractEndDate ? new Date(emp.contractEndDate).toISOString().split('T')[0] : '',
        '免考勤': emp.exemptAttendance ? '是' : '否',
        '部门': extInfo?.department || '',
        '岗位': extInfo?.position || '',
        '状态': emp.status === 'ACTIVE' ? '在职' : '离职',
        [consultantFieldName]: extInfo?.[consultantFieldName] || '',
        [clientNameFieldName]: extInfo?.[clientNameFieldName] || '',
        '合作类型': extInfo?.employeeType || ''
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, '顾问花名册');
    XLSX.writeFile(workbook, `顾问花名册_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const handleImportConsultants = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImportingConsultants(true);
    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const data = evt.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const jsonData: any[] = XLSX.utils.sheet_to_json(sheet);

        const payload = jsonData.map(row => ({
          jobNumber: row['工号'],
          name: row['姓名'],
          idCard: row['身份证'],
          gender: row['性别'] === '男' ? 'MALE' : row['性别'] === '女' ? 'FEMALE' : undefined,
          hireDate: row['入职时间'] ? new Date(row['入职时间']).toISOString() : undefined,
          probationMonths: row['试用期(月)'],
          contractType: row['合同类型'],
          contractStartDate: row['合同开始时间'] ? new Date(row['合同开始时间']).toISOString() : undefined,
          contractEndDate: row['合同结束时间'] ? new Date(row['合同结束时间']).toISOString() : undefined,
          exemptAttendance: row['免考勤'] === '是',
          status: row['状态'] === '离职' ? 'RESIGNED' : 'ACTIVE',
          extInfo: {
            department: row['部门'],
            position: row['岗位'],
            [consultantFieldName]: row[consultantFieldName] || '是',
            [clientNameFieldName]: row[clientNameFieldName],
            employeeType: row['合作类型'] || '外部合作'
          }
        }));

        const res = await importEmployeesBatch(payload, true);
        if (res?.success) {
          alert(`导入成功！成功处理了 ${res.count} 条记录。`);
          window.location.reload();
        } else {
          alert(`导入失败: ${res?.message}`);
        }
      } catch (error: any) {
        alert(`解析文件失败: ${error.message}`);
      } finally {
        setImportingConsultants(false);
        if (consultantFileInputRef.current) consultantFileInputRef.current.value = '';
      }
    };
    reader.readAsBinaryString(file);
  };

  // Multi-dimensional Report Aggregation
  const aggregatedReport = React.useMemo(() => {
    if (reportDimension === 'consultant') {
      // Group by employeeId
      const map = new Map<string, any>();
      report.forEach(r => {
        if (!map.has(r.employeeId)) {
          // deep copy months to avoid mutation
          map.set(r.employeeId, {
            ...r,
            mappingId: r.employeeId, // use employeeId as key
            projectId: '-',
            months: r.months.map(m => ({ ...m }))
          });
        } else {
          const existing = map.get(r.employeeId);
          existing.totalActualDays += r.totalActualDays;
          r.months.forEach((m, idx) => {
            existing.months[idx].planned += m.planned;
            existing.months[idx].actual += m.actual;
            existing.months[idx].finalDays += m.finalDays;
          });
          existing.attainmentRate = existing.baselineDays > 0 ? (existing.totalActualDays / existing.baselineDays) * 100 : 0;
        }
      });
      return Array.from(map.values());
    } else {
      // Do not merge, but sort by projectId to show each consultant's planned/actual
      return [...report].sort((a, b) => a.projectId.localeCompare(b.projectId));
    }
  }, [report, reportDimension]);

  // Export to CSV
  const exportToCSV = () => {
    let headers = [];
    if (reportDimension === 'consultant') {
      headers = ['顾问代称', '目标基线', '全年实际出勤', '达标率', ...Array.from({length: 12}, (_, i) => `${i+1}月`), '年度偏差'];
    } else {
      headers = ['项目 ID & 顾问', '预计投入人天', '实际投入人天', ...Array.from({length: 12}, (_, i) => `${i+1}月`), '年度偏差'];
    }
    
    const rows = aggregatedReport.map(r => {
      const totalPlanned = r.months.reduce((sum: number, m: any) => sum + m.planned, 0);
      const deviation = r.totalActualDays - totalPlanned;
      const monthVals = r.months.map((m: any) => m.finalDays);
      
      if (reportDimension === 'consultant') {
        return [r.consultantName, r.baselineDays, r.totalActualDays, `${r.attainmentRate.toFixed(1)}%`, ...monthVals, deviation].join(',');
      } else {
        const name = `${r.projectId} - ${r.consultantName}`;
        return [name, totalPlanned, r.totalActualDays, ...monthVals, deviation].join(',');
      }
    });
    
    const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `PMO_${reportDimension === 'consultant' ? '顾问' : '项目'}维度出勤汇总_${year}年.csv`;
    link.click();
  };

  useEffect(() => {
    let isMounted = true;
    const fetchAllData = async () => {
      setLoading(true);
      const repRes = await getPMOEfficiencyReport(year, projectIdFilter || undefined);
      if (!isMounted) return;
      if (repRes.success && repRes.data) {
        setReport(repRes.data as any[]);
      }
      setLoading(false);
    };
    fetchAllData();
    return () => { isMounted = false; };
  }, [year, projectIdFilter]);

  useEffect(() => {
    let isMounted = true;
    const fetchEntryRows = async () => {
      if (!entryProjectId) {
        setEntryRows([]);
        return;
      }
      setLoadingEntry(true);
      const res = await getProjectMonthlyData(entryMonth, entryProjectId);
      if (!isMounted) return;
      if (res.success && res.data) {
        setEntryRows(res.data as MonthlyDataRow[]);
      }
      setLoadingEntry(false);
    };
    fetchEntryRows();
    return () => { isMounted = false; };
  }, [entryProjectId, entryMonth]);

  // Save Mapping
  const handleSaveMapping = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectId || !newEmployeeId || !newConsultantName) return;
    setSavingMapping(true);
    setMsg(null);
    const res = await saveProjectConsultantMapping(newProjectId, newEmployeeId, newConsultantName);
    if (res.success) {
      setMsg({ type: 'success', text: '已成功建立【项目 🔗 顾问代称】映射关联关系！' });
      // Fetch updated mappings
      window.location.reload();
    } else {
      setMsg({ type: 'error', text: res.message || '建立映射失败' });
    }
    setSavingMapping(false);
  };

  // Delete Mapping
  const handleDeleteMapping = async (id: string) => {
    if (!confirm('确认删除此项目顾问映射关系？')) return;
    const res = await deleteProjectConsultantMapping(id);
    if (res.success) {
      setMsg({ type: 'success', text: '关联关系已删除。' });
      window.location.reload();
    } else {
      setMsg({ type: 'error', text: res.message || '删除失败' });
    }
  };

  // Save Baseline
  const handleSaveBaseline = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!baselineEmpId || !baselineDaysVal) return;
    setSavingBaseline(true);
    setMsg(null);
    const res = await saveConsultantBaseline(baselineEmpId, year, baselineDaysVal);
    if (res.success) {
      setMsg({ type: 'success', text: '顾问年度人天基线维护成功！' });
      window.location.reload();
    } else {
      setMsg({ type: 'error', text: res.message || '保存基线失败' });
    }
    setSavingBaseline(false);
  };

  // Handle cell inputs inside PMO Entry
  const handleRowChange = (index: number, field: 'plannedDays' | 'actualDays', val: string) => {
    const updated = [...entryRows];
    updated[index] = {
      ...updated[index],
      [field]: parseFloat(val) || 0
    };
    setEntryRows(updated);
  };

  // Save PMO input days
  const handleSaveEntryData = async () => {
    setSavingEntry(true);
    setMsg(null);
    try {
      for (const row of entryRows) {
        await saveProjectMonthlyData(
          row.projectId,
          row.employeeId,
          entryMonth,
          row.plannedDays,
          row.actualDays,
          row.dailyLogs
        );
      }
      setMsg({ type: 'success', text: `成功更新并保存项目【${entryProjectId}】在 ${entryMonth} 的人天计划与出勤录入数据！` });
      
      // refresh report manually
      const repRes = await getPMOEfficiencyReport(year, projectIdFilter || undefined);
      if (repRes.success && repRes.data) {
        setReport(repRes.data as any[]);
      }
    } catch (error: any) {
      setMsg({ type: 'error', text: error.message });
    }
    setSavingEntry(false);
  };

  // Helper to generate days in a month
  const getDaysInMonth = (monthStr: string) => {
    if (!monthStr) return 30;
    const [y, m] = monthStr.split('-').map(Number);
    return new Date(y, m, 0).getDate();
  };

  const handleDailyChange = (dateKey: string, val: string) => {
    if (selectedDailyIndex === null) return;
    const numVal = parseFloat(val) || 0;
    
    const updated = [...entryRows];
    const row = updated[selectedDailyIndex];
    const logs = { ...(row.dailyLogs || {}) };
    logs[dateKey] = numVal;
    
    // Recalculate total actualDays
    const total = Object.values(logs).reduce((sum, curr) => sum + curr, 0);
    
    updated[selectedDailyIndex] = {
      ...row,
      dailyLogs: logs,
      actualDays: total
    };
    
    setEntryRows(updated);
  };

  // Heatmap Saturation Styling Helper
  const getHeatmapColor = (days: number) => {
    if (days === 0) {
      return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    } else if (days >= 1 && days <= 5) {
      return 'bg-orange-100 text-orange-800 border-orange-200';
    } else if (days >= 6 && days <= 10) {
      return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    } else {
      return 'bg-white text-rose-600 font-bold border-rose-300 shadow-sm';
    }
  };

  // Unique Project List for Dropdowns
  const getProjectsList = () => {
    const list = mappings.map(m => m.projectId);
    return Array.from(new Set(list));
  };

  const projects = getProjectsList();

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      
      {/* Premium Header */}
      <div className="bg-gradient-to-r from-indigo-700 via-purple-700 to-pink-700 rounded-2xl shadow-xl p-6 text-white flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">咨询顾问项目交付人效表 (PMO)</h1>
          <p className="text-indigo-100 text-sm mt-2 max-w-3xl">
            此模块面向项目管理办公室 (PMO) 与 HR 进行双重視野锁定。HR 管理顾问年度投入人天基线与项目代称映射，PMO 仅可对其关联授权的顾问进行月度计划（SOW）及真实现场出勤记录的填报，保障数据安全与防泄漏。
          </p>
        </div>
      </div>

      {/* Message Alerts */}
      {msg && (
        <div className={`p-4 rounded-xl shadow-sm border ${
          msg.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-rose-50 border-rose-200 text-rose-800'
        } transition-all duration-300`}>
          <div className="flex items-center space-x-2 font-medium">
            <span className="text-lg">{msg.type === 'success' ? '✓' : '✗'}</span>
            <span>{msg.text}</span>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex bg-gray-200/60 p-1.5 rounded-xl w-fit space-x-1 border border-gray-300/40">
        <button
          onClick={() => setActiveTab('report')}
          className={`px-5 py-2.5 rounded-lg text-sm font-semibold tracking-wide transition-all ${
            activeTab === 'report'
              ? 'bg-white text-indigo-700 shadow-md scale-[1.02]'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'
          }`}
        >
          📊 顾问饱和度热力图 & 人效汇总
        </button>
        <button
          onClick={() => setActiveTab('fill')}
          className={`px-5 py-2.5 rounded-lg text-sm font-semibold tracking-wide transition-all ${
            activeTab === 'fill'
              ? 'bg-white text-indigo-700 shadow-md scale-[1.02]'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'
          }`}
        >
          ✍️ PMO 现场出勤人天填报
        </button>
        <button
          onClick={() => {
            setActiveTab('hr-config');
            if (employees.length > 0 && !baselineEmpId) {
              setBaselineEmpId(employees[0].id);
              setNewEmployeeId(employees[0].id);
            }
          }}
          className={`px-5 py-2.5 rounded-lg text-sm font-semibold tracking-wide transition-all ${
            activeTab === 'hr-config'
              ? 'bg-white text-indigo-700 shadow-md scale-[1.02]'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'
          }`}
        >
          ⚙️ HR 项目授权及人天基线后台
        </button>
        <button
          onClick={() => setActiveTab('consultants')}
          className={`px-5 py-2.5 rounded-lg text-sm font-semibold tracking-wide transition-all ${
            activeTab === 'consultants'
              ? 'bg-white text-indigo-700 shadow-md scale-[1.02]'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'
          }`}
        >
          👨‍💼 顾问花名册
        </button>
      </div>

      {activeTab === 'report' ? (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-6">
          
          {/* Filters Bar */}
          <div className="flex flex-wrap items-center gap-6 pb-4 border-b">
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">查询基线年度</label>
              <select
                value={year}
                onChange={(e) => setYear(parseInt(e.target.value))}
                className="block w-32 rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50 font-bold"
              >
                <option value={2026}>2026 年</option>
                <option value={2027}>2027 年</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">聚合维度</label>
              <div className="flex bg-gray-100 p-1 rounded-lg border border-gray-200 w-fit">
                <button
                  onClick={() => setReportDimension('project')}
                  className={`px-3 py-1.5 rounded-md text-sm font-semibold transition-all ${
                    reportDimension === 'project'
                      ? 'bg-white text-indigo-700 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  项目维度
                </button>
                <button
                  onClick={() => setReportDimension('consultant')}
                  className={`px-3 py-1.5 rounded-md text-sm font-semibold transition-all ${
                    reportDimension === 'consultant'
                      ? 'bg-white text-indigo-700 shadow-sm'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  顾问维度
                </button>
              </div>
            </div>
            
            <div className="flex-1 flex justify-end gap-4 items-center">
              <button 
                onClick={exportToCSV}
                className="px-4 py-2 bg-indigo-50 text-indigo-700 font-bold text-sm rounded-lg hover:bg-indigo-100 transition border border-indigo-200 flex items-center"
              >
                <svg className="w-4 h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                导出 {reportDimension === 'project' ? '项目' : '顾问'} 出勤报表
              </button>
              
              <span className="inline-flex items-center text-xs text-gray-500 font-medium bg-gray-50 border rounded-lg p-2 gap-4">
                <span className="flex items-center"><span className="w-2.5 h-2.5 bg-yellow-100 rounded-sm mr-1 border border-yellow-300"></span>极闲 (0天)</span>
                <span className="flex items-center"><span className="w-2.5 h-2.5 bg-orange-100 rounded-sm mr-1 border border-orange-300"></span>不饱和 (1-5天)</span>
                <span className="flex items-center"><span className="w-2.5 h-2.5 bg-emerald-100 rounded-sm mr-1 border border-emerald-300"></span>饱和健康 (6-10天)</span>
                <span className="flex items-center"><span className="w-2.5 h-2.5 bg-white border border-rose-300 rounded-sm mr-1"></span>超负荷 (&gt;10天)</span>
              </span>
            </div>
          </div>

          {/* Saturation Heatmap Grid */}
          <div className="overflow-x-auto">
            {loading ? (
              <div className="text-center py-16 text-gray-500">重新加载数据中...</div>
            ) : aggregatedReport.length === 0 ? (
              <div className="text-center py-16 text-gray-400 text-sm">
                📭 暂无匹配的项目顾问报表数据，请前往 HR 授权页进行代称绑定并录入人天。
              </div>
            ) : (
              <table className="min-w-full divide-y divide-gray-200 border rounded-xl overflow-hidden">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-bold text-slate-500 tracking-wider">
                      {reportDimension === 'project' ? '项目 ID & 顾问' : '顾问代称'}
                    </th>
                    {reportDimension === 'consultant' ? (
                      <>
                        <th className="px-4 py-3 text-center text-xs font-bold text-slate-500 tracking-wider">年度目标基线</th>
                        <th className="px-4 py-3 text-center text-xs font-bold text-slate-500 tracking-wider">全年实际出勤</th>
                        <th className="px-4 py-3 text-center text-xs font-bold text-slate-500 tracking-wider">达标率</th>
                      </>
                    ) : (
                      <>
                        <th className="px-4 py-3 text-center text-xs font-bold text-slate-500 tracking-wider">预计投入人天</th>
                        <th className="px-4 py-3 text-center text-xs font-bold text-slate-500 tracking-wider">实际投入人天</th>
                      </>
                    )}
                    {Array.from({ length: 12 }, (_, i) => (
                      <th key={i} className="px-2 py-3 text-center text-xs font-bold text-slate-500 tracking-wider w-16">
                        {i + 1}月
                      </th>
                    ))}
                    <th className="px-4 py-3 text-center text-xs font-bold text-slate-500 tracking-wider">年度偏差</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200 text-sm">
                  {aggregatedReport.map((row) => {
                    const totalPlanned = row.months.reduce((sum: number, m: any) => sum + m.planned, 0);
                    const deviation = row.totalActualDays - totalPlanned;
                    
                    return (
                      <tr key={row.mappingId} className="hover:bg-slate-50/40 transition">
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="font-semibold text-slate-900">
                            {reportDimension === 'project' ? row.projectId : row.consultantName}
                          </div>
                          {reportDimension === 'project' ? (
                            <div className="text-[10px] text-indigo-500 font-bold mt-0.5">{row.consultantName}</div>
                          ) : !projectIdFilter && (
                            <div className="text-[10px] text-gray-400 font-medium">真实: {row.realName} ({row.jobNumber})</div>
                          )}
                        </td>
                        {reportDimension === 'consultant' ? (
                          <>
                            <td className="px-4 py-3 whitespace-nowrap text-center font-bold font-mono text-slate-700">
                              {row.baselineDays}天
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-center font-bold font-mono text-indigo-700">
                              {row.totalActualDays}天
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-center">
                              <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                                row.attainmentRate >= 100 
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                                  : row.attainmentRate >= 60 
                                  ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                                  : 'bg-rose-50 text-rose-700 border border-rose-200'
                              }`}>
                                {row.attainmentRate.toFixed(1)}%
                              </span>
                            </td>
                          </>
                        ) : (
                          <>
                            <td className="px-4 py-3 whitespace-nowrap text-center font-bold font-mono text-slate-700">
                              {totalPlanned}天
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-center font-bold font-mono text-indigo-700">
                              {row.totalActualDays}天
                            </td>
                          </>
                        )}
                        {row.months.map((m: any, idx: number) => {
                          const cellColor = getHeatmapColor(m.finalDays);
                          const isOverload = m.finalDays > 10;
                          
                          let segLabel = '';
                          switch (m.segmentType) {
                            case 'PAST':
                              segLabel = '过去实际';
                              break;
                            case 'CURRENT':
                              segLabel = `当前MAX(计划:${m.planned}, 实际:${m.actual})`;
                              break;
                            case 'FUTURE':
                              segLabel = '未来计划预测';
                              break;
                          }

                          return (
                            <td 
                              key={idx} 
                              className={`p-1 text-center font-mono border ${cellColor} relative group cursor-help`}
                              title={`出勤值: ${m.finalDays}天 (${segLabel})`}
                            >
                              <div className="text-xs font-bold leading-tight">{m.finalDays}</div>
                              
                              {/* 三段值标记小圆点 */}
                              <span className={`absolute top-0.5 right-0.5 w-1 h-1 rounded-full ${
                                m.segmentType === 'PAST' ? 'bg-gray-400' :
                                m.segmentType === 'CURRENT' ? 'bg-indigo-500' : 'bg-emerald-400'
                              }`}></span>

                              {/* 超负荷预警阻断提示 */}
                              {isOverload && (
                                <div className="absolute inset-0 border-2 border-rose-400 flex items-center justify-center pointer-events-none">
                                  <span className="absolute -top-6 left-1/2 transform -translate-x-1/2 hidden group-hover:block bg-red-600 text-white text-[9px] font-semibold px-1 py-0.5 rounded shadow z-10 whitespace-nowrap">
                                    🚨 派单阻断
                                  </span>
                                </div>
                              )}
                            </td>
                          );
                        })}
                        <td className="px-4 py-3 whitespace-nowrap text-center">
                          <span className={`font-mono font-bold ${
                            deviation > 0 ? 'text-emerald-600' : 
                            deviation < 0 ? 'text-rose-500' : 'text-gray-400'
                          }`}>
                            {deviation > 0 ? '+' : ''}{deviation}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </div>
      ) : activeTab === 'fill' ? (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-6">
          <div className="border-b pb-4 flex justify-between items-center">
            <div>
              <h3 className="text-xl font-bold text-gray-800">✍️ PMO 现场人天计划与出勤录入</h3>
              <p className="text-xs text-gray-400 mt-1">
                PMO 前端录入时强制隔离名单，仅能展示并修改授权关联到该项目的顾问。
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">选择录入的目标项目</label>
              <select
                value={entryProjectId}
                onChange={(e) => setEntryProjectId(e.target.value)}
                className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-3 bg-gray-50 font-bold"
              >
                <option value="">-- 请选择要录入的项目 --</option>
                {projects.map(prj => (
                  <option key={prj} value={prj}>{prj}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">选择录入的目标月份</label>
              <input
                type="month"
                value={entryMonth}
                onChange={(e) => setEntryMonth(e.target.value)}
                className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-3 bg-gray-50 font-mono"
              />
            </div>
          </div>

          {entryProjectId ? (
            <div className="space-y-4 pt-4">
              <div className="overflow-x-auto border rounded-xl">
                {loadingEntry ? (
                  <div className="text-center py-12 text-gray-500">正在检索项目下已授权顾问...</div>
                ) : entryRows.length === 0 ? (
                  <div className="text-center py-12 text-gray-400 text-sm">
                    ⚠️ 该项目下暂无已关联授权的顾问名单！请让 HR 在后台进行【项目ID 🔗 顾问代称】关联绑定。
                  </div>
                ) : (
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-slate-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">顾问代称 (已隔离敏感姓名)</th>
                        <th className="px-6 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">计划 SOW 出勤人天 (plannedDays)</th>
                        <th className="px-6 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">实际现场出勤人天 (actualDays)</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200 text-sm">
                      {entryRows.map((row, idx) => (
                        <tr key={row.mappingId} className="hover:bg-slate-50/40 transition">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="font-bold text-slate-800 text-base">{row.consultantName}</span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-2">
                              <input
                                type="number"
                                step="0.5"
                                min="0"
                                max="31"
                                value={row.plannedDays}
                                onChange={(e) => handleRowChange(idx, 'plannedDays', e.target.value)}
                                className="block w-24 rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50 font-mono text-center font-bold text-slate-700"
                              />
                              <span className="text-xs text-gray-400">天</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-2">
                              <input
                                type="number"
                                step="0.5"
                                min="0"
                                max="31"
                                value={row.actualDays}
                                readOnly
                                className="block w-20 rounded-lg border-gray-300 shadow-sm text-sm border p-2 bg-gray-100 font-mono text-center font-bold text-indigo-700 cursor-not-allowed"
                              />
                              <span className="text-xs text-gray-400">天</span>
                              <button
                                onClick={() => {
                                  setSelectedDailyIndex(idx);
                                  setDailyModalOpen(true);
                                }}
                                className="ml-2 px-3 py-1.5 bg-indigo-50 text-indigo-700 rounded hover:bg-indigo-100 text-xs font-bold border border-indigo-200"
                              >
                                填写明细
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>

              {entryRows.length > 0 && (
                <div className="flex justify-end pt-2">
                  <button
                    onClick={handleSaveEntryData}
                    disabled={savingEntry}
                    className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white rounded-lg font-bold text-sm shadow-md transition disabled:opacity-50"
                  >
                    {savingEntry ? '正在保存...' : '确认保存数据并重新生成人效表'}
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-16 bg-slate-50 border-2 border-dashed border-gray-200 rounded-xl text-gray-400 text-sm">
              👈 请先在上方下拉菜单中选择一个录入的目标项目 ID。
            </div>
          )}
        </div>
      ) : activeTab === 'hr-config' ? (
        /* HR后台配置及年度投入人天基线管理 */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* 左侧：顾问项目代称映射绑定 */}
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-4">
            <h3 className="text-lg font-bold text-gray-800 border-b pb-2 flex items-center">
              <span>🔗</span>
              <span className="ml-2">项目 ID 🔗 顾问代称/英文名绑定</span>
            </h3>
            
            <form onSubmit={handleSaveMapping} className="space-y-4 pt-2">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">项目编号 (projectId)</label>
                  <input
                    type="text"
                    required
                    placeholder="如: PRJ-ALPHA"
                    value={newProjectId}
                    onChange={(e) => setNewProjectId(e.target.value)}
                    className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50 font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">指定顾问代称/英文名</label>
                  <input
                    type="text"
                    required
                    placeholder="如: John / Consultant-A"
                    value={newConsultantName}
                    onChange={(e) => setNewConsultantName(e.target.value)}
                    className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">选择真实在职员工账户</label>
                <select
                  required
                  value={newEmployeeId}
                  onChange={(e) => setNewEmployeeId(e.target.value)}
                  className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50 font-medium"
                >
                  <option value="">-- 请选择员工 --</option>
                  {consultantEmployees.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.jobNumber})
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                disabled={savingMapping}
                className="w-full px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-sm shadow transition disabled:opacity-50"
              >
                {savingMapping ? '保存中...' : '建立授权关联关系'}
              </button>
            </form>

            <div className="pt-4 border-t">
              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">已生效的项目授权映射</h4>
              <div className="max-h-[250px] overflow-y-auto border rounded-xl divide-y text-xs">
                {mappings.length === 0 ? (
                  <div className="text-center py-8 text-gray-400">暂无项目映射数据。</div>
                ) : (
                  mappings.map(map => (
                    <div key={map.id} className="p-3 hover:bg-slate-50 flex justify-between items-center transition">
                      <div>
                        <span className="font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded mr-2">{map.projectId}</span>
                        <span className="font-bold text-slate-800">{map.consultantName}</span>
                        <span className="text-gray-400 ml-2">(真实: {map.employee.name})</span>
                      </div>
                      <button
                        onClick={() => handleDeleteMapping(map.id)}
                        className="text-red-500 hover:text-red-700 font-bold"
                      >
                        删除
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* 右侧：年度目标出勤人天基线填报 */}
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-4">
            <h3 className="text-lg font-bold text-gray-800 border-b pb-2 flex items-center">
              <span>🎯</span>
              <span className="ml-2">纯人工年度投入人天基线维护</span>
            </h3>
            
            <form onSubmit={handleSaveBaseline} className="space-y-4 pt-2">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">当前基线年份</label>
                  <select
                    value={year}
                    onChange={(e) => setYear(parseInt(e.target.value))}
                    className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50 font-bold"
                  >
                    <option value={2026}>2026 年</option>
                    <option value={2027}>2027 年</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">年度目标人天基线 (分母)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    max="365"
                    value={baselineDaysVal}
                    onChange={(e) => setBaselineDaysVal(parseInt(e.target.value) || 120)}
                    className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50 font-mono text-center font-bold text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">选择在职顾问账户</label>
                <select
                  required
                  value={baselineEmpId}
                  onChange={(e) => setBaselineEmpId(e.target.value)}
                  className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50 font-medium"
                >
                  <option value="">-- 请选择员工 --</option>
                  {consultantEmployees.map(emp => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.jobNumber})
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                disabled={savingBaseline}
                className="w-full px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-sm shadow transition disabled:opacity-50"
              >
                {savingBaseline ? '保存中...' : `保存该年度出勤基线 (${year}年)`}
              </button>
            </form>

            <div className="pt-4 border-t">
              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">各顾问 {year} 年度基线列表</h4>
              <div className="max-h-[250px] overflow-y-auto border rounded-xl divide-y text-xs">
                {baselines.filter(bl => consultantEmployees.some(emp => emp.id === bl.employeeId)).length === 0 ? (
                  <div className="text-center py-8 text-gray-400">暂无该年度基线数据。</div>
                ) : (
                  baselines.filter(bl => consultantEmployees.some(emp => emp.id === bl.employeeId)).map(bl => (
                    <div key={bl.employeeId} className="p-3 hover:bg-slate-50 flex justify-between items-center transition">
                      <div>
                        <span className="font-bold text-slate-800">{bl.name}</span>
                        <span className="text-gray-400 ml-2 font-mono">({bl.jobNumber})</span>
                      </div>
                      <span className="font-bold text-slate-700 bg-gray-100 px-2 py-1 rounded">
                        基线: {bl.baselineDays} 天
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

        </div>
      ) : activeTab === 'consultants' ? (
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-6">
          <div className="flex justify-between items-center border-b pb-4">
            <div>
              <h3 className="text-xl font-bold text-gray-800">👨‍💼 顾问老师花名册 (单独管理)</h3>
              <p className="text-xs text-gray-400 mt-1">
                独立维护的顾问花名册，包含项目专属的在职顾问。与普通员工名单中“顾问=是”的混排。
              </p>
            </div>
            <div className="flex space-x-3">
              <button 
                onClick={handleExportConsultants}
                className="px-4 py-2 border border-gray-300 text-gray-700 bg-white hover:bg-gray-50 rounded-lg transition font-bold text-sm shadow"
              >
                导出顾问表
              </button>
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                ref={consultantFileInputRef}
                className="hidden"
                onChange={handleImportConsultants}
              />
              <button 
                onClick={() => consultantFileInputRef.current?.click()}
                disabled={importingConsultants}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition font-bold text-sm shadow disabled:bg-gray-400"
              >
                {importingConsultants ? '导入中...' : '导入顾问表'}
              </button>
              <button 
                onClick={() => setIsCreateOpen(true)}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition font-bold text-sm shadow"
              >
                + 新增顾问
              </button>
            </div>
          </div>

          <div className="overflow-x-auto border rounded-xl">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">姓名</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">性别</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">客户侧姓名</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider">操作</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200 text-sm">
                {consultantEmployees.length > 0 ? (
                  consultantEmployees.map((emp: any) => {
                    const extInfo = typeof emp.extInfo === 'string' ? JSON.parse(emp.extInfo) : (emp.extInfo || {});
                    return (
                      <tr key={emp.id} className="hover:bg-slate-50 transition">
                        <td className="px-6 py-4 whitespace-nowrap font-bold text-gray-900">
                          {emp.name}
                          {extInfo?.employeeType === '外部合作' ? (
                            <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-800">
                              外部合作
                            </span>
                          ) : (
                            <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                              内部员工
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-gray-500">{emp.gender === 'MALE' ? '男' : emp.gender === 'FEMALE' ? '女' : '未知'}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-gray-500">{extInfo?.[clientNameFieldName] || '-'}</td>
                        <td className="px-6 py-4 whitespace-nowrap font-medium space-x-3">
                          <button 
                            onClick={() => setViewConsultant(emp)}
                            className="text-emerald-600 hover:text-emerald-900"
                          >
                            查看
                          </button>
                          <button 
                            onClick={() => setEditConsultant(emp)}
                            className="text-indigo-600 hover:text-indigo-900"
                          >
                            编辑
                          </button>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={4} className="px-6 py-8 text-center text-gray-400">
                      当前暂无在职的顾问老师数据。
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* 弹窗1：新增顾问 */}
          {isCreateOpen && (
            <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
              <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setIsCreateOpen(false)}></div>
                <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
                <div className="relative inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full">
                  <div className="bg-white px-6 pt-5 pb-4 sm:p-8 sm:pb-6">
                    <h3 className="text-lg leading-6 font-bold text-gray-900 mb-6 border-b pb-3">
                      编辑顾问档案：{editConsultant.name}
                    </h3>
                    <ConsultantForm 
                      customFields={customFields} 
                      initialEmployee={editConsultant} 
                      onSuccess={() => {
                        setEditConsultant(null);
                        window.location.reload();
                      }} 
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 弹窗3：查看顾问详情 */}
          {viewConsultant && (
            <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
              <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setViewConsultant(null)}></div>
                <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
                <div className="relative inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-3xl sm:w-full">
                  <div className="bg-white px-6 pt-5 pb-4 sm:p-8 sm:pb-6">
                    <div className="flex justify-between items-center border-b pb-4 mb-6">
                      <h3 className="text-xl font-bold text-gray-900 flex items-center">
                        <span className="bg-emerald-100 text-emerald-800 p-2 rounded-lg mr-3">👨‍💼</span>
                        顾问详情：{viewConsultant.name}
                      </h3>
                      <button onClick={() => setViewConsultant(null)} className="text-gray-400 hover:text-gray-500">
                        <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                      </button>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-x-8 gap-y-6">
                      <div className="col-span-2 sm:col-span-1">
                        <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">基本信息</h4>
                        <dl className="space-y-3 text-sm">
                          <div className="flex justify-between border-b pb-1"><dt className="text-gray-500">姓名:</dt><dd className="font-medium text-gray-900">{viewConsultant.name}</dd></div>
                          <div className="flex justify-between border-b pb-1"><dt className="text-gray-500">性别:</dt><dd className="font-medium text-gray-900">{viewConsultant.gender === 'MALE' ? '男' : viewConsultant.gender === 'FEMALE' ? '女' : '未知'}</dd></div>
                          <div className="flex justify-between border-b pb-1"><dt className="text-gray-500">身份证号:</dt><dd className="font-medium text-gray-900">{viewConsultant.idCard}</dd></div>
                          <div className="flex justify-between border-b pb-1"><dt className="text-gray-500">联系电话:</dt><dd className="font-medium text-gray-900">{(typeof viewConsultant.extInfo === 'string' ? JSON.parse(viewConsultant.extInfo) : (viewConsultant.extInfo || {}))?.phone || '-'}</dd></div>
                        </dl>
                      </div>
                      
                      <div className="col-span-2 sm:col-span-1">
                        <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">业务与合作</h4>
                        <dl className="space-y-3 text-sm">
                          <div className="flex justify-between border-b pb-1"><dt className="text-gray-500">客户侧姓名:</dt><dd className="font-medium text-gray-900">{(typeof viewConsultant.extInfo === 'string' ? JSON.parse(viewConsultant.extInfo) : (viewConsultant.extInfo || {}))?.[clientNameFieldName] || '-'}</dd></div>
                          <div className="flex justify-between border-b pb-1"><dt className="text-gray-500">合作方式:</dt><dd className="font-medium text-gray-900">{(typeof viewConsultant.extInfo === 'string' ? JSON.parse(viewConsultant.extInfo) : (viewConsultant.extInfo || {}))?.['合作方式'] || '-'}</dd></div>
                          <div className="flex justify-between border-b pb-1"><dt className="text-gray-500">人员类型:</dt><dd className="font-medium text-gray-900">{(typeof viewConsultant.extInfo === 'string' ? JSON.parse(viewConsultant.extInfo) : (viewConsultant.extInfo || {}))?.employeeType || '-'}</dd></div>
                        </dl>
                      </div>

                      <div className="col-span-2">
                        <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">专项履历</h4>
                        <div className="bg-gray-50 p-4 rounded-lg space-y-4 text-sm border border-gray-100">
                          <div>
                            <span className="font-bold text-gray-700 block mb-1">擅长领域:</span>
                            <p className="text-gray-600">{(typeof viewConsultant.extInfo === 'string' ? JSON.parse(viewConsultant.extInfo) : (viewConsultant.extInfo || {}))?.['擅长领域'] || '未填写'}</p>
                          </div>
                          <div>
                            <span className="font-bold text-gray-700 block mb-1">历史背景:</span>
                            <p className="text-gray-600">{(typeof viewConsultant.extInfo === 'string' ? JSON.parse(viewConsultant.extInfo) : (viewConsultant.extInfo || {}))?.['历史背景'] || '未填写'}</p>
                          </div>
                          <div>
                            <span className="font-bold text-gray-700 block mb-1">备注:</span>
                            <p className="text-gray-600">{(typeof viewConsultant.extInfo === 'string' ? JSON.parse(viewConsultant.extInfo) : (viewConsultant.extInfo || {}))?.['备注'] || '无'}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-8 flex justify-end">
                      <button 
                        onClick={() => setViewConsultant(null)}
                        className="bg-white border border-gray-300 rounded-md shadow-sm px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none"
                      >
                        关闭
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      ) : null}

      {/* Daily Grid Modal */}
      {dailyModalOpen && selectedDailyIndex !== null && entryRows[selectedDailyIndex] && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl flex flex-col max-h-[90vh]">
            <div className="p-6 border-b flex justify-between items-center bg-gray-50 rounded-t-2xl">
              <div>
                <h3 className="text-xl font-bold text-gray-800">
                  每日出勤录入：{entryRows[selectedDailyIndex].realName} 
                  <span className="ml-2 text-sm text-gray-500">({entryMonth})</span>
                </h3>
                <p className="text-xs text-gray-500 mt-1">请在每天格子中输入对应的出勤天数（0、0.5 或 1）</p>
              </div>
              <button 
                onClick={() => setDailyModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 transition"
              >
                关闭
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto">
              <div className="grid grid-cols-7 gap-3">
                {['一', '二', '三', '四', '五', '六', '日'].map(d => (
                  <div key={d} className="text-center text-xs font-bold text-gray-400 pb-2">{d}</div>
                ))}
                
                {(() => {
                  const [y, m] = entryMonth.split('-').map(Number);
                  const firstDay = new Date(y, m - 1, 1).getDay(); // 0 is Sunday
                  const daysInMonth = getDaysInMonth(entryMonth);
                  
                  // offset for Monday start
                  const offset = firstDay === 0 ? 6 : firstDay - 1;
                  
                  const cells = [];
                  for (let i = 0; i < offset; i++) {
                    cells.push(<div key={`empty-${i}`} className="p-2 border border-transparent rounded-lg bg-gray-50/50"></div>);
                  }
                  
                  for (let d = 1; d <= daysInMonth; d++) {
                    const dateObj = new Date(y, m - 1, d);
                    const isWeekend = dateObj.getDay() === 0 || dateObj.getDay() === 6;
                    const dateKey = `${entryMonth}-${String(d).padStart(2, '0')}`;
                    const row = entryRows[selectedDailyIndex];
                    const val = row.dailyLogs ? row.dailyLogs[dateKey] : undefined;
                    
                    cells.push(
                      <div key={d} className={`p-2 border rounded-lg ${isWeekend ? 'bg-orange-50/50 border-orange-100' : 'bg-white border-gray-200'}`}>
                        <div className={`text-xs mb-1 font-mono text-center ${isWeekend ? 'text-orange-400' : 'text-gray-500'}`}>{d}号</div>
                        <input
                          type="number"
                          step="0.5"
                          min="0"
                          max="1"
                          value={val !== undefined ? val : ''}
                          onChange={(e) => handleDailyChange(dateKey, e.target.value)}
                          placeholder="0"
                          className="w-full text-center p-1.5 text-sm font-bold text-indigo-700 bg-transparent border-b border-gray-300 focus:border-indigo-500 focus:outline-none transition-colors"
                        />
                      </div>
                    );
                  }
                  return cells;
                })()}
              </div>
            </div>
            
            <div className="p-6 border-t bg-gray-50 rounded-b-2xl flex justify-between items-center">
              <div className="text-sm text-gray-600 font-bold">
                当前合计：<span className="text-xl text-indigo-600 ml-1">{entryRows[selectedDailyIndex].actualDays}</span> 天
              </div>
              <button
                onClick={() => setDailyModalOpen(false)}
                className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold text-sm transition shadow"
              >
                确定保存明细并返回
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
