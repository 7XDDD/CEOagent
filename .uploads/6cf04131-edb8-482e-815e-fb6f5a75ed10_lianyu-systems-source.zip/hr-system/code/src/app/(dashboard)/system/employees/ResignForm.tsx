'use client';

import { useState } from 'react';
import { resignEmployee } from '@/actions/employee';
import { useRouter } from 'next/navigation';

interface ResignFormProps {
  employeeId: string;
  employeeName: string;
  onSuccess: () => void;
}

export default function ResignForm({ employeeId, employeeName, onSuccess }: ResignFormProps) {
  const router = useRouter();
  const [formData, setFormData] = useState({
    resignedAt: '',
    resignationType: '主动离职',
    resignationReason: '',
    hasCompensation: '无',
    submittedFiles: [] as string[],
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleCheckboxChange = (fileName: string) => {
    setFormData(prev => {
      const files = prev.submittedFiles.includes(fileName)
        ? prev.submittedFiles.filter(f => f !== fileName)
        : [...prev.submittedFiles, fileName];
      return { ...prev, submittedFiles: files };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const result = await resignEmployee(employeeId, formData);
    if (result.success) {
      onSuccess();
      router.refresh();
    } else {
      setError((result as any).message || '办理离职失败');
    }
    setLoading(false);
  };

  const fileOptions = ['离职申请表', '工作交接表', '离职证明'];

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && <div className="text-red-500 text-sm p-3 bg-red-50 border border-red-200 rounded">{error}</div>}
      
      <div className="bg-gray-50 p-3 rounded mb-4">
        <span className="text-gray-500 text-sm">正在办理离职员工：</span>
        <span className="text-gray-900 font-semibold text-sm">{employeeName}</span>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">离职时间 <span className="text-red-500">*</span></label>
          <input 
            type="date" required 
            value={formData.resignedAt}
            onChange={e => setFormData({ ...formData, resignedAt: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">离职类型 <span className="text-red-500">*</span></label>
          <select 
            value={formData.resignationType}
            onChange={e => setFormData({ ...formData, resignationType: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
          >
            <option value="主动离职">主动离职</option>
            <option value="被动离职">被动离职</option>
            <option value="退休">退休</option>
            <option value="其他">其他</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700">离职原因 <span className="text-red-500">*</span></label>
        <textarea 
          required rows={3}
          value={formData.resignationReason}
          onChange={e => setFormData({ ...formData, resignationReason: e.target.value })}
          placeholder="请输入详细的离职原因说明..."
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">有无经济补偿</label>
          <select 
            value={formData.hasCompensation}
            onChange={e => setFormData({ ...formData, hasCompensation: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
          >
            <option value="无">无</option>
            <option value="有">有</option>
          </select>
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">离职资料提交情况</label>
        <div className="flex flex-wrap gap-4">
          {fileOptions.map(file => (
            <label key={file} className="flex items-center space-x-2 text-sm text-gray-700 cursor-pointer">
              <input 
                type="checkbox"
                checked={formData.submittedFiles.includes(file)}
                onChange={() => handleCheckboxChange(file)}
                className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
              />
              <span>{file}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="mt-6 flex justify-end pt-4 border-t border-gray-200">
        <button 
          type="button" 
          onClick={onSuccess}
          className="mr-3 px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none"
        >
          取消
        </button>
        <button 
          type="submit" 
          disabled={loading}
          className="px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none disabled:opacity-50"
        >
          {loading ? '提交中...' : '办理离职'}
        </button>
      </div>
    </form>
  );
}
