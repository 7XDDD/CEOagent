import { prisma } from '@/lib/prisma';
import Link from 'next/link';

export const metadata = {
  title: '调休假1:1工资折算报表 - 智能化HR系统',
};

export default async function CompensationReportPage() {
  // 获取所有离职员工
  const resignedEmployees = await prisma.employee.findMany({
    where: { status: 'RESIGNED' },
    orderBy: { updatedAt: 'desc' },
  });

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="flex items-center space-x-2 text-sm text-gray-500 mb-2">
        <Link href="/system/employees" className="hover:text-indigo-600">员工花名册</Link>
        <span>&gt;</span>
        <span className="text-gray-800 font-semibold">1:1工资折算报表</span>
      </div>

      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">离职调休1:1工资折算报表</h1>
          <p className="text-sm text-gray-500 mt-1">
            自动调取离职员工账本，清算未休完的调休额度，将其 1:1 输出为财务应发薪资明细。
          </p>
        </div>
        <button 
          className="px-4 py-2 border border-gray-300 text-gray-700 bg-white hover:bg-gray-50 rounded transition text-sm font-medium"
        >
          📥 导出给财务 (Excel)
        </button>
      </div>

      <div className="bg-white shadow rounded-lg overflow-hidden border border-gray-200">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">工号</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">姓名</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">离职时间</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">清算调休数</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">财务应发结算项</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">结算状态</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 text-sm">
            {resignedEmployees.length > 0 ? (
              resignedEmployees.map(emp => {
                const ext = typeof emp.extInfo === 'string' ? JSON.parse(emp.extInfo) : (emp.extInfo || {});
                return (
                  <tr key={emp.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap font-mono text-gray-500">{emp.jobNumber || '--'}</td>
                    <td className="px-6 py-4 whitespace-nowrap font-semibold text-gray-900">{emp.name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500">{ext?.resignedAt || '--'}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-900 font-semibold">{ext?.settledCompensatoryHours || 0} 小时</td>
                    <td className="px-6 py-4 whitespace-nowrap text-red-600 font-bold">
                      {ext?.settledCompensatoryHours && ext.settledCompensatoryHours > 0 
                        ? `补发 ${ext.settledCompensatoryHours} 小时工资` 
                        : '无补发额度'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded text-xs font-semibold bg-yellow-100 text-yellow-800">
                        待发款（已审批）
                      </span>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-8 text-center text-gray-400">
                  当前暂无已清算的离职员工折现流水。
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
