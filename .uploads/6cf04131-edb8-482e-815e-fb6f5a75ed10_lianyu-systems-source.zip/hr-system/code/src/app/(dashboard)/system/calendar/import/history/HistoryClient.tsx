'use client';

import React, { useState, useEffect } from 'react';
import { getImportedClockings, getImportedOvertimes, getImportedLeaves, getImportedTravels, getLeaveQuotasSummary, getLeaveQuotasDetail, updateLeaveQuota, addManualLeaveQuota, getImportedExemptions, addManualOvertime, addManualLeave, addManualTravel } from '@/actions/history';
import { syncOldOvertimesToQuota } from '@/actions/sync';
import { getEmployees } from '@/actions/employee';

export default function HistoryClient() {
  const [activeTab, setActiveTab] = useState<'clocking' | 'overtime' | 'leave' | 'travel' | 'quota' | 'exemption'>('clocking');
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [searchName, setSearchName] = useState('');
  const [searchDate, setSearchDate] = useState('');
  const [syncing, setSyncing] = useState(false);
  
  const [expandedEmpId, setExpandedEmpId] = useState<string | null>(null);
  const [expandedData, setExpandedData] = useState<any[]>([]);
  const [loadingDetail, setLoadingDetail] = useState(false);

  const [editQuotaModal, setEditQuotaModal] = useState<{ open: boolean, data: any }>({ open: false, data: null });
  const [addQuotaModal, setAddQuotaModal] = useState<{ open: boolean, employeeId: string, name: string, totalHours?: number, sourceDate?: string, expireAt?: string }>({ open: false, employeeId: '', name: '' });
  const [addOvertimeModal, setAddOvertimeModal] = useState<{ open: boolean, employeeId: string, name: string, startTime: string, endTime: string, grossDuration: number, netDuration: number, reason: string }>({ open: false, employeeId: '', name: '', startTime: '', endTime: '', grossDuration: 0, netDuration: 0, reason: '' });
  const [addLeaveModal, setAddLeaveModal] = useState<{ open: boolean, employeeId: string, name: string, leaveType: string, startTime: string, endTime: string, duration: number, reason: string }>({ open: false, employeeId: '', name: '', leaveType: '年假', startTime: '', endTime: '', duration: 0, reason: '' });
  const [addTravelModal, setAddTravelModal] = useState<{ open: boolean, employeeId: string, name: string, startTime: string, endTime: string, duration: number, departure: string, destination: string, reason: string }>({ open: false, employeeId: '', name: '', startTime: '', endTime: '', duration: 0, departure: '', destination: '', reason: '' });
  const [savingQuota, setSavingQuota] = useState(false);
  const [employees, setEmployees] = useState<any[]>([]);

  useEffect(() => {
    if (['quota', 'overtime', 'leave', 'travel'].includes(activeTab) && employees.length === 0) {
      getEmployees().then(res => {
        if (res?.success) setEmployees(res.data || []);
      });
    }
  }, [activeTab]);

  const handleSync = async () => {
    if (!window.confirm('确定要将历史遗留的有效加班数据同步到调休池吗？已经同步过的数据会自动跳过。')) return;
    setSyncing(true);
    const res = await syncOldOvertimesToQuota();
    setSyncing(false);
    if (res?.success) {
      alert(`同步完成！\n新增调休额度：${res.added} 条\n跳过（已存在或节假日）：${res.skipped} 条`);
    } else {
      alert(`同步失败: ${res?.message}`);
    }
  };

  const loadData = async (tab: string, p: number, name?: string, date?: string) => {
    setLoading(true);
    let res: any = null;
    if (tab === 'clocking') res = await getImportedClockings(p, 50, name, date);
    else if (tab === 'overtime') res = await getImportedOvertimes(p, 50, name, date);
    else if (tab === 'leave') res = await getImportedLeaves(p, 50, name, date);
    else if (tab === 'travel') res = await getImportedTravels(p, 50, name, date);
    else if (tab === 'quota') res = await getLeaveQuotasSummary(p, 50, name);
    else if (tab === 'exemption') res = await getImportedExemptions(p, 50, name, date);

    if (res?.success) {
      setData(res.data);
      setTotal(res.total);
    }
    setLoading(false);
    setExpandedEmpId(null);
  };

  const handleExpand = async (employeeId: string) => {
    if (expandedEmpId === employeeId) {
      setExpandedEmpId(null);
      return;
    }
    setExpandedEmpId(employeeId);
    setLoadingDetail(true);
    const res = await getLeaveQuotasDetail(employeeId);
    if (res?.success) {
      setExpandedData(res.data || []);
    }
    setLoadingDetail(false);
  };

  const handleEditQuota = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingQuota(true);
    const { id, totalHours, usedHours, expireAt } = editQuotaModal.data;
    const res = await updateLeaveQuota(id, { 
      totalHours: Number(totalHours), 
      usedHours: Number(usedHours), 
      expireAt: expireAt || null 
    });
    setSavingQuota(false);
    if (res?.success) {
      setEditQuotaModal({ open: false, data: null });
      if (expandedEmpId) handleExpand(expandedEmpId);
      loadData('quota', page, searchName, searchDate);
    } else {
      alert(`保存失败: ${res?.message}`);
    }
  };

  const handleAddQuota = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingQuota(true);
    const { employeeId, totalHours, sourceDate, expireAt } = addQuotaModal;
    const res = await addManualLeaveQuota(employeeId, {
      totalHours: Number(totalHours),
      sourceDate: sourceDate!,
      expireAt: expireAt || null
    });
    setSavingQuota(false);
    if (res?.success) {
      setAddQuotaModal({ open: false, employeeId: '', name: '' });
      loadData('quota', page, searchName, searchDate);
      if (expandedEmpId === employeeId) handleExpand(employeeId);
    } else {
      alert(`添加失败: ${res?.message}`);
    }
  };

  const handleAddOvertime = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingQuota(true);
    const { employeeId, ...rest } = addOvertimeModal;
    const res = await addManualOvertime(employeeId, rest);
    setSavingQuota(false);
    if (res?.success) {
      setAddOvertimeModal({ ...addOvertimeModal, open: false });
      loadData('overtime', page, searchName, searchDate);
    } else alert(`添加失败: ${res?.message}`);
  };

  const handleAddLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingQuota(true);
    const { employeeId, ...rest } = addLeaveModal;
    const res = await addManualLeave(employeeId, rest);
    setSavingQuota(false);
    if (res?.success) {
      setAddLeaveModal({ ...addLeaveModal, open: false });
      loadData('leave', page, searchName, searchDate);
    } else alert(`添加失败: ${res?.message}`);
  };

  const handleAddTravel = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingQuota(true);
    const { employeeId, ...rest } = addTravelModal;
    const res = await addManualTravel(employeeId, rest);
    setSavingQuota(false);
    if (res?.success) {
      setAddTravelModal({ ...addTravelModal, open: false });
      loadData('travel', page, searchName, searchDate);
    } else alert(`添加失败: ${res?.message}`);
  };

  useEffect(() => {
    loadData(activeTab, page, searchName, searchDate);
  }, [activeTab, page]);

  const handleSearch = () => {
    setPage(1);
    loadData(activeTab, 1, searchName, searchDate);
  };

  const handleClear = () => {
    setSearchName('');
    setSearchDate('');
    setPage(1);
    loadData(activeTab, 1, '', '');
  };

  const handleTabChange = (tab: any) => {
    setActiveTab(tab);
    setPage(1);
    setData([]);
  };

  const formatDateWithWeekday = (dateStr: string | Date) => {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    const weekdays = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
    const yyyy = date.getFullYear();
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    return `${yyyy}/${mm}/${dd} ${weekdays[date.getDay()]}`;
  };

  // Helper to render approval status with colors
  const renderStatus = (status: string | null) => {
    if (!status) return <span className="text-gray-400">-</span>;
    if (status.includes('通过') || status.includes('完成')) {
      return <span className="text-green-600 bg-green-50 px-2 py-0.5 rounded font-medium text-xs border border-green-200">{status}</span>;
    }
    return <span className="text-gray-600 bg-gray-50 px-2 py-0.5 rounded font-medium text-xs border border-gray-200">{status}</span>;
  };

  return (
    <div className="max-w-7xl mx-auto relative">
      {/* Frozen Header Area */}
      <div className="sticky top-0 z-30 bg-gray-50/95 backdrop-blur-md pt-6 pb-4 px-6 space-y-6 shadow-sm border-b border-gray-200">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">导入历史台账</h1>
            <p className="text-sm text-gray-500 mt-1">查看所有历史导入的底层原始表单单据数据。</p>
          </div>
          <a href="/system/calendar/import" className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 shadow-sm transition font-medium text-sm flex items-center">
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
            返回导入中心
          </a>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            {[
              { id: 'clocking', name: '原始上下班打卡', icon: '🕒' },
              { id: 'overtime', name: '加班审批', icon: '🔥' },
              { id: 'leave', name: '请假审批', icon: '🏖️' },
              { id: 'travel', name: '出差审批', icon: '✈️' },
              { id: 'quota', name: '历史调休池台账', icon: '🏦' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                className={`
                  whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center
                  ${activeTab === tab.id
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
                `}
              >
                <span className="mr-2 text-lg">{tab.icon}</span>
                {tab.name}
              </button>
            ))}
          </nav>
        </div>

        {/* Search Filters */}
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex space-x-4 items-center">
          <input 
            type="text"
            placeholder="输入姓名查询..."
            value={searchName}
            onChange={e => setSearchName(e.target.value)}
            className="w-64 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
          />
          <input 
            type="date"
            value={searchDate}
            onChange={e => setSearchDate(e.target.value)}
            className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
          />
          <button 
            onClick={handleSearch}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded transition text-sm font-medium"
          >
            查询
          </button>
          <button 
            onClick={handleClear}
            className="px-4 py-2 border border-gray-300 hover:bg-gray-50 text-gray-700 rounded transition text-sm font-medium"
          >
            清空
          </button>
          
          {['overtime', 'leave', 'travel', 'quota'].includes(activeTab) && (
            <div className="ml-auto pl-4 border-l border-gray-200 flex space-x-2">
              {activeTab === 'overtime' && (
                <button 
                  onClick={handleSync}
                  disabled={syncing}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded transition text-sm font-medium flex items-center disabled:opacity-50"
                >
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                  {syncing ? '同步中...' : '同步历史有效加班至调休池'}
                </button>
              )}
              <button 
                onClick={() => {
                  const today = new Date();
                  const dateStr = today.toISOString().split('T')[0] + 'T09:00';
                  if (activeTab === 'quota') {
                    const nextYear = new Date(today);
                    nextYear.setFullYear(today.getFullYear() + 1);
                    setAddQuotaModal({ open: true, employeeId: '', name: '', sourceDate: today.toISOString().split('T')[0], expireAt: nextYear.toISOString().split('T')[0] });
                  } else if (activeTab === 'overtime') {
                    setAddOvertimeModal({ ...addOvertimeModal, open: true, employeeId: '', startTime: dateStr, endTime: dateStr });
                  } else if (activeTab === 'leave') {
                    setAddLeaveModal({ ...addLeaveModal, open: true, employeeId: '', startTime: dateStr, endTime: dateStr });
                  } else if (activeTab === 'travel') {
                    setAddTravelModal({ ...addTravelModal, open: true, employeeId: '', startTime: dateStr, endTime: dateStr });
                  }
                }}
                className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded transition text-sm font-medium flex items-center"
              >
                + 手工新增{activeTab === 'quota' ? '额度' : '记录'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Data Table Area */}
      <div className="p-6">
        <div className="bg-white shadow rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto overflow-y-auto max-h-[calc(100vh-300px)] min-h-[400px] relative">
          {loading && data.length === 0 ? (
            <div className="flex justify-center items-center h-64 text-gray-400">加载中...</div>
          ) : (
            <table className="min-w-full divide-y divide-gray-200 text-sm text-left relative">
              <thead className="bg-gray-50 sticky top-0 z-10 ring-1 ring-gray-200 ring-inset">
                {activeTab === 'clocking' && (
                  <tr>
                    <th className="px-4 py-3 font-semibold text-gray-500">日期</th>
                    <th className="px-4 py-3 font-semibold text-gray-500">姓名 (工号)</th>
                    <th className="px-4 py-3 font-semibold text-gray-500">最早打卡</th>
                    <th className="px-4 py-3 font-semibold text-gray-500">最晚打卡</th>
                    <th className="px-4 py-3 font-semibold text-gray-500">考勤结果</th>
                  </tr>
                )}
                {activeTab === 'overtime' && (
                  <tr>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">审批编号</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">审批详情</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">提交时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">完成时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">申请人</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">申请人部门</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">申请人账号</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">加班类型</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">开始时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">结束时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">申请/有效时长</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">加班事由</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">风控状态</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">说明附件</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">当前审批</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">审批流程</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">备注</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">数据来源</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">登记时间</th>
                  </tr>
                )}
                {activeTab === 'leave' && (
                  <tr>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">审批编号</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">审批详情</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">提交时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">完成时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">申请人</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">申请人部门</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">申请人账号</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">请假类型</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">开始时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">结束时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">请假时长</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">请假事由</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">说明附件</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">当前审批</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">审批流程</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">备注</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">数据来源</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">登记时间</th>
                  </tr>
                )}
                {activeTab === 'travel' && (
                  <tr>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">审批编号</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">审批详情</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">提交时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">完成时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">申请人</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">申请人账号</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">申请人部门</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">出差事由</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">类型</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">出发地</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">目的地</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">开始时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">结束时间</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">出差时长</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">交通工具</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">附件</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">当前审批节点</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">审批记录</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">备注</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">数据来源</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">登记时间</th>
                  </tr>
                )}
                {activeTab === 'quota' && (
                  <tr>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">姓名</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">总调休时长 (h)</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">已调休时长 (h)</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">已过期时长 (h)</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">剩余调休时长 (h)</th>
                    <th className="px-4 py-4 font-semibold text-gray-500 whitespace-nowrap">操作</th>
                  </tr>
                )}
                {activeTab === 'exemption' && (
                  <tr>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 whitespace-nowrap">补卡/豁免日期</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 whitespace-nowrap">审批编号</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 whitespace-nowrap">员工信息</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 whitespace-nowrap">事由</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 whitespace-nowrap">审批状态</th>
                    <th className="px-4 py-3 text-left font-semibold text-gray-500 whitespace-nowrap">导入时间</th>
                  </tr>
                )}
              </thead>
              <tbody className="divide-y divide-gray-200">
                {data.map((item, idx) => (
                  <React.Fragment key={item.id || idx}>
                  <tr className="hover:bg-gray-50">
                    {activeTab === 'clocking' && (
                      <>
                        <td className="px-4 py-3">{formatDateWithWeekday(item.date)}</td>
                        <td className="px-4 py-3 font-medium">{item.name} ({item.jobNumber})</td>
                        <td className="px-4 py-3">{item.checkIn || '-'}</td>
                        <td className="px-4 py-3">{item.checkOut || '-'}</td>
                        <td className="px-4 py-3">{item.result || '-'}</td>
                      </>
                    )}
                    {activeTab === 'overtime' && (
                      <>
                        <td className="px-4 py-4 font-mono text-xs whitespace-nowrap">{item.approvalNumber}</td>
                        <td className="px-4 py-4 text-xs text-blue-600 cursor-pointer hover:underline whitespace-nowrap">{item.approvalDetails || '查看'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.applyTime ? new Date(item.applyTime).toLocaleString('zh-CN', { hour12: false }) : '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.finishTime ? new Date(item.finishTime).toLocaleString('zh-CN', { hour12: false }) : '-'}</td>
                        <td className="px-4 py-4 font-medium whitespace-nowrap">{item.name}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.department || '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.account || item.jobNumber || '-'}</td>
                        <td className="px-4 py-4 whitespace-nowrap"><span className="bg-orange-50 text-orange-700 px-2 py-1 rounded text-xs">{item.type || '-'}</span></td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{formatDateWithWeekday(item.startTime)} {new Date(item.startTime).toLocaleTimeString()}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{formatDateWithWeekday(item.endTime)} {new Date(item.endTime).toLocaleTimeString()}</td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          {item.grossDuration}h / <strong className={item.netDuration > 0 ? "text-green-600" : "text-red-500"}>{item.netDuration}h</strong>
                        </td>
                        <td className="px-4 py-4 text-xs text-gray-500 max-w-xs truncate" title={item.reason}>{item.reason || '-'}</td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          {item.status === 'PROCESSED' ? (
                            <span className="text-green-600 bg-green-50 px-2 py-0.5 rounded border border-green-200 text-xs">有效</span>
                          ) : (
                            <div className="flex flex-col">
                              <span className="text-red-500 font-medium bg-red-50 px-2 py-0.5 rounded border border-red-200 text-xs inline-block w-fit">失效</span>
                              {item.warning && <span className="text-xs text-red-400 mt-1 max-w-xs truncate" title={item.warning}>{item.warning}</span>}
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.attachment ? '有附件' : '-'}</td>
                        <td className="px-4 py-4 whitespace-nowrap">{renderStatus(item.currentApprovalNode || item.approvalStatus)}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 max-w-xs truncate" title={item.approvalProcess}>{item.approvalProcess || '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 max-w-xs truncate" title={item.remarks}>{item.remarks || '-'}</td>
                        <td className="px-4 py-4 whitespace-nowrap text-xs text-gray-500">{item.approvalStatus === '手工创建' ? '手工创建' : '系统导入'}</td>
                        <td className="px-4 py-4 text-xs text-gray-400 whitespace-nowrap">{new Date(item.createdAt).toLocaleString('zh-CN')}</td>
                      </>
                    )}
                    {activeTab === 'leave' && (
                      <>
                        <td className="px-4 py-4 font-mono text-xs whitespace-nowrap">{item.approvalNumber}</td>
                        <td className="px-4 py-4 text-xs text-blue-600 cursor-pointer hover:underline whitespace-nowrap">{item.approvalDetails || '查看'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.applyTime ? new Date(item.applyTime).toLocaleString('zh-CN', { hour12: false }) : '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.finishTime ? new Date(item.finishTime).toLocaleString('zh-CN', { hour12: false }) : '-'}</td>
                        <td className="px-4 py-4 font-medium whitespace-nowrap">{item.name}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.department || '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.account || item.jobNumber || '-'}</td>
                        <td className="px-4 py-4 whitespace-nowrap"><span className="bg-blue-50 text-blue-700 px-2 py-1 rounded text-xs">{item.leaveType}</span></td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{formatDateWithWeekday(item.startTime)}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{formatDateWithWeekday(item.endTime)}</td>
                        <td className="px-4 py-4 font-medium whitespace-nowrap text-center bg-gray-50">{item.duration}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 max-w-xs truncate" title={item.reason}>{item.reason || '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.attachment ? '有附件' : '-'}</td>
                        <td className="px-4 py-4 whitespace-nowrap">{renderStatus(item.currentApprovalNode || item.approvalStatus)}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 max-w-xs truncate" title={item.approvalProcess}>{item.approvalProcess || '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 max-w-xs truncate" title={item.remarks}>{item.remarks || '-'}</td>
                        <td className="px-4 py-4 whitespace-nowrap text-xs text-gray-500">{item.approvalStatus === '手工创建' ? '手工创建' : '系统导入'}</td>
                        <td className="px-4 py-4 text-xs text-gray-400 whitespace-nowrap">{new Date(item.createdAt).toLocaleString('zh-CN')}</td>
                      </>
                    )}
                    {activeTab === 'travel' && (
                      <>
                        <td className="px-4 py-4 font-mono text-xs whitespace-nowrap">{item.approvalNumber}</td>
                        <td className="px-4 py-4 text-xs text-blue-600 cursor-pointer hover:underline whitespace-nowrap">{item.approvalDetails || '查看'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.applyTime ? new Date(item.applyTime).toLocaleString('zh-CN', { hour12: false }) : '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.finishTime ? new Date(item.finishTime).toLocaleString('zh-CN', { hour12: false }) : '-'}</td>
                        <td className="px-4 py-4 font-medium whitespace-nowrap">{item.name}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.account || item.jobNumber || '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.department || '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 max-w-xs truncate" title={item.reason}>{item.reason || '-'}</td>
                        <td className="px-4 py-4 whitespace-nowrap"><span className="bg-indigo-50 text-indigo-700 px-2 py-1 rounded text-xs">{item.type || '-'}</span></td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.departure || '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.destination || '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{formatDateWithWeekday(item.startTime)}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{formatDateWithWeekday(item.endTime)}</td>
                        <td className="px-4 py-4 font-medium whitespace-nowrap text-center bg-gray-50">{item.duration}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.transportation || '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 whitespace-nowrap">{item.attachment ? '有附件' : '-'}</td>
                        <td className="px-4 py-4 whitespace-nowrap">{renderStatus(item.currentApprovalNode || item.approvalStatus)}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 max-w-xs truncate" title={item.approvalProcess}>{item.approvalProcess || '-'}</td>
                        <td className="px-4 py-4 text-xs text-gray-500 max-w-xs truncate" title={item.remarks}>{item.remarks || '-'}</td>
                        <td className="px-4 py-4 whitespace-nowrap text-xs text-gray-500">{item.approvalStatus === '手工创建' ? '手工创建' : '系统导入'}</td>
                        <td className="px-4 py-4 text-xs text-gray-400 whitespace-nowrap">{new Date(item.createdAt).toLocaleString('zh-CN')}</td>
                      </>
                    )}
                    {activeTab === 'quota' && (
                      <>
                        <td className="px-4 py-4 font-medium whitespace-nowrap">{item.name || '-'}</td>
                        <td className="px-4 py-4 font-medium whitespace-nowrap">{item.total.toFixed(1)}</td>
                        <td className="px-4 py-4 font-medium whitespace-nowrap text-orange-600">{item.used.toFixed(1)}</td>
                        <td className="px-4 py-4 font-medium whitespace-nowrap text-gray-400">{item.expired.toFixed(1)}</td>
                        <td className="px-4 py-4 font-bold text-green-600 whitespace-nowrap">{item.remaining.toFixed(1)}</td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          <button 
                            onClick={() => {
                              const today = new Date();
                              const nextYear = new Date(today);
                              nextYear.setFullYear(today.getFullYear() + 1);
                              setAddQuotaModal({ open: true, employeeId: item.employeeId, name: item.name, sourceDate: today.toISOString().split('T')[0], expireAt: nextYear.toISOString().split('T')[0] });
                            }}
                            className="text-green-600 hover:underline text-xs mr-4"
                          >
                            手工新增
                          </button>
                          <button 
                            onClick={() => handleExpand(item.employeeId)}
                            className="text-blue-600 hover:underline text-xs"
                          >
                            {expandedEmpId === item.employeeId ? '收起明细' : '查看明细'}
                          </button>
                        </td>
                      </>
                    )}
                    {activeTab === 'exemption' && (
                      <>
                        <td className="px-4 py-3">{formatDateWithWeekday(item.exemptionDate)}</td>
                        <td className="px-4 py-3 font-mono text-xs">{item.approvalNumber}</td>
                        <td className="px-4 py-3 font-medium">{item.name} ({item.jobNumber || '-'})</td>
                        <td className="px-4 py-3 text-gray-500 max-w-xs truncate" title={item.reason}>{item.reason || '-'}</td>
                        <td className="px-4 py-3">{renderStatus(item.approvalStatus)}</td>
                        <td className="px-4 py-3 text-xs text-gray-400">{new Date(item.importedAt).toLocaleString('zh-CN')}</td>
                      </>
                    )}
                  </tr>
                  
                  {activeTab === 'quota' && expandedEmpId === item.employeeId && (
                    <tr key={`expanded-${idx}`} className="bg-blue-50/50">
                      <td colSpan={6} className="px-6 py-4">
                        {loadingDetail ? (
                          <div className="text-center text-gray-500 text-sm py-4">加载中...</div>
                        ) : (
                          <div className="border border-blue-100 rounded bg-white shadow-sm overflow-hidden">
                            <table className="min-w-full divide-y divide-blue-100">
                              <thead className="bg-blue-50/80">
                                <tr>
                                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">加班日期</th>
                                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">加班时长(h)</th>
                                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">已调休时长(h)</th>
                                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">已调休日期</th>
                                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">到期时间</th>
                                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500">操作</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-blue-50">
                                {expandedData.length === 0 ? (
                                  <tr><td colSpan={5} className="px-4 py-4 text-center text-gray-400 text-xs">无明细记录</td></tr>
                                ) : expandedData.map(d => (
                                  <tr key={d.id} className="hover:bg-blue-50/30">
                                    <td className="px-4 py-2 text-xs">{formatDateWithWeekday(d.sourceDate)}</td>
                                    <td className="px-4 py-2 text-xs">{d.totalHours}</td>
                                    <td className="px-4 py-2 text-xs text-orange-600">{d.usedHours}</td>
                                    <td className="px-4 py-2 text-xs text-gray-500 max-w-xs truncate" title={d.usages?.map((u:any) => new Date(u.usedDate).toLocaleDateString()).join(', ')}>
                                      {d.usages && d.usages.length > 0 
                                        ? d.usages.map((u:any) => new Date(u.usedDate).toLocaleDateString()).join(', ')
                                        : '-'}
                                    </td>
                                    <td className="px-4 py-2 text-xs text-red-500">{d.expireAt ? formatDateWithWeekday(d.expireAt) : '永久有效'}</td>
                                    <td className="px-4 py-2 text-xs">
                                      <button 
                                        onClick={() => setEditQuotaModal({ open: true, data: { ...d, expireAt: d.expireAt ? new Date(d.expireAt).toISOString().split('T')[0] : '' } })}
                                        className="text-blue-600 hover:underline"
                                      >
                                        修改
                                      </button>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </td>
                    </tr>
                  )}
                  </React.Fragment>
                ))}
                {data.length === 0 && !loading && (
                  <tr>
                    <td colSpan={6} className="px-4 py-12 text-center text-gray-400">
                      暂无数据
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
        
        {/* Pagination */}
        <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 flex items-center justify-between sm:px-6">
          <div className="text-sm text-gray-700">
            共 <span className="font-medium">{total}</span> 条记录
          </div>
          <div className="flex space-x-2">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1 || loading}
              className="px-3 py-1 border border-gray-300 rounded-md bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
            >
              上一页
            </button>
            <span className="px-4 py-1 flex items-center text-sm font-medium text-gray-700">第 {page} 页</span>
            <button
              onClick={() => setPage(p => p + 1)}
              disabled={data.length < 50 || loading}
              className="px-3 py-1 border border-gray-300 rounded-md bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50"
            >
              下一页
            </button>
          </div>
        </div>
        </div>
      </div>
      
      {/* 弹窗：修改单笔明细 */}
      {editQuotaModal.open && editQuotaModal.data && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
            <h3 className="text-lg font-medium mb-4">修改调休明细</h3>
            <form onSubmit={handleEditQuota} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">总额度 (小时)</label>
                <input type="number" step="0.5" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={editQuotaModal.data.totalHours} onChange={e => setEditQuotaModal({ ...editQuotaModal, data: { ...editQuotaModal.data, totalHours: e.target.value } })} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">已使用 (小时)</label>
                <input type="number" step="0.5" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={editQuotaModal.data.usedHours} onChange={e => setEditQuotaModal({ ...editQuotaModal, data: { ...editQuotaModal.data, usedHours: e.target.value } })} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">过期时间 (留空代表永久有效)</label>
                <input type="date" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={editQuotaModal.data.expireAt} onChange={e => setEditQuotaModal({ ...editQuotaModal, data: { ...editQuotaModal.data, expireAt: e.target.value } })} />
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <button type="button" onClick={() => setEditQuotaModal({ open: false, data: null })} className="px-4 py-2 border border-gray-300 rounded text-sm text-gray-700 hover:bg-gray-50">取消</button>
                <button type="submit" disabled={savingQuota} className="px-4 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 disabled:opacity-50">
                  {savingQuota ? '保存中...' : '保存'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 弹窗：手工新增额度 */}
      {addQuotaModal.open && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
            <h3 className="text-lg font-medium mb-4">
              {addQuotaModal.name ? `为 ${addQuotaModal.name} 新增调休额度` : '手工新增调休额度'}
            </h3>
            <form onSubmit={handleAddQuota} className="space-y-4">
              {!addQuotaModal.name && (
                <div>
                  <label className="block text-sm font-medium text-gray-700">选择员工</label>
                  <select 
                    required 
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500 text-sm px-3 py-2 border" 
                    value={addQuotaModal.employeeId} 
                    onChange={e => setAddQuotaModal({ ...addQuotaModal, employeeId: e.target.value })}
                  >
                    <option value="">-- 请选择员工 --</option>
                    {employees.map(emp => (
                      <option key={emp.id} value={emp.id}>{emp.name} ({emp.jobNumber})</option>
                    ))}
                  </select>
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-gray-700">发放额度 (小时)</label>
                <input type="number" step="0.5" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addQuotaModal.totalHours || ''} onChange={e => setAddQuotaModal({ ...addQuotaModal, totalHours: Number(e.target.value) })} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">产生日期</label>
                <input type="date" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addQuotaModal.sourceDate} onChange={e => {
                  const newDate = e.target.value;
                  let nextYearStr = addQuotaModal.expireAt;
                  if (newDate) {
                    const d = new Date(newDate);
                    if (!isNaN(d.getTime())) {
                      d.setFullYear(d.getFullYear() + 1);
                      nextYearStr = d.toISOString().split('T')[0];
                    }
                  }
                  setAddQuotaModal({ ...addQuotaModal, sourceDate: newDate, expireAt: nextYearStr });
                }} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">过期时间 (留空代表永久有效)</label>
                <input type="date" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addQuotaModal.expireAt || ''} onChange={e => setAddQuotaModal({ ...addQuotaModal, expireAt: e.target.value })} />
              </div>
              <div className="flex justify-end space-x-3 pt-4">
                <button type="button" onClick={() => setAddQuotaModal({ open: false, employeeId: '', name: '' })} className="px-4 py-2 border border-gray-300 rounded text-sm text-gray-700 hover:bg-gray-50">取消</button>
                <button type="submit" disabled={savingQuota} className="px-4 py-2 bg-green-600 text-white rounded text-sm hover:bg-green-700 disabled:opacity-50">
                  {savingQuota ? '处理中...' : '确认新增'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    {/* 弹窗：手工新增加班 */}
    {addOvertimeModal.open && (
      <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6 max-h-[90vh] overflow-y-auto">
          <h3 className="text-lg font-medium mb-4">手工新增加班记录</h3>
          <form onSubmit={handleAddOvertime} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">选择员工</label>
              <select required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500 text-sm px-3 py-2 border" value={addOvertimeModal.employeeId} onChange={e => setAddOvertimeModal({ ...addOvertimeModal, employeeId: e.target.value })}>
                <option value="">-- 请选择员工 --</option>
                {employees.map(emp => (
                  <option key={emp.id} value={emp.id}>{emp.name} ({emp.jobNumber})</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">开始时间</label>
                <input type="datetime-local" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addOvertimeModal.startTime} onChange={e => setAddOvertimeModal({ ...addOvertimeModal, startTime: e.target.value })} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">结束时间</label>
                <input type="datetime-local" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addOvertimeModal.endTime} onChange={e => setAddOvertimeModal({ ...addOvertimeModal, endTime: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">申请时长 (h)</label>
                <input type="number" step="0.5" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addOvertimeModal.grossDuration || ''} onChange={e => setAddOvertimeModal({ ...addOvertimeModal, grossDuration: Number(e.target.value) })} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">有效时长 (h)</label>
                <input type="number" step="0.5" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addOvertimeModal.netDuration || ''} onChange={e => setAddOvertimeModal({ ...addOvertimeModal, netDuration: Number(e.target.value) })} />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">加班事由</label>
              <textarea className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addOvertimeModal.reason} onChange={e => setAddOvertimeModal({ ...addOvertimeModal, reason: e.target.value })} rows={2}></textarea>
            </div>
            <div className="flex justify-end space-x-3 pt-4">
              <button type="button" onClick={() => setAddOvertimeModal({ ...addOvertimeModal, open: false })} className="px-4 py-2 border border-gray-300 rounded text-sm text-gray-700 hover:bg-gray-50">取消</button>
              <button type="submit" disabled={savingQuota} className="px-4 py-2 bg-green-600 text-white rounded text-sm hover:bg-green-700 disabled:opacity-50">
                {savingQuota ? '处理中...' : '确认新增'}
              </button>
            </div>
          </form>
        </div>
      </div>
    )}

    {/* 弹窗：手工新增请假 */}
    {addLeaveModal.open && (
      <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6 max-h-[90vh] overflow-y-auto">
          <h3 className="text-lg font-medium mb-4">手工新增请假记录</h3>
          <form onSubmit={handleAddLeave} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">选择员工</label>
              <select required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500 text-sm px-3 py-2 border" value={addLeaveModal.employeeId} onChange={e => setAddLeaveModal({ ...addLeaveModal, employeeId: e.target.value })}>
                <option value="">-- 请选择员工 --</option>
                {employees.map(emp => (
                  <option key={emp.id} value={emp.id}>{emp.name} ({emp.jobNumber})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">请假类型</label>
              <select required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addLeaveModal.leaveType} onChange={e => setAddLeaveModal({ ...addLeaveModal, leaveType: e.target.value })}>
                <option value="年假">年假</option>
                <option value="事假">事假</option>
                <option value="病假">病假</option>
                <option value="调休假">调休假</option>
                <option value="婚假">婚假</option>
                <option value="产假">产假</option>
                <option value="其他">其他</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">开始时间</label>
                <input type="datetime-local" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addLeaveModal.startTime} onChange={e => setAddLeaveModal({ ...addLeaveModal, startTime: e.target.value })} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">结束时间</label>
                <input type="datetime-local" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addLeaveModal.endTime} onChange={e => setAddLeaveModal({ ...addLeaveModal, endTime: e.target.value })} />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">请假时长 (天或小时)</label>
              <input type="number" step="0.5" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addLeaveModal.duration || ''} onChange={e => setAddLeaveModal({ ...addLeaveModal, duration: Number(e.target.value) })} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">请假事由</label>
              <textarea className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addLeaveModal.reason} onChange={e => setAddLeaveModal({ ...addLeaveModal, reason: e.target.value })} rows={2}></textarea>
            </div>
            <div className="flex justify-end space-x-3 pt-4">
              <button type="button" onClick={() => setAddLeaveModal({ ...addLeaveModal, open: false })} className="px-4 py-2 border border-gray-300 rounded text-sm text-gray-700 hover:bg-gray-50">取消</button>
              <button type="submit" disabled={savingQuota} className="px-4 py-2 bg-green-600 text-white rounded text-sm hover:bg-green-700 disabled:opacity-50">
                {savingQuota ? '处理中...' : '确认新增'}
              </button>
            </div>
          </form>
        </div>
      </div>
    )}

    {/* 弹窗：手工新增出差 */}
    {addTravelModal.open && (
      <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6 max-h-[90vh] overflow-y-auto">
          <h3 className="text-lg font-medium mb-4">手工新增出差记录</h3>
          <form onSubmit={handleAddTravel} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">选择员工</label>
              <select required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500 text-sm px-3 py-2 border" value={addTravelModal.employeeId} onChange={e => setAddTravelModal({ ...addTravelModal, employeeId: e.target.value })}>
                <option value="">-- 请选择员工 --</option>
                {employees.map(emp => (
                  <option key={emp.id} value={emp.id}>{emp.name} ({emp.jobNumber})</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">出发地</label>
                <input type="text" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addTravelModal.departure} onChange={e => setAddTravelModal({ ...addTravelModal, departure: e.target.value })} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">目的地</label>
                <input type="text" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addTravelModal.destination} onChange={e => setAddTravelModal({ ...addTravelModal, destination: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">开始时间</label>
                <input type="datetime-local" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addTravelModal.startTime} onChange={e => setAddTravelModal({ ...addTravelModal, startTime: e.target.value })} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">结束时间</label>
                <input type="datetime-local" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addTravelModal.endTime} onChange={e => setAddTravelModal({ ...addTravelModal, endTime: e.target.value })} />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">出差时长</label>
              <input type="number" step="0.5" required className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addTravelModal.duration || ''} onChange={e => setAddTravelModal({ ...addTravelModal, duration: Number(e.target.value) })} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">出差事由</label>
              <textarea className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm px-3 py-2 border" value={addTravelModal.reason} onChange={e => setAddTravelModal({ ...addTravelModal, reason: e.target.value })} rows={2}></textarea>
            </div>
            <div className="flex justify-end space-x-3 pt-4">
              <button type="button" onClick={() => setAddTravelModal({ ...addTravelModal, open: false })} className="px-4 py-2 border border-gray-300 rounded text-sm text-gray-700 hover:bg-gray-50">取消</button>
              <button type="submit" disabled={savingQuota} className="px-4 py-2 bg-green-600 text-white rounded text-sm hover:bg-green-700 disabled:opacity-50">
                {savingQuota ? '处理中...' : '确认新增'}
              </button>
            </div>
          </form>
        </div>
      </div>
    )}
  </div>
  );
}
