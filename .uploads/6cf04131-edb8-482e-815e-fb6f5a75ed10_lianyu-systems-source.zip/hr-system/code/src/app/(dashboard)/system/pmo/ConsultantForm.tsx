'use client';

import { useState, useEffect } from 'react';
import { parseIdCard, createEmployee, updateEmployee } from '@/actions/employee';
import { useRouter } from 'next/navigation';

interface ConsultantFormProps {
  customFields: any[];
  initialEmployee?: any; // 如果传入代表编辑模式
  onSuccess: () => void;
}

export default function ConsultantForm({ customFields, initialEmployee, onSuccess }: ConsultantFormProps) {
  const router = useRouter();
  const isEdit = !!initialEmployee;
  
  // Custom Field Lookups
  const consultantField = customFields.find(f => f.label === '顾问');
  const consultantFieldName = consultantField ? consultantField.name : '顾问';

  const clientNameField = customFields.find(f => f.label === '客户侧姓名');
  const clientNameFieldName = clientNameField ? clientNameField.name : '客户侧姓名';

  // State
  const [formData, setFormData] = useState({
    name: '',
    idCard: '',
    phone: '',
    employeeType: '外部合作',
    [clientNameFieldName]: '',
    '擅长领域': '',
    '历史背景': '',
    '备注': '',
    '合作方式': '合作制',
  });

  const [parsedData, setParsedData] = useState({ gender: '', birthday: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // 初始化回显
  useEffect(() => {
    if (isEdit && initialEmployee) {
      const ext = typeof initialEmployee.extInfo === 'string' 
        ? JSON.parse(initialEmployee.extInfo) 
        : (initialEmployee.extInfo || {});

      setFormData({
        name: initialEmployee.name || '',
        idCard: initialEmployee.idCard || '',
        phone: ext.phone || '',
        employeeType: ext.employeeType || '外部合作',
        [clientNameFieldName]: ext[clientNameFieldName] || '',
        '擅长领域': ext['擅长领域'] || '',
        '历史背景': ext['历史背景'] || '',
        '备注': ext['备注'] || '',
        '合作方式': ext['合作方式'] || '合作制',
      });

      setParsedData({
        gender: initialEmployee.gender === 'MALE' ? '男' : initialEmployee.gender === 'FEMALE' ? '女' : '',
        birthday: initialEmployee.birthday ? new Date(initialEmployee.birthday).toISOString().split('T')[0] : '',
      });
    }
  }, [isEdit, initialEmployee, clientNameFieldName]);

  // 身份证智能解析
  const handleIdCardBlur = async (e: React.FocusEvent<HTMLInputElement>) => {
    const idCard = e.target.value;
    if (idCard.length === 18) {
      const result = await parseIdCard(idCard);
      if (result.success && result.data) {
        setParsedData({
          gender: result.data.genderFormatted,
          birthday: result.data.birthdayFormatted,
        });
        setError('');
      } else {
        setError('身份证号码解析失败，请检查格式');
        setParsedData({ gender: '', birthday: '' });
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (!parsedData.gender) {
      setError('请输入有效的 18 位身份证号码');
      setLoading(false);
      return;
    }

    // 组合数据负载
    const payload = {
      name: formData.name,
      idCard: formData.idCard,
      jobNumber: isEdit ? initialEmployee.jobNumber : '', // 顾问默认无工号，或者在后端生成
      exemptAttendance: true, // 顾问默认免考勤或特殊处理
      hireDate: new Date().toISOString(), // 默认当天
      probationMonths: 0,
      
      extInfo: {
        phone: formData.phone,
        employeeType: formData.employeeType,
        [consultantFieldName]: '是',
        [clientNameFieldName]: formData[clientNameFieldName],
        '擅长领域': formData['擅长领域'],
        '历史背景': formData['历史背景'],
        '备注': formData['备注'],
        '合作方式': formData['合作方式'],
      }
    };

    const result = isEdit 
      ? await updateEmployee(initialEmployee.id, payload)
      : await createEmployee(payload);

    if (result.success) {
      onSuccess();
      router.refresh();
    } else {
      setError(result.message || '保存失败');
    }
    setLoading(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-h-[70vh] overflow-y-auto pr-2">
      {error && <div className="text-red-500 text-sm p-3 bg-red-50 border border-red-200 rounded sticky top-0 z-10 shadow-sm">{error}</div>}
      
      <div>
        <h4 className="text-sm font-semibold text-indigo-600 border-b pb-2 mb-4">基本信息</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">姓名 <span className="text-red-500">*</span></label>
            <input type="text" required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">联系电话 <span className="text-red-500">*</span></label>
            <input type="tel" required value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" />
          </div>
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700">身份证号 <span className="text-red-500">*</span></label>
            <input 
              type="text" 
              required 
              value={formData.idCard} 
              onChange={e => setFormData({...formData, idCard: e.target.value})} 
              onBlur={handleIdCardBlur}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" 
              placeholder="18位中国大陆身份证号"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500">智能解析性别</label>
            <div className="mt-1 text-sm text-gray-900 font-semibold bg-gray-100 p-2 rounded border border-gray-200">{parsedData.gender || '输入身份证后自动生成'}</div>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500">智能解析出生日期</label>
            <div className="mt-1 text-sm text-gray-900 font-semibold bg-gray-100 p-2 rounded border border-gray-200">{parsedData.birthday || '输入身份证后自动生成'}</div>
          </div>
        </div>
      </div>

      <div>
        <h4 className="text-sm font-semibold text-indigo-600 border-b pb-2 mb-4">合作及专项信息</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">客户侧姓名</label>
            <input type="text" value={formData[clientNameFieldName]} onChange={e => setFormData({...formData, [clientNameFieldName]: e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-white" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">合作方式 <span className="text-red-500">*</span></label>
            <input type="text" required value={formData['合作方式']} onChange={e => setFormData({...formData, '合作方式': e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-yellow-50" />
          </div>
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700">擅长领域</label>
            <input type="text" value={formData['擅长领域']} onChange={e => setFormData({...formData, '擅长领域': e.target.value})} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-white" placeholder="例如：Java, 架构设计, 敏捷管理等" />
          </div>
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700">历史背景</label>
            <textarea value={formData['历史背景']} onChange={e => setFormData({...formData, '历史背景': e.target.value})} rows={3} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-white" placeholder="填写过往经历或背景..." />
          </div>
          <div className="col-span-2">
            <label className="block text-sm font-medium text-gray-700">备注</label>
            <textarea value={formData['备注']} onChange={e => setFormData({...formData, '备注': e.target.value})} rows={2} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2 bg-white" />
          </div>
        </div>
      </div>

      <div className="pt-4 border-t border-gray-200">
        <button
          type="submit"
          disabled={loading}
          className="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-md shadow-sm text-sm font-bold text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 transition"
        >
          {loading ? '处理中...' : (isEdit ? '保存修改' : '确认新增顾问')}
        </button>
      </div>
    </form>
  );
}
