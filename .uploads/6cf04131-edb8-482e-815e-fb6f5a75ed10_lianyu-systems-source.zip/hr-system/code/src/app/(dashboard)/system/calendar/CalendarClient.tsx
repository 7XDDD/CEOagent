'use client';

import { useState, useEffect } from 'react';
import { getCalendarDays, saveCalendarDay, syncCalendarForYear } from '@/actions/calendar';

interface CalendarClientProps {
  initialYear: number;
  initialMonth: number;
  initialDays: any[];
}

export default function CalendarClient({ initialYear, initialMonth, initialDays }: CalendarClientProps) {
  const [year, setYear] = useState(initialYear);
  const [month, setMonth] = useState(initialMonth);
  const [calendarTags, setCalendarTags] = useState<any[]>(initialDays);
  
  // 选中的日期及编辑状态
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [tagType, setTagType] = useState<'WORKDAY' | 'HOLIDAY' | 'MAKEUP' | 'REST'>('WORKDAY');
  const [description, setDescription] = useState('');
  
  const [loading, setLoading] = useState(false);

  // 当年份/月份变化时，从后端拉取打标数据
  const fetchMonthData = async (y: number, m: number) => {
    setLoading(true);
    const res = await getCalendarDays(y, m);
    if (res.success && res.data) {
      setCalendarTags(res.data);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchMonthData(year, month);
  }, [year, month]);

  const handlePrevMonth = () => {
    if (month === 1) {
      setYear(year - 1);
      setMonth(12);
    } else {
      setMonth(month - 1);
    }
  };

  const handleNextMonth = () => {
    if (month === 12) {
      setYear(year + 1);
      setMonth(1);
    } else {
      setMonth(month + 1);
    }
  };

  // 生成日历网格数据
  const getDaysInMonth = (y: number, m: number) => {
    // 获取当月第一天星期几
    const firstDayIndex = new Date(y, m - 1, 1).getDay();
    // 获取当月有多少天
    const totalDays = new Date(y, m, 0).getDate();
    
    const days = [];
    // 填充空白
    for (let i = 0; i < firstDayIndex; i++) {
      days.push(null);
    }
    // 填充天
    for (let i = 1; i <= totalDays; i++) {
      days.push(i);
    }
    return days;
  };

  const daysGrid = getDaysInMonth(year, month);

  // 获取特定日期的属性配置
  const getDayTag = (dayNum: number) => {
    const targetDateStr = `${year}-${String(month).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
    const dateObj = new Date(targetDateStr);

    // 1. 查找数据库中是否有打标
    const dbTag = calendarTags.find(tag => {
      const dateStr = typeof tag.date === 'string' ? tag.date : tag.date.toISOString();
      return dateStr.startsWith(targetDateStr);
    });

    if (dbTag) {
      return { type: dbTag.type, description: dbTag.description || '' };
    }

    // 2. 默认规则：周六日为 REST，周一至五为 WORKDAY
    const dayOfWeek = dateObj.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      return { type: 'REST', description: '休息日' };
    }
    return { type: 'WORKDAY', description: '正常工作日' };
  };

  const handleCellClick = (dayNum: number) => {
    const targetDateStr = `${year}-${String(month).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
    const tag = getDayTag(dayNum);
    setSelectedDate(targetDateStr);
    setTagType(tag.type as any);
    setDescription(tag.description);
  };

  const handleSaveTag = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedDate) return;

    setLoading(true);
    const res = await saveCalendarDay(selectedDate, tagType, description);
    if (res.success) {
      // 重新载入当月打标数据
      await fetchMonthData(year, month);
      setSelectedDate(null);
    } else {
      alert(res.message || '保存失败');
    }
    setLoading(false);
  };

  const handleSyncCalendar = async () => {
    if (!confirm(`确定要自动同步 ${year} 年的国家法定节假日和补班记录吗？这将覆盖已有日历记录！`)) return;
    setLoading(true);
    const res = await syncCalendarForYear(year);
    if (res.success) {
      await fetchMonthData(year, month);
      alert(`✅ ${year}年国家节假日历已成功同步！`);
    } else {
      alert(res.message || '同步失败');
    }
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">全局考勤日历排班</h1>
          <p className="text-sm text-gray-500 mt-1">HR在此统一为每天打上考勤标签，作为缺卡、旷工、薪资折算等统计的基准坐标。</p>
        </div>
        <button
          onClick={handleSyncCalendar}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded shadow text-sm font-medium transition disabled:opacity-50"
        >
          {loading ? '正在同步...' : `🔄 自动同步 ${year} 年法定节假日`}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* 左侧及中间：月度日历画布 */}
        <div className="bg-white shadow rounded-lg border border-gray-200 p-6 lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center border-b pb-4">
            <h3 className="text-lg font-bold text-gray-800">
              📅 {year}年 {month}月
            </h3>
            <div className="flex space-x-2">
              <button 
                onClick={handlePrevMonth}
                className="px-3 py-1 border border-gray-300 text-sm font-medium rounded hover:bg-gray-50 transition"
              >
                &lt; 上一月
              </button>
              <button 
                onClick={handleNextMonth}
                className="px-3 py-1 border border-gray-300 text-sm font-medium rounded hover:bg-gray-50 transition"
              >
                下一月 &gt;
              </button>
            </div>
          </div>

          {/* 星期 Header */}
          <div className="grid grid-cols-7 gap-2 text-center text-xs font-semibold text-gray-500 uppercase tracking-wider">
            <div>日</div>
            <div>一</div>
            <div>二</div>
            <div>三</div>
            <div>四</div>
            <div>五</div>
            <div>六</div>
          </div>

          {/* 日历天网格 */}
          <div className="grid grid-cols-7 gap-2 min-h-[300px]">
            {daysGrid.map((day, idx) => {
              if (day === null) {
                return <div key={`empty-${idx}`} className="bg-gray-50 rounded-lg border border-gray-100"></div>;
              }

              const tag = getDayTag(day);
              let typeClass = '';
              let badgeText = '';

              switch (tag.type) {
                case 'WORKDAY':
                  typeClass = 'bg-blue-50 text-blue-800 border-blue-100 hover:bg-blue-100';
                  badgeText = '工';
                  break;
                case 'HOLIDAY':
                  typeClass = 'bg-red-50 text-red-800 border-red-200 hover:bg-red-100';
                  badgeText = '假';
                  break;
                case 'MAKEUP':
                  typeClass = 'bg-yellow-50 text-yellow-800 border-yellow-200 hover:bg-yellow-100';
                  badgeText = '班';
                  break;
                case 'REST':
                  typeClass = 'bg-gray-50 text-gray-500 border-gray-200 hover:bg-gray-100';
                  badgeText = '休';
                  break;
              }

              return (
                <button
                  key={`day-${day}`}
                  onClick={() => handleCellClick(day)}
                  className={`relative p-3 h-20 border rounded-lg flex flex-col justify-between items-start transition text-left cursor-pointer group ${typeClass}`}
                >
                  <span className="text-sm font-bold">{day}</span>
                  
                  {/* 右上角打上标签 */}
                  <span className={`absolute top-1 right-1 text-[9px] font-bold px-1 rounded-sm ${
                    tag.type === 'HOLIDAY' ? 'bg-red-200 text-red-800' :
                    tag.type === 'MAKEUP' ? 'bg-yellow-200 text-yellow-800' :
                    tag.type === 'WORKDAY' ? 'bg-blue-200 text-blue-800' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {badgeText}
                  </span>

                  {/* 悬浮/详细描述 */}
                  <span className="text-[10px] text-gray-500 truncate w-full group-hover:text-gray-900" title={tag.description}>
                    {tag.description}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* 右侧：排班类型编辑面板 */}
        <div className="bg-white shadow rounded-lg border border-gray-200 p-6 lg:col-span-1">
          <h3 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2">排班打标面板</h3>

          {selectedDate ? (
            <form onSubmit={handleSaveTag} className="space-y-4">
              <div className="bg-indigo-50 text-indigo-800 p-3 rounded text-sm font-medium">
                正在编辑：{selectedDate}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">日期类型配置</label>
                <div className="space-y-2">
                  <label className="flex items-center space-x-2 text-sm text-gray-700 cursor-pointer">
                    <input 
                      type="radio" 
                      name="tagType" 
                      value="WORKDAY"
                      checked={tagType === 'WORKDAY'}
                      onChange={() => setTagType('WORKDAY')}
                      className="text-indigo-600 focus:ring-indigo-500"
                    />
                    <span>正常工作日 (WORKDAY)</span>
                  </label>
                  <label className="flex items-center space-x-2 text-sm text-gray-700 cursor-pointer">
                    <input 
                      type="radio" 
                      name="tagType" 
                      value="HOLIDAY"
                      checked={tagType === 'HOLIDAY'}
                      onChange={() => setTagType('HOLIDAY')}
                      className="text-red-600 focus:ring-red-500"
                    />
                    <span className="text-red-700">法定节假日 [带薪] (HOLIDAY)</span>
                  </label>
                  <label className="flex items-center space-x-2 text-sm text-gray-700 cursor-pointer">
                    <input 
                      type="radio" 
                      name="tagType" 
                      value="MAKEUP"
                      checked={tagType === 'MAKEUP'}
                      onChange={() => setTagType('MAKEUP')}
                      className="text-yellow-600 focus:ring-yellow-500"
                    />
                    <span className="text-yellow-700">调休补班日 (MAKEUP)</span>
                  </label>
                  <label className="flex items-center space-x-2 text-sm text-gray-700 cursor-pointer">
                    <input 
                      type="radio" 
                      name="tagType" 
                      value="REST"
                      checked={tagType === 'REST'}
                      onChange={() => setTagType('REST')}
                      className="text-gray-600 focus:ring-gray-500"
                    />
                    <span>休息日 (REST)</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">备注描述</label>
                <input 
                  type="text"
                  placeholder="如: 国庆节放假 / 补班"
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                />
              </div>

              <div className="flex space-x-2 pt-2">
                <button 
                  type="button"
                  onClick={() => setSelectedDate(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-sm font-medium rounded text-gray-700 bg-white hover:bg-gray-50 transition"
                >
                  取消
                </button>
                <button 
                  type="submit"
                  disabled={loading}
                  className="flex-1 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded transition disabled:opacity-50"
                >
                  {loading ? '保存中...' : '确认打标'}
                </button>
              </div>
            </form>
          ) : (
            <div className="text-center py-12 text-gray-400 text-sm">
              👈 请在左侧日历中点击任意日期单元格，即可为其打上特定考勤属性。
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
