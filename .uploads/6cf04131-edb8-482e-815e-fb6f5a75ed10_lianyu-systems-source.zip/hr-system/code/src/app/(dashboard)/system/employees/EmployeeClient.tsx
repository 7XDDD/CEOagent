'use client';

import { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import EmployeeForm from './EmployeeForm';
import ResignForm from './ResignForm';
import { importEmployeesBatch } from '@/actions/employee';

interface EmployeeClientProps {
  initialData: any[];
  customFields: any[];
}

export default function EmployeeClient({ initialData, customFields }: EmployeeClientProps) {
  // 看板过滤状态 (在职 ACTIVE / 离职 RESIGNED)
  const [activeTab, setActiveTab] = useState<'ACTIVE' | 'RESIGNED'>('ACTIVE');
  
  // 各种弹窗状态
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editEmployee, setEditEmployee] = useState<any | null>(null);
  const [resignEmp, setResignEmp] = useState<{ id: string; name: string } | null>(null);
  const [viewEmp, setViewEmp] = useState<any | null>(null);
  const [importing, setImporting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const consultantField = customFields.find(f => f.label === '顾问');
  const consultantFieldName = consultantField ? consultantField.name : '顾问';

  const isExternalConsultant = (emp: any) => {
    const ext = typeof emp.extInfo === 'string' ? JSON.parse(emp.extInfo) : (emp.extInfo || {});
    return ext?.[consultantFieldName] === '是' && ext?.employeeType === '外部合作';
  };

  // 过滤当前在职或离职人员数据，且排除外部合作的顾问
  const filteredEmployees = initialData.filter(emp => emp.status === activeTab && !isExternalConsultant(emp));

  // 动态年龄计算逻辑
  const calculateAge = (birthdayStr: string | null) => {
    if (!birthdayStr) return '--';
    const birthDate = new Date(birthdayStr);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const handleExportEmployees = () => {
    const exportData = filteredEmployees.map(emp => {
      const extInfo = typeof emp.extInfo === 'string' ? JSON.parse(emp.extInfo) : (emp.extInfo || {});
      return {
        '工号': emp.jobNumber || '',
        '姓名': emp.name || '',
        '身份证': emp.idCard || '',
        '性别': emp.gender === 'MALE' ? '男' : emp.gender === 'FEMALE' ? '女' : '',
        '入职时间': emp.hireDate ? new Date(emp.hireDate).toISOString().split('T')[0] : '',
        '试用期(月)': emp.probationMonths || 3,
        '合同类型': emp.contractType || '',
        '合同开始时间': emp.contractStartDate ? new Date(emp.contractStartDate).toISOString().split('T')[0] : '',
        '合同结束时间': emp.contractEndDate ? new Date(emp.contractEndDate).toISOString().split('T')[0] : '',
        '免考勤': emp.exemptAttendance ? '是' : '否',
        '部门': extInfo?.department || '',
        '岗位': extInfo?.position || '',
        '状态': emp.status === 'ACTIVE' ? '在职' : '离职',
        [consultantFieldName]: extInfo?.[consultantFieldName] || ''
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, '内部员工花名册');
    XLSX.writeFile(workbook, `内部员工花名册_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const handleImportEmployees = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImporting(true);
    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const data = evt.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const jsonData: any[] = XLSX.utils.sheet_to_json(sheet);

        const payload = jsonData.map(row => ({
          jobNumber: row['工号'],
          name: row['姓名'],
          idCard: row['身份证'],
          gender: row['性别'] === '男' ? 'MALE' : row['性别'] === '女' ? 'FEMALE' : undefined,
          hireDate: row['入职时间'] ? new Date(row['入职时间']).toISOString() : undefined,
          probationMonths: row['试用期(月)'],
          contractType: row['合同类型'],
          contractStartDate: row['合同开始时间'] ? new Date(row['合同开始时间']).toISOString() : undefined,
          contractEndDate: row['合同结束时间'] ? new Date(row['合同结束时间']).toISOString() : undefined,
          exemptAttendance: row['免考勤'] === '是',
          status: row['状态'] === '离职' ? 'RESIGNED' : 'ACTIVE',
          extInfo: {
            department: row['部门'],
            position: row['岗位'],
            [consultantFieldName]: row[consultantFieldName]
          }
        }));

        const res = await importEmployeesBatch(payload, false);
        if (res?.success) {
          alert(`导入成功！成功处理了 ${res.count} 条记录。`);
          window.location.reload();
        } else {
          alert(`导入失败: ${res?.message}`);
        }
      } catch (error: any) {
        alert(`解析文件失败: ${error.message}`);
      } finally {
        setImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsBinaryString(file);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      
      {/* 顶部标题与动作面板 */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">员工花名册中心</h1>
          <p className="text-sm text-gray-500 mt-1">支持全量档案追踪、身份证解析、合同自动预警及动态自定义字段同源渲染</p>
        </div>
        <div className="flex items-center space-x-3">
          <a 
            href="/system/employees/compensation"
            className="px-4 py-2 border border-gray-300 text-gray-700 bg-white hover:bg-gray-50 rounded transition text-sm font-medium"
          >
            📊 1:1调休折薪报表
          </a>
          <a 
            href="/system/employees/config"
            className="px-4 py-2 border border-gray-300 text-gray-700 bg-white hover:bg-gray-50 rounded transition text-sm font-medium"
          >
            ⚙ 配置动态字段 (三要素)
          </a>
          <button 
            onClick={handleExportEmployees}
            className="px-4 py-2 border border-gray-300 text-gray-700 bg-white hover:bg-gray-50 rounded transition font-medium text-sm"
          >
            导出员工表
          </button>
          <input
            type="file"
            accept=".xlsx,.xls,.csv"
            ref={fileInputRef}
            className="hidden"
            onChange={handleImportEmployees}
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={importing}
            className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition font-medium text-sm disabled:bg-gray-400"
          >
            {importing ? '导入中...' : '导入员工表'}
          </button>
          <button 
            onClick={() => setIsCreateOpen(true)}
            className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition font-medium text-sm"
          >
            + 录入新员工
          </button>
        </div>
      </div>

      {/* 看板 Tabs 过滤 */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          <button
            onClick={() => setActiveTab('ACTIVE')}
            className={`border-b-2 py-4 px-1 text-sm font-medium transition ${
              activeTab === 'ACTIVE'
                ? 'border-indigo-500 text-indigo-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            在职看板 ({initialData.filter(e => e.status === 'ACTIVE' && !isExternalConsultant(e)).length}人)
          </button>
          <button
            onClick={() => setActiveTab('RESIGNED')}
            className={`border-b-2 py-4 px-1 text-sm font-medium transition ${
              activeTab === 'RESIGNED'
                ? 'border-red-500 text-red-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            离职看板 ({initialData.filter(e => e.status === 'RESIGNED' && !isExternalConsultant(e)).length}人)
          </button>
        </nav>
      </div>

      {/* 数据列表 */}
      <div className="bg-white shadow rounded-lg overflow-hidden border border-gray-200">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">工号</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">姓名</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">部门与岗位</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">性别/年龄</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">免考勤白名单</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">合同期限</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 text-sm">
            {filteredEmployees.length > 0 ? (
              filteredEmployees.map((emp: any) => {
                const extInfo = typeof emp.extInfo === 'string' ? JSON.parse(emp.extInfo) : (emp.extInfo || {});
                return (
                  <tr key={emp.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500 font-mono">{emp.jobNumber || '--'}</td>
                    <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                      {emp.name}
                      {extInfo?.[consultantFieldName] === '是' && (
                        <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                          顾问
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                      <div>{extInfo?.department || '-'}</div>
                      <div className="text-xs text-gray-400">{extInfo?.position || '-'}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                      {emp.gender === 'MALE' ? '男' : emp.gender === 'FEMALE' ? '女' : '未知'} 
                      <span className="ml-2 bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded text-xs">
                        {calculateAge(emp.birthday)} 岁
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                      {emp.exemptAttendance ? (
                        <span className="px-2.5 py-0.5 rounded bg-blue-100 text-blue-800 text-xs font-semibold">
                          已豁免考勤
                        </span>
                      ) : (
                        <span className="text-gray-400 text-xs">普通考勤</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-gray-500">
                      {emp.contractStartDate ? (
                        <div>
                          <span className="text-xs bg-indigo-50 text-indigo-700 px-1 rounded mr-1">
                            {emp.contractType || '合同'}
                          </span>
                          <span className="text-xs text-gray-500">
                            {new Date(emp.contractEndDate).toLocaleDateString()} 到期
                          </span>
                        </div>
                      ) : (
                        <span className="text-gray-300">未录入合同</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap font-medium space-x-3">
                      <button 
                        onClick={() => setViewEmp(emp)}
                        className="text-indigo-600 hover:text-indigo-900"
                      >
                        详情
                      </button>
                      {emp.status === 'ACTIVE' ? (
                        <>
                          <button 
                            onClick={() => setEditEmployee(emp)}
                            className="text-indigo-600 hover:text-indigo-900"
                          >
                            编辑
                          </button>
                          <button 
                            onClick={() => setResignEmp({ id: emp.id, name: emp.name })}
                            className="text-red-600 hover:text-red-900"
                          >
                            办理离职
                          </button>
                        </>
                      ) : (
                        <span className="text-gray-400 text-xs italic">已归档</span>
                      )}
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={7} className="px-6 py-8 text-center text-gray-400">
                  当前看板暂无员工数据。
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* 弹窗1：录入新员工 */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-10 overflow-y-auto" role="dialog" aria-modal="true">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setIsCreateOpen(false)}></div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="relative inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full">
              <div className="bg-white px-6 pt-5 pb-4 sm:p-8 sm:pb-6">
                <h3 className="text-lg leading-6 font-semibold text-gray-900 mb-6 border-b pb-3">录入新员工</h3>
                <EmployeeForm customFields={customFields} onSuccess={() => setIsCreateOpen(false)} />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 弹窗2：编辑员工档案 */}
      {editEmployee && (
        <div className="fixed inset-0 z-10 overflow-y-auto" role="dialog" aria-modal="true">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setEditEmployee(null)}></div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="relative inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full">
              <div className="bg-white px-6 pt-5 pb-4 sm:p-8 sm:pb-6">
                <h3 className="text-lg leading-6 font-semibold text-gray-900 mb-6 border-b pb-3">
                  编辑员工档案：{editEmployee.name}
                </h3>
                <EmployeeForm 
                  customFields={customFields} 
                  initialEmployee={editEmployee} 
                  onSuccess={() => setEditEmployee(null)} 
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 弹窗3：办理离职 */}
      {resignEmp && (
        <div className="fixed inset-0 z-10 overflow-y-auto" role="dialog" aria-modal="true">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setResignEmp(null)}></div>
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div className="relative inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <div className="bg-white px-6 pt-5 pb-4 sm:p-6 sm:pb-4">
                <h3 className="text-lg leading-6 font-semibold text-gray-900 mb-6 border-b pb-3">员工离职办理</h3>
                <ResignForm 
                  employeeId={resignEmp.id}
                  employeeName={resignEmp.name}
                  onSuccess={() => setResignEmp(null)}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 弹窗4：全量档案详情 (兼容离职快照) */}
      {viewEmp && (() => {
        const ext = typeof viewEmp.extInfo === 'string' ? JSON.parse(viewEmp.extInfo) : (viewEmp.extInfo || {});
        return (
          <div className="fixed inset-0 z-10 overflow-y-auto" role="dialog" aria-modal="true">
            <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
              <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setViewEmp(null)}></div>
              <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
              <div className="relative inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full">
                <div className="bg-white px-6 pt-5 pb-4 sm:p-8 sm:pb-6">
                  <div className="flex justify-between items-center mb-6 border-b pb-3">
                    <h3 className="text-lg leading-6 font-semibold text-gray-900">
                      员工全量档案详情 ({viewEmp.name})
                    </h3>
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                      viewEmp.status === 'ACTIVE' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {viewEmp.status === 'ACTIVE' ? '在职' : '已离职'}
                    </span>
                  </div>

                  <div className="max-h-[65vh] overflow-y-auto pr-2 space-y-6">
                    {/* 基础入职信息 */}
                    <div>
                      <h4 className="text-sm font-semibold text-indigo-600 mb-3 border-l-4 border-indigo-500 pl-2">入职与基本档案</h4>
                      <div className="grid grid-cols-3 gap-4 text-sm bg-gray-50 p-4 rounded-lg">
                        <div><span className="text-gray-500">工号: </span><span className="text-gray-900 font-mono font-semibold">{viewEmp.jobNumber || '--'}</span></div>
                        <div><span className="text-gray-500">姓名: </span><span className="text-gray-900 font-medium">{viewEmp.name}</span></div>
                        <div><span className="text-gray-500">身份证号: </span><span className="text-gray-900 font-medium">{viewEmp.idCard}</span></div>
                        <div><span className="text-gray-500">性别: </span><span className="text-gray-900 font-medium">{viewEmp.gender === 'MALE' ? '男' : '女'}</span></div>
                        <div><span className="text-gray-500">出生日期: </span><span className="text-gray-900 font-medium">{viewEmp.birthday ? new Date(viewEmp.birthday).toLocaleDateString() : '--'}</span></div>
                        <div><span className="text-gray-500">动态年龄: </span><span className="text-gray-900 font-medium">{calculateAge(viewEmp.birthday)} 岁</span></div>
                        <div><span className="text-gray-500">免考勤属性: </span><span className="text-gray-900 font-medium">{viewEmp.exemptAttendance ? '免考勤白名单' : '常规考勤'}</span></div>
                        <div><span className="text-gray-500">入职日期: </span><span className="text-gray-900 font-medium">{viewEmp.hireDate ? new Date(viewEmp.hireDate).toLocaleDateString() : '--'}</span></div>
                        <div><span className="text-gray-500">试用期长度: </span><span className="text-gray-900 font-medium">{viewEmp.probationMonths} 个月</span></div>
                        <div><span className="text-gray-500">合同类型: </span><span className="text-gray-900 font-medium">{viewEmp.contractType || '--'}</span></div>
                        <div><span className="text-gray-500">合同起点: </span><span className="text-gray-900 font-medium">{viewEmp.contractStartDate ? new Date(viewEmp.contractStartDate).toLocaleDateString() : '--'}</span></div>
                        <div><span className="text-gray-500">合同终点: </span><span className="text-gray-900 font-medium">{viewEmp.contractEndDate ? new Date(viewEmp.contractEndDate).toLocaleDateString() : '--'}</span></div>
                      </div>
                    </div>

                    {/* 扩展业务字段 */}
                    <div>
                      <h4 className="text-sm font-semibold text-indigo-600 mb-3 border-l-4 border-indigo-500 pl-2">业务岗位与联系人</h4>
                      <div className="grid grid-cols-3 gap-4 text-sm bg-gray-50 p-4 rounded-lg">
                        <div><span className="text-gray-500">联系电话: </span><span className="text-gray-900 font-medium">{ext?.phone || '--'}</span></div>
                        <div><span className="text-gray-500">个人邮箱: </span><span className="text-gray-900 font-medium">{ext?.email || '--'}</span></div>
                        <div><span className="text-gray-500">工作城市: </span><span className="text-gray-900 font-medium">{ext?.workLocation || '--'}</span></div>
                        <div><span className="text-gray-500">所属部门: </span><span className="text-gray-900 font-medium">{ext?.department || '--'}</span></div>
                        <div><span className="text-gray-500">岗位名称: </span><span className="text-gray-900 font-medium">{ext?.position || '--'}</span></div>
                        <div><span className="text-gray-500">员工类型: </span><span className="text-gray-900 font-medium">{ext?.employeeType || '--'}</span></div>
                        <div><span className="text-gray-500">合同单位: </span><span className="text-gray-900 font-medium">{ext?.contractCompany || '--'}</span></div>
                        <div><span className="text-gray-500">婚姻状况: </span><span className="text-gray-900 font-medium">{ext?.maritalStatus || '--'}</span></div>
                        <div><span className="text-gray-500">政治面貌: </span><span className="text-gray-900 font-medium">{ext?.politicalStatus || '--'}</span></div>
                        <div><span className="text-gray-500">民族: </span><span className="text-gray-900 font-medium">{ext?.ethnicity || '--'}</span></div>
                        <div><span className="text-gray-500">籍贯: </span><span className="text-gray-900 font-medium">{ext?.nativePlace || '--'}</span></div>
                        <div className="col-span-3"><span className="text-gray-500">户口地址: </span><span className="text-gray-900 font-medium">{ext?.hukouAddress || '--'}</span></div>
                        <div className="col-span-3"><span className="text-gray-500">现居住地: </span><span className="text-gray-900 font-medium">{ext?.homeAddress || '--'}</span></div>
                      </div>
                    </div>

                    {/* 财务与紧急联系人 */}
                    <div>
                      <h4 className="text-sm font-semibold text-indigo-600 mb-3 border-l-4 border-indigo-500 pl-2">财务账本与紧急联系人</h4>
                      <div className="grid grid-cols-2 gap-4 text-sm bg-gray-50 p-4 rounded-lg">
                        <div><span className="text-gray-500">紧急联系人姓名: </span><span className="text-gray-900 font-medium">{ext?.emergencyContactName || '--'}</span></div>
                        <div><span className="text-gray-500">紧急联系人电话: </span><span className="text-gray-900 font-medium">{ext?.emergencyContactPhone || '--'}</span></div>
                        <div><span className="text-gray-500">开户行银行: </span><span className="text-gray-900 font-medium">{ext?.bankName || '--'}</span></div>
                        <div><span className="text-gray-500">银行卡号: </span><span className="text-gray-900 font-medium">{ext?.bankAccount || '--'}</span></div>
                      </div>
                    </div>

                    {/* HR 配置的自定义字段 */}
                    {customFields.length > 0 && (
                      <div>
                        <h4 className="text-sm font-semibold text-indigo-600 mb-3 border-l-4 border-indigo-500 pl-2">HR 自定义扩展属性</h4>
                        <div className="grid grid-cols-3 gap-4 text-sm bg-gray-50 p-4 rounded-lg">
                          {customFields.map(f => (
                            <div key={f.id}>
                              <span className="text-gray-500">{f.label}: </span>
                              <span className="text-gray-900 font-medium">{ext[f.name] || '--'}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* 离职信息 (仅离职看板中加载，支持 1:1 折薪记录归档回显) */}
                    {viewEmp.status === 'RESIGNED' && (
                      <div>
                        <h4 className="text-sm font-semibold text-red-600 mb-3 border-l-4 border-red-500 pl-2">离职生命周期结算快照</h4>
                        <div className="grid grid-cols-2 gap-4 text-sm bg-red-50 p-4 rounded-lg border border-red-100">
                          <div><span className="text-red-700">离职办理时间: </span><span className="text-gray-900 font-semibold">{ext?.resignedAt || '--'}</span></div>
                          <div><span className="text-red-700">离职类型: </span><span className="text-gray-900 font-semibold">{ext?.resignationType || '--'}</span></div>
                          <div className="col-span-2"><span className="text-red-700">离职原因: </span><span className="text-gray-900 font-medium whitespace-pre-wrap">{ext?.resignationReason || '--'}</span></div>
                          <div><span className="text-red-700">有无补偿金: </span><span className="text-gray-900 font-semibold">{ext?.hasCompensation || '--'}</span></div>
                          <div>
                            <span className="text-red-700">材料归档: </span>
                            <span className="text-gray-900 font-medium">
                              {ext?.submittedFiles && ext.submittedFiles.length > 0 
                                ? ext.submittedFiles.join(', ') 
                                : '无提交资料'}
                            </span>
                          </div>
                          <div className="col-span-2 border-t border-red-200 pt-2 mt-2">
                            <span className="text-red-700 font-semibold">⏰ 调休假1:1工资折算流水: </span>
                            <span className="text-red-800 font-bold bg-white px-2 py-0.5 rounded border border-red-300">
                              {ext?.settledCompensationStatus || '无调休账户待折算'}
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="mt-6 flex justify-end pt-4 border-t border-gray-200">
                    <button 
                      onClick={() => setViewEmp(null)}
                      className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded font-medium text-sm transition"
                    >
                      关闭档案
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
}
