import HistoryClient from './HistoryClient';

export default function ImportHistoryPage() {
  return <HistoryClient />;
}
