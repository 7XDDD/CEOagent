import { prisma } from '@/lib/prisma';
import Link from 'next/link';

export const metadata = {
  title: '控制台首页 - 智能化HR系统',
};

export default async function DashboardPage() {
  const now = new Date();
  
  // 1. 核心指标统计
  const totalActive = await prisma.employee.count({ where: { status: 'ACTIVE' } });
  const totalResigned = await prisma.employee.count({ where: { status: 'RESIGNED' } });
  const totalExempt = await prisma.employee.count({ where: { status: 'ACTIVE', exemptAttendance: true } });
  
  // 2. 合同到期前 1 个月预警 (在职且合同结束日期在未来 30 天内)
  const thirtyDaysLater = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  const expiringContracts = await prisma.employee.findMany({
    where: {
      status: 'ACTIVE',
      contractEndDate: {
        gte: now,
        lte: thirtyDaysLater,
      },
    },
    orderBy: { contractEndDate: 'asc' },
  });

  // 3. 试用期满2个月（转正前1个月）预警
  const activeEmployees = await prisma.employee.findMany({
    where: { status: 'ACTIVE' },
  });

  const probationWarnings = activeEmployees.filter(emp => {
    if (!emp.hireDate) return false;
    const hire = new Date(emp.hireDate);
    const probation = emp.probationMonths ?? 3;
    
    // 预警开始时间 (转正前1个月)
    const warnStart = new Date(hire);
    warnStart.setMonth(warnStart.getMonth() + Math.max(0, probation - 1));
    
    // 预计转正时间
    const regularDate = new Date(hire);
    regularDate.setMonth(regularDate.getMonth() + probation);
    
    return now >= warnStart && now < regularDate;
  }).map(emp => {
    const hire = new Date(emp.hireDate!);
    const regularDate = new Date(hire);
    regularDate.setMonth(regularDate.getMonth() + (emp.probationMonths ?? 3));
    return {
      ...emp,
      regularDateFormatted: regularDate.toLocaleDateString(),
    };
  });

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      
      {/* 头部欢迎 */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">智能化 HR 系统控制台</h1>
          <p className="text-sm text-gray-500 mt-1">欢迎回来，超级管理员！系统已实时同步最新静态考勤台历及花名册快照数据。</p>
        </div>
        <Link 
          href="/system/employees" 
          className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition text-sm font-medium"
        >
          查看花名册 &rarr;
        </Link>
      </div>

      {/* 核心指标仪表盘 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="text-sm font-medium text-gray-500">在职员工总数</div>
          <div className="mt-2 text-3xl font-bold text-gray-900">{totalActive} 人</div>
          <div className="mt-2 text-xs text-green-600">全部正常录入档案</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="text-sm font-medium text-gray-500">离职已归档人员</div>
          <div className="mt-2 text-3xl font-bold text-red-600">{totalResigned} 人</div>
          <div className="mt-2 text-xs text-gray-400">已打下全量快照归档并清结调休</div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="text-sm font-medium text-gray-500">免考勤高管/销售白名单</div>
          <div className="mt-2 text-3xl font-bold text-blue-600">{totalExempt} 人</div>
          <div className="mt-2 text-xs text-blue-500">考勤清算时豁免罚金</div>
        </div>
      </div>

      {/* 智能高亮预警模块 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* 1. 试用期到期预警 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between border-b pb-3 mb-4">
            <h3 className="font-bold text-gray-800 flex items-center">
              <span className="w-2.5 h-2.5 rounded-full bg-yellow-500 mr-2"></span>
              试用期满2个月 (转正前1月预警)
            </h3>
            <span className="px-2 py-0.5 rounded bg-yellow-100 text-yellow-800 text-xs font-semibold">
              共 {probationWarnings.length} 人
            </span>
          </div>

          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
            {probationWarnings.length > 0 ? (
              probationWarnings.map(emp => (
                <div key={emp.id} className="p-3 bg-yellow-50 rounded border border-yellow-100 flex justify-between items-center text-sm">
                  <div>
                    <span className="font-semibold text-gray-900">{emp.name}</span>
                    <span className="text-xs text-gray-400 ml-2 font-mono">{emp.jobNumber}</span>
                    <div className="text-xs text-gray-500 mt-1">
                      入职时间: {emp.hireDate ? new Date(emp.hireDate).toLocaleDateString() : '--'}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-yellow-700 bg-white px-2 py-1 rounded border border-yellow-200 font-medium">
                      预计转正: {emp.regularDateFormatted}
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-400 text-sm">
                目前无符合预警要求的试用期员工。
              </div>
            )}
          </div>
        </div>

        {/* 2. 合同到期预警 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between border-b pb-3 mb-4">
            <h3 className="font-bold text-gray-800 flex items-center">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 mr-2"></span>
              劳动合同到期前1月预警
            </h3>
            <span className="px-2 py-0.5 rounded bg-red-100 text-red-800 text-xs font-semibold">
              共 {expiringContracts.length} 人
            </span>
          </div>

          <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
            {expiringContracts.length > 0 ? (
              expiringContracts.map(emp => (
                <div key={emp.id} className="p-3 bg-red-50 rounded border border-red-100 flex justify-between items-center text-sm">
                  <div>
                    <span className="font-semibold text-gray-900">{emp.name}</span>
                    <span className="text-xs text-gray-400 ml-2 font-mono">{emp.jobNumber}</span>
                    <div className="text-xs text-gray-500 mt-1">
                      合同起止: {emp.contractStartDate ? new Date(emp.contractStartDate).toLocaleDateString() : '--'} ~ {emp.contractEndDate ? new Date(emp.contractEndDate).toLocaleDateString() : '--'}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-red-700 bg-white px-2 py-1 rounded border border-red-200 font-medium">
                      合同即将到期
                    </span>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-400 text-sm">
                目前没有合同在1个月内到期的员工。
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
