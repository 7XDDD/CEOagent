import { getCustomFields } from '@/actions/customField';
import ConfigClient from './ConfigClient';

export const metadata = {
  title: '字段三要素配置 - 智能化HR系统',
};

export default async function ConfigPage() {
  const result = await getCustomFields();
  const fields = result.success ? (result.data ?? []) : [];

  return <ConfigClient initialFields={fields} />;
}
