'use client';

import { useState, useEffect } from 'react';
import { getMonthlySummaryList } from '@/actions/attendance';
import ExcelJS from 'exceljs';

export default function SummaryClient() {
  const [selectedMonth, setSelectedMonth] = useState('2026-05');
  const [summaryData, setSummaryData] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchSummary = async (month: string) => {
    setLoading(true);
    const res = await getMonthlySummaryList(month);
    if (res.success && res.data) {
      setSummaryData(res.data);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchSummary(selectedMonth);
  }, [selectedMonth]);

  // 模糊检索
  const filteredData = summaryData.filter(item => 
    item.name.includes(searchQuery) || item.jobNumber.includes(searchQuery)
  );

  // 1:1 Excel 模板导出逻辑 (客户端使用 exceljs 导出)
  const handleExportExcel = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(`${selectedMonth}月考勤表`);

    // 设置列宽
    worksheet.columns = [
      { width: 8 },   // A: 序号
      { width: 15 },  // B: 部门
      { width: 12 },  // C: 姓名
      { width: 15 },  // D: 岗位
      { width: 15 },  // E: 入职时间
      { width: 15 },  // F: 离职时间
      { width: 12 },  // G: 应出勤天数
      { width: 10 },  // H: 未到岗
      { width: 12 },  // I: 事假（小时）
      { width: 10 },  // J: 病假
      { width: 15 },  // K: 迟到/早退/缺卡次数
      { width: 25 },  // L: 迟到/早退/缺卡扣除缺勤（小时）
      { width: 10 },  // M: 旷工
      { width: 10 },  // N: 年休假
      { width: 10 },  // O: 调休假
      { width: 10 },  // P: 婚假
      { width: 12 },  // Q: 产假/陪产假
      { width: 12 },  // R: 产检假
      { width: 10 },  // S: 丧假
      { width: 10 },  // T: 居家办公
      { width: 10 },  // U: 外出公干
      { width: 10 },  // V: 出差
      { width: 15 },  // W: 实际出勤天数
      { width: 20 },  // X: 备注
    ];

    // 第一行: 标题
    const titleRow = worksheet.addRow([`链宇HR系统 ${selectedMonth} 月度考勤表`]);
    worksheet.mergeCells('A1:X1');
    titleRow.getCell(1).font = { name: 'Microsoft YaHei', size: 16, bold: true };
    titleRow.getCell(1).alignment = { vertical: 'middle', horizontal: 'center' };
    titleRow.height = 40;

    // 第二行: 一级表头
    const r2 = worksheet.addRow([
      '序号', '部门', '姓名', '岗位', '入职时间', '离职时间', '应出勤\n天数', 
      '扣薪假（天）', '', '', '', '', '', 
      '带薪假（天）', '', '', '', '', '', 
      '其他（天）', '', '', 
      '实际出勤天数', '备注'
    ]);
    r2.height = 25;

    // 第三行: 二级表头
    const r3 = worksheet.addRow([
      '', '', '', '', '', '', '', 
      '未到岗', '事假\n（小时）', '病假', '迟到/早退/缺卡', '', '旷工', 
      '年休假', '调休假', '婚假', '产假/\n陪产假', '产检假', '丧假', 
      '居家\n办公', '外出\n公干', '出差', 
      '', ''
    ]);
    r3.height = 25;

    // 第四行: 三级表头
    const r4 = worksheet.addRow([
      '', '', '', '', '', '', '', '', '', '', 
      '次数', '扣除\n缺勤\n（小时）', 
      '', '', '', '', '', '', '', '', '', '', '', ''
    ]);
    r4.height = 25;

    // 单元格垂直合并 (序号 ~ 应出勤天数)
    worksheet.mergeCells('A2:A4');
    worksheet.mergeCells('B2:B4');
    worksheet.mergeCells('C2:C4');
    worksheet.mergeCells('D2:D4');
    worksheet.mergeCells('E2:E4');
    worksheet.mergeCells('F2:F4');
    worksheet.mergeCells('G2:G4');

    // 单元格水平合并
    worksheet.mergeCells('H2:M2'); // 扣薪假（天）
    worksheet.mergeCells('N2:S2'); // 带薪假（天）
    worksheet.mergeCells('T2:V2'); // 其他（天）

    // 单元格垂直合并 (实际出勤天数、备注)
    worksheet.mergeCells('W2:W4');
    worksheet.mergeCells('X2:X4');

    // 单元格二级表头垂直/水平合并
    worksheet.mergeCells('H3:H4'); // 未到岗
    worksheet.mergeCells('I3:I4'); // 事假（小时）
    worksheet.mergeCells('J3:J4'); // 病假
    worksheet.mergeCells('K3:L3'); // 迟到/早退/缺卡
    worksheet.mergeCells('M3:M4'); // 旷工
    worksheet.mergeCells('N3:N4'); // 年休假
    worksheet.mergeCells('O3:O4'); // 调休假
    worksheet.mergeCells('P3:P4'); // 婚假
    worksheet.mergeCells('Q3:Q4'); // 产假/陪产假
    worksheet.mergeCells('R3:R4'); // 产检假
    worksheet.mergeCells('S3:S4'); // 丧假
    worksheet.mergeCells('T3:T4'); // 居家办公
    worksheet.mergeCells('U3:U4'); // 外出公干
    worksheet.mergeCells('V3:V4'); // 出差

    // 格式化表头样式
    const headerRows = [r2, r3, r4];
    headerRows.forEach((row) => {
      row.eachCell({ includeEmpty: true }, (cell) => {
        cell.font = { name: 'Microsoft YaHei', size: 9, bold: true, color: { argb: 'FF333333' } };
        cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: 'FFF2F2F2' },
        };
        cell.border = {
          top: { style: 'thin', color: { argb: 'FFD3D3D3' } },
          left: { style: 'thin', color: { argb: 'FFD3D3D3' } },
          bottom: { style: 'thin', color: { argb: 'FFD3D3D3' } },
          right: { style: 'thin', color: { argb: 'FFD3D3D3' } },
        };
      });
    });

    // 添加数据行
    filteredData.forEach((item, index) => {
      const row = worksheet.addRow([
        index + 1,
        item.department || '',
        item.name,
        item.position || '',
        item.hireDate ? new Date(item.hireDate).toLocaleDateString() : '',
        item.resignedDate ? new Date(item.resignedDate).toLocaleDateString() : '',
        item.shouldWorkDays,
        item.absentDays,
        item.personalLeaveHours,
        item.sickLeaveDays,
        item.lateEarlyCount,
        item.lateEarlyDeductHours,
        item.absenteeismDays,
        item.annualLeaveDays,
        item.compLeaveDays,
        item.marriageLeaveDays,
        item.maternityLeaveDays,
        item.maternityCheckDays,
        item.bereavementLeaveDays,
        item.wfhDays,
        item.outworkDays,
        item.travelDays,
        item.actualWorkDays,
        item.notes || '',
      ]);

      row.height = 20;
      row.eachCell({ includeEmpty: true }, (cell) => {
        cell.font = { name: 'Microsoft YaHei', size: 10 };
        cell.alignment = { vertical: 'middle', horizontal: 'center' };
        cell.border = {
          top: { style: 'thin', color: { argb: 'FFEAEAEA' } },
          left: { style: 'thin', color: { argb: 'FFEAEAEA' } },
          bottom: { style: 'thin', color: { argb: 'FFEAEAEA' } },
          right: { style: 'thin', color: { argb: 'FFEAEAEA' } },
        };
      });
    });

    // 生成二进制流下载
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `链宇HR系统_${selectedMonth}月考勤表.xlsx`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      
      {/* 头部信息 */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">月度考勤表汇总看板</h1>
          <p className="text-sm text-gray-500 mt-1">展示与导出与链宇官方标准考勤模板 24 字段完全对齐的数据清单。</p>
        </div>
        <div className="flex items-center space-x-3">
          <input 
            type="month"
            value={selectedMonth}
            onChange={e => setSelectedMonth(e.target.value)}
            className="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
          />
          <button 
            onClick={handleExportExcel}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded transition text-sm font-medium"
          >
            📥 导出本月考勤表
          </button>
        </div>
      </div>

      {/* 搜索过滤栏 */}
      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 flex justify-between items-center">
        <input 
          type="text"
          placeholder="输入姓名或工号进行过滤检索..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="w-1/3 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
        />
        <a 
          href="/system/calendar/import"
          className="text-sm text-indigo-600 hover:text-indigo-900 font-semibold"
        >
          &larr; 前往考勤与假勤数据导入中心
        </a>
      </div>

      {/* 滚动表格展现 */}
      <div className="bg-white shadow rounded-lg border border-gray-200 overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 text-xs text-center">
          <thead className="bg-gray-50 font-bold text-gray-700 sticky top-0 z-10 shadow-sm ring-1 ring-gray-200 ring-inset">
            {/* 第一层表头 */}
            <tr>
              <th rowSpan={3} className="px-2 py-3 border-r border-b">序号</th>
              <th rowSpan={3} className="px-2 py-3 border-r border-b">部门</th>
              <th rowSpan={3} className="px-2 py-3 border-r border-b">姓名</th>
              <th rowSpan={3} className="px-2 py-3 border-r border-b">工号</th>
              <th rowSpan={3} className="px-2 py-3 border-r border-b">岗位</th>
              <th rowSpan={3} className="px-2 py-3 border-r border-b">入职时间</th>
              <th rowSpan={3} className="px-2 py-3 border-r border-b">离职时间</th>
              <th rowSpan={3} className="px-2 py-3 border-r border-b">应出勤<br/>天数</th>
              
              <th colSpan={6} className="px-2 py-2 border-r border-b bg-red-50 text-red-800">扣薪假（天）</th>
              <th colSpan={6} className="px-2 py-2 border-r border-b bg-green-50 text-green-800">带薪假（天）</th>
              <th colSpan={3} className="px-2 py-2 border-r border-b bg-indigo-50 text-indigo-800">其他（天）</th>
              <th colSpan={2} className="px-2 py-2 border-r border-b bg-blue-50 text-blue-800">加班（小时）</th>
              
              <th rowSpan={3} className="px-2 py-3 border-r border-b">实际出勤<br/>天数</th>
              <th rowSpan={3} className="px-2 py-3 border-b min-w-[120px]">备注</th>
            </tr>
            {/* 第二层表头 */}
            <tr>
              {/* 扣薪假子项 */}
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-red-50/80 text-red-800">未到岗</th>
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-red-50/80 text-red-800">事假<br/>(小时)</th>
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-red-50/80 text-red-800">病假</th>
              <th colSpan={2} className="px-2 py-2 border-r border-b bg-red-50/80 text-red-800">迟到/早退/缺卡</th>
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-red-50/80 text-red-800">旷工</th>
              
              {/* 带薪假子项 */}
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-green-50/80 text-green-800">年休假</th>
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-green-50/80 text-green-800">调休假</th>
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-green-50/80 text-green-800">婚假</th>
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-green-50/80 text-green-800">产假/<br/>陪产假</th>
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-green-50/80 text-green-800">产检假</th>
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-green-50/80 text-green-800">丧假</th>

              {/* 其他子项 */}
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-indigo-50/80 text-indigo-800">居家<br/>办公</th>
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-indigo-50/80 text-indigo-800">外出<br/>公干</th>
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-indigo-50/80 text-indigo-800">出差</th>

              {/* 加班子项 */}
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-blue-50/80 text-blue-800">法定<br/>加班</th>
              <th rowSpan={2} className="px-2 py-2 border-r border-b bg-blue-50/80 text-blue-800">周末<br/>加班</th>
            </tr>
            {/* 第三层表头 */}
            <tr>
              <th className="px-2 py-2 border-r border-b bg-red-50/60 text-red-800 font-normal">次数</th>
              <th className="px-2 py-2 border-r border-b bg-red-50/60 text-red-800 font-normal">扣除缺勤<br/>(小时)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {loading ? (
              <tr>
                <td colSpan={27} className="px-6 py-12 text-center text-gray-500 font-semibold">
                  正在加载汇总报表数据...
                </td>
              </tr>
            ) : filteredData.length > 0 ? (
              filteredData.map((item, index) => (
                <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-2 py-3 border-r border-b font-mono text-gray-400">{index + 1}</td>
                  <td className="px-2 py-3 border-r border-b text-gray-700">{item.department || '-'}</td>
                  <td className="px-2 py-3 border-r border-b font-bold text-gray-900">{item.name}</td>
                  <td className="px-2 py-3 border-r border-b font-mono text-gray-500">{item.jobNumber}</td>
                  <td className="px-2 py-3 border-r border-b text-gray-600">{item.position || '-'}</td>
                  <td className="px-2 py-3 border-r border-b text-gray-500">{item.hireDate ? new Date(item.hireDate).toLocaleDateString() : '-'}</td>
                  <td className="px-2 py-3 border-r border-b text-gray-500">{item.resignedDate ? new Date(item.resignedDate).toLocaleDateString() : '-'}</td>
                  <td className="px-2 py-3 border-r border-b font-bold text-gray-900 bg-gray-50/50">{item.shouldWorkDays}</td>
                  
                  <td className="px-2 py-3 border-r border-b font-semibold text-red-700 bg-red-50/30">{item.absentDays}</td>
                  <td className="px-2 py-3 border-r border-b font-semibold text-red-700 bg-red-50/30">{item.personalLeaveHours}</td>
                  <td className="px-2 py-3 border-r border-b font-semibold text-red-700 bg-red-50/30">{item.sickLeaveDays}</td>
                  <td className="px-2 py-3 border-r border-b font-semibold text-red-700 bg-red-50/30">{item.lateEarlyCount}</td>
                  <td className="px-2 py-3 border-r border-b font-semibold text-red-700 bg-red-50/30">{item.lateEarlyDeductHours}</td>
                  <td className="px-2 py-3 border-r border-b font-bold text-red-800 bg-red-50/50">{item.absenteeismDays}</td>
                  
                  <td className="px-2 py-3 border-r border-b font-semibold text-green-700 bg-green-50/30">{item.annualLeaveDays}</td>
                  <td className="px-2 py-3 border-r border-b font-semibold text-green-700 bg-green-50/30">{item.compLeaveDays}</td>
                  <td className="px-2 py-3 border-r border-b font-semibold text-green-700 bg-green-50/30">{item.marriageLeaveDays || 0}</td>
                  <td className="px-2 py-3 border-r border-b font-semibold text-green-700 bg-green-50/30">{item.maternityLeaveDays || 0}</td>
                  <td className="px-2 py-3 border-r border-b font-semibold text-green-700 bg-green-50/30">{item.maternityCheckDays || 0}</td>
                  <td className="px-2 py-3 border-r border-b font-semibold text-green-700 bg-green-50/30">{item.bereavementLeaveDays || 0}</td>
                  
                  <td className="px-2 py-3 border-r border-b font-semibold text-indigo-700 bg-indigo-50/30">{item.wfhDays || 0}</td>
                  <td className="px-2 py-3 border-r border-b font-semibold text-indigo-700 bg-indigo-50/30">{item.outworkDays || 0}</td>
                  <td className="px-2 py-3 border-r border-b font-semibold text-indigo-700 bg-indigo-50/30">{item.travelDays}</td>
                  
                  <td className="px-2 py-3 border-r border-b font-bold text-blue-600 bg-blue-50/30">{item.overtimePayHours || 0}</td>
                  <td className="px-2 py-3 border-r border-b font-bold text-blue-600 bg-blue-50/30">{item.weekendOvertimeHours || 0}</td>
                  
                  <td className="px-2 py-3 border-r border-b font-bold text-emerald-700 bg-emerald-50/50">{item.actualWorkDays}</td>
                  <td className="px-2 py-3 border-b text-gray-400 text-xs italic">{item.notes || '--'}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={27} className="px-6 py-12 text-center text-gray-400">
                  本月暂无核算清洗完结的汇总数据，请在“导入中心”点击一键清洗生成。
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

    </div>
  );
}
