'use client';

import React, { useState, useEffect } from 'react';
import { 
  createOrUpdateProject, 
  deleteProject, 
  getProjectConsultantsAndSow, 
  allocateConsultantWithSow 
} from '@/actions/project';

interface Employee {
  id: string;
  jobNumber: string;
  name: string;
  status: string;
}

interface Project {
  id: string;
  code: string;
  name: string;
  signDate?: string | null;
  startDate: string;
  endDate: string;
  _count?: { mappings: number };
}

interface SOWAllocation {
  month: string;
  plannedDays: number;
}

interface ConsultantSowRow {
  mappingId: string;
  employeeId: string;
  jobNumber: string;
  realName: string;
  consultantName: string;
  monthlySows: SOWAllocation[];
}

interface ProjectsClientProps {
  initialProjects: Project[];
  employees: Employee[];
}

export default function ProjectsClient({ initialProjects, employees }: ProjectsClientProps) {
  const [projects, setProjects] = useState<Project[]>(initialProjects);
  const [msg, setMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Project Modal State
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);
  const [projCode, setProjCode] = useState('');
  const [projName, setProjName] = useState('');
  const [projSignDate, setProjSignDate] = useState('');
  const [projStart, setProjStart] = useState('');
  const [projEnd, setProjEnd] = useState('');
  const [savingProj, setSavingProj] = useState(false);

  // Allocation & SOW Modal State
  const [isAllocModalOpen, setIsAllocModalOpen] = useState(false);
  const [allocTargetProject, setAllocTargetProject] = useState<Project | null>(null);
  const [allocRows, setAllocRows] = useState<ConsultantSowRow[]>([]);
  const [loadingAlloc, setLoadingAlloc] = useState(false);
  
  // New Allocation Input State
  const [newAllocEmpId, setNewAllocEmpId] = useState('');
  const [newAllocAlias, setNewAllocAlias] = useState('');
  const [newAllocSows, setNewAllocSows] = useState<{ month: string; plannedDays: number }[]>([]);
  const [savingAlloc, setSavingAlloc] = useState(false);

  const formatDate = (date: any) => {
    if (!date) return '';
    if (typeof date === 'string') return date.split('T')[0];
    return new Date(date).toISOString().split('T')[0];
  };

  const openNewProject = () => {
    setEditingProjectId(null);
    setProjCode('');
    setProjName('');
    setProjSignDate('');
    setProjStart('');
    setProjEnd('');
    setIsProjectModalOpen(true);
  };

  const openEditProject = (p: Project) => {
    setEditingProjectId(p.id);
    setProjCode(p.code);
    setProjName(p.name);
    setProjSignDate(formatDate(p.signDate));
    // Convert full ISO string to YYYY-MM-DD for date input
    setProjStart(formatDate(p.startDate));
    setProjEnd(formatDate(p.endDate));
    setIsProjectModalOpen(true);
  };

  const handleSaveProject = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProj(true);
    setMsg(null);
    const res = await createOrUpdateProject(editingProjectId, {
      code: projCode,
      name: projName,
      signDate: projSignDate ? new Date(projSignDate) : null,
      startDate: new Date(projStart),
      endDate: new Date(projEnd)
    });
    if (res.success) {
      setMsg({ type: 'success', text: '项目保存成功！' });
      setIsProjectModalOpen(false);
      window.location.reload();
    } else {
      setMsg({ type: 'error', text: res.message || '保存失败' });
    }
    setSavingProj(false);
  };

  const handleDeleteProject = async (id: string) => {
    if (!confirm('警告：删除项目将同时级联删除它关联的所有 PMO 映射和 SOW/出勤人天数据！确认继续？')) return;
    const res = await deleteProject(id);
    if (res.success) {
      window.location.reload();
    } else {
      setMsg({ type: 'error', text: res.message || '删除失败' });
    }
  };

  const openAllocationModal = async (p: Project) => {
    setAllocTargetProject(p);
    setIsAllocModalOpen(true);
    setLoadingAlloc(true);
    
    // reset new input forms
    setNewAllocEmpId('');
    setNewAllocAlias('');
    setNewAllocSows([]);

    // fetch existing consultants & sows
    const res = await getProjectConsultantsAndSow(p.code);
    if (res.success && res.data) {
      setAllocRows(res.data as ConsultantSowRow[]);
    }
    setLoadingAlloc(false);
  };

  const handleSaveNewAllocation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!allocTargetProject || !newAllocEmpId || !newAllocAlias) return;
    setSavingAlloc(true);
    setMsg(null);

    // Use dynamic monthlySows
    const monthlySows = newAllocSows.filter(s => s.month && s.month.length === 7);

    const res = await allocateConsultantWithSow(
      allocTargetProject.code,
      newAllocEmpId,
      newAllocAlias,
      monthlySows
    );

    if (res.success) {
      setMsg({ type: 'success', text: '顾问 SOW 预估工时分配成功！' });
      // refresh modal list
      const fresh = await getProjectConsultantsAndSow(allocTargetProject.code);
      if (fresh.success && fresh.data) {
        setAllocRows(fresh.data as ConsultantSowRow[]);
      }
      // reset forms
      setNewAllocEmpId('');
      setNewAllocAlias('');
      setNewAllocSows([]);
    } else {
      setMsg({ type: 'error', text: res.message || '分配失败' });
    }
    setSavingAlloc(false);
  };

  // Dynamic row changes
  const handleSowMonthChange = (index: number, val: string) => {
    const updated = [...newAllocSows];
    updated[index].month = val;
    setNewAllocSows(updated);
  };

  const handleSowDaysChange = (index: number, val: string) => {
    const newVal = parseFloat(val);
    const updated = [...newAllocSows];
    updated[index].plannedDays = isNaN(newVal) ? 0 : newVal;
    setNewAllocSows(updated);
  };

  const addSowRow = () => {
    setNewAllocSows([...newAllocSows, { month: '', plannedDays: 0 }]);
  };

  const removeSowRow = (index: number) => {
    const updated = [...newAllocSows];
    updated.splice(index, 1);
    setNewAllocSows(updated);
  };

  // Compute helper to get planned days for an existing row given a month
  const getExistingSowForMonth = (row: ConsultantSowRow, monthStr: string) => {
    const s = row.monthlySows.find(m => m.month === monthStr);
    return s ? s.plannedDays : '-';
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-blue-700 to-indigo-800 rounded-2xl shadow-xl p-6 text-white flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">项目主数据与 SOW 计划</h1>
          <p className="text-blue-100 text-sm mt-2 max-w-3xl">
            维护底层项目生命周期（启动/结束时间），并在项目级别统一规划各参与顾问的【多月连贯 SOW 预估出勤人天】，彻底取代之前单月录入的繁琐流程。
          </p>
        </div>
        <button 
          onClick={openNewProject}
          className="bg-white text-indigo-700 px-6 py-3 rounded-lg font-bold shadow-md hover:bg-blue-50 transition"
        >
          + 注册新项目
        </button>
      </div>

      {msg && (
        <div className={`p-4 rounded-xl shadow-sm border ${
          msg.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-rose-50 border-rose-200 text-rose-800'
        } transition-all duration-300`}>
          {msg.text}
        </div>
      )}

      {/* Projects List */}
      <div className="bg-white border rounded-2xl shadow-sm overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">项目编号 (Code)</th>
              <th className="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">项目名称</th>
              <th className="px-6 py-4 text-left text-xs font-bold text-slate-500 uppercase">生命周期 (Start - End)</th>
              <th className="px-6 py-4 text-center text-xs font-bold text-slate-500 uppercase">已关联顾问数</th>
              <th className="px-6 py-4 text-right text-xs font-bold text-slate-500 uppercase">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 text-sm">
            {projects.length === 0 ? (
              <tr>
                <td colSpan={5} className="text-center py-16 text-gray-400">
                  📦 暂无项目主数据，请点击右上角注册新项目。
                </td>
              </tr>
            ) : (
              projects.map(p => (
                <tr key={p.id} className="hover:bg-slate-50 transition">
                  <td className="px-6 py-4 font-mono font-bold text-indigo-700">{p.code}</td>
                  <td className="px-6 py-4 font-bold text-slate-800">{p.name}</td>
                  <td className="px-6 py-4 font-mono text-gray-500">
                    {formatDate(p.startDate)} ~ {formatDate(p.endDate)}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className="bg-indigo-50 text-indigo-700 font-bold px-3 py-1 rounded-full">
                      {p._count?.mappings || 0} 人
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right space-x-3">
                    <button 
                      onClick={() => openAllocationModal(p)}
                      className="text-emerald-600 hover:text-emerald-800 font-bold"
                    >
                      人员与SOW规划
                    </button>
                    <span className="text-gray-300">|</span>
                    <button 
                      onClick={() => openEditProject(p)}
                      className="text-blue-600 hover:text-blue-800 font-bold"
                    >
                      编辑
                    </button>
                    <span className="text-gray-300">|</span>
                    <button 
                      onClick={() => handleDeleteProject(p.id)}
                      className="text-rose-500 hover:text-rose-700 font-bold"
                    >
                      删除
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* 1. Project Edit Modal */}
      {isProjectModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl p-6 relative">
            <button onClick={() => setIsProjectModalOpen(false)} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
              ✕
            </button>
            <h2 className="text-xl font-bold text-gray-800 mb-6">
              {editingProjectId ? '编辑项目信息' : '注册新项目'}
            </h2>
            <form onSubmit={handleSaveProject} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">项目编号 (唯一, 例如 PRJ-2026-X)</label>
                <input required type="text" value={projCode} onChange={e => setProjCode(e.target.value)} disabled={!!editingProjectId} className="block w-full border rounded-lg p-2.5 bg-gray-50 disabled:opacity-50" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">项目名称</label>
                <input required type="text" value={projName} onChange={e => setProjName(e.target.value)} className="block w-full border rounded-lg p-2.5 bg-gray-50" />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-600 mb-1">签约时间 (选填)</label>
                <input type="date" value={projSignDate} onChange={e => setProjSignDate(e.target.value)} className="block w-full border rounded-lg p-2.5 bg-gray-50 font-mono" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-600 mb-1">项目启动时间</label>
                  <input required type="date" value={projStart} onChange={e => setProjStart(e.target.value)} className="block w-full border rounded-lg p-2.5 bg-gray-50 font-mono" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-600 mb-1">预估结束时间</label>
                  <input required type="date" value={projEnd} onChange={e => setProjEnd(e.target.value)} className="block w-full border rounded-lg p-2.5 bg-gray-50 font-mono" />
                </div>
              </div>
              <button disabled={savingProj} type="submit" className="w-full mt-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 rounded-xl transition">
                {savingProj ? '保存中...' : '提交保存'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 2. Allocation & SOW Modal */}
      {isAllocModalOpen && allocTargetProject && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-6xl max-h-[90vh] flex flex-col rounded-2xl shadow-2xl relative overflow-hidden">
            
            {/* Modal Header */}
            <div className="bg-slate-50 border-b p-6 flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-slate-800">
                  {allocTargetProject.name} <span className="text-indigo-600 font-mono text-lg ml-2">({allocTargetProject.code})</span>
                </h2>
                <p className="text-sm text-gray-500 font-mono mt-1">
                  生命周期展开：{formatDate(allocTargetProject.startDate)} ➡️ {formatDate(allocTargetProject.endDate)}
                </p>
              </div>
              <button onClick={() => setIsAllocModalOpen(false)} className="bg-gray-200 text-gray-700 hover:bg-gray-300 font-bold px-4 py-2 rounded-lg">
                关闭
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-8 bg-slate-50/50">
              
              {/* Add New Allocation Section */}
              <div className="bg-white border rounded-xl shadow-sm p-5">
                <h3 className="text-sm font-bold text-indigo-700 border-b pb-2 mb-4 flex items-center">
                  <span className="text-lg mr-2">➕</span> 为项目新增/编辑顾问，并预排 SOW 工时
                </h3>
                <form onSubmit={handleSaveNewAllocation} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-600 mb-1">选择真实在职顾问</label>
                      <select 
                        required 
                        value={newAllocEmpId} 
                        onChange={e => {
                          const eid = e.target.value;
                          setNewAllocEmpId(eid);
                          const existing = allocRows.find(r => r.employeeId === eid);
                          if (existing) {
                            setNewAllocAlias(existing.consultantName);
                            setNewAllocSows(existing.monthlySows.map(s => ({ ...s })));
                          } else {
                            setNewAllocAlias('');
                            setNewAllocSows([{ month: '', plannedDays: 0 }]);
                          }
                        }}
                        className="block w-full border rounded-lg p-2.5 bg-gray-50"
                      >  <option value="">-- 请选择员工 --</option>
                        {employees.filter(e => e.status === 'ACTIVE').map(emp => (
                          <option key={emp.id} value={emp.id}>{emp.name} ({emp.jobNumber})</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-600 mb-1">项目对外代称/英文名</label>
                      <input required type="text" placeholder="例如: Consultant-A / John" value={newAllocAlias} onChange={e => setNewAllocAlias(e.target.value)} className="block w-full border rounded-lg p-2.5 bg-gray-50" />
                    </div>
                  </div>
                  
                  {/* SOW Months Dynamic List Input */}
                  <div className="pt-2">
                    <div className="flex justify-between items-center mb-2">
                      <label className="block text-xs font-bold text-gray-600">手动规划该顾问各月度的预估出勤天数 (SOW)</label>
                      <button 
                        type="button" 
                        onClick={addSowRow}
                        className="text-xs bg-indigo-100 text-indigo-700 px-3 py-1 rounded hover:bg-indigo-200 font-bold"
                      >
                        + 添加月份
                      </button>
                    </div>
                    {newAllocSows.length === 0 ? (
                      <div className="text-xs text-gray-400 py-2 border-b-2 border-indigo-50">未添加任何月份的规划</div>
                    ) : (
                      <div className="space-y-2 pb-2 border-b-2 border-indigo-50 max-h-48 overflow-y-auto pr-2">
                        {newAllocSows.map((sow, idx) => (
                          <div key={idx} className="flex items-center space-x-2">
                            <input 
                              type="month"
                              required
                              value={sow.month}
                              onChange={e => handleSowMonthChange(idx, e.target.value)}
                              className="border rounded-md p-1.5 text-xs font-mono text-gray-700 flex-1"
                            />
                            <div className="relative w-24">
                              <input 
                                type="number" 
                                min="0" max="31" step="0.5" 
                                required
                                value={sow.plannedDays} 
                                onChange={e => handleSowDaysChange(idx, e.target.value)} 
                                className="w-full border rounded-md p-1.5 text-center font-bold text-indigo-700 bg-indigo-50/30 focus:ring-2 ring-indigo-300 outline-none"
                              />
                            </div>
                            <span className="text-xs text-gray-500">天</span>
                            <button 
                              type="button" 
                              onClick={() => removeSowRow(idx)}
                              className="text-rose-500 hover:text-rose-700 px-2"
                            >
                              ✕
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex justify-end pt-2">
                    <button disabled={savingAlloc} type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-6 py-2.5 rounded-lg shadow disabled:opacity-50">
                      {savingAlloc ? '保存中...' : '提交规划并下发'}
                    </button>
                  </div>
                </form>
              </div>

              {/* Existing Allocations Data Table */}
              <div>
                <h3 className="text-sm font-bold text-gray-700 mb-3 pl-1">项目已挂载人员 & 历史 SOW 阵列盘</h3>
                <div className="bg-white border rounded-xl overflow-hidden shadow-sm overflow-x-auto">
                  {loadingAlloc ? (
                    <div className="py-12 text-center text-gray-400">加载中...</div>
                  ) : allocRows.length === 0 ? (
                    <div className="py-12 text-center text-gray-400">该项目目前没有分配任何顾问。</div>
                  ) : (() => {
                    const allMonthsSet = new Set<string>();
                    allocRows.forEach(r => r.monthlySows.forEach(s => allMonthsSet.add(s.month)));
                    const projectMonths = Array.from(allMonthsSet).sort();
                    return (
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-slate-100">
                          <tr>
                            <th className="px-4 py-3 text-left text-xs font-bold text-slate-600 sticky left-0 bg-slate-100 z-10 border-r shadow-[2px_0_4px_rgba(0,0,0,0.02)]">
                              顾问代称 (真实姓名)
                            </th>
                            {projectMonths.map(m => (
                              <th key={m} className="px-2 py-3 text-center text-[10px] font-bold text-slate-500 font-mono min-w-[60px]">
                                {m}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200 text-sm">
                          {allocRows.map(row => (
                            <tr key={row.mappingId} className="hover:bg-blue-50/30">
                              <td className="px-4 py-3 whitespace-nowrap sticky left-0 bg-white border-r shadow-[2px_0_4px_rgba(0,0,0,0.02)]">
                                <span className="font-bold text-slate-800">{row.consultantName}</span>
                                <span className="text-[10px] text-gray-400 ml-1 block">
                                  {row.realName} ({row.jobNumber})
                                </span>
                              </td>
                              {projectMonths.map(m => {
                                const val = getExistingSowForMonth(row, m);
                                return (
                                  <td key={m} className="px-2 py-3 text-center font-mono font-bold text-indigo-600 bg-white group-hover:bg-transparent">
                                    {val}
                                  </td>
                                );
                              })}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    );
                  })()}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
