'use client';

import React, { useState, useEffect } from 'react';
import { 
  getEmployeeAnomalies, 
  submitAnomalyAppeal, 
  approveAnomalyAppeal, 
  rejectAnomalyAppeal,
  createMakeUpApproval,
  generateMonthlySummaryForEmployee
} from '@/actions/attendance';

interface Employee {
  id: string;
  name: string;
  jobNumber: string;
  status: string;
  exemptAttendance: boolean;
}

interface Anomaly {
  id: string;
  date: Date | string;
  type: string;
  details: string | null;
  deductHours: number;
  appealStatus: string;
  appealReason: string | null;
  appealVoucher: string | null;
  managerComment: string | null;
}

interface AppealsClientProps {
  employees: Employee[];
  initialPendingAppeals: any[];
}

export default function AppealsClient({ employees, initialPendingAppeals }: AppealsClientProps) {
  const [activeTab, setActiveTab] = useState<'employee' | 'manager'>('employee');
  
  // Employee View State
  const [selectedEmpId, setSelectedEmpId] = useState<string>('');
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-06');
  const [anomalies, setAnomalies] = useState<Anomaly[]>([]);
  const [loadingAnomalies, setLoadingAnomalies] = useState<boolean>(false);
  const [msg, setMsg] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // Manager View State
  const [pendingAppeals, setPendingAppeals] = useState<any[]>(initialPendingAppeals);
  const [managerComment, setManagerComment] = useState<string>('');
  
  // Appeal Modal State
  const [appealModalOpen, setAppealModalOpen] = useState<boolean>(false);
  const [targetAnomaly, setTargetAnomaly] = useState<Anomaly | null>(null);
  const [appealReason, setAppealReason] = useState<string>('');
  const [appealVoucher, setAppealVoucher] = useState<string>('');
  const [submittingAppeal, setSubmittingAppeal] = useState<boolean>(false);

  // Simulation: Add Make Up Card
  const [makeUpDate, setMakeUpDate] = useState<string>('');
  const [simulatingMakeUp, setSimulatingMakeUp] = useState<boolean>(false);

  // Load selected employee's anomalies
  const loadEmployeeAnomalies = async () => {
    if (!selectedEmpId) return;
    setLoadingAnomalies(true);
    const res = await getEmployeeAnomalies(selectedEmpId, selectedMonth);
    if (res.success && res.data) {
      setAnomalies(res.data as any[]);
    } else {
      setMsg({ type: 'error', text: res.message || '加载考勤异常失败' });
    }
    setLoadingAnomalies(false);
  };

  useEffect(() => {
    if (selectedEmpId) {
      loadEmployeeAnomalies();
    } else if (employees.length > 0) {
      setSelectedEmpId(employees[0].id);
    }
  }, [selectedEmpId, selectedMonth, employees]);

  // Handle employee selector load
  useEffect(() => {
    if (employees.length > 0 && !selectedEmpId) {
      setSelectedEmpId(employees[0].id);
    }
  }, [employees]);

  // Trigger reload of pending approvals
  const refreshPendingAppeals = async () => {
    const res = await fetch('/api/pending-appeals').then(r => r.json()).catch(() => null);
    if (res && res.success) {
      setPendingAppeals(res.data);
    } else {
      // Fallback: reload page window
      window.location.reload();
    }
  };

  // Submit Appeal Action
  const handleOpenAppealModal = (anomaly: Anomaly) => {
    setTargetAnomaly(anomaly);
    setAppealReason('');
    setAppealVoucher('');
    setAppealModalOpen(true);
  };

  const handleSubmitAppeal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetAnomaly) return;
    setSubmittingAppeal(true);
    setMsg(null);
    
    const res = await submitAnomalyAppeal(targetAnomaly.id, appealReason, appealVoucher);
    if (res.success) {
      setMsg({ type: 'success', text: '申诉已提交，等待主管审批！' });
      setAppealModalOpen(false);
      loadEmployeeAnomalies();
      refreshPendingAppeals();
    } else {
      setMsg({ type: 'error', text: res.message || '提交申诉失败' });
    }
    setSubmittingAppeal(false);
  };

  // Approve / Reject actions
  const handleApprove = async (anomalyId: string) => {
    setMsg(null);
    const res = await approveAnomalyAppeal(anomalyId, managerComment || '同意冲抵异常工时');
    if (res.success) {
      setMsg({ type: 'success', text: '已批准申诉，对应扣减工时已对冲，并已重新计算该月汇总！' });
      setManagerComment('');
      loadEmployeeAnomalies();
      // Reload pending list
      window.location.reload();
    } else {
      setMsg({ type: 'error', text: res.message || '审批通过操作失败' });
    }
  };

  const handleReject = async (anomalyId: string) => {
    if (!managerComment) {
      alert('驳回时必须填写审批评语！');
      return;
    }
    setMsg(null);
    const res = await rejectAnomalyAppeal(anomalyId, managerComment);
    if (res.success) {
      setMsg({ type: 'success', text: '已驳回申诉！' });
      setManagerComment('');
      loadEmployeeAnomalies();
      window.location.reload();
    } else {
      setMsg({ type: 'error', text: res.message || '审批驳回操作失败' });
    }
  };

  // Simulate Make-Up Card Creation
  const handleSimulateMakeUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmpId || !makeUpDate) return;
    setSimulatingMakeUp(true);
    setMsg(null);

    const emp = employees.find(e => e.id === selectedEmpId);
    const res = await createMakeUpApproval(selectedEmpId, makeUpDate);
    if (res.success) {
      setMsg({ type: 'success', text: '模拟成功！审批通过的补打卡已录入系统，正在重新计算考勤表...' });
      if (emp) {
        await generateMonthlySummaryForEmployee(emp.jobNumber, selectedMonth);
      }
      loadEmployeeAnomalies();
      setMakeUpDate('');
    } else {
      setMsg({ type: 'error', text: res.message || '模拟补打卡审批失败' });
    }
    setSimulatingMakeUp(false);
  };

  const handleRecalculate = async () => {
    if (!selectedEmpId) return;
    const emp = employees.find(e => e.id === selectedEmpId);
    if (!emp) return;
    setLoadingAnomalies(true);
    setMsg(null);
    const res = await generateMonthlySummaryForEmployee(emp.jobNumber, selectedMonth);
    if (res.success) {
      setMsg({ type: 'success', text: '已成功手动触发该月考勤重跑与汇总刷新！' });
      loadEmployeeAnomalies();
    } else {
      setMsg({ type: 'error', text: res.message || '计算失败' });
    }
    setLoadingAnomalies(false);
  };

  // Date limit checker: within 3 days
  const isAppealPeriodValid = (dateVal: Date | string) => {
    const anomalyDate = new Date(dateVal);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - anomalyDate.getTime());
    const diffDays = diffTime / (1000 * 60 * 60 * 24);
    return diffDays <= 3.0;
  };

  const getDaysLeftText = (dateVal: Date | string) => {
    const anomalyDate = new Date(dateVal);
    const now = new Date();
    const diffTime = now.getTime() - anomalyDate.getTime();
    const diffDays = diffTime / (1000 * 60 * 60 * 24);
    if (diffDays < 0) return '未到日期';
    if (diffDays > 3.0) return '已超限期';
    const remain = 3.0 - diffDays;
    if (remain < 1) {
      return `仅剩 ${Math.ceil(remain * 24)} 小时`;
    }
    return `剩 ${remain.toFixed(1)} 天`;
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      
      {/* 头部标题与渐变底纹 */}
      <div className="bg-gradient-to-r from-violet-600 to-indigo-600 rounded-2xl shadow-xl p-6 text-white flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">月度考勤异常与自助申诉闭环</h1>
          <p className="text-violet-100 text-sm mt-2 max-w-2xl">
            提供考勤异常账单展示，员工限期3天内针对单条异常（如外勤漏卡、迟到）线上自助申诉，主管审批通过后自动对冲扣款。白名单豁免与月度最高4次补打卡豁免由底层引擎同源清洗。
          </p>
        </div>
      </div>

      {/* 消息提示 */}
      {msg && (
        <div className={`p-4 rounded-xl shadow-sm border ${
          msg.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-rose-50 border-rose-200 text-rose-800'
        } transition-all duration-300`}>
          <div className="flex items-center space-x-2 font-medium">
            <span className="text-lg">{msg.type === 'success' ? '✓' : '✗'}</span>
            <span>{msg.text}</span>
          </div>
        </div>
      )}

      {/* 视角切换 Tabs */}
      <div className="flex bg-gray-200/60 p-1.5 rounded-xl w-fit space-x-1 border border-gray-300/40">
        <button
          onClick={() => setActiveTab('employee')}
          className={`px-5 py-2.5 rounded-lg text-sm font-semibold tracking-wide transition-all ${
            activeTab === 'employee'
              ? 'bg-white text-indigo-700 shadow-md scale-[1.02]'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'
          }`}
        >
          👤 员工自助考勤异常 & 申诉
        </button>
        <button
          onClick={() => setActiveTab('manager')}
          className={`px-5 py-2.5 rounded-lg text-sm font-semibold tracking-wide transition-all relative ${
            activeTab === 'manager'
              ? 'bg-white text-indigo-700 shadow-md scale-[1.02]'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100/50'
          }`}
        >
          🛡️ 主管/HR 异常审批账单
          {pendingAppeals.length > 0 && (
            <span className="absolute -top-1.5 -right-1.5 bg-rose-500 text-white rounded-full text-[10px] w-5 h-5 flex items-center justify-center font-bold border-2 border-white animate-pulse">
              {pendingAppeals.length}
            </span>
          )}
        </button>
      </div>

      {activeTab === 'employee' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* 左侧及中间：考勤异常清单 */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-4">
              
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b">
                <div className="flex items-center space-x-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">选择员工账户</label>
                    <select
                      value={selectedEmpId}
                      onChange={(e) => setSelectedEmpId(e.target.value)}
                      className="block w-48 rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50 font-medium"
                    >
                      {employees.map(emp => (
                        <option key={emp.id} value={emp.id}>
                          {emp.name} ({emp.jobNumber})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-400 uppercase tracking-wider mb-1">选择统计月份</label>
                    <input
                      type="month"
                      value={selectedMonth}
                      onChange={(e) => setSelectedMonth(e.target.value)}
                      className="block w-40 rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50 font-medium font-mono"
                    />
                  </div>
                </div>
                <button
                  onClick={handleRecalculate}
                  disabled={loadingAnomalies}
                  className="px-4 py-2 border border-indigo-200 hover:border-indigo-500 text-indigo-700 bg-indigo-50/50 hover:bg-indigo-50 rounded-lg font-medium text-sm transition-all"
                >
                  ⚡ 重跑当月考勤汇总
                </button>
              </div>

              {/* 异常账单表格 */}
              <div className="overflow-x-auto">
                {loadingAnomalies ? (
                  <div className="text-center py-12 text-gray-500 font-medium">加载中...</div>
                ) : anomalies.length === 0 ? (
                  <div className="text-center py-12 text-gray-400 text-sm">
                    🎉 太棒了！本月在此员工账单中未发现任何考勤异常情况。
                  </div>
                ) : (
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50/50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">日期</th>
                        <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">异常类型</th>
                        <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">异常详情</th>
                        <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">扣减工时</th>
                        <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">申诉截止</th>
                        <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase tracking-wider">状态/操作</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200 text-sm">
                      {anomalies.map((anom) => {
                        const inPeriod = isAppealPeriodValid(anom.date);
                        const leftText = getDaysLeftText(anom.date);
                        
                        let typePill = '';
                        switch (anom.type) {
                          case 'LATE':
                            typePill = 'bg-amber-100 text-amber-800';
                            break;
                          case 'MISSED_CARD':
                            typePill = 'bg-orange-100 text-orange-800';
                            break;
                          case 'ABSENT':
                            typePill = 'bg-rose-100 text-rose-800';
                            break;
                        }

                        return (
                          <tr key={anom.id} className="hover:bg-gray-50/40 transition">
                            <td className="px-4 py-3 whitespace-nowrap font-mono font-medium text-gray-700">
                              {new Date(anom.date).toLocaleDateString('zh-CN')}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className={`px-2 py-0.5 rounded text-xs font-bold ${typePill}`}>
                                {anom.type === 'LATE' ? '迟到' : anom.type === 'MISSED_CARD' ? '缺卡' : '旷工'}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-gray-600 font-medium">
                              {anom.details}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-rose-600 font-bold font-mono">
                              -{anom.deductHours}h
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap text-xs">
                              {anom.appealStatus === 'NONE' ? (
                                <span className={`font-semibold ${inPeriod ? 'text-indigo-600' : 'text-gray-400'}`}>
                                  {leftText}
                                </span>
                              ) : (
                                <span className="text-gray-400">--</span>
                              )}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {anom.appealStatus === 'NONE' ? (
                                <button
                                  onClick={() => handleOpenAppealModal(anom)}
                                  disabled={!inPeriod}
                                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold shadow-sm transition-all ${
                                    inPeriod
                                      ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 text-white hover:shadow hover:scale-[1.04]'
                                      : 'bg-gray-100 text-gray-400 cursor-not-allowed border border-gray-200'
                                  }`}
                                >
                                  {inPeriod ? '申诉说明' : '超时锁定'}
                                </button>
                              ) : anom.appealStatus === 'PENDING' ? (
                                <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
                                  ⌛ 待主管审批
                                </span>
                              ) : anom.appealStatus === 'APPROVED' ? (
                                <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                  ✓ 申诉通过
                                </span>
                              ) : (
                                <div className="space-y-1">
                                  <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                                    ✗ 已驳回
                                  </span>
                                  {anom.managerComment && (
                                    <div className="text-[10px] text-gray-400 max-w-[150px] truncate" title={anom.managerComment}>
                                      {anom.managerComment}
                                    </div>
                                  )}
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>

            </div>
          </div>

          {/* 右侧：模拟/测试控制面板 */}
          <div className="lg:col-span-1 space-y-6">
            
            {/* 1. 补打卡豁免对冲测试 */}
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-4">
              <h3 className="text-lg font-bold text-gray-800 border-b pb-2 flex items-center">
                <span>🛡️</span>
                <span className="ml-2">4次豁免额度对冲模拟</span>
              </h3>
              <p className="text-xs text-gray-500 leading-relaxed">
                考勤底盘引擎自带“免费补打卡豁免”算法：当月审核通过的补卡单限额4次内，自动在考勤汇总计算时，冲抵异常状态及待扣4h。此处可快捷模拟新增一条本月通过的补打卡。
              </p>
              
              <form onSubmit={handleSimulateMakeUp} className="space-y-3 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">选择补打卡发生日期</label>
                  <input
                    type="date"
                    required
                    value={makeUpDate}
                    onChange={(e) => setMakeUpDate(e.target.value)}
                    className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50 font-mono"
                  />
                </div>
                <button
                  type="submit"
                  disabled={simulatingMakeUp}
                  className="w-full px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white rounded-lg font-semibold text-sm shadow-md transition disabled:opacity-50"
                >
                  {simulatingMakeUp ? '提交中...' : '提交审批通过的补打卡'}
                </button>
              </form>
            </div>

            {/* 2. 规则说明看板 */}
            <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-2xl border border-gray-200 shadow-sm p-6 space-y-4">
              <h3 className="text-sm font-bold text-slate-800 flex items-center">
                <span>💡</span>
                <span className="ml-2 uppercase tracking-wider">考勤扣工时规则细则</span>
              </h3>
              <ul className="space-y-2.5 text-xs text-slate-600 leading-relaxed">
                <li className="flex items-start">
                  <span className="text-indigo-500 mr-1.5">•</span>
                  <span><strong>阶梯迟到算薪：</strong>09:01-09:05扣0.5h；09:06-09:15扣1h；09:16及以后直扣4.0h。</span>
                </li>
                <li className="flex items-start">
                  <span className="text-indigo-500 mr-1.5">•</span>
                  <span><strong>缺卡罚工时：</strong>单日仅1次打卡记【缺卡1次】，扣4h。可通过最多4次补打卡免除。</span>
                </li>
                <li className="flex items-start">
                  <span className="text-indigo-500 mr-1.5">•</span>
                  <span><strong>旷工罚工时：</strong>单日0打卡记【旷工1天】，扣8h。（白名单人员免除）</span>
                </li>
                <li className="flex items-start">
                  <span className="text-indigo-500 mr-1.5">•</span>
                  <span><strong>3天时效性限制：</strong>系统强控制，迟到/旷工/缺卡发生日期与申诉时间之差必须在3天内。</span>
                </li>
              </ul>
            </div>

          </div>

        </div>
      ) : (
        /* 主管/HR审批面板 */
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 space-y-6">
          <div className="border-b pb-4">
            <h3 className="text-xl font-bold text-gray-800">📋 员工自助申诉待批账单</h3>
            <p className="text-xs text-gray-400 mt-1">
              这里是需要主管做出裁决的线上申诉单。当点击“批准申诉”时，系统将扣减工时对冲清零，并立即触发对应员工当月考勤报表的重算，HR全程零干预。
            </p>
          </div>

          {pendingAppeals.length === 0 ? (
            <div className="text-center py-16 text-gray-400 text-sm">
              🍵 暂无需要处理的申诉单，员工考勤状态运行良好！
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-600 mb-1">写下审批批注/评语</label>
                  <input
                    type="text"
                    placeholder="例如: 情况属实，同意冲抵 / 凭证不足，予以驳回"
                    value={managerComment}
                    onChange={(e) => setManagerComment(e.target.value)}
                    className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-3 bg-gray-50"
                  />
                </div>
              </div>

              <div className="overflow-x-auto border rounded-xl">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase">申请人</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase">异常发生日期</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase">异常详情</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase">拟扣工时</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase">申诉原因说明</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-400 uppercase">凭证/外勤链接</th>
                      <th className="px-4 py-3 text-center text-xs font-bold text-gray-400 uppercase">操作</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200 text-sm">
                    {pendingAppeals.map((appeal) => (
                      <tr key={appeal.id} className="hover:bg-gray-50/50 transition">
                        <td className="px-4 py-3">
                          <div className="font-semibold text-gray-900">{appeal.employee.name}</div>
                          <div className="text-xs text-gray-400 font-mono">{appeal.employee.jobNumber}</div>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap font-mono">
                          {new Date(appeal.date).toLocaleDateString('zh-CN')}
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-medium text-gray-700">{appeal.details}</span>
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-rose-600 font-bold font-mono">
                          -{appeal.deductHours}h
                        </td>
                        <td className="px-4 py-3 text-gray-600 font-medium">
                          {appeal.appealReason || '--'}
                        </td>
                        <td className="px-4 py-3 text-indigo-600 truncate max-w-[150px]">
                          {appeal.appealVoucher ? (
                            <a href={appeal.appealVoucher} target="_blank" rel="noreferrer" className="underline hover:text-indigo-800">
                              {appeal.appealVoucher}
                            </a>
                          ) : '未提供'}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-center space-x-2">
                          <button
                            onClick={() => handleApprove(appeal.id)}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-sm transition"
                          >
                            通过
                          </button>
                          <button
                            onClick={() => handleReject(appeal.id)}
                            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-semibold shadow-sm transition"
                          >
                            驳回
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 员工自助申诉发起模态框 */}
      {appealModalOpen && targetAnomaly && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 transition-all">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-gray-200 overflow-hidden transform scale-100 transition">
            
            <div className="bg-gradient-to-r from-indigo-600 to-indigo-700 px-6 py-4 text-white">
              <h3 className="text-lg font-bold">发起考勤异常线上申诉</h3>
              <p className="text-indigo-100 text-xs mt-1">
                正在申诉：{new Date(targetAnomaly.date).toLocaleDateString('zh-CN')} {targetAnomaly.details}
              </p>
            </div>

            <form onSubmit={handleSubmitAppeal} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1">申诉事由/异常原因说明</label>
                <textarea
                  required
                  rows={3}
                  placeholder="请输入导致异常的具体工作原因，如: 拜访客户外勤迟到，忘打卡..."
                  value={appealReason}
                  onChange={(e) => setAppealReason(e.target.value)}
                  className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-1">佐证凭证 / 外勤定位截图URL</label>
                <input
                  type="text"
                  placeholder="请粘贴云存储凭证链接或工作沟通截图"
                  value={appealVoucher}
                  onChange={(e) => setAppealVoucher(e.target.value)}
                  className="block w-full rounded-lg border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm border p-2 bg-gray-50"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setAppealModalOpen(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition"
                >
                  取消
                </button>
                <button
                  type="submit"
                  disabled={submittingAppeal}
                  className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-lg text-sm font-semibold shadow-md hover:from-indigo-700 hover:to-indigo-800 transition disabled:opacity-50"
                >
                  {submittingAppeal ? '提交中...' : '确认发起申诉'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
