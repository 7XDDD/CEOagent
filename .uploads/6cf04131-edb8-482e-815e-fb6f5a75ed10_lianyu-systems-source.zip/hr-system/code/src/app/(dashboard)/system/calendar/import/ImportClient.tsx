'use client';

import { useState } from 'react';
import * as XLSX from 'xlsx';
import { 
  importClockingRecords, 
  importOvertimeRecords, 
  importLeaveRecords, 
  importTravelRecords,
  importHistoricalOvertimeRecords,
  importExemptionRecords,
  generateMonthlySummary
} from '@/actions/attendance';

export default function ImportClient() {
  const [selectedMonth, setSelectedMonth] = useState('2026-05');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // 加班明细数据（用于展示风控预警）
  const [overtimeLogs, setOvertimeLogs] = useState<any[]>([]);

  // 四表文件导入解析逻辑 + 历史加班调休池资产导入 + 补卡豁免导入
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'clocking' | 'overtime' | 'leave' | 'travel' | 'historical-overtime' | 'exemption') => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setMessage(null);

    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data, { type: 'array' });
      
      // 依据对应的表单名称查找 sheet
      let sheetName = '';
      if (type === 'clocking') sheetName = '上下班打卡导入表';
      else if (type === 'overtime') sheetName = '加班审批表';
      else if (type === 'leave') sheetName = '请假审批表';
      else if (type === 'travel') sheetName = '出差审批表';
      else if (type === 'historical-overtime') sheetName = '历史加班额度表';
      else if (type === 'exemption') sheetName = '补卡审批表';

      const sheet = workbook.Sheets[sheetName] || workbook.Sheets[workbook.SheetNames[0]];
      if (!sheet) {
        throw new Error(`找不到对应的子表 [${sheetName}]，请确认模板格式`);
      }

      // Read worksheet rows as raw 2D array of cells (row-by-row) to ensure index-based mapping
      const rawRows: any[][] = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });

      if (rawRows.length === 0) {
        throw new Error('表中未检测到有效数据');
      }

      let res: any = { success: false, message: '未知异常' };

      if (type === 'clocking') {
        // Clocking data starts at row 4 (index 4)
        const dataRows = rawRows.slice(4);
        const payload = dataRows.map(row => ({
          date: row[0],
          name: row[1],
          jobNumber: row[5] || row[2], // F column is 工号 (index 5), C column is 账号 (index 2)
          checkIn: row[8], // I column is 最早 (index 8)
          checkOut: row[9], // J column is 最晚 (index 9)
          result: row[14], // O column is 考勤结果 (index 14)
          lateCount: parseInt(row[16]) || 0,
          lateMinutes: parseInt(row[17]) || 0,
          earlyCount: parseInt(row[18]) || 0,
          earlyMinutes: parseInt(row[19]) || 0,
          absentCount: parseInt(row[20]) || 0,
          missedCardCount: parseInt(row[22]) || 0,
        })).filter(item => item.name && item.date);

        res = await importClockingRecords(payload);
      } else if (type === 'overtime') {
        // Overtime data starts at row 1 (index 1)
        const dataRows = rawRows.slice(1);
        const payload = dataRows.map(row => ({
          approvalNumber: row[0],
          approvalDetails: row[1] ? String(row[1]) : null,
          applyTime: row[2],
          finishTime: row[3],
          name: row[4],
          department: row[5] ? String(row[5]) : null,
          jobNumber: row[6] ? String(row[6]) : '',
          account: row[6] ? String(row[6]) : null,
          type: row[7] ? String(row[7]) : null,
          startTime: row[8],
          endTime: row[9],
          grossDuration: parseFloat(row[10]) || 0.0,
          reason: row[11] ? String(row[11]) : null,
          attachment: row[12] ? String(row[12]) : null,
          currentApprovalNode: row[13] ? String(row[13]) : null,
          approvalProcess: row[14] ? String(row[14]) : null,
          remarks: row[15] ? String(row[15]) : null,
          approvalStatus: row[13] ? String(row[13]) : null,
        })).filter(item => item.approvalNumber);

        res = await importOvertimeRecords(payload);
        if (res.success && res.data) {
          setOvertimeLogs(res.data);
        }
      } else if (type === 'leave') {
        // Leave data starts at row 1 (index 1)
        const dataRows = rawRows.slice(1);
        const payload = dataRows.map(row => ({
          approvalNumber: row[0],
          approvalDetails: row[1] ? String(row[1]) : null,
          applyTime: row[2],
          finishTime: row[3],
          name: row[4],
          department: row[5] ? String(row[5]) : null,
          jobNumber: row[6] ? String(row[6]) : '',
          account: row[6] ? String(row[6]) : null,
          leaveType: row[7],
          startTime: row[8],
          endTime: row[9],
          duration: parseFloat(row[10]) || 0.0,
          reason: row[11] ? String(row[11]) : null,
          attachment: row[12] ? String(row[12]) : null,
          currentApprovalNode: row[13] ? String(row[13]) : null,
          approvalProcess: row[14] ? String(row[14]) : null,
          remarks: row[15] ? String(row[15]) : null,
          approvalStatus: row[13] ? String(row[13]) : null, // Keep for backward compatibility or mapping
        })).filter(item => item.approvalNumber);

        res = await importLeaveRecords(payload);
      } else if (type === 'travel') {
        // Travel data starts at row 1 (index 1)
        const dataRows = rawRows.slice(1);
        const payload = dataRows.map(row => ({
          approvalNumber: row[0],
          approvalDetails: row[1] ? String(row[1]) : null,
          applyTime: row[2],
          finishTime: row[3],
          name: row[4],
          department: row[5] ? String(row[5]) : null,
          jobNumber: row[6] ? String(row[6]) : '',
          account: row[6] ? String(row[6]) : null,
          reason: row[7] ? String(row[7]) : null,
          type: row[8] ? String(row[8]) : null,
          departure: row[9] ? String(row[9]) : null,
          destination: row[10] ? String(row[10]) : null,
          startTime: row[11],
          endTime: row[12],
          duration: parseFloat(row[13]) || 0.0,
          transportation: row[14] ? String(row[14]) : null,
          attachment: row[15] ? String(row[15]) : null,
          currentApprovalNode: row[16] ? String(row[16]) : null,
          approvalProcess: row[17] ? String(row[17]) : null,
          remarks: row[18] ? String(row[18]) : null,
          approvalStatus: row[16] ? String(row[16]) : null,
        })).filter(item => item.approvalNumber);

        res = await importTravelRecords(payload);
      } else if (type === 'historical-overtime') {
        const dataRows = rawRows.slice(1);
        const payload = dataRows.map(row => ({
          jobNumber: row[0] ? String(row[0]) : '',
          name: row[1] ? String(row[1]) : '',
          generatedDate: row[2] ? String(row[2]) : '',
          totalHours: parseFloat(row[3]) || 0.0,
          expireAt: row[4] ? String(row[4]) : ''
        })).filter(item => item.jobNumber);

        res = await importHistoricalOvertimeRecords(payload);
      } else if (type === 'exemption') {
        const dataRows = rawRows.slice(1);
        const payload = dataRows.map(row => ({
          approvalNumber: row[0],
          name: row[1] ? String(row[1]) : '',
          jobNumber: row[2] ? String(row[2]) : null,
          exemptionDate: row[3] ? new Date(row[3]) : new Date(),
          approvalStatus: row[4] ? String(row[4]) : null,
          reason: row[5] ? String(row[5]) : null,
        })).filter(item => item.approvalNumber);

        res = await importExemptionRecords(payload);
      }

      if (res.success) {
        setMessage({ type: 'success', text: `文件导入并保存成功！处理了 ${res.count || res.data?.length || 0} 条数据。` });
      } else {
        setMessage({ type: 'error', text: res.message || '保存入库失败' });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: `解析失败: ${err.message}` });
    } finally {
      setLoading(false);
      // 清空 input 缓存以允许重复上传同一文件
      e.target.value = '';
    }
  };

  const handleWashSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    const res = await generateMonthlySummary(selectedMonth);
    if (res.success) {
      setMessage({ type: 'success', text: `🎉 [${selectedMonth}] 月度考勤账单清洗汇总成功！已生成报表。` });
    } else {
      setMessage({ type: 'error', text: res.message || '清洗汇总失败' });
    }
    setLoading(false);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      
      {/* 头部导航与标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">加班与假勤风控导入中心</h1>
          <p className="text-sm text-gray-500 mt-1">
            在此上传打卡明细及审批流单据，运行“事前拦截、跨天拆分、双线扣餐及假种消耗优先级”清洗引擎。
          </p>
        </div>
        <a href="/system/calendar/import/history" className="bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-50 shadow-sm transition font-medium text-sm flex items-center">
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          查看导入历史台账
        </a>
      </div>

      {message && (
        <div className={`p-4 rounded-md border text-sm ${
          message.type === 'success' ? 'bg-green-50 text-green-800 border-green-200' : 'bg-red-50 text-red-800 border-red-200'
        }`}>
          {message.text}
        </div>
      )}

      {/* 四表上传卡片网格 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        
        {/* 1. 打卡明细 */}
        <div className="bg-white shadow rounded-lg border border-gray-200 p-6 flex flex-col justify-between">
          <div>
            <span className="text-2xl">🕒</span>
            <h3 className="font-bold text-gray-800 mt-2">1. 原始上下班打卡导入</h3>
            <p className="text-xs text-gray-400 mt-1">对应上下班打卡导入表，包含迟到、早退、旷工及缺卡次数。</p>
          </div>
          <div className="mt-6">
            <label className="block w-full text-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 cursor-pointer">
              {loading ? '导入中...' : '选择文件导入'}
              <input type="file" accept=".xlsx,.xls" onChange={e => handleFileUpload(e, 'clocking')} disabled={loading} className="hidden" />
            </label>
          </div>
        </div>

        {/* 2. 加班审批 */}
        <div className="bg-white shadow rounded-lg border border-gray-200 p-6 flex flex-col justify-between">
          <div>
            <span className="text-2xl">🔥</span>
            <h3 className="font-bold text-gray-800 mt-2">2. 加班审批导入</h3>
            <p className="text-xs text-gray-400 mt-1">对应加班审批表，系统在此执行事前申请拦截及周末双线扣餐算法。</p>
          </div>
          <div className="mt-6">
            <label className="block w-full text-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 cursor-pointer">
              {loading ? '导入中...' : '选择文件导入'}
              <input type="file" accept=".xlsx,.xls" onChange={e => handleFileUpload(e, 'overtime')} disabled={loading} className="hidden" />
            </label>
          </div>
        </div>

        {/* 3. 请假审批 */}
        <div className="bg-white shadow rounded-lg border border-gray-200 p-6 flex flex-col justify-between">
          <div>
            <span className="text-2xl">🏖️</span>
            <h3 className="font-bold text-gray-800 mt-2">3. 请假审批导入</h3>
            <p className="text-xs text-gray-400 mt-1">对应请假审批表，导入时自动校验假种消耗顺序，前置防套假。</p>
          </div>
          <div className="mt-6">
            <label className="block w-full text-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 cursor-pointer">
              {loading ? '导入中...' : '选择文件导入'}
              <input type="file" accept=".xlsx,.xls" onChange={e => handleFileUpload(e, 'leave')} disabled={loading} className="hidden" />
            </label>
          </div>
        </div>

        {/* 4. 出差审批 */}
        <div className="bg-white shadow rounded-lg border border-gray-200 p-6 flex flex-col justify-between">
          <div>
            <span className="text-2xl">✈️</span>
            <h3 className="font-bold text-gray-800 mt-2">4. 出差审批导入</h3>
            <p className="text-xs text-gray-400 mt-1">对应出差审批表，用于在统计月份天数时自动核算抵扣。</p>
          </div>
          <div className="mt-6">
            <label className="block w-full text-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 cursor-pointer">
              {loading ? '导入中...' : '选择文件导入'}
              <input type="file" accept=".xlsx,.xls" onChange={e => handleFileUpload(e, 'travel')} disabled={loading} className="hidden" />
            </label>
          </div>
        </div>

        {/* 5. 历史加班额度导入 */}
        <div className="bg-amber-50 shadow rounded-lg border border-amber-200 p-6 flex flex-col justify-between">
          <div>
            <span className="text-2xl">🏦</span>
            <h3 className="font-bold text-amber-800 mt-2">5. 历史调休池导入</h3>
            <p className="text-xs text-amber-600 mt-1">上传“历史加班额度表”，包含有效期至。后续请假调休时将按 FIFO 算法自动对冲此池子额度。</p>
          </div>
          <div className="mt-6">
            <label className="block w-full text-center px-4 py-2 border border-amber-300 text-sm font-medium rounded-md text-amber-800 bg-white hover:bg-amber-50 cursor-pointer">
              {loading ? '导入中...' : '选择文件导入'}
              <input type="file" accept=".xlsx,.xls" onChange={e => handleFileUpload(e, 'historical-overtime')} disabled={loading} className="hidden" />
            </label>
          </div>
        </div>

        {/* 6. 补卡豁免导入 */}
        <div className="bg-purple-50 shadow rounded-lg border border-purple-200 p-6 flex flex-col justify-between">
          <div>
            <span className="text-2xl">🛡️</span>
            <h3 className="font-bold text-purple-800 mt-2">6. 补卡豁免导入</h3>
            <p className="text-xs text-purple-600 mt-1">上传“补卡审批表”，清洗时将启用最高 4 次豁免算法，自动对冲当月缺卡异常。</p>
          </div>
          <div className="mt-6">
            <label className="block w-full text-center px-4 py-2 border border-purple-300 text-sm font-medium rounded-md text-purple-800 bg-white hover:bg-purple-50 cursor-pointer">
              {loading ? '导入中...' : '选择文件导入'}
              <input type="file" accept=".xlsx,.xls" onChange={e => handleFileUpload(e, 'exemption')} disabled={loading} className="hidden" />
            </label>
          </div>
        </div>

      </div>

      {/* 清洗引擎触发器与结果明细 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* 清洗面板 */}
        <div className="bg-white shadow rounded-lg border border-gray-200 p-6 lg:col-span-1 space-y-4">
          <h3 className="text-lg font-bold text-gray-800 border-b pb-2">⚙️ 智能风控核算清洗</h3>
          <p className="text-xs text-gray-500">
            第一步导入所有审批与打卡数据后，在此选择需要结算的月份，一键聚合清洗生成月度考勤表。
          </p>

          <form onSubmit={handleWashSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">选择核算结算月份</label>
              <input 
                type="month" required
                value={selectedMonth}
                onChange={e => setSelectedMonth(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
              />
            </div>

            <button 
              type="submit" disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-3 rounded text-sm transition disabled:opacity-50"
            >
              {loading ? '正在计算风控与清洗汇总...' : '🚀 一键清洗并生成月考勤表'}
            </button>
          </form>

          <div className="border-t pt-4">
            <a 
              href="/system/calendar/summary" 
              className="block w-full text-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 transition"
            >
              📊 前往查看月考勤报表
            </a>
          </div>
        </div>

        {/* 预警明细表格 */}
        <div className="bg-white shadow rounded-lg border border-gray-200 p-6 lg:col-span-2 space-y-4">
          <h3 className="text-lg font-bold text-gray-800 border-b pb-2 flex items-center">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 mr-2"></span>
            当前加班智能风控解析与补单预警明细
          </h3>

          <div className="overflow-x-auto max-h-[300px]">
            <table className="min-w-full divide-y divide-gray-200 text-sm text-left">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase">流程编号</th>
                  <th className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase">申请人</th>
                  <th className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase">解析日期</th>
                  <th className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase">有效工时</th>
                  <th className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase">风控判定</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {overtimeLogs.length > 0 ? (
                  overtimeLogs.map((log, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-4 py-2.5 font-mono text-xs">{log.approvalNumber}</td>
                      <td className="px-4 py-2.5 font-medium">{log.name}</td>
                      <td className="px-4 py-2.5">{log.date}</td>
                      <td className="px-4 py-2.5 font-bold text-gray-900">{log.netHours} 小时</td>
                      <td className="px-4 py-2.5">
                        {log.warning ? (
                          <span className={`px-2 py-0.5 rounded text-xs font-semibold ${
                            log.warning.includes('LATE_APPLY') 
                              ? 'bg-red-100 text-red-800 border border-red-200' 
                              : 'bg-yellow-100 text-yellow-800 border border-yellow-200'
                          }`}>
                            ⚠️ {log.warning.split(':')[1] || log.warning}
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded text-xs font-semibold bg-green-100 text-green-800 border border-green-200">
                            正常有效
                          </span>
                        )}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-gray-400">
                      暂无解析中的加班预警，请在上方导入加班文件。
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>

    </div>
  );
}
