import { getEmployees } from '@/actions/employee';
import { getCustomFields } from '@/actions/customField';
import EmployeeClient from './EmployeeClient';

export const metadata = {
  title: '员工花名册 - 智能化HR系统',
};

export default async function EmployeesPage() {
  const employeesRes = await getEmployees();
  const customFieldsRes = await getCustomFields();
  
  const employees = employeesRes.success ? (employeesRes.data ?? []) : [];
  const customFields = customFieldsRes.success ? (customFieldsRes.data ?? []) : [];

  return <EmployeeClient initialData={employees} customFields={customFields} />;
}
