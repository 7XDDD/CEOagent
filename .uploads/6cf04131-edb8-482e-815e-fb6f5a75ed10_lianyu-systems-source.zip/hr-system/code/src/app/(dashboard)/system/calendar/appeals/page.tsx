import { getEmployees } from '@/actions/employee';
import { getPendingAppeals } from '@/actions/attendance';
import AppealsClient from './AppealsClient';

export const metadata = {
  title: '自助考勤异常申诉 - 链宇HR系统',
};

export default async function AppealsPage() {
  const employeesRes = await getEmployees();
  const pendingRes = await getPendingAppeals();

  const employees = employeesRes.success ? employeesRes.data : [];
  const initialPending = pendingRes.success ? pendingRes.data : [];

  return (
    <AppealsClient 
      employees={employees as any[]} 
      initialPendingAppeals={initialPending as any[]}
    />
  );
}
