import { getEmployees } from '@/actions/employee';
import { 
  getConsultantBaselines, 
  getProjectConsultantMappings, 
  getPMOEfficiencyReport 
} from '@/actions/pmo';
import { getCustomFields } from '@/actions/customField';
import PmoClient from './PmoClient';

export const metadata = {
  title: '咨询顾问项目人效表 - 链宇HR系统',
};

export default async function PmoPage() {
  const year = 2026;
  const employeesRes = await getEmployees();
  const baselinesRes = await getConsultantBaselines(year);
  const mappingsRes = await getProjectConsultantMappings();
  const reportRes = await getPMOEfficiencyReport(year);
  const customFieldsRes = await getCustomFields();

  const employees = employeesRes.success ? employeesRes.data : [];
  const initialBaselines = baselinesRes.success ? baselinesRes.data : [];
  const initialMappings = mappingsRes.success ? mappingsRes.data : [];
  const initialReport = reportRes.success ? reportRes.data : [];
  const customFields = customFieldsRes.success ? customFieldsRes.data : [];

  return (
    <PmoClient
      employees={employees as any[]}
      initialBaselines={initialBaselines as any[]}
      initialMappings={initialMappings as any[]}
      initialReport={initialReport as any[]}
      initialYear={year}
      customFields={customFields as any[]}
    />
  );
}
