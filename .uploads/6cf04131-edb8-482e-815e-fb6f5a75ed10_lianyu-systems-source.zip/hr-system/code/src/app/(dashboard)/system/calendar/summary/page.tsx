import SummaryClient from './SummaryClient';

export const metadata = {
  title: '月度考勤表汇总 - 智能化HR系统',
};

export default function SummaryPage() {
  return <SummaryClient />;
}
