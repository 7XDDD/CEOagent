import { getProjects } from '@/actions/project';
import { getEmployees } from '@/actions/employee';
import ProjectsClient from './ProjectsClient';

export const metadata = {
  title: '项目主数据管理 - 链宇HR系统',
};

export default async function ProjectsPage() {
  const projectsRes = await getProjects();
  const employeesRes = await getEmployees();

  const projects = projectsRes.success ? projectsRes.data : [];
  const employees = employeesRes.success ? employeesRes.data : [];

  return (
    <ProjectsClient
      initialProjects={projects as any[]}
      employees={employees as any[]}
    />
  );
}
