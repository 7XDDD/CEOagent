'use client';

import { useState } from 'react';
import { createCustomField, deleteCustomField } from '@/actions/customField';
import { useRouter } from 'next/navigation';

export default function ConfigClient({ initialFields }: { initialFields: any[] }) {
  const router = useRouter();
  const [fields, setFields] = useState(initialFields);
  
  // 新增表单状态
  const [name, setName] = useState('');
  const [label, setLabel] = useState('');
  const [type, setType] = useState('TEXT');
  const [optionsStr, setOptionsStr] = useState('');
  const [required, setRequired] = useState(false);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    // 格式化下拉框选项
    let options: string[] = [];
    if (type === 'SELECT') {
      options = optionsStr
        .split(',')
        .map(opt => opt.trim())
        .filter(opt => opt.length > 0);
      if (options.length === 0) {
        setError('请为下拉框类型配置至少一个选项(英文逗号分隔)');
        setLoading(false);
        return;
      }
    }

    const payload = {
      name: name.trim(),
      label: label.trim(),
      type,
      options: type === 'SELECT' ? options : undefined,
      required,
    };

    const res = await createCustomField(payload);
    if (res.success && res.data) {
      setSuccess('字段创建成功，录入新员工页面已实时零延迟更新！');
      setFields([...fields, res.data]);
      // 重置表单
      setName('');
      setLabel('');
      setType('TEXT');
      setOptionsStr('');
      setRequired(false);
      router.refresh();
    } else {
      setError(res.message || '创建字段失败');
    }
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('确定要删除该自定义字段吗？删除后该字段数据在员工档案中将无法显示。')) return;
    
    const res = await deleteCustomField(id);
    if (res.success) {
      setFields(fields.filter(f => f.id !== id));
      router.refresh();
    } else {
      alert(res.message || '删除失败');
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center space-x-2 text-sm text-gray-500 mb-4">
        <a href="/system/employees" className="hover:text-indigo-600">员工花名册</a>
        <span>&gt;</span>
        <span className="text-gray-800 font-semibold">动态配置中心</span>
      </div>

      <h1 className="text-2xl font-bold text-gray-800 mb-6">花名册动态配置中心 (字段三要素)</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* 左侧：新增自定义字段 */}
        <div className="bg-white shadow rounded-lg border border-gray-200 p-6 lg:col-span-1">
          <h3 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2">① 配置新字段</h3>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && <div className="p-3 bg-red-50 text-red-500 text-xs rounded border border-red-100">{error}</div>}
            {success && <div className="p-3 bg-green-50 text-green-600 text-xs rounded border border-green-100">{success}</div>}

            <div>
              <label className="block text-sm font-medium text-gray-700">字段标识(Key) <span className="text-red-500">*</span></label>
              <input 
                type="text" required placeholder="如: positionLevel (限英文字母/无空格)"
                value={name}
                onChange={e => setName(e.target.value.replace(/[^a-zA-Z0-9]/g, ''))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">字段显示名称(Label) <span className="text-red-500">*</span></label>
              <input 
                type="text" required placeholder="如: 岗位职级"
                value={label}
                onChange={e => setLabel(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">数据类型 <span className="text-red-500">*</span></label>
              <select 
                value={type}
                onChange={e => setType(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
              >
                <option value="TEXT">文本输入框 (TEXT)</option>
                <option value="NUMBER">数字输入框 (NUMBER)</option>
                <option value="DATE">日期选择器 (DATE)</option>
                <option value="SELECT">下拉单选框 (SELECT)</option>
              </select>
            </div>

            {type === 'SELECT' && (
              <div>
                <label className="block text-sm font-medium text-gray-700">下拉框选项(逗号分隔) <span className="text-red-500">*</span></label>
                <input 
                  type="text" placeholder="如: P1,P2,P3,P4"
                  value={optionsStr}
                  onChange={e => setOptionsStr(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
                />
              </div>
            )}

            <div className="flex items-center space-x-2 pt-2">
              <input 
                type="checkbox" id="required"
                checked={required}
                onChange={e => setRequired(e.target.checked)}
                className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
              />
              <label htmlFor="required" className="text-sm font-medium text-gray-700 cursor-pointer">是否必填 (Required)</label>
            </div>

            <button 
              type="submit" disabled={loading}
              className="w-full mt-4 bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 rounded transition text-sm disabled:opacity-50"
            >
              {loading ? '创建中...' : '保存并应用配置'}
            </button>
          </form>
        </div>

        {/* 右侧：列表和状态展示 */}
        <div className="bg-white shadow rounded-lg border border-gray-200 p-6 lg:col-span-2">
          <h3 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2">② 实时生效的自定义字段列表</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">显示名称 (Label)</th>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">标识 (Key)</th>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">字段类型</th>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">是否必填</th>
                  <th className="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">操作</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200 text-sm">
                {fields.length > 0 ? (
                  fields.map(f => (
                    <tr key={f.id} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-semibold text-gray-900">{f.label}</td>
                      <td className="px-4 py-3 text-gray-500 font-mono">{f.name}</td>
                      <td className="px-4 py-3 text-gray-500">
                        <span className="px-2 py-0.5 rounded bg-gray-100 text-xs text-gray-700">
                          {f.type}
                        </span>
                        {f.type === 'SELECT' && (
                          <div className="text-xs text-gray-400 mt-1 max-w-[200px] truncate" title={JSON.stringify(f.options)}>
                            选项: {Array.isArray(f.options) ? f.options.join('/') : JSON.stringify(f.options)}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {f.required ? (
                          <span className="text-red-600 font-semibold">必填</span>
                        ) : (
                          <span className="text-gray-400">选填</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <button 
                          onClick={() => handleDelete(f.id)}
                          className="text-red-500 hover:text-red-700 transition"
                        >
                          删除
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-4 py-6 text-center text-gray-400">
                      目前没有配置自定义动态字段，员工入职表单将仅包含标准字段。
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
}
