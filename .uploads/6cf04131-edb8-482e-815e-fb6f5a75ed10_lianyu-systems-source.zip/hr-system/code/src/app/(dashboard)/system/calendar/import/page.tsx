import ImportClient from './ImportClient';

export const metadata = {
  title: '考勤数据导入与风控 - 智能化HR系统',
};

export default function ImportPage() {
  return <ImportClient />;
}
