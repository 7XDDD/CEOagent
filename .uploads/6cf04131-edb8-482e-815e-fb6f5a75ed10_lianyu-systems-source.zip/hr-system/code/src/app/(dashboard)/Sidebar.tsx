'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function Sidebar() {
  const pathname = usePathname();

  const navItems = [
    { href: '/system', label: '首页控制台', exact: true },
    { href: '/system/roles', label: '角色与权限' },
    { href: '/system/employees', label: '员工花名册' },
    { href: '/system/calendar', label: '考勤日历排班', exact: true },
    { href: '/system/calendar/import', label: '考勤数据导入' },
    { href: '/system/calendar/summary', label: '月度考勤汇总' },
    { href: '/system/calendar/appeals', label: '异常自助申诉' },
    { href: '/system/pmo', label: '项目交付人效' },
    { href: '/system/projects', label: '项目主数据' },
  ];

  return (
    <div className="w-64 bg-gray-900 text-white flex flex-col">
      <div className="h-16 flex items-center justify-center border-b border-gray-800">
        <h1 className="text-xl font-bold">HR Core System</h1>
      </div>
      <nav className="flex-1 p-4 space-y-2 font-medium">
        {navItems.map((item) => {
          const isActive = item.exact
            ? pathname === item.href
            : pathname.startsWith(item.href);

          return (
            <Link
              key={item.href}
              href={item.href}
              className={`block px-4 py-2 rounded transition-colors ${isActive
                  ? 'text-indigo-300 font-bold bg-indigo-900/40 shadow-inner'
                  : 'text-gray-400 hover:bg-gray-800 hover:text-gray-200'
                }`}
            >
              {item.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
