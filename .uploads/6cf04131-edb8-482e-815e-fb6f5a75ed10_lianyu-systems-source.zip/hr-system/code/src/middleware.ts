import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { decrypt } from '@/lib/session';

export async function middleware(request: NextRequest) {
  const currentPath = request.nextUrl.pathname;

  // 放行静态资源和登录接口
  if (currentPath.startsWith('/_next') || currentPath === '/login' || currentPath.startsWith('/api')) {
    return NextResponse.next();
  }

  // 拦截 /system 及其子路由
  if (currentPath.startsWith('/system')) {
    const sessionCookie = request.cookies.get('session')?.value;
    const session = await decrypt(sessionCookie);

    if (!session || !session.userId) {
      // 未登录或 token 无效，重定向到登录页
      const url = request.nextUrl.clone();
      url.pathname = '/login';
      return NextResponse.redirect(url);
    }
    
    // 如果需要更细粒度的鉴权，可以在这里根据 session.roleCode 进行拦截
    // 例如：非超级管理员不能访问 /system/roles
    if (currentPath.startsWith('/system/roles') && session.roleCode !== 'SUPER_ADMIN') {
      const url = request.nextUrl.clone();
      // 这里可以重定向到一个无权限提示页，暂时重定向到 /system/dashboard
      url.pathname = '/system'; 
      return NextResponse.redirect(url);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!api|_next/static|_next/image|favicon.ico).*)'],
};
