import { prisma } from './src/lib/prisma';
async function main() {
  await prisma.attendanceCalendar.deleteMany({});
  console.log("All calendar records deleted.");
}
main().catch(console.error);
