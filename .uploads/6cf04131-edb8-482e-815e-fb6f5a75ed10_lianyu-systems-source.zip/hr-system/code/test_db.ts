import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  try {
    const lisi = await prisma.employee.findFirst({
      where: { name: '李四' }
    });
    console.log('Employee 李四:', lisi);

    if (lisi) {
      const summary = await prisma.monthlyAttendanceSummary.findFirst({
        where: { name: '李四', month: '2026-05' }
      });
      console.log('MonthlyAttendanceSummary (2026-05):', summary);

      // check by actual date object
      const start = new Date('2026-05-01');
      const end = new Date('2026-06-01');
      const clockingsDateCount = await prisma.importedClocking.count({
        where: { name: '李四', date: { gte: start, lt: end } }
      });
      console.log('ImportedClocking count in 2026-05:', clockingsDateCount);

      const logs = await prisma.importedClocking.findMany({
        where: { name: '李四', date: { gte: start, lt: end } }
      });
      console.log('ImportedClockings:', logs);
    }
  } catch (e) {
    console.error(e);
  } finally {
    await prisma.$disconnect();
  }
}

main();
