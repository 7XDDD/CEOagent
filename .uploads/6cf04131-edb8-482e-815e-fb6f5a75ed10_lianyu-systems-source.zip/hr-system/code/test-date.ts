import { prisma } from './src/lib/prisma';
import { saveCalendarDay, getCalendarDays } from './src/actions/calendar';

async function main() {
  console.log("Saving...");
  const res1 = await saveCalendarDay('2026-06-11', 'HOLIDAY', 'Test Holiday');
  console.log("Save Result:", res1);
  
  console.log("Fetching...");
  const res2 = await getCalendarDays(2026, 6);
  console.log("Fetch Result:", res2);
}
main().catch(console.error);
