import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Start seeding...');

  // 1. 初始化系统默认角色
  const rolesData = [
    { code: 'SUPER_ADMIN', name: '超级管理员', description: '系统全量配置、底层数据库、强审计日志权限' },
    { code: 'HR_MANAGER', name: 'HR负责人', description: '全盘数据一键导入、全量人员主责录入、规则校准与报表导出' },
    { code: 'PMO', name: '项目PMO', description: '仅限所辖项目顾问信息查看、各月份实际现场投入天数填报' },
    { code: 'EMPLOYEE', name: '普通员工', description: '个人档案非敏感信息、考勤、调休假剩余额度及流水明细看板' },
  ];

  for (const r of rolesData) {
    await prisma.role.upsert({
      where: { code: r.code },
      update: {},
      create: r,
    });
  }

  // 2. 预置超级管理员用户
  const superAdminRole = await prisma.role.findUnique({ where: { code: 'SUPER_ADMIN' } });
  
  if (superAdminRole) {
    await prisma.user.upsert({
      where: { username: 'admin' },
      update: {},
      create: {
        username: 'admin',
        password: 'password123', // 在实际系统中应使用 bcrypt 等加密
        name: '系统管理员',
        email: 'admin@hrsystem.com',
        roleId: superAdminRole.id,
      },
    });
  }

  console.log('Seeding finished.');
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
