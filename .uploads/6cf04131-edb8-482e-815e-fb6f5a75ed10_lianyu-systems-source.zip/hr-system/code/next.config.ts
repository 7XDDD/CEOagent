import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  serverExternalPackages: ['chinese-days'],
};

export default nextConfig;
