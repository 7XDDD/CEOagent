import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Starting historical overtime sync...');
  
  // 1. Fetch all PROCESSED overtimes with netDuration > 0
  const overtimes = await prisma.importedOvertime.findMany({
    where: {
      status: 'PROCESSED',
      netDuration: { gt: 0 }
    }
  });

  console.log(`Found ${overtimes.length} valid overtime records.`);

  let added = 0;
  let skipped = 0;

  for (const ot of overtimes) {
    // 2. Resolve employee
    const emp = await prisma.employee.findUnique({
      where: { jobNumber: ot.jobNumber }
    });

    if (!emp) {
      console.log(`Skipped ${ot.approvalNumber}: Employee not found for jobNumber ${ot.jobNumber}`);
      skipped++;
      continue;
    }

    // 3. Check if it's a holiday
    const dateStr = ot.startTime.toISOString().split('T')[0];
    const dateObj = new Date(`${dateStr}T00:00:00.000Z`); // use midnight UTC
    
    // Attempt to match calendar date using start of day
    const calendarDay = await prisma.attendanceCalendar.findFirst({
      where: {
        date: {
          gte: new Date(`${dateStr}T00:00:00.000Z`),
          lt: new Date(`${dateStr}T23:59:59.999Z`)
        }
      }
    });

    const isHoliday = calendarDay ? calendarDay.type === 'HOLIDAY' : false;

    if (isHoliday) {
      console.log(`Skipped ${ot.approvalNumber}: Is Statutory Holiday`);
      skipped++;
      continue;
    }

    // 4. Check if quota already exists for this source date and employee
    const existing = await prisma.leaveQuota.findFirst({
      where: {
        employeeId: emp.id,
        leaveType: 'COMP_TIME',
        totalHours: ot.netDuration,
        // Since startTime could be slightly different, we match by date range
        sourceDate: {
          gte: new Date(`${dateStr}T00:00:00.000Z`),
          lt: new Date(`${dateStr}T23:59:59.999Z`)
        }
      }
    });

    if (existing) {
      console.log(`Skipped ${ot.approvalNumber}: Quota already exists`);
      skipped++;
      continue;
    }

    // 5. Calculate expiration date (1 year)
    const expireAt = new Date(dateObj);
    expireAt.setFullYear(expireAt.getFullYear() + 1);
    expireAt.setDate(expireAt.getDate() - 1);
    expireAt.setHours(23, 59, 59, 999);

    // 6. Insert LeaveQuota and update LeaveBalance
    await prisma.leaveQuota.create({
      data: {
        employeeId: emp.id,
        leaveType: 'COMP_TIME',
        totalHours: ot.netDuration,
        usedHours: 0,
        expireAt: expireAt,
        sourceDate: dateObj
      }
    });

    await prisma.leaveBalance.upsert({
      where: { employeeId: emp.id },
      update: { compensatory: { increment: ot.netDuration } },
      create: { employeeId: emp.id, compensatory: ot.netDuration }
    });

    console.log(`Added ${ot.netDuration} hours for ${emp.name} from ${dateStr}`);
    added++;
  }

  console.log(`\nSync complete! Added: ${added}, Skipped: ${skipped}`);
}

main()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
