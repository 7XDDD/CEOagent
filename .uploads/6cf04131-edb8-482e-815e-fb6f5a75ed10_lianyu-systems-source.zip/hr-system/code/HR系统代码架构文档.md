# HR系统代码架构文档

## 1. 技术栈选型建议
*   **前端**：Vue 3 / React, TypeScript, Tailwind CSS, Ant Design / Element Plus
*   **后端**：Java (Spring Boot) / Node.js (NestJS) / Go (Gin), RESTful API 或 GraphQL
*   **数据库**：MySQL / PostgreSQL (核心数据), Redis (缓存与会话管理)
*   **消息队列**：RabbitMQ / Kafka (用于异步任务，如批量发送工资条通知)
*   **部署架构**：Docker, Kubernetes, CI/CD 自动化部署

## 2. 代码目录结构设计 (业务场景划分)
本项目采用领域驱动设计 (DDD) 或按业务模块划分微服务/模块。在 `code` 目录下，按照业务场景生成了相应的文件夹目录。

*   `employee_management/` - 组织架构与人事档案模块代码
*   `attendance_management/` - 考勤打卡与排班模块代码
*   `payroll_management/` - 薪资核算与福利模块代码
*   `performance_management/` - 绩效考核方案与评分模块代码
*   `recruitment_management/` - 简历流转与面试模块代码
*   `system_core/` - 系统核心模块（用户、权限RBAC、日志、基础配置）

## 3. 开发规范
*   遵循 RESTful API 设计标准。
*   所有业务逻辑需编写单元测试，覆盖率要求不低于 80%。
*   代码提交需遵循 Conventional Commits 规范 (feat, fix, docs, refactor 等)。
