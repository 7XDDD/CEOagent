# 考勤管理模块 (Attendance Management)

## 模块职责
管理员工排班规则、考勤打卡记录、请假、加班、出差等流程审批以及考勤月度汇总。

## 核心接口设计
*   `POST /api/v1/attendance/clock-in` - 上下班打卡
*   `GET /api/v1/attendance/records` - 查询打卡记录
*   `POST /api/v1/attendance/leaves` - 提交请假申请
*   `GET /api/v1/attendance/monthly-summary` - 获取月度考勤汇总报表

## 数据表设计概要
*   `hr_attendance_rule` - 考勤规则表
*   `hr_attendance_record` - 员工打卡记录表
*   `hr_leave_request` - 请假申请表
*   `hr_attendance_summary` - 考勤汇总明细表
