# 招聘管理模块 (Recruitment Management)

## 模块职责
统筹企业用人需求，发布职位，收集与解析简历，安排面试流程并最终发放Offer。

## 核心接口设计
*   `POST /api/v1/recruitment/requirements` - 提交招聘需求
*   `GET /api/v1/recruitment/positions` - 获取对外发布的职位列表
*   `POST /api/v1/recruitment/resumes` - 简历投递/录入
*   `POST /api/v1/recruitment/interviews` - 安排面试
*   `POST /api/v1/recruitment/offers` - 生成并发送Offer

## 数据表设计概要
*   `hr_recruit_position` - 招聘职位表
*   `hr_resume` - 简历信息库
*   `hr_interview_record` - 面试流程与评价表
*   `hr_offer_record` - Offer记录表
