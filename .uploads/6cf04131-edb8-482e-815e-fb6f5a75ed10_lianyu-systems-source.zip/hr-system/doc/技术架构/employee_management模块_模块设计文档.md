# 组织人事管理模块 (Employee Management)

## 模块职责
负责管理企业组织架构、部门信息、岗位职级以及员工全生命周期（入职、转正、调岗、离职）档案信息。

## 核心接口设计
*   `GET /api/v1/departments` - 获取组织架构树
*   `POST /api/v1/departments` - 新增部门
*   `GET /api/v1/employees` - 分页获取员工列表
*   `POST /api/v1/employees` - 员工入职办理
*   `GET /api/v1/employees/{id}` - 获取员工详情档案
*   `PUT /api/v1/employees/{id}/status` - 更新员工状态（转正/离职等）

## 数据表设计概要
*   `sys_department` - 部门表
*   `sys_position` - 岗位表
*   `hr_employee` - 员工主表
*   `hr_employee_contract` - 员工合同表
