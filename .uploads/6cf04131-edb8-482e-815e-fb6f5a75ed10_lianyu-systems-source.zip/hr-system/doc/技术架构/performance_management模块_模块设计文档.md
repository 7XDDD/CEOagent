# 绩效管理模块 (Performance Management)

## 模块职责
建立KPI/OKR指标库，发起周期性绩效考核，记录各级评分结果并应用到薪酬计算。

## 核心接口设计
*   `GET /api/v1/performance/indicators` - 获取考核指标库
*   `POST /api/v1/performance/assessments` - 创建考核任务
*   `POST /api/v1/performance/assessments/{id}/score` - 提交考核评分
*   `GET /api/v1/performance/results` - 查询考核结果报表

## 数据表设计概要
*   `hr_perf_indicator` - 绩效指标库
*   `hr_perf_plan` - 绩效考核计划
*   `hr_perf_assessment` - 个人考核明细表
*   `hr_perf_score_record` - 评分流程记录表
