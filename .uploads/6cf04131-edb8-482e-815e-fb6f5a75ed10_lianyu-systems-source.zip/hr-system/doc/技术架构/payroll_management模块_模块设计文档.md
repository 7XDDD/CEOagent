# 薪酬福利管理模块 (Payroll Management)

## 模块职责
根据员工基本薪资、考勤数据、绩效成绩以及社保公积金基数，自动计算每月薪资，并支持工资条发放。

## 核心接口设计
*   `GET /api/v1/payroll/plans` - 获取薪酬方案配置
*   `POST /api/v1/payroll/calculate` - 触发特定月份薪资核算
*   `GET /api/v1/payroll/salary-slips` - 获取工资条列表
*   `POST /api/v1/payroll/salary-slips/publish` - 发放电子工资条

## 数据表设计概要
*   `hr_salary_plan` - 薪资方案表
*   `hr_social_security_rule` - 社保公积金缴纳规则表
*   `hr_salary_record` - 薪资计算明细主表
*   `hr_salary_slip` - 员工工资条视图表
