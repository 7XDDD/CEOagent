# GitHub 仓库指南

你可以去浏览器里刷新一下你的仓库页面：
[https://github.com/ethelliu37-liu/hr-system](https://github.com/ethelliu37-liu/hr-system)

确认一下所有的文件是不是都已经就位了。以后你在此工程里的任何修改，只要执行 `git commit` 和 `git push`，就会自动使用这个新 Token 推送上去，不需要你再额外输入密码了。
