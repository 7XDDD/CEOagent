package com.crm.vo.budget;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class BudgetSheetVO {

    private Long id;

    private Long companyId;

    private Integer fiscalYear;

    private Long versionId;

    private Long catalogId;

    private String catalogCode;

    private Long contractId;

    private String contractNo;

    private String contractName;

    private String projectCode;

    private String projectName;

    private BigDecimal contractAmount;

    private Long customerId;

    private String customerName;

    private Long contractTypeId;

    private String contractType;

    private String contractTypeName;

    private Long orgId;

    private String orgName;

    private Long productLineId;

    private String productLineName;

    private String productLine;

    private String stockFlag;

    private String manager;

    private String salesManager;

    private String contractStatus;

    private BigDecimal totalAmount;

    private String calcRule;

    private String approvalStatus;

    private Integer isSummaryRow;

    private String remark;

    private Long ownerId;

    private Long createdBy;

    private Long updatedBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    private Integer version;

    private Integer deleted;
}
