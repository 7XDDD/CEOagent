package com.crm.dto;

import lombok.Data;

@Data
public class PageQueryDTO {
    private Integer pageNum = 1;
    private Integer pageSize = 10;
    private String keyword;
    private String sortField;
    private String sortOrder;
    private Integer fiscalYear;
    private Long companyId;
    private Long versionId;
    private String catalogCode;
    private String contractStatus;
    private String stockFlag;
    private Long contractTypeId;
    private Long orgId;
    private Long customerId;
    private String budgetScene;
    
    private String productLine;
    private String projectName;
    private String manager;
    private String customerName;
    private String contractTypeName;
    private String invoiceStatus;
}
