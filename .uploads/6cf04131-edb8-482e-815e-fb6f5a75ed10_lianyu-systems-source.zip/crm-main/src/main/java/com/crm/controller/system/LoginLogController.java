package com.crm.controller.system;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.Result;
import com.crm.dto.system.LoginLogQueryDTO;
import com.crm.service.LoginLogService;
import com.crm.vo.system.LoginLogVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(tags = "系统管理-登录日志")
@RestController
@RequestMapping("/system/login-log")
public class LoginLogController {

    @Autowired
    private LoginLogService loginLogService;

    @ApiOperation("分页查询登录日志")
    // 与角色管理「登录日志-查看」按钮权限码（橙色标签 base:log:login:view）对齐；菜单级权限仅控制侧边栏入口显示
    // 主权限：与角色管理「登录日志-查看」橙色标签对齐（base:log:login:view）；同时兼容旧配置的模块级编码（base:log:login）
    @PreAuthorize("@permissionChecker.hasAnyPermission('crm:log:login:view','crm:log:login')")
    @GetMapping("/page")
    public Result<Page<LoginLogVO>> page(LoginLogQueryDTO query) {
        return Result.success(loginLogService.pageList(query));
    }
}
