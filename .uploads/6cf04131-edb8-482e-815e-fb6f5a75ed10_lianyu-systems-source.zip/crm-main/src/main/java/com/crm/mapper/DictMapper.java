package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.system.DictQueryDTO;
import com.crm.entity.Dict;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface DictMapper extends BaseMapper<Dict> {

    Page<Dict> selectPageList(Page<Dict> page, @Param("q") DictQueryDTO query);

    Dict findByDictCode(@Param("dictCode") String dictCode);

    Dict findByDictCodeAndSystemType(@Param("dictCode") String dictCode, @Param("systemType") String systemType);

    List<Dict> findByDictType(@Param("dictType") String dictType);

    int softDeleteById(@Param("id") Long id);
}
