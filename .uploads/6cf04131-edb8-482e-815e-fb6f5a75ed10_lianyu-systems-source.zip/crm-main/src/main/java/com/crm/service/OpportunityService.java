package com.crm.service;

import com.crm.dto.PageResult;
import com.crm.dto.opportunity.OpportunityCreateDTO;
import com.crm.dto.opportunity.OpportunityQueryDTO;
import com.crm.dto.opportunity.OpportunityUpdateDTO;
import com.crm.vo.opportunity.OpportunityVO;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

public interface OpportunityService {

    PageResult<OpportunityVO> page(OpportunityQueryDTO query);

    List<OpportunityVO> list(OpportunityQueryDTO query);

    OpportunityVO getById(Long id);

    OpportunityVO save(OpportunityCreateDTO dto);

    OpportunityVO update(OpportunityUpdateDTO dto);

    void deleteById(Long id);

    void deleteBatch(List<Long> ids);

    OpportunityVO changeStage(Long id, String stage);

    OpportunityVO changeStatus(Long id, String status);

    /** 转移商机负责人给其他用户 */
    OpportunityVO transfer(Long id, Long newOwnerId, String newOwnerName);

    /** 由商机一键构建合同草稿，返回新建合同ID */
    Long buildContract(Long opportunityId);

    void exportOpportunities(OpportunityQueryDTO query, HttpServletResponse response) throws Exception;

    void downloadImportTemplate(HttpServletResponse response) throws Exception;

    Map<String, Object> importExcel(Long companyId, MultipartFile file);
}
