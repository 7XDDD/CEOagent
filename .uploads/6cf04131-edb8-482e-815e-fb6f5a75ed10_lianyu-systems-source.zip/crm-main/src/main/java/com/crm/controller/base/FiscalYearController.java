package com.crm.controller.base;

import com.crm.annotation.OperationLog;
import com.crm.common.Result;
import com.crm.dto.PageResult;
import com.crm.dto.base.FiscalYearCreateDTO;
import com.crm.dto.base.FiscalYearQueryDTO;
import com.crm.dto.base.FiscalYearUpdateDTO;
import com.crm.service.base.FiscalYearService;
import com.crm.vo.base.FiscalYearVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.Serializable;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/base/fiscal-year")
public class FiscalYearController {

    @Autowired
    private FiscalYearService fiscalYearService;

    @GetMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:base:year:view')")
    public Result<FiscalYearVO> getById(@PathVariable Serializable id) {
        FiscalYearVO vo = fiscalYearService.getById(id);
        return Result.success("查询成功", vo);
    }

    @PostMapping("/page")
    @PreAuthorize("@permissionChecker.hasPermission('crm:base:year:view')")
    public Result<PageResult<FiscalYearVO>> page(@RequestBody(required = false) FiscalYearQueryDTO query) {
        PageResult<FiscalYearVO> result = fiscalYearService.page(query);
        return Result.success("查询成功", result);
    }

    @PostMapping("/list")
    @PreAuthorize("@permissionChecker.hasPermission('crm:base:year:view')")
    public Result<List<FiscalYearVO>> list(@RequestBody(required = false) FiscalYearQueryDTO query) {
        List<FiscalYearVO> list = fiscalYearService.list(query);
        return Result.success("查询成功", list);
    }

    @PostMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:base:year:edit')")
    @OperationLog(module = "基础数据", description = "新增财年", type = OperationLog.OperationType.INSERT)
    public Result<FiscalYearVO> create(@Valid @RequestBody FiscalYearCreateDTO dto) {
        FiscalYearVO vo = fiscalYearService.create(dto);
        return Result.success("保存成功", vo);
    }

    @PutMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:base:year:edit')")
    @OperationLog(module = "基础数据", description = "更新财年", type = OperationLog.OperationType.UPDATE)
    public Result<FiscalYearVO> update(@Valid @RequestBody FiscalYearUpdateDTO dto) {
        FiscalYearVO vo = fiscalYearService.update(dto);
        return Result.success("更新成功", vo);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:base:year:edit')")
    @OperationLog(module = "基础数据", description = "删除财年", type = OperationLog.OperationType.DELETE)
    public Result<String> delete(@PathVariable Serializable id) {
        fiscalYearService.deleteById(id);
        return Result.success("删除成功", null);
    }

    @DeleteMapping("/batch")
    @PreAuthorize("@permissionChecker.hasPermission('crm:base:year:edit')")
    @OperationLog(module = "基础数据", description = "批量删除财年", type = OperationLog.OperationType.DELETE)
    public Result<String> deleteBatch(@RequestBody List<Long> ids) {
        fiscalYearService.deleteBatch(ids);
        return Result.success("批量删除成功", null);
    }

    @GetMapping("/list/all")
    public Result<List<FiscalYearVO>> listAll() {
        List<FiscalYearVO> list = fiscalYearService.listAllActive();
        return Result.success("查询成功", list);
    }

    @GetMapping("/current")
    public Result<FiscalYearVO> getCurrent() {
        FiscalYearVO vo = fiscalYearService.getCurrent();
        return Result.success("查询成功", vo);
    }
}
