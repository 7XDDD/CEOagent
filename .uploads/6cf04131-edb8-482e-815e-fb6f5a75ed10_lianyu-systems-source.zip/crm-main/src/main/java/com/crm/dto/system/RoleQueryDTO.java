package com.crm.dto.system;

import com.crm.dto.PageQueryDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class RoleQueryDTO extends PageQueryDTO {
    private String keyword;
    private Integer status;
    private String roleType;
}
