package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.CustomerQueryDTO;
import com.crm.entity.PmtCustomer;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PmtCustomerMapper extends BaseMapper<PmtCustomer> {

    PmtCustomer selectCustomerById(@Param("id") Long id);

    Page<PmtCustomer> selectPageList(Page<PmtCustomer> page, @Param("query") CustomerQueryDTO query);

    Page<PmtCustomer> selectPublicSeaList(Page<PmtCustomer> page, @Param("query") CustomerQueryDTO query);

    List<PmtCustomer> selectListByCondition(@Param("query") CustomerQueryDTO query);

    List<PmtCustomer> selectAllActive();

    PmtCustomer findByName(@Param("customerName") String customerName);

    PmtCustomer findByCode(@Param("customerCode") String customerCode);

    int countByCode(@Param("customerCode") String customerCode, @Param("excludeId") Long excludeId);

    List<PmtCustomer> selectByIds(@Param("ids") List<Long> ids);

    int insertCustomer(PmtCustomer customer);

    int updateCustomer(PmtCustomer customer);

    int softDeleteById(@Param("id") Long id);

    int softDeleteByIds(@Param("ids") List<Long> ids);
}
