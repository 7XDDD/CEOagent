package com.crm.service.budget.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.BusinessException;
import com.crm.common.ExcelUtil;
import com.crm.common.ResultCode;
import com.crm.common.SecurityContextUtil;
import com.crm.dto.BudgetCalculateRequest;
import com.crm.dto.PageResult;
import com.crm.dto.budget.BudgetSheetQueryDTO;
import com.crm.entity.BudgetLine;
import com.crm.entity.BudgetPeriodAmount;
import com.crm.entity.BudgetSheet;
import com.crm.mapper.BudgetLineMapper;
import com.crm.mapper.BudgetPeriodAmountMapper;
import com.crm.mapper.budget.BudgetSheetMapper;
import com.crm.service.budget.BudgetCalculateService;
import com.crm.service.budget.BudgetSheetService;
import com.crm.vo.budget.BudgetSheetSummaryVO;
import com.crm.vo.budget.BudgetSheetVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 预算明细服务实现类
 * 负责预算明细数据的查询、计算、导出等操作
 * 核心业务逻辑：
 * 1. 按版本查询预算明细数据
 * 2. 按预算类型（合同额/收入/税费）汇总月度数据
 * 3. 导出Excel报表（单Sheet/多Sheet/对比分析）
 * 4. 批量获取期间金额数据
 */
@Service
public class BudgetSheetServiceImpl implements BudgetSheetService {

    private static final Logger log = LoggerFactory.getLogger(BudgetSheetServiceImpl.class);

    private static final String CATALOG_CODE_CONTRACT_AMOUNT = "101";
    private static final String CATALOG_CODE_REVENUE = "102";
    private static final String CATALOG_CODE_TAX = "103";
    private static final String CATALOG_CODE_REPAYMENT = "201";
    private static final BigDecimal WAN = new BigDecimal("10000");

    @Autowired
    private BudgetSheetMapper budgetSheetMapper;

    @Autowired
    private BudgetLineMapper lineMapper;

    @Autowired
    private BudgetPeriodAmountMapper periodAmountMapper;

    @Autowired
    private BudgetCalculateService budgetCalculateService;

    /**
     * 分页查询预算明细列表
     * @param query 查询条件DTO
     * @return 分页结果（包含summary全量统计）
     */
    @Override
    public PageResult<BudgetSheetVO> page(BudgetSheetQueryDTO query) {
        if (query == null) query = new BudgetSheetQueryDTO();
        int pageNum = query.getPageNum() != null ? query.getPageNum() : 1;
        int pageSize = query.getPageSize() != null ? query.getPageSize() : 10;
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;

        Page<BudgetSheetVO> page = new Page<>(pageNum, pageSize);
        IPage<BudgetSheetVO> result = budgetSheetMapper.selectPageList(page, companyId, query);
        for (BudgetSheetVO vo : result.getRecords()) {
            vo.setContractAmount(toWan(vo.getContractAmount()));
            vo.setTotalAmount(toWan(vo.getTotalAmount()));
        }

        PageResult<BudgetSheetVO> pr = new PageResult<>(result.getRecords(), result.getTotal(), pageNum, pageSize);

        BudgetSheetSummaryVO summary = buildSummary(companyId, query);
        pr.setSummary(summary);

        return pr;
    }

    private BudgetSheetSummaryVO buildSummary(Long companyId, BudgetSheetQueryDTO query) {
        BudgetSheetSummaryVO summary = new BudgetSheetSummaryVO();
        try {
            Map<String, Object> baseStats = budgetSheetMapper.selectSummaryBaseStats(companyId, query, null);
            if (baseStats != null) {
                Object cnt = baseStats.get("contractCount");
                if (cnt != null) {
                    summary.setContractCount(((Number) cnt).longValue());
                }
                Object tca = baseStats.get("totalContractAmount");
                if (tca != null) {
                    summary.setTotalContractAmount(toWan(toBigDecimal(tca)).setScale(6, RoundingMode.HALF_UP));
                }
                Object tba = baseStats.get("totalBudgetAmount");
                if (tba != null) {
                    summary.setTotalBudgetAmount(toWan(toBigDecimal(tba)).setScale(6, RoundingMode.HALF_UP));
                }
            }

            List<Long> sheetIds = budgetSheetMapper.selectSummarySheetIds(companyId, query);
            if (sheetIds != null && !sheetIds.isEmpty()) {
                List<Map<String, Object>> monthAmts = budgetSheetMapper.selectSummaryMonthAmounts(sheetIds);
                BigDecimal[] months = summary.getMonthAmounts();
                for (Map<String, Object> row : monthAmts) {
                    String periodCode = (String) row.get("periodCode");
                    Object amtObj = row.get("amount");
                    if (periodCode == null || amtObj == null) continue;
                    int m = parseMonth(periodCode);
                    if (m >= 1 && m <= 12) {
                        BigDecimal amt = toWan(toBigDecimal(amtObj)).setScale(6, RoundingMode.HALF_UP);
                        months[m] = months[m].add(amt);
                    }
                }
                BigDecimal[] quarters = summary.getQuarterAmounts();
                quarters[1] = months[1].add(months[2]).add(months[3]);
                quarters[2] = months[4].add(months[5]).add(months[6]);
                quarters[3] = months[7].add(months[8]).add(months[9]);
                quarters[4] = months[10].add(months[11]).add(months[12]);
            }
        } catch (Exception e) {
            log.warn("构建预算统计汇总失败: {}", e.getMessage(), e);
        }
        return summary;
    }

    private static BigDecimal toBigDecimal(Object obj) {
        if (obj == null) return BigDecimal.ZERO;
        if (obj instanceof BigDecimal) return (BigDecimal) obj;
        if (obj instanceof Number) return new BigDecimal(obj.toString());
        try {
            return new BigDecimal(obj.toString());
        } catch (Exception e) {
            return BigDecimal.ZERO;
        }
    }

    /**
     * 根据合同ID查询关联的预算明细
     * @param contractId 合同ID
     * @return 预算明细列表
     */
    @Override
    public List<BudgetSheetVO> getByContract(Long contractId) {
        return budgetSheetMapper.selectByContract(contractId);
    }

    /**
     * 触发预算计算
     * @param request 预算计算请求参数
     * @return 计算结果信息
     */
    @Override
    public String calculateBudget(BudgetCalculateRequest request) {
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        return budgetCalculateService.calculateBudget(companyId, request);
    }

    /**
     * 获取预算明细行数据
     * @param sheetId 预算单ID
     * @return 预算行列表
     */
    @Override
    public List<BudgetLine> getLines(Long sheetId) {
        List<BudgetLine> list = lineMapper.selectBySheetId(sheetId);
        for (BudgetLine line : list) {
            line.setContractAmount(toWan(line.getContractAmount()));
            line.setLineAmount(toWan(line.getLineAmount()));
        }
        return list;
    }

    /**
     * 获取预算单的期间金额数据
     * @param sheetId 预算单ID
     * @return 期间金额列表
     */
    @Override
    public List<BudgetPeriodAmount> getPeriodAmounts(Long sheetId) {
        List<BudgetPeriodAmount> list = periodAmountMapper.selectBySheetId(sheetId);
        for (BudgetPeriodAmount pa : list) {
            pa.setBudgetAmount(toWan(pa.getBudgetAmount()));
        }
        return list;
    }

    /**
     * 批量获取多个预算单的期间金额数据
     * 关键逻辑：将逗号分隔的sheetId字符串解析后批量查询，按sheetId分组返回
     * @param sheetIdsStr 逗号分隔的预算单ID字符串
     * @return key为sheetId，value为该单的期间金额列表
     */
    @Override
    public Map<Long, List<BudgetPeriodAmount>> getPeriodAmountsBatch(String sheetIdsStr) {
        if (sheetIdsStr == null || sheetIdsStr.trim().isEmpty()) {
            return Collections.emptyMap();
        }
        // 1. 解析逗号分隔的ID字符串
        List<Long> sheetIds = new ArrayList<>();
        for (String s : sheetIdsStr.split(",")) {
            try {
                sheetIds.add(Long.valueOf(s.trim()));
            } catch (Exception ignored) {
            }
        }
        if (sheetIds.isEmpty()) {
            return Collections.emptyMap();
        }
        // 2. 批量查询并按sheetId分组，同时将金额从元转万元
        List<BudgetPeriodAmount> all = periodAmountMapper.selectBySheetIds(sheetIds);
        for (BudgetPeriodAmount pa : all) {
            pa.setBudgetAmount(toWan(pa.getBudgetAmount()));
        }
        return all.stream().collect(Collectors.groupingBy(BudgetPeriodAmount::getBudgetSheetId));
    }

    /**
     * 导出指定类型的预算明细Excel（单Sheet）
     * 关键逻辑：
     * 1. 按版本、财年、预算类型查询数据
     * 2. 批量加载期间金额并按月汇总
     * 3. 金额单位转换为万元
     * @param fiscalYear 财年
     * @param versionId 版本ID
     * @param catalogCode 预算类型编码
     * @param response HTTP响应
     */
    @Override
    public void exportBudgetSheets(Integer fiscalYear, Long versionId, String catalogCode, Long orgId, Long productLineId, String orgName, String productLineName, HttpServletResponse response) throws Exception {
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        if (fiscalYear == null) fiscalYear = LocalDate.now().getYear();

        List<BudgetSheetVO> sheets = budgetSheetMapper.selectListByCondition(companyId, fiscalYear, versionId, catalogCode, orgId, productLineId);

        List<Map<String, Object>> rows = new ArrayList<>();
        if (!sheets.isEmpty()) {
            // 2. 批量查询期间金额并分组
            List<Long> sheetIds = sheets.stream().map(BudgetSheetVO::getId).collect(Collectors.toList());
            Map<Long, List<BudgetPeriodAmount>> paBySheet = periodAmountMapper.selectBySheetIds(sheetIds).stream()
                    .collect(Collectors.groupingBy(BudgetPeriodAmount::getBudgetSheetId));

            // 3. 组装每行数据，按月汇总金额
            for (BudgetSheetVO sheet : sheets) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("catalogName", catalogCodeToName(sheet.getCatalogCode()));
                row.put("stockFlag", "STOCK".equals(sheet.getStockFlag()) ? "存量" : "增量");
                row.put("contractNo", sheet.getContractNo());
                row.put("contractName", sheet.getContractName());
                row.put("projectName", sheet.getProjectName());
                row.put("manager", sheet.getManager());
                row.put("salesManager", sheet.getSalesManager());
                row.put("customerName", sheet.getCustomerName());
                row.put("contractTypeName", sheet.getContractTypeName());
                row.put("contractStatus", contractStatusToText(sheet.getContractStatus()));
                row.put("contractAmount", toWan(sheet.getContractAmount()).setScale(6, RoundingMode.HALF_UP));
                row.put("totalAmount", toWan(sheet.getTotalAmount()).setScale(6, RoundingMode.HALF_UP));

                // 4. 按月汇总期间金额（从元转为万元）
                List<BudgetPeriodAmount> paList = paBySheet.getOrDefault(sheet.getId(), Collections.emptyList());
                Map<Integer, BigDecimal> monthAmounts = new HashMap<>();
                for (BudgetPeriodAmount pa : paList) {
                    int month = parseMonth(pa.getPeriodCode());
                    if (month >= 1 && month <= 12) {
                        monthAmounts.put(month, monthAmounts.getOrDefault(month, BigDecimal.ZERO)
                                .add(toWan(pa.getBudgetAmount())));
                    }
                }
                for (int m = 1; m <= 12; m++) {
                    BigDecimal amt = monthAmounts.getOrDefault(m, BigDecimal.ZERO);
                    row.put("M" + m, amt.setScale(6, RoundingMode.HALF_UP));
                }
                for (int q = 1; q <= 4; q++) {
                    int m1 = (q - 1) * 3 + 1;
                    BigDecimal qAmt = monthAmounts.getOrDefault(m1, BigDecimal.ZERO)
                            .add(monthAmounts.getOrDefault(m1 + 1, BigDecimal.ZERO))
                            .add(monthAmounts.getOrDefault(m1 + 2, BigDecimal.ZERO));
                    row.put("Q" + q, qAmt.setScale(6, RoundingMode.HALF_UP));
                }
                rows.add(row);
            }
        }

        // 5. 定义Excel列并导出
        List<ExcelUtil.Column<Map<String, Object>>> columns = new ArrayList<>();
        columns.add(ExcelUtil.Column.of("预算类型", 12, r -> (String) r.get("catalogName")));
        columns.add(ExcelUtil.Column.of("性质", 8, r -> (String) r.get("stockFlag")));
        columns.add(ExcelUtil.Column.of("合同编号", 16, r -> (String) r.get("contractNo")));
        columns.add(ExcelUtil.Column.of("合同名称", 28, r -> (String) r.get("contractName")));
        columns.add(ExcelUtil.Column.of("项目名称", 22, r -> (String) r.get("projectName")));
        columns.add(ExcelUtil.Column.of("客户名称", 18, r -> (String) r.get("customerName")));
        columns.add(ExcelUtil.Column.of("合同类型", 12, r -> (String) r.get("contractTypeName")));
        columns.add(ExcelUtil.Column.of("负责人", 10, r -> (String) r.get("manager")));
        columns.add(ExcelUtil.Column.of("销售经理", 10, r -> (String) r.get("salesManager")));
        columns.add(ExcelUtil.Column.of("状态", 10, r -> (String) r.get("contractStatus")));
        columns.add(ExcelUtil.Column.of("合同金额(万元)", 16, r -> (BigDecimal) r.get("contractAmount")));
        columns.add(ExcelUtil.Column.of("预算合计(万元)", 16, r -> (BigDecimal) r.get("totalAmount")));
        for (int m = 1; m <= 12; m++) {
            final int mm = m;
            columns.add(ExcelUtil.Column.of(m + "月(万元)", 12, r -> (BigDecimal) r.get("M" + mm)));
        }
        for (int q = 1; q <= 4; q++) {
            final int qq = q;
            columns.add(ExcelUtil.Column.of("Q" + q + "(万元)", 12, r -> (BigDecimal) r.get("Q" + qq)));
        }

        String fileName = "预算明细_" + fiscalYear + "_" + catalogCodeToName(catalogCode);
        if (orgName != null && !orgName.isEmpty()) fileName += "_" + orgName;
        if (productLineName != null && !productLineName.isEmpty()) fileName += "_" + productLineName;
        fileName += "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        ExcelUtil.export(rows, "预算明细", columns, response, fileName);
    }

    /**
     * 导出全部预算类型明细（多Sheet Excel）
     * 关键逻辑：
     * 1. 按合同额、收入、税费三种类型分别生成Sheet
     * 2. 每个Sheet包含明细数据和汇总行
     * 3. 汇总行计算各月度和年度合计
     * @param fiscalYear 财年
     * @param versionId 版本ID
     * @param response HTTP响应
     */
    @Override
    public void exportAll(Integer fiscalYear, Long versionId, Long orgId, Long productLineId, String orgName, String productLineName, HttpServletResponse response) throws Exception {
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        if (fiscalYear == null) fiscalYear = LocalDate.now().getYear();

        String[] catalogCodes = {CATALOG_CODE_CONTRACT_AMOUNT, CATALOG_CODE_REVENUE, CATALOG_CODE_TAX, CATALOG_CODE_REPAYMENT};
        String[] catalogNames = {"合同额预算", "收入预算", "税费预算", "回款预算"};

        List<BudgetSheetVO> allSheets = budgetSheetMapper.selectListByCondition(companyId, fiscalYear, versionId, null, orgId, productLineId);

        // 2. 批量加载期间金额并分组
        List<Long> allSheetIds = allSheets.stream().map(BudgetSheetVO::getId).collect(Collectors.toList());
        Map<Long, List<BudgetPeriodAmount>> paBySheet = new HashMap<>();
        if (!allSheetIds.isEmpty()) {
            paBySheet = periodAmountMapper.selectBySheetIds(allSheetIds).stream()
                    .collect(Collectors.groupingBy(BudgetPeriodAmount::getBudgetSheetId));
        }

        // 3. 按预算类型分组
        Map<String, List<BudgetSheetVO>> sheetsByCatalog = allSheets.stream()
                .collect(Collectors.groupingBy(BudgetSheetVO::getCatalogCode));

        List<Map<String, Object>> sheetDataList = new ArrayList<>();

        // 4. 为每种预算类型生成Sheet数据
        for (int ci = 0; ci < catalogCodes.length; ci++) {
            String code = catalogCodes[ci];
            String name = catalogNames[ci];
            List<BudgetSheetVO> catSheets = sheetsByCatalog.getOrDefault(code, Collections.emptyList());

            List<ExcelUtil.Column<Map<String, Object>>> columns = new ArrayList<>();
            columns.add(ExcelUtil.Column.of("预算类型", 12, r -> (String) r.get("catalogName")));
            columns.add(ExcelUtil.Column.of("性质", 8, r -> (String) r.get("stockFlag")));
            columns.add(ExcelUtil.Column.of("合同编号", 16, r -> (String) r.get("contractNo")));
            columns.add(ExcelUtil.Column.of("合同名称", 28, r -> (String) r.get("contractName")));
            columns.add(ExcelUtil.Column.of("项目名称", 22, r -> (String) r.get("projectName")));
            columns.add(ExcelUtil.Column.of("客户名称", 18, r -> (String) r.get("customerName")));
            columns.add(ExcelUtil.Column.of("合同类型", 12, r -> (String) r.get("contractTypeName")));
            columns.add(ExcelUtil.Column.of("负责人", 10, r -> (String) r.get("manager")));
            columns.add(ExcelUtil.Column.of("销售经理", 10, r -> (String) r.get("salesManager")));
            columns.add(ExcelUtil.Column.of("状态", 10, r -> (String) r.get("contractStatus")));
            columns.add(ExcelUtil.Column.of("合同金额(万元)", 16, r -> (BigDecimal) r.get("contractAmount")));
            columns.add(ExcelUtil.Column.of("预算合计(万元)", 16, r -> (BigDecimal) r.get("totalAmount")));
            for (int m = 1; m <= 12; m++) {
                final int mm = m;
                columns.add(ExcelUtil.Column.of(m + "月(万元)", 12, r -> (BigDecimal) r.get("M" + mm)));
            }
            for (int q = 1; q <= 4; q++) {
                final int qq = q;
                columns.add(ExcelUtil.Column.of("Q" + q + "(万元)", 12, r -> (BigDecimal) r.get("Q" + qq)));
            }

            List<Map<String, Object>> rows = new ArrayList<>();
            BigDecimal sumContractAmount = BigDecimal.ZERO;
            BigDecimal sumTotalAmount = BigDecimal.ZERO;
            BigDecimal[] sumMonths = new BigDecimal[13];
            BigDecimal[] sumQuarters = new BigDecimal[5];
            for (int m = 1; m <= 12; m++) sumMonths[m] = BigDecimal.ZERO;
            for (int q = 1; q <= 4; q++) sumQuarters[q] = BigDecimal.ZERO;
            // 5. 组装明细行，同时累加汇总数据
            for (BudgetSheetVO sheet : catSheets) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("catalogName", catalogCodeToName(sheet.getCatalogCode()));
                row.put("stockFlag", "STOCK".equals(sheet.getStockFlag()) ? "存量" : "增量");
                row.put("contractNo", sheet.getContractNo());
                row.put("contractName", sheet.getContractName());
                row.put("projectName", sheet.getProjectName());
                row.put("manager", sheet.getManager());
                row.put("salesManager", sheet.getSalesManager());
                row.put("customerName", sheet.getCustomerName());
                row.put("contractTypeName", sheet.getContractTypeName());
                row.put("contractStatus", contractStatusToText(sheet.getContractStatus()));
                BigDecimal ca = toWan(sheet.getContractAmount()).setScale(6, RoundingMode.HALF_UP);
                BigDecimal ta = toWan(sheet.getTotalAmount()).setScale(6, RoundingMode.HALF_UP);
                row.put("contractAmount", ca);
                row.put("totalAmount", ta);
                sumContractAmount = sumContractAmount.add(ca);
                sumTotalAmount = sumTotalAmount.add(ta);

                // 按月汇总期间金额（元转万元）
                List<BudgetPeriodAmount> paList = paBySheet.getOrDefault(sheet.getId(), Collections.emptyList());
                Map<Integer, BigDecimal> monthAmounts = new HashMap<>();
                for (int m = 1; m <= 12; m++) monthAmounts.put(m, BigDecimal.ZERO);
                for (BudgetPeriodAmount pa : paList) {
                    int month = parseMonth(pa.getPeriodCode());
                    if (month >= 1 && month <= 12) {
                        monthAmounts.put(month, monthAmounts.get(month)
                                .add(toWan(pa.getBudgetAmount())));
                    }
                }
                for (int m = 1; m <= 12; m++) {
                    BigDecimal mv = monthAmounts.get(m).setScale(6, RoundingMode.HALF_UP);
                    row.put("M" + m, mv);
                    sumMonths[m] = sumMonths[m].add(mv);
                }
                for (int q = 1; q <= 4; q++) {
                    int m1 = (q - 1) * 3 + 1;
                    BigDecimal qv = monthAmounts.get(m1).add(monthAmounts.get(m1 + 1)).add(monthAmounts.get(m1 + 2))
                            .setScale(6, RoundingMode.HALF_UP);
                    row.put("Q" + q, qv);
                    sumQuarters[q] = sumQuarters[q].add(qv);
                }
                rows.add(row);
            }

            // 6. 添加汇总行
            Map<String, Object> sumRow = new LinkedHashMap<>();
            sumRow.put("catalogName", "");
            sumRow.put("stockFlag", "");
            sumRow.put("contractNo", "");
            sumRow.put("contractName", "汇总");
            sumRow.put("projectName", "");
            sumRow.put("manager", "");
            sumRow.put("salesManager", "");
            sumRow.put("customerName", "");
            sumRow.put("contractTypeName", "");
            sumRow.put("contractStatus", "");
            sumRow.put("contractAmount", sumContractAmount.setScale(6, RoundingMode.HALF_UP));
            sumRow.put("totalAmount", sumTotalAmount.setScale(6, RoundingMode.HALF_UP));
            for (int m = 1; m <= 12; m++) {
                sumRow.put("M" + m, sumMonths[m].setScale(6, RoundingMode.HALF_UP));
            }
            for (int q = 1; q <= 4; q++) {
                sumRow.put("Q" + q, sumQuarters[q].setScale(6, RoundingMode.HALF_UP));
            }
            rows.add(sumRow);

            Map<String, Object> sheetData = new HashMap<>();
            sheetData.put("sheetName", name);
            sheetData.put("data", rows);
            sheetData.put("columns", columns);
            sheetDataList.add(sheetData);
        }

        // 7. 添加季度汇总Sheet
        Map<String, Object> quarterSheet = buildQuarterSummarySheet(sheetsByCatalog, paBySheet, catalogCodes, catalogNames);
        if (quarterSheet != null) {
            sheetDataList.add(quarterSheet);
        }

        String fileName = "预算明细_" + fiscalYear;
        if (orgName != null && !orgName.isEmpty()) fileName += "_" + orgName;
        if (productLineName != null && !productLineName.isEmpty()) fileName += "_" + productLineName;
        fileName += "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        ExcelUtil.exportMultiSheet(sheetDataList, response, fileName);
    }

    /**
     * 导出预算汇总对比分析（多Sheet Excel）
     * 关键逻辑：
     * 1. 第一个Sheet为月度对比分析，横向对比合同额、收入、税费
     * 2. 后续Sheet为各类型明细数据
     * 3. 数据按版本、财年汇总
     * @param fiscalYear 财年
     * @param versionId 版本ID
     * @param response HTTP响应
     */
    @Override
    public void exportOverview(Integer fiscalYear, Long versionId, Long orgId, Long productLineId, String orgName, String productLineName, HttpServletResponse response) throws Exception {
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        if (fiscalYear == null) fiscalYear = LocalDate.now().getYear();

        String[] catalogCodes = {CATALOG_CODE_CONTRACT_AMOUNT, CATALOG_CODE_REVENUE, CATALOG_CODE_TAX, CATALOG_CODE_REPAYMENT};
        String[] catalogNames = {"合同额预算", "收入预算", "税费预算", "回款预算"};

        List<BudgetSheetVO> allSheets = budgetSheetMapper.selectListByCondition(companyId, fiscalYear, versionId, null, orgId, productLineId);

        // 2. 批量加载期间金额
        List<Long> allSheetIds = allSheets.stream().map(BudgetSheetVO::getId).collect(Collectors.toList());
        Map<Long, List<BudgetPeriodAmount>> paBySheet = new HashMap<>();
        if (!allSheetIds.isEmpty()) {
            paBySheet = periodAmountMapper.selectBySheetIds(allSheetIds).stream()
                    .collect(Collectors.groupingBy(BudgetPeriodAmount::getBudgetSheetId));
        }

        Map<String, List<BudgetSheetVO>> sheetsByCatalog = allSheets.stream()
                .collect(Collectors.groupingBy(BudgetSheetVO::getCatalogCode));

        List<Map<String, Object>> sheetDataList = new ArrayList<>();

        // 3. 构建月度对比分析Sheet
        List<ExcelUtil.Column<Map<String, Object>>> compareColumns = new ArrayList<>();
        compareColumns.add(ExcelUtil.Column.of("月份", 10, r -> (String) r.get("month")));
        compareColumns.add(ExcelUtil.Column.of("合同额预算(万元)", 18, r -> (BigDecimal) r.get("m101")));
        compareColumns.add(ExcelUtil.Column.of("收入预算(万元)", 18, r -> (BigDecimal) r.get("m102")));
        compareColumns.add(ExcelUtil.Column.of("税费预算(万元)", 18, r -> (BigDecimal) r.get("m103")));
        compareColumns.add(ExcelUtil.Column.of("回款预算(万元)", 18, r -> (BigDecimal) r.get("m201")));

        List<Map<String, Object>> compareRows = new ArrayList<>();
        // 4. 按预算类型、月份汇总数据
        Map<String, BigDecimal[]> monthByCatalog = new HashMap<>();
        for (String code : catalogCodes) monthByCatalog.put(code, new BigDecimal[13]);
        for (String code : catalogCodes) {
            BigDecimal[] arr = monthByCatalog.get(code);
            for (int m = 1; m <= 12; m++) arr[m] = BigDecimal.ZERO;
        }

        // 5. 遍历所有预算单，按类型和月份累加金额（元转万元）
        for (BudgetSheetVO sheet : allSheets) {
            List<BudgetPeriodAmount> paList = paBySheet.getOrDefault(sheet.getId(), Collections.emptyList());
            Map<Integer, BigDecimal> mAmts = new HashMap<>();
            for (BudgetPeriodAmount pa : paList) {
                int month = parseMonth(pa.getPeriodCode());
                if (month >= 1 && month <= 12) {
                    mAmts.put(month, mAmts.getOrDefault(month, BigDecimal.ZERO)
                            .add(toWan(pa.getBudgetAmount())));
                }
            }
            BigDecimal[] catArr = monthByCatalog.get(sheet.getCatalogCode());
            if (catArr != null) {
                for (int m = 1; m <= 12; m++) {
                    BigDecimal a = mAmts.getOrDefault(m, BigDecimal.ZERO);
                    catArr[m] = catArr[m].add(a);
                }
            }
        }

        // 6. 组装月度对比行，计算年度合计
        BigDecimal grand101 = BigDecimal.ZERO, grand102 = BigDecimal.ZERO, grand103 = BigDecimal.ZERO, grand201 = BigDecimal.ZERO;
        for (int m = 1; m <= 12; m++) {
            Map<String, Object> row = new LinkedHashMap<>();
            BigDecimal v101 = monthByCatalog.get(CATALOG_CODE_CONTRACT_AMOUNT)[m].setScale(6, RoundingMode.HALF_UP);
            BigDecimal v102 = monthByCatalog.get(CATALOG_CODE_REVENUE)[m].setScale(6, RoundingMode.HALF_UP);
            BigDecimal v103 = monthByCatalog.get(CATALOG_CODE_TAX)[m].setScale(6, RoundingMode.HALF_UP);
            BigDecimal v201 = monthByCatalog.get(CATALOG_CODE_REPAYMENT)[m].setScale(6, RoundingMode.HALF_UP);
            row.put("month", m + "月");
            row.put("m101", v101);
            row.put("m102", v102);
            row.put("m103", v103);
            row.put("m201", v201);
            compareRows.add(row);
            grand101 = grand101.add(v101);
            grand102 = grand102.add(v102);
            grand103 = grand103.add(v103);
            grand201 = grand201.add(v201);
        }
        Map<String, Object> totalRow = new LinkedHashMap<>();
        totalRow.put("month", "年度合计");
        totalRow.put("m101", grand101);
        totalRow.put("m102", grand102);
        totalRow.put("m103", grand103);
        totalRow.put("m201", grand201);
        compareRows.add(totalRow);

        Map<String, Object> compareSheet = new HashMap<>();
        compareSheet.put("sheetName", "月度对比分析");
        compareSheet.put("data", compareRows);
        compareSheet.put("columns", compareColumns);
        sheetDataList.add(compareSheet);

        // 7. 构建各类型明细Sheet
        for (int ci = 0; ci < catalogCodes.length; ci++) {
            String code = catalogCodes[ci];
            String name = catalogNames[ci];
            List<BudgetSheetVO> catSheets = sheetsByCatalog.getOrDefault(code, Collections.emptyList());

            List<ExcelUtil.Column<Map<String, Object>>> detailColumns = new ArrayList<>();
            detailColumns.add(ExcelUtil.Column.of("性质", 8, r -> "STOCK".equals(r.get("stockFlag")) ? "存量" : "增量"));
            detailColumns.add(ExcelUtil.Column.of("合同编号", 16, r -> (String) r.get("contractNo")));
            detailColumns.add(ExcelUtil.Column.of("合同名称", 28, r -> (String) r.get("contractName")));
            detailColumns.add(ExcelUtil.Column.of("项目名称", 22, r -> (String) r.get("projectName")));
            detailColumns.add(ExcelUtil.Column.of("客户名称", 18, r -> (String) r.get("customerName")));
            detailColumns.add(ExcelUtil.Column.of("负责人", 10, r -> (String) r.get("manager")));
            detailColumns.add(ExcelUtil.Column.of("合同金额(万元)", 16, r -> (BigDecimal) r.get("contractAmount")));
            detailColumns.add(ExcelUtil.Column.of("预算合计(万元)", 16, r -> (BigDecimal) r.get("totalAmount")));
            for (int m = 1; m <= 12; m++) {
                final int mm = m;
                detailColumns.add(ExcelUtil.Column.of(m + "月(万元)", 12, r -> (BigDecimal) r.get("M" + mm)));
            }
            for (int q = 1; q <= 4; q++) {
                final int qq = q;
                detailColumns.add(ExcelUtil.Column.of("Q" + q + "(万元)", 12, r -> (BigDecimal) r.get("Q" + qq)));
            }

            List<Map<String, Object>> detailRows = new ArrayList<>();
            BigDecimal detSumContractAmount = BigDecimal.ZERO;
            BigDecimal detSumTotalAmount = BigDecimal.ZERO;
            BigDecimal[] detSumMonths = new BigDecimal[13];
            BigDecimal[] detSumQuarters = new BigDecimal[5];
            for (int m = 1; m <= 12; m++) detSumMonths[m] = BigDecimal.ZERO;
            for (int q = 1; q <= 4; q++) detSumQuarters[q] = BigDecimal.ZERO;
            for (BudgetSheetVO sheet : catSheets) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("stockFlag", sheet.getStockFlag());
                row.put("contractNo", sheet.getContractNo());
                row.put("contractName", sheet.getContractName());
                row.put("projectName", sheet.getProjectName());
                row.put("customerName", sheet.getCustomerName());
                row.put("manager", sheet.getManager());
                BigDecimal dca = toWan(sheet.getContractAmount()).setScale(6, RoundingMode.HALF_UP);
                BigDecimal dta = toWan(sheet.getTotalAmount()).setScale(6, RoundingMode.HALF_UP);
                row.put("contractAmount", dca);
                row.put("totalAmount", dta);
                detSumContractAmount = detSumContractAmount.add(dca);
                detSumTotalAmount = detSumTotalAmount.add(dta);

                List<BudgetPeriodAmount> paList = paBySheet.getOrDefault(sheet.getId(), Collections.emptyList());
                Map<Integer, BigDecimal> monthAmounts = new HashMap<>();
                for (int m = 1; m <= 12; m++) monthAmounts.put(m, BigDecimal.ZERO);
                for (BudgetPeriodAmount pa : paList) {
                    int month = parseMonth(pa.getPeriodCode());
                    if (month >= 1 && month <= 12) {
                        monthAmounts.put(month, monthAmounts.get(month)
                                .add(toWan(pa.getBudgetAmount())));
                    }
                }
                for (int m = 1; m <= 12; m++) {
                    BigDecimal mv = monthAmounts.get(m).setScale(6, RoundingMode.HALF_UP);
                    row.put("M" + m, mv);
                    detSumMonths[m] = detSumMonths[m].add(mv);
                }
                for (int q = 1; q <= 4; q++) {
                    int m1 = (q - 1) * 3 + 1;
                    BigDecimal qv = monthAmounts.get(m1).add(monthAmounts.get(m1 + 1)).add(monthAmounts.get(m1 + 2))
                            .setScale(6, RoundingMode.HALF_UP);
                    row.put("Q" + q, qv);
                    detSumQuarters[q] = detSumQuarters[q].add(qv);
                }
                detailRows.add(row);
            }

            // 添加明细汇总行
            Map<String, Object> detSumRow = new LinkedHashMap<>();
            detSumRow.put("stockFlag", "");
            detSumRow.put("contractNo", "");
            detSumRow.put("contractName", "汇总");
            detSumRow.put("projectName", "");
            detSumRow.put("customerName", "");
            detSumRow.put("manager", "");
            detSumRow.put("contractAmount", detSumContractAmount.setScale(6, RoundingMode.HALF_UP));
            detSumRow.put("totalAmount", detSumTotalAmount.setScale(6, RoundingMode.HALF_UP));
            for (int m = 1; m <= 12; m++) {
                detSumRow.put("M" + m, detSumMonths[m].setScale(6, RoundingMode.HALF_UP));
            }
            for (int q = 1; q <= 4; q++) {
                detSumRow.put("Q" + q, detSumQuarters[q].setScale(6, RoundingMode.HALF_UP));
            }
            detailRows.add(detSumRow);

            Map<String, Object> detailSheet = new HashMap<>();
            detailSheet.put("sheetName", name);
            detailSheet.put("data", detailRows);
            detailSheet.put("columns", detailColumns);
            sheetDataList.add(detailSheet);
        }

        Map<String, Object> quarterSheet = buildQuarterSummarySheet(sheetsByCatalog, paBySheet, catalogCodes, catalogNames);
        if (quarterSheet != null) {
            sheetDataList.add(quarterSheet);
        }

        String fileName = "预算汇总_" + fiscalYear;
        if (orgName != null && !orgName.isEmpty()) fileName += "_" + orgName;
        if (productLineName != null && !productLineName.isEmpty()) fileName += "_" + productLineName;
        fileName += "_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        ExcelUtil.exportMultiSheet(sheetDataList, response, fileName);
    }

    /**
     * 获取预算概览统计数据
     * 关键逻辑：按预算类型汇总合同数、合同总额、收入总额、税费总额
     * @param fiscalYear 财年
     * @param versionId 版本ID
     * @param dimensions 维度（预留参数）
     * @return 概览统计Map
     */
    @Override
    public Map<String, Object> getOverviewData(Integer fiscalYear, Long versionId, String dimensions) {
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        if (fiscalYear == null) fiscalYear = LocalDate.now().getYear();

        // 1. 按版本查询预算明细
        List<BudgetSheetVO> sheets = budgetSheetMapper.selectListByCondition(companyId, fiscalYear, versionId, null, null, null);

        Map<String, Object> result = new HashMap<>();
        result.put("fiscalYear", fiscalYear);
        // 2. 统计合同数量（去重）
        result.put("totalContracts", sheets.stream().map(BudgetSheetVO::getContractId).distinct().count());
        // 3. 按预算类型分别汇总金额（元转万元）
        result.put("totalContractAmount", toWan(sheets.stream()
                .filter(s -> CATALOG_CODE_CONTRACT_AMOUNT.equals(s.getCatalogCode()))
                .map(BudgetSheetVO::getTotalAmount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)).setScale(6, RoundingMode.HALF_UP));
        result.put("totalRevenue", toWan(sheets.stream()
                .filter(s -> CATALOG_CODE_REVENUE.equals(s.getCatalogCode()))
                .map(BudgetSheetVO::getTotalAmount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)).setScale(6, RoundingMode.HALF_UP));
        result.put("totalTax", toWan(sheets.stream()
                .filter(s -> CATALOG_CODE_TAX.equals(s.getCatalogCode()))
                .map(BudgetSheetVO::getTotalAmount)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)).setScale(6, RoundingMode.HALF_UP));

        return result;
    }

    /**
     * 根据ID查询预算明细
     * @param id 预算单ID
     * @return 预算明细VO
     */
    @Override
    public BudgetSheetVO getById(Long id) {
        BudgetSheet entity = budgetSheetMapper.selectById(id);
        if (entity == null) {
            return null;
        }
        BudgetSheetVO vo = new BudgetSheetVO();
        BeanUtils.copyProperties(entity, vo);
        vo.setContractAmount(toWan(vo.getContractAmount()));
        vo.setTotalAmount(toWan(vo.getTotalAmount()));
        return vo;
    }

    /**
     * 新增预算明细
     * @param entity 预算明细实体
     * @return 是否成功
     */
    @Override
    public boolean save(BudgetSheet entity) {
        return budgetSheetMapper.insert(entity) > 0;
    }

    /**
     * 更新预算明细
     * @param entity 预算明细实体
     * @return 是否成功
     */
    @Override
    public boolean update(BudgetSheet entity) {
        return budgetSheetMapper.updateById(entity) > 0;
    }

    /**
     * 删除预算明细
     * @param id 预算单ID
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Long id) {
        return budgetSheetMapper.deleteById(id) > 0;
    }

    /**
     * 批量删除预算明细
     * @param ids 预算单ID列表
     * @return 是否成功
     */
    @Override
    public boolean deleteBatch(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return false;
        }
        return budgetSheetMapper.deleteBatchIds(ids) > 0;
    }

    /**
     * 构建季度汇总Sheet
     */
    private Map<String, Object> buildQuarterSummarySheet(
            Map<String, List<BudgetSheetVO>> sheetsByCatalog,
            Map<Long, List<BudgetPeriodAmount>> paBySheet,
            String[] catalogCodes, String[] catalogNames) {

        List<ExcelUtil.Column<Map<String, Object>>> columns = new ArrayList<>();
        columns.add(ExcelUtil.Column.of("预算类型", 16, r -> (String) r.get("catalogName")));
        columns.add(ExcelUtil.Column.of("合同金额(万元)", 16, r -> (BigDecimal) r.get("contractAmount")));
        columns.add(ExcelUtil.Column.of("预算合计(万元)", 16, r -> (BigDecimal) r.get("totalAmount")));
        for (int q = 1; q <= 4; q++) {
            final int qq = q;
            columns.add(ExcelUtil.Column.of("Q" + q + "(万元)", 14, r -> (BigDecimal) r.get("Q" + qq)));
        }

        List<Map<String, Object>> rows = new ArrayList<>();
        BigDecimal totalContractAmount = BigDecimal.ZERO;
        BigDecimal totalTotalAmount = BigDecimal.ZERO;
        BigDecimal[] totalQuarters = new BigDecimal[5];
        for (int q = 1; q <= 4; q++) totalQuarters[q] = BigDecimal.ZERO;

        for (int ci = 0; ci < catalogCodes.length; ci++) {
            String code = catalogCodes[ci];
            String name = catalogNames[ci];
            List<BudgetSheetVO> catSheets = sheetsByCatalog.getOrDefault(code, Collections.emptyList());

            BigDecimal sumContract = BigDecimal.ZERO;
            BigDecimal sumTotal = BigDecimal.ZERO;
            BigDecimal[] sumQ = new BigDecimal[5];
            for (int q = 1; q <= 4; q++) sumQ[q] = BigDecimal.ZERO;

            for (BudgetSheetVO sheet : catSheets) {
                sumContract = sumContract.add(toWan(sheet.getContractAmount()));
                sumTotal = sumTotal.add(toWan(sheet.getTotalAmount()));

                List<BudgetPeriodAmount> paList = paBySheet.getOrDefault(sheet.getId(), Collections.emptyList());
                Map<Integer, BigDecimal> monthAmounts = new HashMap<>();
                for (int m = 1; m <= 12; m++) monthAmounts.put(m, BigDecimal.ZERO);
                for (BudgetPeriodAmount pa : paList) {
                    int month = parseMonth(pa.getPeriodCode());
                    if (month >= 1 && month <= 12) {
                        monthAmounts.put(month, monthAmounts.get(month).add(toWan(pa.getBudgetAmount())));
                    }
                }
                for (int q = 1; q <= 4; q++) {
                    int m1 = (q - 1) * 3 + 1;
                    sumQ[q] = sumQ[q].add(monthAmounts.get(m1)).add(monthAmounts.get(m1 + 1)).add(monthAmounts.get(m1 + 2));
                }
            }

            Map<String, Object> row = new LinkedHashMap<>();
            row.put("catalogName", name);
            row.put("contractAmount", sumContract.setScale(6, RoundingMode.HALF_UP));
            row.put("totalAmount", sumTotal.setScale(6, RoundingMode.HALF_UP));
            for (int q = 1; q <= 4; q++) {
                row.put("Q" + q, sumQ[q].setScale(6, RoundingMode.HALF_UP));
                totalQuarters[q] = totalQuarters[q].add(sumQ[q]);
            }
            totalContractAmount = totalContractAmount.add(sumContract);
            totalTotalAmount = totalTotalAmount.add(sumTotal);
            rows.add(row);
        }

        Map<String, Object> totalRow = new LinkedHashMap<>();
        totalRow.put("catalogName", "合计");
        totalRow.put("contractAmount", totalContractAmount.setScale(6, RoundingMode.HALF_UP));
        totalRow.put("totalAmount", totalTotalAmount.setScale(6, RoundingMode.HALF_UP));
        for (int q = 1; q <= 4; q++) {
            totalRow.put("Q" + q, totalQuarters[q].setScale(6, RoundingMode.HALF_UP));
        }
        rows.add(totalRow);

        Map<String, Object> sheetData = new HashMap<>();
        sheetData.put("sheetName", "季度汇总");
        sheetData.put("data", rows);
        sheetData.put("columns", columns);
        return sheetData;
    }

    /**
     * 预算类型编码转名称
     * @param code 类型编码
     * @return 类型名称
     */
    private static String catalogCodeToName(String code) {
        if (code == null) return "预算";
        switch (code) {
            case CATALOG_CODE_CONTRACT_AMOUNT:
                return "合同额预算";
            case CATALOG_CODE_REVENUE:
                return "收入预算";
            case CATALOG_CODE_TAX:
                return "税费预算";
            case CATALOG_CODE_REPAYMENT:
                return "回款预算";
            default:
                return code;
        }
    }

    /**
     * 合同状态编码转中文
     * @param status 状态编码
     * @return 状态中文
     */
    private static String contractStatusToText(String status) {
        if (status == null) return "";
        switch (status) {
            case "UNSIGNED":
                return "未签订";
            case "SIGNED":
                return "已签订";
            case "COMPLETED":
                return "已完成";
            case "CANCELED":
                return "已取消";
            default:
                return status;
        }
    }

    /**
     * 从期间编码解析月份
     * @param periodCode 期间编码（如"M1"、"2026-01"等）
     * @return 月份数字(1-12)，解析失败返回0
     */
    private static int parseMonth(String periodCode) {
        if (periodCode == null) return 0;
        try {
            String m = periodCode.replaceAll("[^0-9]", "");
            return m.isEmpty() ? 0 : Integer.parseInt(m);
        } catch (Exception e) {
            return 0;
        }
    }

    @Override
    public void exportDimension(Integer fiscalYear, Long versionId, String catalogCode,
                                String stockFlag, String productLine, String contractType,
                                String customerName, String projectName, String manager,
                                List<String> dimFields, HttpServletResponse response) throws Exception {
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        if (fiscalYear == null) fiscalYear = LocalDate.now().getYear();
        if (catalogCode == null || catalogCode.isEmpty()) catalogCode = "101";
        List<String> effectiveDims = (dimFields == null || dimFields.isEmpty()) ? Collections.singletonList("customerName") : dimFields;

        Map<String, String> dimTitleMap = new LinkedHashMap<>();
        dimTitleMap.put("stockFlag", "增量/存量");
        dimTitleMap.put("productLine", "产品线");
        dimTitleMap.put("contractType", "合同类型");
        dimTitleMap.put("customerName", "客户");
        dimTitleMap.put("projectName", "项目");
        dimTitleMap.put("manager", "Sponsor");

        Map<String, String> catalogNameMap = new HashMap<>();
        catalogNameMap.put("101", "合同额预算");
        catalogNameMap.put("102", "收入预算");
        catalogNameMap.put("103", "税费预算");
        catalogNameMap.put("201", "回款预算");

        List<BudgetSheetVO> allSheets = budgetSheetMapper.selectListByCondition(companyId, fiscalYear, versionId, catalogCode, null, null);

        List<BudgetSheetVO> filtered = new ArrayList<>();
        for (BudgetSheetVO s : allSheets) {
            if (s.getDeleted() != null && s.getDeleted() == 1) continue;
            if (s.getIsSummaryRow() != null && s.getIsSummaryRow() == 1) continue;
            if (stockFlag != null && !stockFlag.isEmpty() && !stockFlag.equals(s.getStockFlag())) continue;
            if (productLine != null && !productLine.isEmpty() && !productLine.equals(s.getProductLine()) && !productLine.equals(s.getProductLineName())) continue;
            if (contractType != null && !contractType.isEmpty() && !contractType.equals(s.getContractType()) && !contractType.equals(s.getContractTypeName())) continue;
            if (customerName != null && !customerName.isEmpty() && !customerName.equals(s.getCustomerName())) continue;
            if (projectName != null && !projectName.isEmpty() && !projectName.equals(s.getProjectName())) continue;
            if (manager != null && !manager.isEmpty() && !manager.equals(s.getManager())) continue;
            filtered.add(s);
        }

        List<Long> sheetIds = filtered.stream().map(BudgetSheetVO::getId).collect(Collectors.toList());
        Map<Long, List<BudgetPeriodAmount>> paBySheet = new HashMap<>();
        if (!sheetIds.isEmpty()) {
            paBySheet = periodAmountMapper.selectBySheetIds(sheetIds).stream()
                    .collect(Collectors.groupingBy(BudgetPeriodAmount::getBudgetSheetId));
        }

        Map<String, Map<Integer, BigDecimal>> breakdown = new LinkedHashMap<>();
        Map<String, Map<String, String>> breakdownDims = new LinkedHashMap<>();

        for (BudgetSheetVO sheet : filtered) {
            List<BudgetPeriodAmount> paList = paBySheet.getOrDefault(sheet.getId(), Collections.emptyList());
            Map<Integer, BigDecimal> monthAmts = new HashMap<>();
            for (int m = 1; m <= 12; m++) monthAmts.put(m, BigDecimal.ZERO);
            for (BudgetPeriodAmount pa : paList) {
                int month = parseMonth(pa.getPeriodCode());
                if (month >= 1 && month <= 12) {
                    BigDecimal amt = pa.getBudgetAmount() != null ? toWan(pa.getBudgetAmount()) : BigDecimal.ZERO;
                    monthAmts.put(month, monthAmts.get(month).add(amt));
                }
            }

            Map<String, String> dims = new LinkedHashMap<>();
            List<String> keyParts = new ArrayList<>();
            for (String f : effectiveDims) {
                String v = getDimValueStr(sheet, f);
                dims.put(f, v);
                keyParts.add(v);
            }
            String key = String.join("||", keyParts);
            if (!breakdown.containsKey(key)) {
                breakdown.put(key, new HashMap<>());
                for (int m = 1; m <= 12; m++) breakdown.get(key).put(m, BigDecimal.ZERO);
                breakdownDims.put(key, dims);
            }
            Map<Integer, BigDecimal> bm = breakdown.get(key);
            for (int m = 1; m <= 12; m++) {
                bm.put(m, bm.get(m).add(monthAmts.get(m)));
            }
        }

        List<Map<String, Object>> rows = new ArrayList<>();
        List<Map.Entry<String, Map<Integer, BigDecimal>>> entryList = new ArrayList<>(breakdown.entrySet());
        entryList.sort((a, b) -> {
            Map<String, String> da = breakdownDims.get(a.getKey());
            Map<String, String> db = breakdownDims.get(b.getKey());
            for (String f : effectiveDims) {
                String av = da.getOrDefault(f, "");
                String bv = db.getOrDefault(f, "");
                int cmp = av.compareTo(bv);
                if (cmp != 0) return cmp;
            }
            BigDecimal ta = BigDecimal.ZERO, tb = BigDecimal.ZERO;
            for (int m = 1; m <= 12; m++) { ta = ta.add(a.getValue().get(m)); tb = tb.add(b.getValue().get(m)); }
            return tb.compareTo(ta);
        });

        BigDecimal[] gMonthTotals = new BigDecimal[13];
        BigDecimal[] gQuarterTotals = new BigDecimal[5];
        for (int m = 1; m <= 12; m++) gMonthTotals[m] = BigDecimal.ZERO;
        for (int q = 1; q <= 4; q++) gQuarterTotals[q] = BigDecimal.ZERO;
        BigDecimal gTotal = BigDecimal.ZERO;

        for (Map.Entry<String, Map<Integer, BigDecimal>> entry : entryList) {
            Map<String, String> dims = breakdownDims.get(entry.getKey());
            Map<Integer, BigDecimal> mAmts = entry.getValue();
            Map<String, Object> row = new LinkedHashMap<>();
            for (String f : effectiveDims) {
                row.put(f, dims.getOrDefault(f, "-"));
            }
            BigDecimal rowTotal = BigDecimal.ZERO;
            for (int m = 1; m <= 12; m++) {
                BigDecimal mv = mAmts.get(m).setScale(6, RoundingMode.HALF_UP);
                row.put("M" + m, mv);
                gMonthTotals[m] = gMonthTotals[m].add(mv);
                rowTotal = rowTotal.add(mv);
            }
            for (int q = 1; q <= 4; q++) {
                int m1 = (q - 1) * 3 + 1;
                BigDecimal qv = mAmts.get(m1).add(mAmts.get(m1 + 1)).add(mAmts.get(m1 + 2)).setScale(6, RoundingMode.HALF_UP);
                row.put("Q" + q, qv);
                gQuarterTotals[q] = gQuarterTotals[q].add(qv);
            }
            row.put("TOTAL", rowTotal.setScale(6, RoundingMode.HALF_UP));
            gTotal = gTotal.add(rowTotal);
            rows.add(row);
        }

        Map<String, Object> totalRow = new LinkedHashMap<>();
        for (int i = 0; i < effectiveDims.size(); i++) {
            totalRow.put(effectiveDims.get(i), i == 0 ? "合计" : "");
        }
        for (int m = 1; m <= 12; m++) totalRow.put("M" + m, gMonthTotals[m].setScale(6, RoundingMode.HALF_UP));
        for (int q = 1; q <= 4; q++) totalRow.put("Q" + q, gQuarterTotals[q].setScale(6, RoundingMode.HALF_UP));
        totalRow.put("TOTAL", gTotal.setScale(6, RoundingMode.HALF_UP));
        rows.add(totalRow);

        List<ExcelUtil.Column<Map<String, Object>>> columns = new ArrayList<>();
        for (String f : effectiveDims) {
            final String ff = f;
            columns.add(ExcelUtil.Column.of(dimTitleMap.getOrDefault(f, f), Math.max(12, Math.min(28, dimTitleMap.getOrDefault(f, f).length() * 3 + 6)),
                    r -> r.get(ff)));
        }
        for (int m = 1; m <= 12; m++) {
            final int mm = m;
            columns.add(ExcelUtil.Column.of(m + "月(万元)", 16, r -> r.get("M" + mm)));
        }
        for (int q = 1; q <= 4; q++) {
            final int qq = q;
            columns.add(ExcelUtil.Column.of("Q" + q + "(万元)", 16, r -> r.get("Q" + qq)));
        }
        columns.add(ExcelUtil.Column.of("合计(万元)", 18, r -> r.get("TOTAL")));

        String sheetName = catalogNameMap.getOrDefault(catalogCode, "预算明细");
        String fileName = sheetName + "_" + fiscalYear + "年度_维度明细_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        ExcelUtil.export(rows, sheetName, columns, response, fileName);
    }

    private String getDimValueStr(BudgetSheetVO sheet, String field) {
        if ("stockFlag".equals(field)) {
            String v = sheet.getStockFlag();
            if ("STOCK".equals(v)) return "存量";
            if ("INCREMENT".equals(v)) return "增量";
            return v != null ? v : "未分类";
        }
        String v;
        switch (field) {
            case "productLine":
                v = sheet.getProductLine() != null ? sheet.getProductLine() : sheet.getProductLineName();
                break;
            case "contractType":
                v = sheet.getContractType() != null ? sheet.getContractType() : sheet.getContractTypeName();
                break;
            case "customerName": v = sheet.getCustomerName(); break;
            case "projectName": v = sheet.getProjectName(); break;
            case "manager": v = sheet.getManager(); break;
            default: v = null;
        }
        return v != null && !v.isEmpty() ? v : "未分类";
    }

    private static BigDecimal toWan(BigDecimal yuan) {
        if (yuan == null) return BigDecimal.ZERO.setScale(6, RoundingMode.HALF_UP);
        return yuan.divide(WAN, 6, RoundingMode.HALF_UP);
    }
}
