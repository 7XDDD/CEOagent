package com.crm.dto.base;

import com.crm.dto.PageQueryDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class FiscalYearQueryDTO extends PageQueryDTO {

    private Integer fiscalYear;

    private String yearStatus;

    private Integer isCurrentYear;
}
