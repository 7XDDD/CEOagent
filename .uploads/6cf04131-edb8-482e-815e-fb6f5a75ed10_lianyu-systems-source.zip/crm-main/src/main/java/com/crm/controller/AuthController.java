package com.crm.controller;

import com.crm.common.Result;
import com.crm.common.SecurityContextUtil;
import com.crm.dto.LoginDTO;
import com.crm.dto.LoginResponseDTO;
import com.crm.entity.User;
import com.crm.security.JwtTokenUtil;
import com.crm.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/auth")
@Api(tags = "认证接口")
public class AuthController {

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    @ApiOperation("用户登录")
    public Result<LoginResponseDTO> login(@Validated @RequestBody LoginDTO loginDTO,
                                           HttpServletRequest request) {
        String clientIp = UserService.getClientIp(request);
        String userAgent = request.getHeader("User-Agent");
        log.info("用户登录请求: username={}, ip={}", loginDTO.getUsername(), clientIp);

        UserService.LoginResult loginResult = userService.login(
                loginDTO.getUsername(),
                loginDTO.getPassword(),
                loginDTO.getCaptchaKey(),
                loginDTO.getCaptchaCode(),
                clientIp,
                userAgent
        );

        if (!loginResult.isSuccess()) {
            log.warn("用户登录失败: username={}, code={}, reason={}",
                    loginDTO.getUsername(), loginResult.getCode(), loginResult.getMessage());
            return Result.error(loginResult.getCode(), loginResult.getMessage());
        }

        User user = loginResult.getUser();
        String token = jwtTokenUtil.generateToken(
                user.getId(),
                user.getUsername(),
                null,
                user.getDeptId(),
                loginResult.getRoles(),
                loginResult.getPermissions()
        );

        LoginResponseDTO response = new LoginResponseDTO(
                token,
                user.getId(),
                user.getUsername(),
                user.getRealName(),
                null,
                user.getDeptId(),
                loginResult.getRoles(),
                loginResult.getPermissions()
        );

        log.info("用户 {} 登录成功 (orgId={}, roles={}, permissions={})",
                user.getUsername(), user.getDeptId(),
                loginResult.getRoles().size(), loginResult.getPermissions().size());
        return Result.success("登录成功", response);
    }

    @PostMapping("/logout")
    @ApiOperation("用户登出")
    public Result<?> logout() {
        return Result.success("登出成功", null);
    }

    @GetMapping("/info")
    @ApiOperation("获取当前用户信息")
    public Result<?> getUserInfo() {
        try {
            Long userId = SecurityContextUtil.getCurrentUserId();
            if (userId == null) {
                return Result.error(401, "未登录或Token已过期");
            }
            Map<String, Object> info = userService.getCurrentUserInfo(userId);
            if (info == null) {
                return Result.error(401, "用户不存在");
            }
            return Result.success("获取成功", info);
        } catch (Exception e) {
            log.warn("获取用户信息失败: {}", e.getMessage());
        }
        return Result.error(401, "未登录或Token已过期");
    }

    @PutMapping("/profile")
    @ApiOperation("更新当前用户个人信息")
    public Result<?> updateProfile(@RequestBody Map<String, String> body) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        if (userId == null) {
            return Result.error(401, "未登录或Token已过期");
        }
        boolean ok = userService.updateProfile(userId, body);
        if (!ok) {
            return Result.error("用户不存在");
        }
        return Result.success("信息保存成功", null);
    }

    @PostMapping("/change-password")
    @ApiOperation("修改当前用户密码")
    public Result<?> changePassword(@RequestBody Map<String, String> body) {
        Long userId = SecurityContextUtil.getCurrentUserId();
        if (userId == null) {
            return Result.error(401, "未登录或Token已过期");
        }
        String err = userService.changePassword(userId, body.get("oldPassword"), body.get("newPassword"));
        if (err != null) {
            return Result.error(err);
        }
        return Result.success("密码修改成功，请使用新密码重新登录", null);
    }
}
