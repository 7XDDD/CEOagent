package com.crm.dto.system;

import lombok.Data;

@Data
public class PermissionUpdateDTO {
    private Long parentId;
    private String permissionName;
    private String permissionType;
    private String path;
    private String routePath;
    private String apiPath;
    private String httpMethod;
    private String icon;
    private String component;
    private Integer sortOrder;
    private Integer status;
}
