package com.crm.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@TableName("crm_customer_address")
public class PmtCustomerAddress implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long customerId;

    private String addressType;

    private Long countryId;

    private String countryName;

    private Long provinceId;

    private String provinceName;

    private Long cityId;

    private String cityName;

    private Long districtId;

    private String districtName;

    private String street;

    private String detailAddress;

    private String postalCode;

    private BigDecimal longitude;

    private BigDecimal latitude;

    private String contactPerson;

    private String contactPhone;

    @TableField(fill = FieldFill.INSERT)
    private Integer isDefault = 0;

    private Integer sortOrder;

    @TableField(fill = FieldFill.INSERT)
    private String status = "ACTIVE";

    private String remark;

    @TableField(value = "created_by", fill = FieldFill.INSERT)
    private Long createdBy;

    @TableField(value = "updated_by", fill = FieldFill.INSERT_UPDATE)
    private Long updatedBy;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    @TableLogic
    @TableField(fill = FieldFill.INSERT)
    private Long deleted = 0L;
}
