package com.crm.dto.contract;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
public class ContractCreateDTO {

    @NotBlank(message = "合同号不能为空")
    private String contractNo;

    @NotBlank(message = "合同名称不能为空")
    private String contractName;

    private String projectCode;

    @NotBlank(message = "项目名称不能为空")
    private String projectName;

    private Long customerId;

    private String customerName;

    private Long contractTypeId;

    private String contractType;

    private Long orgId;

    private String productLine;

    @NotBlank(message = "负责人不能为空")
    private String manager;

    private String salesManager;

    @NotNull(message = "合同金额不能为空")
    private BigDecimal contractAmount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate signDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedSignDate;

    @NotBlank(message = "合同状态不能为空")
    private String contractStatus;

    @NotNull(message = "合同创建时间不能为空")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate contractCreateTime;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate contractCompleteTime;

    private String remark;

    /** 父合同ID */
    private Long parentId;

    /** 关联商机ID列表 */
    private List<Long> opportunityIds;

    /** 关联项目ID列表 */
    private List<Long> projectIds;
}
