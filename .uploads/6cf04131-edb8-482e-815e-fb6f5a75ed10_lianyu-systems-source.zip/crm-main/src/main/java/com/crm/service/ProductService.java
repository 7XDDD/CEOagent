package com.crm.service;

import com.crm.dto.PageResult;
import com.crm.dto.product.ProductCreateDTO;
import com.crm.dto.product.ProductQueryDTO;
import com.crm.dto.product.ProductUpdateDTO;
import com.crm.vo.product.ProductVO;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

public interface ProductService {

    PageResult<ProductVO> page(ProductQueryDTO query);

    List<ProductVO> list(ProductQueryDTO query);

    ProductVO getById(Long id);

    ProductVO save(ProductCreateDTO dto);

    ProductVO update(ProductUpdateDTO dto);

    void deleteById(Long id);

    void deleteBatch(List<Long> ids);

    ProductVO changeStatus(Long id, String status);

    void exportProducts(ProductQueryDTO query, HttpServletResponse response) throws Exception;

    void downloadImportTemplate(HttpServletResponse response) throws Exception;

    Map<String, Object> importExcel(Long companyId, MultipartFile file);
}
