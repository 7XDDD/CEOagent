package com.crm.dto.product;

import com.crm.dto.PageQueryDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ProductQueryDTO extends PageQueryDTO {

    /**
     * 商品状态：ON_SHELF(上架中)/OFF_SHELF(已下架)
     */
    private String status;

    /**
     * 商品分类
     */
    private String category;
}
