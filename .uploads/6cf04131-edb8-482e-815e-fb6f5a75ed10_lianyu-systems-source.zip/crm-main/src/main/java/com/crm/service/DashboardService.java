package com.crm.service;

import com.crm.vo.dashboard.DashboardStatsVO;

public interface DashboardService {
    DashboardStatsVO stats(String range, String rankTab);
}
