package com.crm.dataperm.resolver;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crm.dataperm.DataOwnerResolver;
import com.crm.dataperm.DataPermModule;
import com.crm.entity.Opportunity;
import com.crm.mapper.OpportunityMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

/** 商机负责人：owner_id / 创建人 */
@Component
public class OpportunityOwnerResolver implements DataOwnerResolver {

    @Autowired
    private OpportunityMapper opportunityMapper;

    @Override
    public String module() {
        return DataPermModule.OPPORTUNITY;
    }

    @Override
    public boolean isOwner(Long bizId, Long userId) {
        if (bizId == null || userId == null) return false;
        LambdaQueryWrapper<Opportunity> w = new LambdaQueryWrapper<>();
        w.eq(Opportunity::getId, bizId)
                .and(x -> x.eq(Opportunity::getOwnerId, userId).or().eq(Opportunity::getCreatedBy, userId));
        return opportunityMapper.selectCount(w) > 0;
    }

    @Override
    public Set<Long> findOwnerIds(Collection<Long> bizIds, Long userId) {
        if (bizIds == null || bizIds.isEmpty() || userId == null) return Collections.emptySet();
        LambdaQueryWrapper<Opportunity> w = new LambdaQueryWrapper<>();
        w.in(Opportunity::getId, bizIds)
                .and(x -> x.eq(Opportunity::getOwnerId, userId).or().eq(Opportunity::getCreatedBy, userId));
        return opportunityMapper.selectList(w).stream().map(Opportunity::getId).collect(Collectors.toSet());
    }
}
