package com.crm.controller;

import com.crm.common.Result;
import com.crm.dto.PageResult;
import com.crm.dto.project.ProjectQueryDTO;
import com.crm.service.ProjectService;
import com.crm.vo.project.ProjectVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/project")
public class ProjectController {

    @Autowired
    private ProjectService projectService;

    @PostMapping("/page")
    public Result<PageResult<ProjectVO>> page(@RequestBody ProjectQueryDTO query) {
        return Result.success(projectService.page(query));
    }

    @GetMapping("/{id}")
    public Result<ProjectVO> getById(@PathVariable Long id) {
        return Result.success(projectService.getById(id));
    }
}
