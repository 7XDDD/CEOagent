package com.crm.controller.budget;

import com.crm.annotation.OperationLog;
import com.crm.common.Result;
import com.crm.dto.BudgetCalculateRequest;
import com.crm.dto.PageResult;
import com.crm.dto.budget.BudgetSheetQueryDTO;
import com.crm.entity.BudgetLine;
import com.crm.entity.BudgetPeriodAmount;
import com.crm.entity.BudgetSheet;
import com.crm.entity.Org;
import com.crm.mapper.OrgMapper;
import com.crm.service.budget.BudgetSheetService;
import com.crm.vo.budget.BudgetSheetVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/budget/sheet")
public class BudgetSheetController {

    @Autowired
    private BudgetSheetService budgetSheetService;

    @Autowired
    private OrgMapper orgMapper;

    @PostMapping("/page")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:view')")
    public Result<PageResult<BudgetSheetVO>> page(@RequestBody(required = false) BudgetSheetQueryDTO query) {
        if (query == null) query = new BudgetSheetQueryDTO();
        PageResult<BudgetSheetVO> pr = budgetSheetService.page(query);
        return Result.success("查询成功", pr);
    }

    @GetMapping("/org-options")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:view')")
    public Result<Map<String, Object>> orgOptions() {
        List<Org> allOrgs = orgMapper.selectAllActive();
        List<Map<String, Object>> branches = allOrgs.stream()
                .filter(o -> "SUBCOMPANY".equals(o.getOrgType()))
                .map(o -> {
                    Map<String, Object> m = new HashMap<>();
                    m.put("id", o.getId());
                    m.put("orgName", o.getOrgName());
                    return m;
                })
                .collect(Collectors.toList());
        List<Map<String, Object>> productLines = allOrgs.stream()
                .filter(o -> "PRODUCT_LINE".equals(o.getOrgType()))
                .map(o -> {
                    Map<String, Object> m = new HashMap<>();
                    m.put("id", o.getId());
                    m.put("orgName", o.getOrgName());
                    return m;
                })
                .collect(Collectors.toList());
        Map<String, Object> result = new HashMap<>();
        result.put("branches", branches);
        result.put("productLines", productLines);
        return Result.success(result);
    }

    @GetMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:view')")
    public Result<BudgetSheetVO> getById(@PathVariable Long id) {
        BudgetSheetVO vo = budgetSheetService.getById(id);
        return Result.success("查询成功", vo);
    }

    @PostMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:edit')")
    public Result<BudgetSheetVO> create(@RequestBody BudgetSheet entity) {
        budgetSheetService.save(entity);
        BudgetSheetVO vo = budgetSheetService.getById(entity.getId());
        return Result.success("保存成功", vo);
    }

    @PutMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:edit')")
    public Result<BudgetSheetVO> update(@RequestBody BudgetSheet entity) {
        budgetSheetService.update(entity);
        BudgetSheetVO vo = budgetSheetService.getById(entity.getId());
        return Result.success("更新成功", vo);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:delete')")
    public Result<String> delete(@PathVariable Long id) {
        budgetSheetService.deleteById(id);
        return Result.success("删除成功", null);
    }

    @GetMapping("/{id}/lines")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:view')")
    public Result<List<BudgetLine>> lines(@PathVariable Long id) {
        List<BudgetLine> list = budgetSheetService.getLines(id);
        return Result.success("查询成功", list);
    }

    @GetMapping("/{id}/period-amounts")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:view')")
    public Result<List<BudgetPeriodAmount>> periodAmounts(@PathVariable Long id) {
        List<BudgetPeriodAmount> list = budgetSheetService.getPeriodAmounts(id);
        return Result.success("查询成功", list);
    }

    @GetMapping("/period-amounts/batch")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:view')")
    public Result<Map<Long, List<BudgetPeriodAmount>>> periodAmountsBatch(
            @RequestParam("sheetIds") String sheetIdsStr) {
        Map<Long, List<BudgetPeriodAmount>> result = budgetSheetService.getPeriodAmountsBatch(sheetIdsStr);
        return Result.success("查询成功", result);
    }

    @PostMapping("/calculate")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:edit') or @permissionChecker.hasPermission('crm:budget:calculate')")
    @OperationLog(module = "预算计算", description = "执行预算计算")
    public Result<String> calculate(@Validated @RequestBody BudgetCalculateRequest request) {
        String resultMsg = budgetSheetService.calculateBudget(request);
        return Result.success(resultMsg, null);
    }

    @GetMapping("/by-contract/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:view')")
    public Result<List<BudgetSheetVO>> byContract(@PathVariable Long id) {
        List<BudgetSheetVO> list = budgetSheetService.getByContract(id);
        return Result.success("查询成功", list);
    }

    @GetMapping("/export")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:export')")
    public void export(
            @RequestParam(value = "fiscalYear", required = false) Integer fiscalYear,
            @RequestParam(value = "versionId", required = false) Long versionId,
            @RequestParam(value = "catalogCode", required = false) String catalogCode,
            @RequestParam(value = "orgId", required = false) Long orgId,
            @RequestParam(value = "productLineId", required = false) Long productLineId,
            @RequestParam(value = "orgName", required = false) String orgName,
            @RequestParam(value = "productLineName", required = false) String productLineName,
            HttpServletResponse response) throws Exception {
        budgetSheetService.exportBudgetSheets(fiscalYear, versionId, catalogCode, orgId, productLineId, orgName, productLineName, response);
    }

    @GetMapping("/export-overview")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:export')")
    public void exportOverview(
            @RequestParam(value = "fiscalYear", required = false) Integer fiscalYear,
            @RequestParam(value = "versionId", required = false) Long versionId,
            @RequestParam(value = "orgId", required = false) Long orgId,
            @RequestParam(value = "productLineId", required = false) Long productLineId,
            @RequestParam(value = "orgName", required = false) String orgName,
            @RequestParam(value = "productLineName", required = false) String productLineName,
            HttpServletResponse response) throws Exception {
        budgetSheetService.exportOverview(fiscalYear, versionId, orgId, productLineId, orgName, productLineName, response);
    }

    @GetMapping("/export-all")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:export')")
    public void exportAll(
            @RequestParam(value = "fiscalYear", required = false) Integer fiscalYear,
            @RequestParam(value = "versionId", required = false) Long versionId,
            @RequestParam(value = "orgId", required = false) Long orgId,
            @RequestParam(value = "productLineId", required = false) Long productLineId,
            @RequestParam(value = "orgName", required = false) String orgName,
            @RequestParam(value = "productLineName", required = false) String productLineName,
            HttpServletResponse response) throws Exception {
        budgetSheetService.exportAll(fiscalYear, versionId, orgId, productLineId, orgName, productLineName, response);
    }

    @GetMapping("/export-dimension")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:export')")
    public void exportDimension(
            @RequestParam Integer fiscalYear,
            @RequestParam Long versionId,
            @RequestParam String catalogCode,
            @RequestParam(required = false) String stockFlag,
            @RequestParam(required = false) String productLine,
            @RequestParam(required = false) String contractType,
            @RequestParam(required = false) String customerName,
            @RequestParam(required = false) String projectName,
            @RequestParam(required = false) String manager,
            @RequestParam("dimFields") List<String> dimFields,
            HttpServletResponse response) throws Exception {
        budgetSheetService.exportDimension(fiscalYear, versionId, catalogCode, stockFlag, productLine, contractType,
                customerName, projectName, manager, dimFields, response);
    }
}
