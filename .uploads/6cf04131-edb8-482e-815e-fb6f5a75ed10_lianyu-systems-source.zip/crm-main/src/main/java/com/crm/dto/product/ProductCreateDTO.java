package com.crm.dto.product;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;

@Data
public class ProductCreateDTO {

    @NotBlank(message = "商品编号不能为空")
    private String productCode;

    @NotBlank(message = "商品名称不能为空")
    private String productName;

    private String unit;

    private BigDecimal salesPrice;

    private String status;

    private String category;

    private String description;

    private String remark;
}
