package com.crm.service.payment.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.SecurityContextUtil;
import com.crm.dataperm.DataPermModule;
import com.crm.dto.PageResult;
import com.crm.dto.payment.PaymentQueryDTO;
import com.crm.mapper.payment.PaymentMapper;
import com.crm.service.DataPermissionService;
import com.crm.service.payment.PaymentService;
import com.crm.vo.payment.PaymentRecordVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentMapper paymentMapper;

    @Autowired
    private DataPermissionService dataPermissionService;

    @Override
    public PageResult<PaymentRecordVO> page(PaymentQueryDTO query) {
        if (query == null) query = new PaymentQueryDTO();
        int pageNum = query.getPageNum() != null ? query.getPageNum() : 1;
        int pageSize = query.getPageSize() != null ? query.getPageSize() : 10;

        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;

        boolean isAdmin = SecurityContextUtil.hasRole("super_admin") || SecurityContextUtil.hasRole("ADMIN");
        // 管理员查看"全部"时不做行级过滤；其余场景按本人/共享范围收敛
        Long currentUserId = isAdmin && (query.getScope() == null || "all".equals(query.getScope()) || "".equals(query.getScope()))
                ? null : SecurityContextUtil.getCurrentUserId();

        Page<PaymentRecordVO> page = new Page<>(pageNum, pageSize);
        IPage<PaymentRecordVO> result = paymentMapper.selectPaymentPage(page, companyId, currentUserId, query);

        List<PaymentRecordVO> records = result.getRecords();
        if (records != null && !records.isEmpty()) {
            List<Long> contractIds = records.stream()
                    .map(PaymentRecordVO::getContractId).distinct().collect(Collectors.toList());
            // 以合同为维度计算权限位（回款记录继承合同权限）
            Map<Long, Integer> contractBits = dataPermissionService.permBitsMap(DataPermModule.CONTRACT, contractIds);
            records.forEach(vo -> vo.setPermBits(contractBits.getOrDefault(vo.getContractId(), 0)));
        }

        return new PageResult<>(records, result.getTotal(), pageNum, pageSize);
    }
}
