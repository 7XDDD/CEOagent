package com.crm.common;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.function.Function;
import java.util.Map;

public class ExcelUtil {

    public static class Column<T> {
        private String header;
        private int width;
        private Function<T, Object> valueExtractor;

        public Column(String header, int width, Function<T, Object> valueExtractor) {
            this.header = header;
            this.width = width;
            this.valueExtractor = valueExtractor;
        }

        public static <T> Column<T> of(String header, int width, Function<T, Object> extractor) {
            return new Column<>(header, width, extractor);
        }
    }

    public static <T> void export(List<T> data, String sheetName, List<Column<T>> columns,
                                   HttpServletResponse response, String fileName) throws Exception {
        Workbook workbook = new XSSFWorkbook();
        createSheet(workbook, data, sheetName, columns);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        String encodedFileName = URLEncoder.encode(fileName + ".xlsx", StandardCharsets.UTF_8.name()).replace("+", "%20");
        response.setHeader("Content-Disposition", "attachment; filename*=UTF-8''" + encodedFileName);
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");

        OutputStream out = response.getOutputStream();
        workbook.write(out);
        workbook.close();
        out.flush();
    }

    public static void exportMultiSheet(List<Map<String, Object>> sheetDataList,
                                         HttpServletResponse response, String fileName) throws Exception {
        Workbook workbook = new XSSFWorkbook();
        CellStyle headerStyle = createHeaderStyle(workbook);
        CellStyle dataStyle = createDataStyle(workbook);
        CellStyle amountStyle = createAmountStyle(workbook);

        for (Map<String, Object> sheetData : sheetDataList) {
            String sheetName = (String) sheetData.get("sheetName");
            List<Map<String, Object>> data = (List<Map<String, Object>>) sheetData.get("data");
            List<Column<Map<String, Object>>> columns = (List<Column<Map<String, Object>>>) sheetData.get("columns");

            Sheet sheet = workbook.createSheet(sheetName);

            Row headerRow = sheet.createRow(0);
            headerRow.setHeightInPoints(22);
            for (int i = 0; i < columns.size(); i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(columns.get(i).header);
                cell.setCellStyle(headerStyle);
                sheet.setColumnWidth(i, columns.get(i).width * 256);
            }

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            int rowNum = 1;
            for (Map<String, Object> item : data) {
                Row row = sheet.createRow(rowNum++);
                row.setHeightInPoints(18);
                for (int i = 0; i < columns.size(); i++) {
                    Cell cell = row.createCell(i);
                    Object value = columns.get(i).valueExtractor.apply(item);
                    if (value == null) {
                        cell.setCellValue("");
                        cell.setCellStyle(dataStyle);
                    } else if (value instanceof BigDecimal) {
                        BigDecimal bd = (BigDecimal) value;
                        cell.setCellValue(bd.doubleValue());
                        cell.setCellStyle(amountStyle);
                    } else if (value instanceof Number) {
                        cell.setCellValue(((Number) value).doubleValue());
                        cell.setCellStyle(amountStyle);
                    } else if (value instanceof Date) {
                        cell.setCellValue(sdf.format((Date) value));
                        cell.setCellStyle(dataStyle);
                    } else if (value instanceof Boolean) {
                        cell.setCellValue((Boolean) value ? "是" : "否");
                        cell.setCellStyle(dataStyle);
                    } else {
                        cell.setCellValue(value.toString());
                        cell.setCellStyle(dataStyle);
                    }
                }
            }
        }

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        String encodedFileName = URLEncoder.encode(fileName + ".xlsx", StandardCharsets.UTF_8.name()).replace("+", "%20");
        response.setHeader("Content-Disposition", "attachment; filename*=UTF-8''" + encodedFileName);
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");

        OutputStream out = response.getOutputStream();
        workbook.write(out);
        workbook.close();
        out.flush();
    }

    private static <T> void createSheet(Workbook workbook, List<T> data, String sheetName, List<Column<T>> columns) {
        Sheet sheet = workbook.createSheet(sheetName);
        CellStyle headerStyle = createHeaderStyle(workbook);
        CellStyle dataStyle = createDataStyle(workbook);
        CellStyle amountStyle = createAmountStyle(workbook);

        Row headerRow = sheet.createRow(0);
        headerRow.setHeightInPoints(22);
        for (int i = 0; i < columns.size(); i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns.get(i).header);
            cell.setCellStyle(headerStyle);
            sheet.setColumnWidth(i, columns.get(i).width * 256);
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        int rowNum = 1;
        for (T item : data) {
            Row row = sheet.createRow(rowNum++);
            row.setHeightInPoints(18);
            for (int i = 0; i < columns.size(); i++) {
                Cell cell = row.createCell(i);
                Object value = columns.get(i).valueExtractor.apply(item);
                if (value == null) {
                    cell.setCellValue("");
                    cell.setCellStyle(dataStyle);
                } else if (value instanceof BigDecimal) {
                    BigDecimal bd = (BigDecimal) value;
                    cell.setCellValue(bd.doubleValue());
                    cell.setCellStyle(amountStyle);
                } else if (value instanceof Number) {
                    cell.setCellValue(((Number) value).doubleValue());
                    cell.setCellStyle(amountStyle);
                } else if (value instanceof Date) {
                    cell.setCellValue(sdf.format((Date) value));
                    cell.setCellStyle(dataStyle);
                } else if (value instanceof Boolean) {
                    cell.setCellValue((Boolean) value ? "是" : "否");
                    cell.setCellStyle(dataStyle);
                } else {
                    cell.setCellValue(value.toString());
                    cell.setCellStyle(dataStyle);
                }
            }
        }
    }

    private static CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 11);
        font.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.ROYAL_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setTopBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setBottomBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setLeftBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        style.setRightBorderColor(IndexedColors.GREY_40_PERCENT.getIndex());
        return style;
    }

    private static CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setTopBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setBottomBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setLeftBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setRightBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
        return style;
    }

    private static CellStyle createAmountStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setAlignment(HorizontalAlignment.RIGHT);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setTopBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setBottomBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setLeftBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setRightBorderColor(IndexedColors.GREY_25_PERCENT.getIndex());
        DataFormat df = workbook.createDataFormat();
        style.setDataFormat(df.getFormat("#,##0.000000"));
        return style;
    }
}
