package com.crm.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class CustomerQueryDTO extends PageQueryDTO {
    private String keyword;
    private String customerCode;
    private String customerName;
    private String customerType;
    private String customerLevel;
    private String customerScale;
    private String customerNature;
    private String customerStatus;
    private String status;
    private String customerIndustry;
    private String industryL1;
    private String industryL2;
    private String region;
    private String callStatus;
    /** 视图类型: pending待跟进/todayNew今天新增/todayRecycle今天回收/noFollow7七天未跟进/dealed已成 */
    private String viewType;
    /** 数据权限：当前用户ID，非管理员只看自己跟进或创建的客户 */
    private Long currentUserId;
}
