package com.crm.security;

import com.crm.common.SecurityContextUtil;
import org.springframework.stereotype.Component;

import java.util.Arrays;

/**
 * 权限检查器，供 @PreAuthorize("@permissionChecker.hasPermission(...)") 使用。
 * 管理员角色（super_admin）自动拥有所有权限。
 */
@Component("permissionChecker")
public class PermissionChecker {

    private static final String ADMIN_ROLE = "super_admin";

    public boolean hasPermission(String permission) {
        if (SecurityContextUtil.hasRole(ADMIN_ROLE)) {
            return true;
        }
        return SecurityContextUtil.hasPermission(permission);
    }

    public boolean hasAnyPermission(String... permissions) {
        if (permissions == null || permissions.length == 0) {
            return true;
        }
        if (SecurityContextUtil.hasRole(ADMIN_ROLE)) {
            return true;
        }
        return SecurityContextUtil.hasAnyPermission(Arrays.asList(permissions));
    }
}
