package com.crm;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@MapperScan("com.crm.mapper")
@EnableScheduling
public class CrmApplication {

    public static void main(String[] args) {
        SpringApplication.run(CrmApplication.class, args);
        System.out.println("====================================");
        System.out.println("  CRM系统后端启动成功!");
        System.out.println("  API文档: http://localhost:8080/api/doc.html");
        System.out.println("====================================");
    }
}
