package com.crm.dto.product;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
public class ProductUpdateDTO {

    @NotNull(message = "商品ID不能为空")
    private Long id;

    private String productCode;

    private String productName;

    private String unit;

    private BigDecimal salesPrice;

    private String status;

    private String category;

    private String description;

    private String remark;
}
