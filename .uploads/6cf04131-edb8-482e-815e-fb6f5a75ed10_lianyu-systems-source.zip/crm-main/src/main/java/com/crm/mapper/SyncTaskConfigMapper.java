package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.SyncTaskConfig;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SyncTaskConfigMapper extends BaseMapper<SyncTaskConfig> {
}
