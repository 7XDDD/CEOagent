package com.crm.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

/**
 * 权限数据初始化器
 * 应用启动时检查 crm_permission 表，如果 base: 前缀权限不足则自动初始化。
 * 确保 super_admin 角色存在并拥有所有权限，admin 用户分配 super_admin 角色。
 */
@Slf4j
@Component
public class PermissionDataInitializer implements ApplicationRunner {

    private static final int EXPECTED_PERMISSION_COUNT = 79;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private DataSource dataSource;

    @Override
    public void run(ApplicationArguments args) {
        try {
            // 检查 base: 前缀的权限数量
            Integer count = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM crm_permission WHERE permission_code LIKE 'crm:%'",
                    Integer.class);
            int basePermCount = count != null ? count : 0;

            if (basePermCount >= EXPECTED_PERMISSION_COUNT) {
                log.info("[PermissionInit] base: 权限数量 = {}，无需初始化", basePermCount);
                ensureSuperAdminRole();
                return;
            }

            log.warn("[PermissionInit] base: 权限数量 = {}，低于期望值 {}，开始初始化权限数据...",
                    basePermCount, EXPECTED_PERMISSION_COUNT);

            // 执行初始化 SQL 脚本
            executeSqlScript("sql/init-permissions.sql");

            log.info("[PermissionInit] 权限数据初始化完成");
        } catch (Exception e) {
            log.error("[PermissionInit] 权限数据初始化失败", e);
        }
    }

    private void ensureSuperAdminRole() {
        try {
            // 确保 role_id=1 是 super_admin
            Integer roleCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM crm_role WHERE id = 1 AND role_code = 'super_admin'",
                    Integer.class);
            if (roleCount == null || roleCount == 0) {
                jdbcTemplate.update(
                        "UPDATE crm_role SET role_code = 'super_admin', role_name = '超级管理员', " +
                                "role_desc = '系统超级管理员，拥有所有权限' WHERE id = 1");
                log.info("[PermissionInit] 已将 role_id=1 更新为 super_admin");
            }

            // 确保 admin 用户(user_id=1)拥有 super_admin 角色
            Integer userRoleCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM crm_user_role WHERE user_id = 1 AND role_id = 1 AND deleted = 0",
                    Integer.class);
            if (userRoleCount == null || userRoleCount == 0) {
                jdbcTemplate.update("DELETE FROM crm_user_role WHERE user_id = 1");
                jdbcTemplate.update(
                        "INSERT INTO crm_user_role (user_id, role_id, created_by, updated_by, create_time, update_time, version, deleted) " +
                                "VALUES (1, 1, 1, 1, NOW(), NOW(), 0, 0)");
                log.info("[PermissionInit] 已为 admin 用户分配 super_admin 角色");
            }

            // 确保 super_admin 拥有所有权限
            Integer rpCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM crm_role_permission WHERE role_id = 1 AND deleted = 0",
                    Integer.class);
            int allPermCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM crm_permission", Integer.class);
            if (rpCount == null || rpCount < allPermCount) {
                jdbcTemplate.update("DELETE FROM crm_role_permission WHERE role_id = 1");
                jdbcTemplate.update(
                        "INSERT INTO crm_role_permission (role_id, permission_id, created_by, updated_by, create_time, update_time, version, deleted) " +
                                "SELECT 1, id, 1, 1, NOW(), NOW(), 0, 0 FROM crm_permission");
                log.info("[PermissionInit] 已为 super_admin 分配全部 {} 个权限", allPermCount);
            }
        } catch (Exception e) {
            log.error("[PermissionInit] 确保 super_admin 角色失败", e);
        }
    }

    private void executeSqlScript(String classpathLocation) throws Exception {
        ClassPathResource resource = new ClassPathResource(classpathLocation);
        try (Connection connection = dataSource.getConnection()) {
            org.springframework.jdbc.datasource.init.ScriptUtils.executeSqlScript(connection, resource);
        }
    }
}
