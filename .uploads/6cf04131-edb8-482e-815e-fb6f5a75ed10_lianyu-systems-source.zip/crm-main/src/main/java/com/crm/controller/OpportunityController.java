package com.crm.controller;

import com.crm.annotation.OperationLog;
import com.crm.common.Result;
import com.crm.dto.PageResult;
import com.crm.dto.opportunity.OpportunityCreateDTO;
import com.crm.dto.opportunity.OpportunityQueryDTO;
import com.crm.dto.opportunity.OpportunityUpdateDTO;
import com.crm.service.OpportunityService;
import com.crm.vo.opportunity.OpportunityVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/opportunity")
@Slf4j
public class OpportunityController {

    @Autowired
    private OpportunityService opportunityService;

    @PostMapping("/page")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:view')")
    public Result<PageResult<OpportunityVO>> page(@RequestBody(required = false) OpportunityQueryDTO query) {
        return Result.success("查询成功", opportunityService.page(query));
    }

    @PostMapping("/list")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:view')")
    public Result<List<OpportunityVO>> list(@RequestBody(required = false) OpportunityQueryDTO query) {
        return Result.success("查询成功", opportunityService.list(query));
    }

    @GetMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:view')")
    public Result<OpportunityVO> getById(@PathVariable Long id) {
        return Result.success("查询成功", opportunityService.getById(id));
    }

    @PostMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:add')")
    @OperationLog(module = "商机管理", description = "新增商机")
    public Result<OpportunityVO> save(@Valid @RequestBody OpportunityCreateDTO dto) {
        return Result.success("保存成功", opportunityService.save(dto));
    }

    @PutMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:edit')")
    @OperationLog(module = "商机管理", description = "更新商机")
    public Result<OpportunityVO> update(@Valid @RequestBody OpportunityUpdateDTO dto) {
        return Result.success("更新成功", opportunityService.update(dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:delete')")
    @Transactional(rollbackFor = Exception.class)
    @OperationLog(module = "商机管理", description = "删除商机")
    public Result<String> deleteById(@PathVariable Long id) {
        opportunityService.deleteById(id);
        return Result.success("删除成功", null);
    }

    @DeleteMapping("/batch")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:delete')")
    @Transactional(rollbackFor = Exception.class)
    @OperationLog(module = "商机管理", description = "批量删除商机")
    public Result<String> deleteBatch(@RequestBody List<Long> ids) {
        opportunityService.deleteBatch(ids);
        return Result.success("删除成功", null);
    }

    @PostMapping("/{id}/change-stage")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:edit')")
    public Result<OpportunityVO> changeStage(@PathVariable Long id, @RequestParam String stage) {
        return Result.success("阶段更新成功", opportunityService.changeStage(id, stage));
    }

    @PostMapping("/{id}/change-status")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:edit')")
    public Result<OpportunityVO> changeStatus(@PathVariable Long id, @RequestParam String status) {
        return Result.success("状态更新成功", opportunityService.changeStatus(id, status));
    }

    @PostMapping("/{id}/transfer")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:edit')")
    @OperationLog(module = "商机管理", description = "转移商机负责人")
    public Result<OpportunityVO> transfer(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        Long newOwnerId = body.get("newOwnerId") != null ? Long.valueOf(body.get("newOwnerId").toString()) : null;
        String newOwnerName = body.get("newOwnerName") != null ? body.get("newOwnerName").toString() : null;
        return Result.success("转移成功", opportunityService.transfer(id, newOwnerId, newOwnerName));
    }

    @PostMapping("/{id}/build-contract")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:edit')")
    @OperationLog(module = "商机管理", description = "由商机构建合同")
    public Result<Long> buildContract(@PathVariable Long id) {
        return Result.success("合同草稿已生成，请完善合同信息", opportunityService.buildContract(id));
    }

    @PostMapping("/export")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:export')")
    public void exportOpportunities(@RequestBody(required = false) OpportunityQueryDTO query,
                                    HttpServletResponse response) throws Exception {
        opportunityService.exportOpportunities(query, response);
    }

    @GetMapping("/import-template")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:import')")
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        opportunityService.downloadImportTemplate(response);
    }

    @PostMapping("/import-excel")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:import')")
    @OperationLog(module = "商机管理", description = "导入商机")
    public Result<Map<String, Object>> importExcel(@RequestParam("companyId") Long companyId,
                                                    @RequestParam("file") MultipartFile file) {
        Map<String, Object> result = opportunityService.importExcel(companyId, file);
        int success = (int) result.getOrDefault("success", 0);
        int failed = (int) result.getOrDefault("failed", 0);
        String msg = "导入完成，成功 " + success + " 条，失败 " + failed + " 条";
        return Result.success(msg, result);
    }
}
