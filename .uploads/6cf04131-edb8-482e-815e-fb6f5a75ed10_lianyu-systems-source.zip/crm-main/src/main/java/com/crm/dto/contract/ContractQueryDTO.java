package com.crm.dto.contract;

import com.crm.dto.PageQueryDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
public class ContractQueryDTO extends PageQueryDTO {

    /**
     * 合同ID精确过滤（用于从合同预算页点击合同编号跳转，仅定位到该条合同）
     */
    private Long id;

    /**
     * 合同ID集合过滤（用于跳转场景下复制合同后，同时展示原合同与复制件）
     */
    private List<Long> ids;

    /** 服务端注入：当前登录用户ID，用于行级数据权限（非管理员只看负责/创建/被共享的合同） */
    private Long currentUserId;
}
