package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.budget.BudgetVersionQueryDTO;
import com.crm.entity.BudgetVersion;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface BudgetVersionMapper extends BaseMapper<BudgetVersion> {

    Page<BudgetVersion> selectPageList(Page<BudgetVersion> page, @Param("q") BudgetVersionQueryDTO query);

    List<BudgetVersion> selectListByCondition(@Param("q") BudgetVersionQueryDTO query);

    BudgetVersion findActiveVersion(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    List<BudgetVersion> selectRollingVersions(@Param("fiscalYear") Integer fiscalYear);

    int resetActiveByFiscalYear(@Param("fiscalYear") Integer fiscalYear, @Param("companyId") Long companyId);

    int setActive(@Param("id") Long id);

    int lockById(@Param("id") Long id);

    int unlockById(@Param("id") Long id);

    int countByCode(@Param("code") String code, @Param("excludeId") Long excludeId, @Param("companyId") Long companyId);

    /**
     * 统计同一公司、同一财年下已定稿的调整预算（ADJUST）版本数量
     * @param companyId 公司ID
     * @param fiscalYear 财年
     * @param excludeId 排除的版本ID（更新时传自身ID，新增时传null）
     * @return 已定稿调整版本数量
     */
    int countFinalizedAdjust(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("excludeId") Long excludeId);

    /**
     * 查找指定公司、财年下已定稿的调整预算（ADJUST）版本（取最新一个）
     * @param companyId 公司ID
     * @param fiscalYear 财年
     * @return 已定稿调整版本，不存在返回null
     */
    BudgetVersion findFinalizedAdjust(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    int softDeleteById(@Param("id") Long id);

    int softDeleteByIds(@Param("ids") List<Long> ids);

    BudgetVersion findLatestInMonth(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("monthStart") LocalDateTime monthStart, @Param("monthEnd") LocalDateTime monthEnd);

    BudgetVersion findLatestBeforeMonth(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("monthStart") LocalDateTime monthStart);

    BudgetVersion findLatest(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    BudgetVersion findByRollingMonth(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("rollingMonth") Integer rollingMonth);

    BudgetVersion findAnnualVersion(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    BudgetVersion findFirstNonRolling(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    BudgetVersion findFirstAny(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    BudgetVersion findFirstInMonth(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("monthStart") LocalDateTime monthStart, @Param("monthEnd") LocalDateTime monthEnd);

    BudgetVersion findFirstBeforeMonth(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("monthStart") LocalDateTime monthStart);

    BudgetVersion findFirstVersion(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    long countActiveVersions();

    long countAllVersions();

    List<BudgetVersion> listByFiscalYear(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    BudgetVersion findLatestVersion(@Param("companyId") Long companyId);

    BudgetVersion findFirstByScene(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("budgetScene") String budgetScene);

    BudgetVersion findLatestByScene(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("budgetScene") String budgetScene);

    BudgetVersion findRollingByMonth(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("rollingMonth") Integer rollingMonth);

    /** 查询指定滚动月的第一个ROLLING版本（按创建时间升序），用于预测与实际对比页 */
    BudgetVersion findFirstRollingByMonth(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("rollingMonth") Integer rollingMonth);
}