package com.crm.dto.budget;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
public class BudgetVersionUpdateDTO {

    @NotNull(message = "ID不能为空")
    private Long id;

    private Integer fiscalYear;

    private String versionCode;

    private String versionName;

    private String budgetScene;

    private Integer rollingMonth;

    /**
     * 是否定稿：0=否（默认），1=是。仅调整预算（ADJUST）版本使用
     */
    private Integer isFinalized;

    private Integer isActive;

    private Integer isLocked;

    private String approvalStatus;

    private LocalDate effectiveDate;

    private LocalDate expireDate;

    private Long parentVersionId;

    private String remark;

    private Long ownerId;
}
