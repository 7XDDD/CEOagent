package com.crm.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crm.annotation.OperationLog;
import com.crm.common.Result;
import com.crm.dto.dataperm.DataPermGrantDTO;
import com.crm.entity.DataPermission;
import com.crm.entity.User;
import com.crm.mapper.UserMapper;
import com.crm.service.DataPermissionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 通用数据级共享授权（客户/商机/合同复用）。
 * 服务端二次校验：仅数据负责人或管理员可授权/收回。
 */
@RestController
@RequestMapping("/data-perm")
@Slf4j
public class DataPermissionController {

    @Autowired
    private DataPermissionService dataPermissionService;

    @Autowired
    private UserMapper userMapper;

    /** 可授权人员简表（仅id/姓名/账号），供共享弹窗选择；无需用户管理菜单权限 */
    @GetMapping("/users")
    @PreAuthorize("@permissionChecker.hasPermission('crm:data:share')")
    public Result<List<Map<String, Object>>> users() {
        LambdaQueryWrapper<User> w = new LambdaQueryWrapper<>();
        w.eq(User::getStatus, 1)
                .select(User::getId, User::getUsername, User::getRealName, User::getDeptId)
                .orderByAsc(User::getId);
        List<Map<String, Object>> list = userMapper.selectList(w).stream()
                .map(u -> {
                    Map<String, Object> m = new java.util.LinkedHashMap<>();
                    m.put("id", u.getId());
                    m.put("username", u.getUsername());
                    m.put("realName", u.getRealName());
                    return m;
                })
                .collect(Collectors.toList());
        return Result.success("查询成功", list);
    }

    @GetMapping("/list")
    @PreAuthorize("@permissionChecker.hasPermission('crm:data:share')")
    public Result<List<DataPermission>> list(@RequestParam String module, @RequestParam Long bizId) {
        return Result.success("查询成功", dataPermissionService.listGrants(module, bizId));
    }

    @PostMapping("/grant")
    @PreAuthorize("@permissionChecker.hasPermission('crm:data:share')")
    @OperationLog(module = "数据权限", description = "授予数据共享权限")
    public Result<Void> grant(@RequestBody DataPermGrantDTO dto) {
        dataPermissionService.grant(dto.getModule(), dto.getBizId(), dto.getGranteeId(),
                dto.getPermBits(), dto.getExpireDate(), dto.getRemark());
        return Result.success("授权成功", null);
    }

    @DeleteMapping("/revoke")
    @PreAuthorize("@permissionChecker.hasPermission('crm:data:share')")
    @OperationLog(module = "数据权限", description = "收回数据共享权限")
    public Result<Void> revoke(@RequestParam String module, @RequestParam Long bizId, @RequestParam Long grantId) {
        dataPermissionService.revoke(module, bizId, grantId);
        return Result.success("已收回授权", null);
    }
}
