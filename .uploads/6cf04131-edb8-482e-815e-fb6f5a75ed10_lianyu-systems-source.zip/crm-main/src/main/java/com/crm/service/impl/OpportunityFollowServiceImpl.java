package com.crm.service.impl;

import com.crm.common.SecurityContextUtil;
import com.crm.dto.opportunity.OpportunityFollowCreateDTO;
import com.crm.entity.Opportunity;
import com.crm.entity.OpportunityFollow;
import com.crm.mapper.OpportunityFollowMapper;
import com.crm.mapper.OpportunityMapper;
import com.crm.service.OpportunityFollowService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class OpportunityFollowServiceImpl implements OpportunityFollowService {

    @Autowired
    private OpportunityFollowMapper followMapper;

    @Autowired
    private OpportunityMapper opportunityMapper;

    @Override
    public IPage<OpportunityFollow> page(Integer pageNum, Integer pageSize, String keyword, String scope) {
        int pn = pageNum != null ? pageNum : 1;
        int ps = pageSize != null ? pageSize : 10;
        Page<OpportunityFollow> page = new Page<>(pn, ps);
        LambdaQueryWrapper<OpportunityFollow> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(OpportunityFollow::getDeleted, 0);
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.and(w -> w.like(OpportunityFollow::getOpportunityName, keyword)
                    .or().like(OpportunityFollow::getCustomerName, keyword)
                    .or().like(OpportunityFollow::getContent, keyword)
                    .or().like(OpportunityFollow::getFollower, keyword));
        }
        wrapper.orderByDesc(OpportunityFollow::getFollowTime);
        return followMapper.selectPage(page, wrapper);
    }

    @Override
    public IPage<OpportunityFollow> planPage(Integer pageNum, Integer pageSize, String keyword, String scope, String planStatus) {
        int pn = pageNum != null ? pageNum : 1;
        int ps = pageSize != null ? pageSize : 10;
        Page<OpportunityFollow> page = new Page<>(pn, ps);
        LambdaQueryWrapper<OpportunityFollow> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(OpportunityFollow::getDeleted, 0);
        // 跟进计划：必须有下次计划内容
        wrapper.and(w -> w.isNotNull(OpportunityFollow::getPlanTitle).or().isNotNull(OpportunityFollow::getPlanContent));
        String status = (planStatus == null || planStatus.isEmpty() || "ALL".equals(planStatus)) ? "PENDING" : planStatus;
        wrapper.and(w -> w.eq(OpportunityFollow::getPlanStatus, status).or().isNull(OpportunityFollow::getPlanStatus));
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.and(w -> w.like(OpportunityFollow::getOpportunityName, keyword)
                    .or().like(OpportunityFollow::getCustomerName, keyword)
                    .or().like(OpportunityFollow::getPlanTitle, keyword)
                    .or().like(OpportunityFollow::getPlanContent, keyword));
        }
        wrapper.orderByAsc(OpportunityFollow::getPlanTime).orderByDesc(OpportunityFollow::getFollowTime);
        return followMapper.selectPage(page, wrapper);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void markPlanDone(Long id) {
        OpportunityFollow f = followMapper.selectById(id);
        if (f == null) {
            throw new com.crm.common.BusinessException(com.crm.common.ResultCode.DATA_NOT_FOUND.getCode(), "跟进计划不存在");
        }
        f.setPlanStatus("DONE");
        followMapper.updateById(f);
        log.info("跟进计划标记完成: id={}", id);
    }

    @Override
    public List<OpportunityFollow> listByOpportunityId(Long opportunityId) {
        return followMapper.selectByOpportunityId(opportunityId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public OpportunityFollow save(OpportunityFollowCreateDTO dto) {
        Opportunity opp = opportunityMapper.selectById(dto.getOpportunityId());
        if (opp == null) {
            throw new com.crm.common.BusinessException(com.crm.common.ResultCode.DATA_NOT_FOUND.getCode(), "商机不存在");
        }

        OpportunityFollow entity = new OpportunityFollow();
        BeanUtils.copyProperties(dto, entity);

        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        entity.setCompanyId(companyId);

        if (entity.getOpportunityName() == null) {
            entity.setOpportunityName(opp.getOpportunityName());
        }
        if (entity.getCustomerId() == null && opp.getCustomerId() != null) {
            entity.setCustomerId(opp.getCustomerId());
            entity.setCustomerName(opp.getCustomerName());
        }
        if (entity.getFollowTime() == null) {
            entity.setFollowTime(LocalDateTime.now());
        }
        // 填写了下次计划则默认待跟进
        boolean hasPlan = (entity.getPlanTitle() != null && !entity.getPlanTitle().isEmpty())
                || (entity.getPlanContent() != null && !entity.getPlanContent().isEmpty());
        if (hasPlan && (entity.getPlanStatus() == null || entity.getPlanStatus().isEmpty())) {
            entity.setPlanStatus("PENDING");
        }

        followMapper.insert(entity);
        log.info("新增商机跟进记录成功: id={}, opportunityId={}", entity.getId(), entity.getOpportunityId());
        return entity;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Long id) {
        followMapper.deleteById(id);
        log.info("删除商机跟进记录成功: id={}", id);
    }
}
