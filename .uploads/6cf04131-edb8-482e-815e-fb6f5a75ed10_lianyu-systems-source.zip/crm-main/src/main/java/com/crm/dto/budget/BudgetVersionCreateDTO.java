package com.crm.dto.budget;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Data
public class BudgetVersionCreateDTO {

    @NotNull(message = "财年不能为空")
    private Integer fiscalYear;

    @NotBlank(message = "版本编码不能为空")
    private String versionCode;

    @NotBlank(message = "版本名称不能为空")
    private String versionName;

    private String budgetScene;

    private Integer rollingMonth;

    /**
     * 是否定稿：0=否（默认），1=是。仅调整预算（ADJUST）版本使用
     */
    private Integer isFinalized;

    private LocalDate effectiveDate;

    private LocalDate expireDate;

    private Long parentVersionId;

    private String remark;

    private Long ownerId;
}
