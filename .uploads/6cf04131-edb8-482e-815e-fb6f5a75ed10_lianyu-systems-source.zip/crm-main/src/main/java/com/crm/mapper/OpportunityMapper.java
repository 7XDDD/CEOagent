package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.crm.dto.opportunity.OpportunityQueryDTO;
import com.crm.entity.Opportunity;
import com.crm.vo.opportunity.OpportunityVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface OpportunityMapper extends BaseMapper<Opportunity> {

    IPage<OpportunityVO> selectPageList(IPage<OpportunityVO> page,
                                        @Param("companyId") Long companyId,
                                        @Param("query") OpportunityQueryDTO query);

    List<OpportunityVO> selectListByQuery(@Param("companyId") Long companyId,
                                          @Param("query") OpportunityQueryDTO query);

    OpportunityVO selectDetailById(@Param("id") Long id);
}
