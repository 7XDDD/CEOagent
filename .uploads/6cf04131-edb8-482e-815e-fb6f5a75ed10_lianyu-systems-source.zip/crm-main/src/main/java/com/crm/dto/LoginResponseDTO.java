package com.crm.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponseDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String token;
    private Long userId;
    private String username;
    private String realName;
    private Long companyId;
    private Long orgId;
    private String avatarUrl;
    private List<String> roles;
    private List<String> permissions;
    private Integer passwordExpireRemainDays;
    private Boolean passwordNeedChange;
    private String passwordExpireMessage;
    private Boolean passwordExpired;

    public LoginResponseDTO(String token, Long userId, String username, String realName,
                            Long companyId, Long orgId, List<String> roles, List<String> permissions) {
        this.token = token;
        this.userId = userId;
        this.username = username;
        this.realName = realName;
        this.companyId = companyId;
        this.orgId = orgId;
        this.roles = roles;
        this.permissions = permissions;
    }
}
