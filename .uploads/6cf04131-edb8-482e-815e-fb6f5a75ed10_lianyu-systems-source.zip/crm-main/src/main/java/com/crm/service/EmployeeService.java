package com.crm.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.crm.dto.EmployeeQueryDTO;
import com.crm.entity.PmtEmployee;

import java.util.List;

public interface EmployeeService extends IService<PmtEmployee> {

    Page<PmtEmployee> pageList(EmployeeQueryDTO queryDTO);

    List<PmtEmployee> listAll(EmployeeQueryDTO queryDTO);

    List<PmtEmployee> listActive(String keyword);

    PmtEmployee getByJobNumber(String jobNumber);

    boolean isHrMode();

    void createEmployee(PmtEmployee employee);

    void updateEmployee(Long id, PmtEmployee employee);

    void deleteEmployee(Long id);
}
