package com.crm.controller.system;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.annotation.OperationLog;
import com.crm.annotation.OperationLog.OperationType;
import com.crm.common.Result;
import com.crm.dto.system.RoleCreateDTO;
import com.crm.dto.system.RoleQueryDTO;
import com.crm.dto.system.RoleUpdateDTO;
import com.crm.entity.Role;
import com.crm.service.RoleService;
import com.crm.vo.system.RoleVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "系统管理-角色管理")
@RestController
@RequestMapping("/system/role")
public class RoleController {

    @Autowired
    private RoleService roleService;

    @ApiOperation("分页查询角色列表")
    @PreAuthorize("@permissionChecker.hasPermission('crm:role:view')")
    @GetMapping("/page")
    public Result<Page<RoleVO>> page(RoleQueryDTO query) {
        return Result.success(roleService.pageList(query));
    }

    @ApiOperation("获取所有角色")
    @PreAuthorize("@permissionChecker.hasPermission('crm:role:view')")
    @GetMapping("/list")
    public Result<List<Role>> list() {
        return Result.success(roleService.listAll());
    }

    @ApiOperation("获取角色详情")
    @PreAuthorize("@permissionChecker.hasPermission('crm:role:view')")
    @GetMapping("/{id}")
    public Result<RoleVO> getDetail(@PathVariable Long id) {
        return Result.success(roleService.getDetail(id));
    }

    @ApiOperation("新增角色")
    @PreAuthorize("@permissionChecker.hasPermission('crm:role:create')")
    @OperationLog(module = "角色管理", description = "新增角色", type = OperationType.INSERT)
    @PostMapping
    public Result<?> create(@Validated @RequestBody RoleCreateDTO dto) {
        roleService.create(dto);
        return Result.success("创建成功");
    }

    @ApiOperation("修改角色")
    @PreAuthorize("@permissionChecker.hasPermission('crm:role:update')")
    @OperationLog(module = "角色管理", description = "修改角色", type = OperationType.UPDATE)
    @PutMapping("/{id:\\d+}")
    public Result<?> update(@PathVariable Long id, @RequestBody RoleUpdateDTO dto) {
        roleService.update(id, dto);
        return Result.success("修改成功");
    }

    @ApiOperation("删除角色")
    @PreAuthorize("@permissionChecker.hasPermission('crm:role:delete')")
    @OperationLog(module = "角色管理", description = "删除角色", type = OperationType.DELETE)
    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id) {
        roleService.delete(id);
        return Result.success("删除成功");
    }

    @ApiOperation("获取角色权限ID列表")
    @PreAuthorize("@permissionChecker.hasPermission('crm:role:view')")
    @GetMapping("/{id}/permissions")
    public Result<List<Long>> getPermissionIds(@PathVariable Long id) {
        return Result.success(roleService.getPermissionIds(id));
    }

    @ApiOperation("获取角色权限ID列表(兼容路径)")
    @PreAuthorize("@permissionChecker.hasPermission('crm:role:view')")
    @GetMapping("/permission-ids/{id}")
    public Result<List<Long>> getPermissionIdsCompat(@PathVariable Long id) {
        return Result.success(roleService.getPermissionIds(id));
    }

    @ApiOperation("分配角色权限")
    @PreAuthorize("@permissionChecker.hasPermission('crm:role:assign-perms')")
    @OperationLog(module = "角色管理", description = "分配角色权限", type = OperationType.UPDATE)
    @PostMapping("/assign-permissions/{id}")
    public Result<?> assignPermissions(@PathVariable Long id, @RequestBody java.util.Map<String, List<Long>> body) {
        roleService.assignPermissions(id, body.get("permissionIds"));
        return Result.success("分配成功");
    }

    @ApiOperation("获取角色项目权限ID列表")
    @PreAuthorize("@permissionChecker.hasPermission('crm:role:view')")
    @GetMapping("/{id}/projects")
    public Result<List<Long>> getProjectIds(@PathVariable Long id) {
        return Result.success(roleService.getProjectIds(id));
    }

    @ApiOperation("分配角色项目数据权限")
    @PreAuthorize("@permissionChecker.hasPermission('crm:role:assign-data')")
    @OperationLog(module = "角色管理", description = "分配角色数据权限", type = OperationType.UPDATE)
    @PostMapping("/assign-projects/{id}")
    public Result<?> assignProjects(@PathVariable Long id, @RequestBody java.util.Map<String, List<Long>> body) {
        roleService.assignProjects(id, body.get("projectIds"));
        return Result.success("项目权限分配成功");
    }
}
