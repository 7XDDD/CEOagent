package com.crm.service.contract.impl;

import cn.hutool.core.io.IoUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.BusinessException;
import com.crm.common.ResultCode;
import com.crm.common.SecurityContextUtil;
import com.crm.dataperm.DataPermBits;
import com.crm.dataperm.DataPermModule;
import com.crm.dto.PageResult;
import com.crm.dto.contract.ContractCreateDTO;
import com.crm.dto.contract.ContractMilestoneDTO;
import com.crm.dto.contract.ContractQueryDTO;
import com.crm.dto.contract.ContractUpdateDTO;
import com.crm.entity.Contract;
import com.crm.entity.ContractMilestone;
import com.crm.entity.ContractOpportunity;
import com.crm.entity.ContractProject;
import com.crm.entity.Opportunity;
import com.crm.entity.Org;
import com.crm.mapper.OpportunityMapper;
import com.crm.mapper.OrgMapper;
import com.crm.mapper.contract.ContractMapper;
import com.crm.mapper.contract.ContractMilestoneMapper;
import com.crm.mapper.contract.ContractOpportunityMapper;
import com.crm.mapper.contract.ContractProjectMapper;
import com.crm.service.DataPermissionService;
import com.crm.service.contract.ContractService;
import com.crm.vo.contract.ContractMilestoneVO;
import com.crm.vo.contract.ContractVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 合同管理服务实现类
 * 负责合同主表及里程碑子表的CRUD操作、Excel导入导出、数据校验等功能
 * 核心业务逻辑：
 * 1. 合同与里程碑的级联保存/删除
 * 2. 合同金额变更时按比例自动重算里程碑金额
 * 3. 已开票/未开票金额汇总计算
 * 4. 合同状态流转管理（未签订→已签订→已完成/已取消）
 * 5. Excel批量导入（支持同一合同多行里程碑）与导出
 */
@Service
@Slf4j
public class ContractServiceImpl implements ContractService {

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter[] DATE_FORMATS = {
            DateTimeFormatter.ofPattern("yyyy-MM-dd"),
            DateTimeFormatter.ofPattern("yyyy/MM/dd"),
            DateTimeFormatter.ofPattern("yyyy.MM.dd"),
            DateTimeFormatter.ofPattern("yyyyMMdd"),
            DateTimeFormatter.ofPattern("MM/dd/yyyy"),
            DateTimeFormatter.ofPattern("dd/MM/yyyy")
    };
    private static final DateTimeFormatter YEAR_MONTH_FMT = DateTimeFormatter.ofPattern("yyyy-MM");
    private static final DateTimeFormatter[] YEAR_MONTH_FORMATS = {
            DateTimeFormatter.ofPattern("yyyy-MM"),
            DateTimeFormatter.ofPattern("yyyy/MM"),
            DateTimeFormatter.ofPattern("yyyy.MM"),
            DateTimeFormatter.ofPattern("yyyyMM")
    };
    private static final BigDecimal WAN = new BigDecimal("10000");
    private static final Set<String> ALLOWED_EXTENSIONS = new HashSet<>(Arrays.asList(".xlsx", ".xls"));
    private static final Set<String> ALLOWED_MIME_TYPES = new HashSet<>(Arrays.asList(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-excel",
            "application/octet-stream"
    ));
    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024;
    private static final LocalDate EXCEL_EPOCH = LocalDate.of(1899, 12, 30);

    @Autowired
    private ContractMapper contractMapper;

    @Autowired
    private ContractMilestoneMapper milestoneMapper;

    @Autowired
    private OrgMapper orgMapper;

    @Autowired
    private DataPermissionService dataPermissionService;

    @Autowired
    private ContractOpportunityMapper contractOpportunityMapper;

    @Autowired
    private ContractProjectMapper contractProjectMapper;

    @Autowired
    private OpportunityMapper opportunityMapper;

    /** 行级数据权限：非管理员只能查询自己负责/创建或被共享的合同 */
    private void applyRowScope(ContractQueryDTO query) {
        boolean isAdmin = SecurityContextUtil.hasRole("super_admin") || SecurityContextUtil.hasRole("ADMIN");
        if (!isAdmin) {
            query.setCurrentUserId(SecurityContextUtil.getCurrentUserId());
        }
    }

    /**
     * 分页查询合同列表
     * 关键逻辑：默认查询当前财年数据，查询后填充已开票/未开票金额等虚拟字段
     * @param query 查询条件（含分页参数、筛选条件）
     * @return 分页结果（含合同列表和总记录数）
     */
    @Override
    public PageResult<ContractVO> page(ContractQueryDTO query) {
        if (query == null) query = new ContractQueryDTO();
        int pageNum = query.getPageNum() != null ? query.getPageNum() : 1;
        int pageSize = query.getPageSize() != null ? query.getPageSize() : 10;

        // 1. 获取当前登录用户所属公司
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;

        // 2. 行级数据权限：非管理员只能查询自己负责/创建或被共享的合同
        applyRowScope(query);

        // 3. 获取当前财年，默认查询本财年数据
        Integer currentFiscalYear = getCurrentFiscalYear();
        String fiscalYearStart = currentFiscalYear + "-01-01";

        // 4. 执行分页查询
        Page<ContractVO> page = new Page<>(pageNum, pageSize);
        IPage<ContractVO> result = contractMapper.selectPageList(page, companyId, query, fiscalYearStart, currentFiscalYear);

        // 5. 填充虚拟字段（已开票金额、未开票金额、库存标识等）与记录级权限位
        List<ContractVO> records = result.getRecords();
        fillVirtualFields(records, currentFiscalYear);
        enrichRelations(records);
        if (records != null && !records.isEmpty()) {
            Map<Long, Integer> bits = dataPermissionService.permBitsMap(
                    DataPermModule.CONTRACT,
                    records.stream().map(ContractVO::getId).collect(Collectors.toList()));
            records.forEach(vo -> vo.setPermBits(bits.getOrDefault(vo.getId(), 0)));
        }

        return new PageResult<>(records, result.getTotal(), pageNum, pageSize);
    }

    /**
     * 查询合同列表（不分页，用于导出等场景）
     * @param query 查询条件
     * @return 合同列表
     */
    @Override
    public List<ContractVO> list(ContractQueryDTO query) {
        if (query == null) query = new ContractQueryDTO();

        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;

        // 行级数据权限：非管理员导出/列表同样受限
        applyRowScope(query);

        Integer currentFiscalYear = getCurrentFiscalYear();
        String fiscalYearStart = currentFiscalYear + "-01-01";

        List<ContractVO> list = contractMapper.selectListByQuery(companyId, query, fiscalYearStart, currentFiscalYear);
        fillVirtualFields(list, currentFiscalYear);
        enrichRelations(list);
        return list;
    }

    /**
     * 根据ID查询合同详情（含里程碑信息）
     * @param id 合同ID
     * @return 合同详情VO
     */
    @Override
    public ContractVO getById(Long id) {
        ContractVO vo = contractMapper.selectDetailById(id);
        if (vo == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "合同不存在");
        }
        Integer currentFiscalYear = getCurrentFiscalYear();
        fillVirtualFields(Collections.singletonList(vo), currentFiscalYear);
        enrichRelations(Collections.singletonList(vo));
        vo.setPermBits(dataPermissionService.effectiveBits(DataPermModule.CONTRACT, id));
        return vo;
    }

    /** 填充合同的父合同信息、关联商机号、关联项目名 */
    private void enrichRelations(List<ContractVO> records) {
        if (records == null || records.isEmpty()) return;
        List<Long> ids = records.stream().map(ContractVO::getId).collect(Collectors.toList());
        // 父合同
        Map<Long, ContractVO> idMap = records.stream().collect(Collectors.toMap(ContractVO::getId, v -> v, (a, b) -> a));
        for (ContractVO vo : records) {
            if (vo.getParentId() != null && vo.getParentId() > 0 && idMap.containsKey(vo.getParentId())) {
                ContractVO p = idMap.get(vo.getParentId());
                vo.setParentContractNo(p.getContractNo());
                vo.setParentContractName(p.getContractName());
            } else if (vo.getParentId() != null && vo.getParentId() > 0) {
                Contract p = contractMapper.selectById(vo.getParentId());
                if (p != null) {
                    vo.setParentContractNo(p.getContractNo());
                    vo.setParentContractName(p.getContractName());
                }
            }
        }
        // 关联商机号
        List<ContractOpportunity> cos = contractOpportunityMapper.selectList(
                new QueryWrapper<ContractOpportunity>().in("contract_id", ids));
        Map<Long, List<Long>> oppMap = cos.stream().collect(Collectors.groupingBy(
                ContractOpportunity::getContractId,
                Collectors.mapping(ContractOpportunity::getOpportunityId, Collectors.toList())));
        if (!oppMap.isEmpty()) {
            List<Long> oppIds = cos.stream().map(ContractOpportunity::getOpportunityId).distinct().collect(Collectors.toList());
            Map<Long, String> oppNoMap = new HashMap<>();
            opportunityMapper.selectList(new QueryWrapper<Opportunity>().in("id", oppIds))
                    .forEach(o -> oppNoMap.put(o.getId(), o.getOpportunityNo()));
            records.forEach(vo -> {
                List<Long> oids = oppMap.get(vo.getId());
                if (oids != null) {
                    vo.setOpportunityIds(oids);
                    vo.setOpportunityNos(oids.stream().map(oppNoMap::get).filter(java.util.Objects::nonNull)
                            .collect(Collectors.joining(",")));
                }
            });
        }
        // 关联项目名
        List<ContractProject> cps = contractProjectMapper.selectList(
                new QueryWrapper<ContractProject>().in("contract_id", ids));
        Map<Long, List<Long>> projIdMap = cps.stream().collect(Collectors.groupingBy(
                ContractProject::getContractId,
                Collectors.mapping(ContractProject::getProjectId, Collectors.toList())));
        Map<Long, String> projMap = cps.stream().collect(Collectors.groupingBy(
                ContractProject::getContractId,
                Collectors.mapping(cp -> cp.getProjectName() != null ? cp.getProjectName() : "", Collectors.joining(","))));
        records.forEach(vo -> {
            vo.setProjectNames(projMap.get(vo.getId()));
            vo.setProjectIds(projIdMap.get(vo.getId()));
        });
    }

    /**
     * 新增合同
     * 关键逻辑：
     * 1. 填充关联信息（客户、合同类型、产品线的ID和编码）
     * 2. 校验未签订合同必须填写预计签约时间
     * 3. 计算库存/增量标识（往年合同为库存，本年为增量）
     * @param dto 合同创建DTO
     * @return 创建后的合同详情
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ContractVO save(ContractCreateDTO dto) {
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;

        Contract entity = new Contract();
        BeanUtils.copyProperties(dto, entity);
        entity.setCompanyId(companyId);

        // 1. 根据名称填充关联实体ID和编码
        fillContractRelations(entity);
        // 2. 校验未签约合同必填预计签约时间
        validateExpectedSignDate(entity);

        // 3. 默认状态为未签订
        if (entity.getContractStatus() == null || entity.getContractStatus().isEmpty()) {
            entity.setContractStatus("UNSIGNED");
        }

        // 4. 计算库存/增量标识
        if (entity.getContractCreateTime() != null) {
            entity.setStockFlag(calculateStockFlag(entity.getContractCreateTime(), getCurrentFiscalYear()));
        }

        // 5. 生成子合同号并查重
        entity.setSubContractNo(generateSubContractNo(companyId, entity.getContractNo()));
        Contract dup = contractMapper.findByContractNoAndType(companyId, entity.getContractNo(),
                entity.getOrgId(), entity.getContractTypeId());
        if (dup != null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(),
                    String.format("合同号[%s]在该产品线+合同类型下已存在", entity.getContractNo()));
        }

        contractMapper.insert(entity);
        // 保存合同-商机、合同-项目关联
        saveContractRelations(entity.getId(), dto.getOpportunityIds(), dto.getProjectIds());
        log.info("新增合同成功: id={}, contractNo={}, subContractNo={}", entity.getId(), entity.getContractNo(), entity.getSubContractNo());
        return getById(entity.getId());
    }

    /** 保存合同与商机/项目的关联关系（先删后插） */
    private void saveContractRelations(Long contractId, List<Long> opportunityIds, List<Long> projectIds) {
        Long currentUserId = SecurityContextUtil.getCurrentUserId();
        // 商机关联
        contractOpportunityMapper.delete(new QueryWrapper<ContractOpportunity>().eq("contract_id", contractId));
        if (opportunityIds != null) {
            for (Long oppId : opportunityIds) {
                if (oppId == null) continue;
                ContractOpportunity co = new ContractOpportunity();
                co.setContractId(contractId);
                co.setOpportunityId(oppId);
                co.setCreatedBy(currentUserId);
                contractOpportunityMapper.insert(co);
            }
        }
        // 项目关联
        contractProjectMapper.delete(new QueryWrapper<ContractProject>().eq("contract_id", contractId));
        if (projectIds != null) {
            for (Long pid : projectIds) {
                if (pid == null) continue;
                ContractProject cp = new ContractProject();
                cp.setContractId(contractId);
                cp.setProjectId(pid);
                cp.setCreatedBy(currentUserId);
                contractProjectMapper.insert(cp);
            }
        }
    }

    /**
     * 更新合同信息
     * 关键逻辑：
     * 1. 合同金额变更时，按收款比例自动重算所有里程碑的金额及预计回款金额
     * 2. 公式：里程碑金额 = 预计回款金额 = 新合同金额 × 收款比例
     * @param dto 合同更新DTO
     * @return 更新后的合同详情
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ContractVO update(ContractUpdateDTO dto) {
        Contract oldContract = contractMapper.selectById(dto.getId());
        if (oldContract == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "合同不存在");
        }
        // 记录级写权限：仅负责人/管理员或被授予编辑位的共享者可修改
        dataPermissionService.assertWrite(DataPermModule.CONTRACT, dto.getId(), DataPermBits.UPDATE);

        Contract entity = new Contract();
        BeanUtils.copyProperties(dto, entity);
        entity.setVersion(oldContract.getVersion());

        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        entity.setCompanyId(companyId);

        // 1. 填充关联信息并校验
        fillContractRelations(entity);
        validateExpectedSignDate(entity);

        // 1.1 查重：修改产品线/合同类型时检查是否与已有子合同冲突
        Long newOrgId = entity.getOrgId() != null ? entity.getOrgId() : oldContract.getOrgId();
        Long newCtId = entity.getContractTypeId() != null ? entity.getContractTypeId() : oldContract.getContractTypeId();
        Contract dup = contractMapper.findByContractNoAndType(companyId, oldContract.getContractNo(), newOrgId, newCtId);
        if (dup != null && !dup.getId().equals(oldContract.getId())) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(),
                    String.format("合同号[%s]在该产品线+合同类型下已存在", oldContract.getContractNo()));
        }

        // 2. 重新计算库存/增量标识
        if (entity.getContractCreateTime() != null) {
            entity.setStockFlag(calculateStockFlag(entity.getContractCreateTime(), getCurrentFiscalYear()));
        }

        // 3. 合同金额变更时，按比例重算所有里程碑金额及预计回款金额
        if (dto.getContractAmount() != null
                && oldContract.getContractAmount() != null
                && dto.getContractAmount().compareTo(oldContract.getContractAmount()) != 0) {
            List<ContractMilestoneVO> milestones = milestoneMapper.selectByContractId(dto.getId());
            BigDecimal newAmount = dto.getContractAmount();
            for (ContractMilestoneVO ms : milestones) {
                if (ms.getPaymentRatio() != null && ms.getPaymentRatio().compareTo(BigDecimal.ZERO) > 0) {
                    ContractMilestone updateMs = new ContractMilestone();
                    updateMs.setId(ms.getId());
                    updateMs.setVersion(ms.getVersion());
                    BigDecimal newMilestoneAmount = newAmount.multiply(ms.getPaymentRatio()).setScale(2, RoundingMode.HALF_UP);
                    updateMs.setMilestoneAmount(newMilestoneAmount);
                    // 预计回款金额与里程碑金额保持同一口径（合同额×收款比例），随合同金额联动变化
                    updateMs.setExpectedPaymentAmount(newMilestoneAmount);
                    milestoneMapper.updateById(updateMs);
                }
            }
        }

        contractMapper.updateById(entity);
        // 更新合同-商机、合同-项目关联
        saveContractRelations(dto.getId(), dto.getOpportunityIds(), dto.getProjectIds());
        log.info("更新合同成功: id={}", entity.getId());
        return getById(entity.getId());
    }

    /**
     * 删除合同（级联软删除里程碑）
     * 关键逻辑：先软删除该合同下所有里程碑，再删除合同主记录
     * @param id 合同ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Long id) {
        // 1. 级联软删除合同下所有里程碑
        milestoneMapper.softDeleteByContractId(id);
        // 2. 删除合同主记录
        contractMapper.deleteById(id);
        log.info("删除合同成功: id={}", id);
    }

    /**
     * 批量删除合同（级联软删除里程碑）
     * @param ids 合同ID列表
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteBatch(List<Long> ids) {
        // 1. 逐个级联软删除里程碑并清理关联
        for (Long id : ids) {
            milestoneMapper.softDeleteByContractId(id);
            contractOpportunityMapper.delete(new QueryWrapper<ContractOpportunity>().eq("contract_id", id));
            contractProjectMapper.delete(new QueryWrapper<ContractProject>().eq("contract_id", id));
        }
        // 2. 批量删除合同主记录
        contractMapper.deleteBatchIds(ids);
        log.info("批量删除合同成功: ids={}", ids);
    }

    /**
     * 变更合同状态
     * 关键逻辑：状态变为"已完成"时自动设置完成时间为当天，其他状态清空完成时间
     * @param id 合同ID
     * @param status 目标状态（UNSIGNED/SIGNED/COMPLETED/CANCELED）
     * @return 更新后的合同详情
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ContractVO changeStatus(Long id, String status) {
        if (status == null || status.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请指定目标状态");
        }
        if (!"UNSIGNED".equals(status) && !"SIGNED".equals(status)
                && !"COMPLETED".equals(status) && !"CANCELED".equals(status)) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "状态值无效");
        }
        Contract contract = contractMapper.selectById(id);
        if (contract == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "合同不存在");
        }
        dataPermissionService.assertWrite(DataPermModule.CONTRACT, id, DataPermBits.UPDATE);
        contract.setContractStatus(status);
        // 状态为已完成时自动设置完成时间
        if ("COMPLETED".equals(status)) {
            contract.setContractCompleteTime(LocalDate.now());
        } else {
            contract.setContractCompleteTime(null);
        }
        contractMapper.updateById(contract);
        log.info("更新合同状态成功: id={}, status={}", id, status);
        return getById(id);
    }

    /**
     * 复制合同
     * 关键逻辑：
     * 1. 完整复制合同主表全部字段及该合同下所有里程碑（含计划/预测/实际开票与收款数据），不仅是基础信息
     * 2. 新合同编号 = 原合同编号 + "copy"，若已存在则依次使用 copy2、copy3...
     * 3. 子合同号按规则重新生成，清空导入来源标记
     * @param id 源合同ID
     * @return 新合同详情
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ContractVO copyContract(Long id) {
        // 1. 查询源合同
        Contract source = contractMapper.selectById(id);
        if (source == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "合同不存在");
        }

        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;

        // 2. 生成新合同编号（原编号+copy，冲突时递增 copy2/copy3...）
        String baseNo = source.getContractNo();
        String newContractNo = baseNo + "copy";
        int seq = 2;
        while (contractMapper.findByContractNoAndType(companyId, newContractNo, source.getOrgId(), source.getContractTypeId()) != null) {
            newContractNo = baseNo + "copy" + seq;
            seq++;
        }

        // 3. 复制合同主表全部字段
        Contract copy = new Contract();
        BeanUtils.copyProperties(source, copy);
        copy.setId(null);
        copy.setVersion(null);
        copy.setCompanyId(companyId);
        copy.setContractNo(newContractNo);
        copy.setSubContractNo(generateSubContractNo(companyId, newContractNo));
        // 复制件为手工创建，清空导入来源标记
        copy.setSourceType(null);
        copy.setSourceFileName(null);
        copy.setCreatedBy(null);
        copy.setUpdatedBy(null);
        copy.setCreateTime(null);
        copy.setUpdateTime(null);
        copy.setDeleted(0);
        contractMapper.insert(copy);

        // 4. 复制该合同下全部里程碑（含计划、预测、实际开票/收款等全部字段）
        List<ContractMilestoneVO> milestones = milestoneMapper.selectByContractId(id);
        for (ContractMilestoneVO ms : milestones) {
            ContractMilestone msCopy = new ContractMilestone();
            BeanUtils.copyProperties(ms, msCopy);
            msCopy.setId(null);
            msCopy.setVersion(null);
            msCopy.setContractId(copy.getId());
            msCopy.setCompanyId(companyId);
            msCopy.setCreatedBy(null);
            msCopy.setUpdatedBy(null);
            msCopy.setCreateTime(null);
            msCopy.setUpdateTime(null);
            msCopy.setDeleted(0);
            milestoneMapper.insert(msCopy);
        }

        log.info("复制合同成功: sourceId={}, newId={}, newContractNo={}, 里程碑{}条", id, copy.getId(), newContractNo, milestones.size());
        return getById(copy.getId());
    }

    /**
     * 查询合同下的所有里程碑
     * @param contractId 合同ID
     * @return 里程碑列表
     */
    @Override
    public List<ContractMilestoneVO> getMilestones(Long contractId) {
        return milestoneMapper.selectByContractId(contractId);
    }

    /**
     * 新增合同里程碑
     * 关键逻辑：
     * 1. 归一化收款比例（百分比转小数，如30%→0.3）
     * 2. 根据合同金额和比例自动计算里程碑金额
     * 3. 同步日期字段（LocalDate与年/月数字字段互转）
     * @param dto 里程碑创建DTO
     * @return 创建后的里程碑VO
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ContractMilestoneVO saveMilestone(ContractMilestoneDTO dto) {
        // 里程碑是合同子资源，需具备该合同的编辑权限
        if (dto.getContractId() != null) {
            dataPermissionService.assertWrite(DataPermModule.CONTRACT, dto.getContractId(), DataPermBits.UPDATE);
        }
        ContractMilestone entity = new ContractMilestone();
        BeanUtils.copyProperties(dto, entity);

        // 1. 收款比例归一化（百分比转小数）
        normalizePaymentRatio(entity);
        // 2. 填充日期字段并自动计算里程碑金额
        fillMilestoneDateFields(entity);

        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        entity.setCompanyId(companyId);

        milestoneMapper.insert(entity);
        log.info("新增里程碑成功: id={}, contractId={}", entity.getId(), entity.getContractId());

        ContractMilestoneVO vo = new ContractMilestoneVO();
        BeanUtils.copyProperties(entity, vo);
        return vo;
    }

    /**
     * 更新合同里程碑
     * @param dto 里程碑更新DTO
     * @return 更新后的里程碑VO
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ContractMilestoneVO updateMilestone(ContractMilestoneDTO dto) {
        if (dto.getId() == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "里程碑ID不能为空");
        }
        ContractMilestone oldMs = milestoneMapper.selectById(dto.getId());
        if (oldMs == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "里程碑不存在");
        }
        dataPermissionService.assertWrite(DataPermModule.CONTRACT, oldMs.getContractId(), DataPermBits.UPDATE);

        ContractMilestone entity = new ContractMilestone();
        BeanUtils.copyProperties(dto, entity);
        entity.setVersion(oldMs.getVersion());

        normalizePaymentRatio(entity);
        fillMilestoneDateFields(entity);

        int rows = milestoneMapper.updateById(entity);
        if (rows == 0) {
            throw new BusinessException(ResultCode.DATA_VERSION_OUTDATED.getCode(), "更新里程碑失败，数据可能已被其他用户修改，请刷新后重试");
        }
        log.info("更新里程碑成功: id={}", entity.getId());

        ContractMilestoneVO vo = new ContractMilestoneVO();
        BeanUtils.copyProperties(milestoneMapper.selectById(dto.getId()), vo);
        return vo;
    }

    /**
     * 删除里程碑
     * @param id 里程碑ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteMilestone(Long id) {
        milestoneMapper.deleteById(id);
        log.info("删除里程碑成功: id={}", id);
    }

    /**
     * 导出合同数据为Excel
     * 关键逻辑：同一合同有多里程碑时，拆分为多行导出（合同信息重复，里程碑信息不同）
     * @param query 查询条件
     * @param response HTTP响应
     */
    @Override
    public void exportContracts(ContractQueryDTO query, HttpServletResponse response) throws Exception {
        List<ContractVO> list = list(query);

        // 1. 批量查询所有合同的里程碑，按合同ID分组
        Map<Long, List<ContractMilestoneVO>> milestoneMap = new HashMap<>();
        if (!list.isEmpty()) {
            List<Long> contractIds = list.stream().map(ContractVO::getId).collect(Collectors.toList());
            List<ContractMilestoneVO> allMilestones = milestoneMapper.selectByContractIds(contractIds);
            milestoneMap = allMilestones.stream().collect(Collectors.groupingBy(ContractMilestoneVO::getContractId));
        }

        ExcelWriter writer = ExcelUtil.getWriter();
        String[] headers = {"合同号*", "合同名称*", "项目号", "项目名称*", "客户名称*", "负责人*", "销售经理",
                "合同金额(万元)*", "已开票金额(万元)", "未开票金额(万元)",
                "合同签订日期(yyyy-MM-dd)", "预计签约时间(yyyy-MM-dd)", "合同创建时间(yyyy-MM-dd)*", "合同完成时间(yyyy-MM-dd)",
                "产品线*", "合同类型*", "合同状态*", "里程碑节点*", "收款比例(%)*",
                "计划开票时间(年+月，如2026-02)*", "预测开票时间(年+月，如2026-03)*",
                "实际开票时间(年+月，如2026-03)*", "里程碑开票状态*",
                "预计回款时间(yyyy-MM-dd)", "实际回款时间(yyyy-MM-dd)",
                "预计回款金额(万元)", "实际回款金额(万元)", "备注"};
        for (int i = 0; i < headers.length; i++) {
            writer.writeCellValue(i, 0, headers[i]);
        }

        int rowNum = 1;
        DateTimeFormatter ymFmt = DateTimeFormatter.ofPattern("yyyy-MM");
        for (ContractVO c : list) {
            List<ContractMilestoneVO> msList = milestoneMap.getOrDefault(c.getId(), Collections.emptyList());
            if (msList.isEmpty()) {
                writeContractRow(writer, rowNum++, c, null, ymFmt);
            } else {
                for (ContractMilestoneVO ms : msList) {
                    writeContractRow(writer, rowNum++, c, ms, ymFmt);
                }
            }
        }

        for (int i = 0; i < headers.length; i++) {
            writer.setColumnWidth(i, i == 1 || i == 3 ? 25 : 14);
        }

        String fileName = URLEncoder.encode("合同数据_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".xlsx", "UTF-8");
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    /**
     * 下载合同导入Excel模板（含示例数据）
     * @param response HTTP响应
     */
    @Override
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        ExcelWriter writer = ExcelUtil.getWriter();
        writer.addHeaderAlias("合同号*", "contractNo");
        writer.addHeaderAlias("合同名称*", "contractName");
        writer.addHeaderAlias("项目号", "projectCode");
        writer.addHeaderAlias("项目名称*", "projectName");
        writer.addHeaderAlias("客户名称*", "customerName");
        writer.addHeaderAlias("负责人*", "manager");
        writer.addHeaderAlias("销售经理", "salesManager");
        writer.addHeaderAlias("合同金额(万元)*", "contractAmount");
        writer.addHeaderAlias("合同签订日期(yyyy-MM-dd)", "signDate");
        writer.addHeaderAlias("预计签约时间(yyyy-MM-dd)", "expectedSignDate");
        writer.addHeaderAlias("合同创建时间(yyyy-MM-dd)*", "contractCreateTime");
        writer.addHeaderAlias("合同完成时间(yyyy-MM-dd)", "contractCompleteTime");
        writer.addHeaderAlias("产品线*", "productLine");
        writer.addHeaderAlias("合同类型*", "contractTypeName");
        writer.addHeaderAlias("合同状态*", "contractStatus");
        writer.addHeaderAlias("里程碑节点*", "milestoneCode");
        writer.addHeaderAlias("收款比例(%)*", "paymentRatio");
        writer.addHeaderAlias("计划开票时间(年+月，如2026-02)*", "planInvoiceDate");
        writer.addHeaderAlias("预测开票时间(年+月，如2026-03)*", "forecastInvoiceDate");
        writer.addHeaderAlias("实际开票时间(年+月，如2026-03)*", "actualInvoiceDate");
        writer.addHeaderAlias("里程碑开票状态*", "invoiceStatus");
        writer.addHeaderAlias("预计回款时间(yyyy-MM-dd)", "expectedPaymentDate");
        writer.addHeaderAlias("预计回款时间", "expectedPaymentDate");
        writer.addHeaderAlias("实际回款时间(yyyy-MM-dd)", "actualPaymentDate");
        writer.addHeaderAlias("实际回款时间", "actualPaymentDate");
        writer.addHeaderAlias("预计回款金额(万元)", "expectedPaymentAmount");
        writer.addHeaderAlias("预计回款金额", "expectedPaymentAmount");
        writer.addHeaderAlias("实际回款金额(万元)", "actualPaymentAmount");
        writer.addHeaderAlias("实际回款金额", "actualPaymentAmount");
        writer.addHeaderAlias("备注", "remark");

        List<Map<String, Object>> demo = new ArrayList<>();
        Map<String, Object> row1 = new LinkedHashMap<>();
        row1.put("合同号*", "HT2026-0001");
        row1.put("合同名称*", "示例合同-XX项目系统开发");
        row1.put("项目号", "PRJ2026-001");
        row1.put("项目名称*", "示例项目系统开发");
        row1.put("客户名称*", "示例客户");
        row1.put("负责人*", "张三");
        row1.put("销售经理", "李四");
        row1.put("合同金额(万元)*", 400.00);
        row1.put("合同签订日期(yyyy-MM-dd)", "2026-02-09");
        row1.put("预计签约时间(yyyy-MM-dd)", "");
        row1.put("合同创建时间(yyyy-MM-dd)*", "2026-02-01");
        row1.put("合同完成时间(yyyy-MM-dd)", "");
        row1.put("产品线*", "订单");
        row1.put("合同类型*", "IT产品");
        row1.put("合同状态*", "已签订");
        row1.put("里程碑节点*", "M0");
        row1.put("收款比例(%)*", 30.0);
        row1.put("计划开票时间(年+月，如2026-02)*", "2026-02");
        row1.put("预测开票时间(年+月，如2026-03)*", "2026-03");
        row1.put("实际开票时间(年+月，如2026-03)*", "2026-03");
        row1.put("里程碑开票状态*", "已开票");
        row1.put("预计回款时间(yyyy-MM-dd)", "");
        row1.put("实际回款时间(yyyy-MM-dd)", "2026-04-15");
        row1.put("预计回款金额(万元)", 120.00);
        row1.put("实际回款金额(万元)", 120.00);
        row1.put("备注", "示例数据-删除后填写实际合同");

        Map<String, Object> row2 = new LinkedHashMap<>();
        row2.put("合同号*", "HT2026-0001");
        row2.put("合同名称*", "示例合同-XX项目系统开发");
        row2.put("项目号", "PRJ2026-001");
        row2.put("项目名称*", "示例项目系统开发");
        row2.put("客户名称*", "示例客户");
        row2.put("负责人*", "张三");
        row2.put("销售经理", "李四");
        row2.put("合同金额(万元)*", 400.00);
        row2.put("合同签订日期(yyyy-MM-dd)", "2026-02-09");
        row2.put("预计签约时间(yyyy-MM-dd)", "");
        row2.put("合同创建时间(yyyy-MM-dd)*", "2026-02-01");
        row2.put("合同完成时间(yyyy-MM-dd)", "");
        row2.put("产品线*", "订单");
        row2.put("合同类型*", "IT产品");
        row2.put("合同状态*", "已签订");
        row2.put("里程碑节点*", "M1");
        row2.put("收款比例(%)*", 15.0);
        row2.put("计划开票时间(年+月，如2026-02)*", "2026-04");
        row2.put("预测开票时间(年+月，如2026-03)*", "2026-05");
        row2.put("实际开票时间(年+月，如2026-03)*", "");
        row2.put("里程碑开票状态*", "未开票");
        row2.put("预计回款时间(yyyy-MM-dd)", "");
        row2.put("实际回款时间(yyyy-MM-dd)", "");
        row2.put("预计回款金额(万元)", 60.00);
        row2.put("实际回款金额(万元)", "");
        row2.put("备注", "同一合同号多行表示多个里程碑");

        Map<String, Object> row3 = new LinkedHashMap<>();
        row3.put("合同号*", "HT2026-0001");
        row3.put("合同名称*", "示例合同-XX项目系统开发");
        row3.put("项目号", "PRJ2026-001");
        row3.put("项目名称*", "示例项目系统开发");
        row3.put("客户名称*", "示例客户");
        row3.put("负责人*", "张三");
        row3.put("销售经理", "李四");
        row3.put("合同金额(万元)*", 400.00);
        row3.put("合同签订日期(yyyy-MM-dd)", "");
        row3.put("预计签约时间(yyyy-MM-dd)", "2026-08-15");
        row3.put("合同创建时间(yyyy-MM-dd)*", "2026-02-01");
        row3.put("合同完成时间(yyyy-MM-dd)", "");
        row3.put("产品线*", "订单");
        row3.put("合同类型*", "IT产品");
        row3.put("合同状态*", "未签订");
        row3.put("里程碑节点*", "M2");
        row3.put("收款比例(%)*", 20.0);
        row3.put("计划开票时间(年+月，如2026-02)*", "2026-06");
        row3.put("预测开票时间(年+月，如2026-03)*", "");
        row3.put("实际开票时间(年+月，如2026-03)*", "");
        row3.put("里程碑开票状态*", "未开票");
        row3.put("预计回款时间(yyyy-MM-dd)", "");
        row3.put("实际回款时间(yyyy-MM-dd)", "");
        row3.put("预计回款金额(万元)", 80.00);
        row3.put("实际回款金额(万元)", "");
        row3.put("备注", "未签订合同必填预计签约时间");

        demo.add(row1);
        demo.add(row2);
        demo.add(row3);
        writer.write(demo, true);

        Workbook wb = writer.getWorkbook();
        Sheet sheet = wb.getSheetAt(0);
        DataFormat fmt = wb.createDataFormat();

        CellStyle textStyle = wb.createCellStyle();
        textStyle.setDataFormat(fmt.getFormat("@"));
        textStyle.setBorderTop(BorderStyle.THIN);
        textStyle.setBorderBottom(BorderStyle.THIN);
        textStyle.setBorderLeft(BorderStyle.THIN);
        textStyle.setBorderRight(BorderStyle.THIN);

        CellStyle numStyle = wb.createCellStyle();
        numStyle.setDataFormat(fmt.getFormat("#,##0.00"));
        numStyle.setBorderTop(BorderStyle.THIN);
        numStyle.setBorderBottom(BorderStyle.THIN);
        numStyle.setBorderLeft(BorderStyle.THIN);
        numStyle.setBorderRight(BorderStyle.THIN);

        CellStyle pctStyle = wb.createCellStyle();
        pctStyle.setDataFormat(fmt.getFormat("0.0"));
        pctStyle.setBorderTop(BorderStyle.THIN);
        pctStyle.setBorderBottom(BorderStyle.THIN);
        pctStyle.setBorderLeft(BorderStyle.THIN);
        pctStyle.setBorderRight(BorderStyle.THIN);

        int[] dateCols = {8, 9, 10, 11, 17, 18, 19, 21, 22};
        for (int col : dateCols) {
            sheet.setDefaultColumnStyle(col, textStyle);
        }
        for (int col : dateCols) {
            for (int r = 1; r <= demo.size() + 1; r++) {
                Row row = sheet.getRow(r);
                if (row != null) {
                    Cell cell = row.getCell(col);
                    if (cell != null) {
                        cell.setCellStyle(textStyle);
                    }
                }
            }
        }

        sheet.setColumnWidth(0, 16 * 256);
        sheet.setColumnWidth(1, 28 * 256);
        sheet.setColumnWidth(2, 14 * 256);
        sheet.setColumnWidth(3, 24 * 256);
        sheet.setColumnWidth(4, 18 * 256);
        sheet.setColumnWidth(5, 10 * 256);
        sheet.setColumnWidth(6, 12 * 256);
        sheet.setColumnWidth(7, 14 * 256);
        for (int col : dateCols) {
            sheet.setColumnWidth(col, 20 * 256);
        }
        sheet.setColumnWidth(12, 10 * 256);
        sheet.setColumnWidth(13, 12 * 256);
        sheet.setColumnWidth(14, 10 * 256);
        sheet.setColumnWidth(15, 12 * 256);
        sheet.setColumnWidth(16, 12 * 256);
        sheet.setColumnWidth(20, 14 * 256);
        sheet.setColumnWidth(21, 20 * 256);
        sheet.setColumnWidth(22, 20 * 256);
        sheet.setColumnWidth(23, 16 * 256);
        sheet.setColumnWidth(24, 16 * 256);

        Sheet noteSheet = wb.createSheet("填写说明");
        String[] notes = {
                "合同导入模板填写说明：",
                "",
                "1. 带*号的列为必填项",
                "2. 日期格式请使用 yyyy-MM-dd（如：2026-02-09），开票时间使用 yyyy-MM（如：2026-02）",
                "3. 从其他Excel拷贝数据时，请使用「选择性粘贴 → 仅粘贴值」，避免覆盖单元格格式",
                "4. 同一合同号可以有多行，每行代表一个里程碑节点",
                "5. 合同金额单位为万元，收款比例填数字（如30表示30%）",
                "6. 合同状态可选值：未签订/已签订/已完成/已取消",
                "7. 里程碑开票状态可选值：已开票/未开票",
                "8. 未签订合同必须填写预计签约时间",
                "9. 已签订/已完成合同的里程碑必须填写预测开票时间",
                "10. 预计回款时间、实际回款时间格式为yyyy-MM-dd，可选填",
                "11. 预计回款金额、实际回款金额单位为万元，可选填；实际回款金额允许为负数（退款/红冲）",
                "",
                "提示：如果日期列显示为数字或格式异常，请将该列单元格格式设置为「文本」后重新输入。"
        };
        for (int i = 0; i < notes.length; i++) {
            Row nr = noteSheet.createRow(i);
            Cell nc = nr.createCell(0);
            nc.setCellValue(notes[i]);
        }
        noteSheet.setColumnWidth(0, 80 * 256);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode("合同导入模板.xlsx", "UTF-8"));
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    /**
     * 从Excel批量导入合同及里程碑数据
     * 关键逻辑：
     * 1. 同一合同号多行数据合并为一个合同，每行对应一个里程碑
     * 2. 先校验所有行数据，校验通过后批量入库
     * 3. 支持中英文状态自动转换（如"已签订"→SIGNED）
     * @param companyId 公司ID
     * @param file Excel文件
     * @return 导入结果（成功/失败数量、错误信息）
     */
    @Override
    public Map<String, Object> importExcel(Long companyId, MultipartFile file) {
        // 1. 文件格式和大小校验
        if (file == null || file.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请选择要上传的文件");
        }
        String filename = file.getOriginalFilename();
        if (filename == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "文件名不能为空");
        }
        String safeFilename = sanitizeFilename(filename);
        String lowerName = safeFilename.toLowerCase();
        boolean validExt = false;
        for (String ext : ALLOWED_EXTENSIONS) {
            if (lowerName.endsWith(ext)) {
                validExt = true;
                break;
            }
        }
        if (!validExt) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "仅支持 .xlsx 或 .xls 格式");
        }
        String contentType = file.getContentType();
        if (contentType != null && !ALLOWED_MIME_TYPES.contains(contentType.toLowerCase())) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "文件类型不合法，请上传有效的Excel文件");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "文件大小不能超过 10MB");
        }

        int contractInserted = 0;
        int milestoneInserted = 0;
        int failed = 0;
        List<String> errorMsgs = new ArrayList<>();
        List<Map<String, Object>> allRows;

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            IoUtil.copy(file.getInputStream(), baos);
            try (ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray())) {
                ExcelReader reader = ExcelUtil.getReader(bais);
                reader.addHeaderAlias("合同号*", "contractNo");
                reader.addHeaderAlias("合同号", "contractNo");
                reader.addHeaderAlias("合同编号*", "contractNo");
                reader.addHeaderAlias("合同名称*", "contractName");
                reader.addHeaderAlias("合同名称", "contractName");
                reader.addHeaderAlias("项目号", "projectCode");
                reader.addHeaderAlias("项目名称*", "projectName");
                reader.addHeaderAlias("项目名称", "projectName");
                reader.addHeaderAlias("客户名称*", "customerName");
                reader.addHeaderAlias("客户名称", "customerName");
                reader.addHeaderAlias("负责人*", "manager");
                reader.addHeaderAlias("负责人", "manager");
                reader.addHeaderAlias("销售经理", "salesManager");
                reader.addHeaderAlias("合同金额(万元)*", "contractAmount");
                reader.addHeaderAlias("合同金额", "contractAmount");
                reader.addHeaderAlias("合同签订日期(yyyy-MM-dd)", "signDate");
                reader.addHeaderAlias("合同签订时间(yyyy-MM-dd)", "signDate");
                reader.addHeaderAlias("签约日期(yyyy-MM-dd)", "signDate");
                reader.addHeaderAlias("签约日期", "signDate");
                reader.addHeaderAlias("预计签约时间(yyyy-MM-dd)", "expectedSignDate");
                reader.addHeaderAlias("预计签约时间", "expectedSignDate");
                reader.addHeaderAlias("预计签约日期(yyyy-MM-dd)", "expectedSignDate");
                reader.addHeaderAlias("预计签约日期", "expectedSignDate");
                reader.addHeaderAlias("合同创建时间(yyyy-MM-dd)*", "contractCreateTime");
                reader.addHeaderAlias("合同创建时间", "contractCreateTime");
                reader.addHeaderAlias("合同完成时间(yyyy-MM-dd)", "contractCompleteTime");
                reader.addHeaderAlias("合同完成时间", "contractCompleteTime");
                reader.addHeaderAlias("产品线*", "productLine");
                reader.addHeaderAlias("产品线", "productLine");
                reader.addHeaderAlias("合同类型*", "contractTypeName");
                reader.addHeaderAlias("合同类型", "contractTypeName");
                reader.addHeaderAlias("合同状态*", "contractStatus");
                reader.addHeaderAlias("合同状态", "contractStatus");
                reader.addHeaderAlias("状态", "contractStatus");
                reader.addHeaderAlias("里程碑节点*", "milestoneCode");
                reader.addHeaderAlias("里程碑节点", "milestoneCode");
                reader.addHeaderAlias("收款比例(%)*", "paymentRatio");
                reader.addHeaderAlias("收款比例(%)", "paymentRatio");
                reader.addHeaderAlias("计划开票时间(年+月，如2026-02)*", "planInvoiceDate");
                reader.addHeaderAlias("计划开票时间", "planInvoiceDate");
                reader.addHeaderAlias("预测开票时间(年+月，如2026-03)*", "forecastInvoiceDate");
                reader.addHeaderAlias("预测开票时间", "forecastInvoiceDate");
                reader.addHeaderAlias("实际开票时间(年+月，如2026-03)*", "actualInvoiceDate");
                reader.addHeaderAlias("实际开票时间", "actualInvoiceDate");
                reader.addHeaderAlias("里程碑开票状态*", "invoiceStatus");
                reader.addHeaderAlias("里程碑开票状态", "invoiceStatus");
                reader.addHeaderAlias("预计回款时间(yyyy-MM-dd)", "expectedPaymentDate");
                reader.addHeaderAlias("预计回款时间", "expectedPaymentDate");
                reader.addHeaderAlias("实际回款时间(yyyy-MM-dd)", "actualPaymentDate");
                reader.addHeaderAlias("实际回款时间", "actualPaymentDate");
                reader.addHeaderAlias("预计回款金额(万元)", "expectedPaymentAmount");
                reader.addHeaderAlias("预计回款金额", "expectedPaymentAmount");
                reader.addHeaderAlias("实际回款金额(万元)", "actualAmount");
                reader.addHeaderAlias("实际回款金额", "actualAmount");
                reader.addHeaderAlias("备注", "remark");
                allRows = reader.readAll();
            }
        } catch (Exception e) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "Excel 解析失败: " + e.getMessage());
        }

        if (allRows == null || allRows.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "Excel 文件为空");
        }

        Integer currentFiscalYear = getCurrentFiscalYear();

        Set<String> validContractStatuses = new HashSet<>(Arrays.asList("UNSIGNED", "SIGNED", "COMPLETED", "CANCELED"));
        Set<String> validInvoiceStatuses = new HashSet<>(Arrays.asList("INVOICED", "UNINVOICED"));

        Map<String, ContractData> contractDataMap = new LinkedHashMap<>();
        Map<String, String> contractStatusMap = new LinkedHashMap<>();
        Map<String, String[]> parentContractCache = new LinkedHashMap<>();

        int rowNum = 1;
        for (Map<String, Object> row : allRows) {
            rowNum++;
            try {
                String contractNo = objToStr(row.get("contractNo"));
                String contractName = objToStr(row.get("contractName"));
                String projectName = objToStr(row.get("projectName"));
                String customerName = objToStr(row.get("customerName"));
                String manager = objToStr(row.get("manager"));
                String salesManager = objToStr(row.get("salesManager"));
                String productLine = objToStr(row.get("productLine"));
                String contractTypeName = objToStr(row.get("contractTypeName"));
                String contractStatusStr = objToStr(row.get("contractStatus"));

                List<String> rowErrors = new ArrayList<>();

                if (contractNo == null || contractNo.isEmpty()) {
                    rowErrors.add("合同号不能为空");
                }
                if (contractName == null || contractName.isEmpty()) {
                    rowErrors.add("合同名称不能为空");
                }
                if (projectName == null || projectName.isEmpty()) {
                    rowErrors.add("项目名称不能为空");
                }
                if (customerName == null || customerName.isEmpty()) {
                    rowErrors.add("客户名称不能为空");
                }
                if (manager == null || manager.isEmpty()) {
                    rowErrors.add("负责人不能为空");
                }
                if (productLine == null || productLine.isEmpty()) {
                    rowErrors.add("产品线不能为空");
                }
                if (contractTypeName == null || contractTypeName.isEmpty()) {
                    rowErrors.add("合同类型不能为空");
                }
                if (contractStatusStr == null || contractStatusStr.isEmpty()) {
                    rowErrors.add("合同状态不能为空");
                }

                String normalizedStatus = normalizeContractStatus(contractStatusStr);
                if (!validContractStatuses.contains(normalizedStatus)) {
                    rowErrors.add("合同状态值无效，有效状态：未签订/已签订/已完成/已取消");
                }

                String pl = productLine != null ? productLine.trim() : "";
                String ct = contractTypeName != null ? contractTypeName.trim() : "";
                String groupKey = contractNo.trim() + "||" + pl + "||" + ct;
                String parentKey = contractNo.trim();

                if (contractNo != null && !contractNo.isEmpty()) {
                    String existingStatus = contractStatusMap.get(parentKey);
                    if (existingStatus != null && !existingStatus.equals(normalizedStatus)) {
                        rowErrors.add("合同号[" + contractNo + "]状态不一致，当前行状态为[" + normalizedStatus + "]，其他行状态为[" + existingStatus + "]");
                    }
                }

                BigDecimal amountWan = null;
                String amtStr = objToStr(row.get("contractAmount"));
                if (amtStr != null && !amtStr.isEmpty()) {
                    try {
                        amountWan = new BigDecimal(amtStr.replaceAll(",", "").trim());
                    } catch (Exception e) {
                        rowErrors.add("合同金额格式错误，请输入数字");
                    }
                } else {
                    rowErrors.add("合同金额不能为空");
                }

                String createTimeStr = objToStr(row.get("contractCreateTime"));
                LocalDate contractCreateTime = parseDateFlexible(row.get("contractCreateTime"));
                if (createTimeStr != null && !createTimeStr.isEmpty() && contractCreateTime == null) {
                    rowErrors.add("合同创建时间格式错误，请使用 yyyy-MM-dd 格式");
                } else if (contractCreateTime == null) {
                    rowErrors.add("合同创建时间不能为空");
                }

                String completeTimeStr = objToStr(row.get("contractCompleteTime"));
                LocalDate contractCompleteTime = parseDateFlexible(row.get("contractCompleteTime"));
                if (completeTimeStr != null && !completeTimeStr.isEmpty() && contractCompleteTime == null) {
                    rowErrors.add("合同完成时间格式错误，请使用 yyyy-MM-dd 格式");
                } else if ("COMPLETED".equals(normalizedStatus) && contractCompleteTime == null) {
                    rowErrors.add("合同状态为已完成时，合同完成时间不能为空");
                }

                String expectedSignStr = objToStr(row.get("expectedSignDate"));
                LocalDate expectedSignDate = parseDateFlexible(row.get("expectedSignDate"));
                if (expectedSignStr != null && !expectedSignStr.isEmpty() && expectedSignDate == null) {
                    rowErrors.add("预计签约时间格式错误，请使用 yyyy-MM-dd 格式");
                }

                String signDateStrVal = objToStr(row.get("signDate"));
                LocalDate parsedSignDate = parseDateFlexible(row.get("signDate"));
                if ("UNSIGNED".equals(normalizedStatus) && parsedSignDate == null && expectedSignDate == null) {
                    rowErrors.add("合同未签约且未填写签约日期时，预计签约时间必填");
                }

                ContractData cd;
                if (!contractDataMap.containsKey(groupKey)) {
                    cd = new ContractData();
                    cd.rowNum = rowNum;
                    cd.contract = new Contract();
                    cd.contract.setCompanyId(companyId);
                    cd.contract.setContractNo(contractNo.trim());
                } else {
                    cd = contractDataMap.get(groupKey);
                }

                if (!rowErrors.isEmpty()) {
                    cd.hasError = true;
                    cd.errors.add("第" + rowNum + "行: " + String.join("；", rowErrors));
                }

                BigDecimal contractAmount = null;
                if (amountWan != null) {
                    contractAmount = amountWan.multiply(WAN);
                }

                // 客户信息仅保留字符串，不做存在性校验
                // 合同类型仅保留字符串，不做存在性校验

                Org orgByName = orgMapper.findByName(pl.isEmpty() ? null : pl);
                if (orgByName == null) {
                    cd.hasError = true;
                    cd.errors.add("第" + rowNum + "行: 产品线[" + productLine + "]不存在，请先在组织管理中添加");
                }

                if (cd.hasError) {
                    contractDataMap.put(groupKey, cd);
                    continue;
                }

                String projectCode = objToStr(row.get("projectCode"));
                LocalDate signDateParsed = parseDateFlexible(row.get("signDate"));

                String[] cached = parentContractCache.get(parentKey);
                if (cached == null) {
                    parentContractCache.put(parentKey, new String[]{
                            contractName.trim(), projectCode, projectName.trim(), customerName.trim(),
                            manager.trim(), normalizedStatus,
                            signDateParsed != null ? signDateParsed.toString() : "",
                            expectedSignDate != null ? expectedSignDate.toString() : "",
                            contractCreateTime != null ? contractCreateTime.toString() : "",
                            contractCompleteTime != null ? contractCompleteTime.toString() : ""
                    });
                } else {
                    String errPrefix = "第" + rowNum + "行: 同一合同号[" + contractNo + "]";
                    if (!cached[0].equals(contractName.trim())) {
                        cd.hasError = true; cd.errors.add(errPrefix + "合同名称不一致，该行[" + contractName + "]，其他行[" + cached[0] + "]");
                    }
                    String cachedProjCode = cached[1];
                    if ((projectCode == null ? "" : projectCode).equals(cachedProjCode == null ? "" : cachedProjCode) == false
                            && !((projectCode == null || projectCode.isEmpty()) && (cachedProjCode == null || cachedProjCode.isEmpty()))) {
                        cd.hasError = true; cd.errors.add(errPrefix + "项目号不一致");
                    }
                    if (!cached[2].equals(projectName.trim())) {
                        cd.hasError = true; cd.errors.add(errPrefix + "项目名称不一致，该行[" + projectName + "]，其他行[" + cached[2] + "]");
                    }
                    if (!cached[3].equals(customerName.trim())) {
                        cd.hasError = true; cd.errors.add(errPrefix + "客户名称不一致，该行[" + customerName + "]，其他行[" + cached[3] + "]");
                    }
                    if (!cached[4].equals(manager.trim())) {
                        cd.hasError = true; cd.errors.add(errPrefix + "负责人不一致，该行[" + manager + "]，其他行[" + cached[4] + "]");
                    }
                }

                if (cd.hasError) {
                    contractDataMap.put(groupKey, cd);
                    continue;
                }

                cd.contract.setContractName(contractName.trim());
                cd.contract.setProjectCode(projectCode);
                cd.contract.setProjectName(projectName.trim());
                cd.contract.setContractAmount(contractAmount);
                cd.contract.setCustomerName(customerName != null ? customerName.trim() : null);
                cd.contract.setContractType(ct);

                cd.contract.setOrgId(orgByName.getId());
                cd.contract.setProductLineCode(orgByName.getOrgCode());
                cd.contract.setProductLine(pl);
                cd.contract.setManager(manager.trim());
                cd.contract.setSalesManager(salesManager != null && !salesManager.isEmpty() ? salesManager.trim() : null);
                cd.contract.setContractStatus(normalizedStatus);
                cd.contract.setContractCreateTime(contractCreateTime);
                cd.contract.setContractCompleteTime(contractCompleteTime);

                if (contractCreateTime != null) {
                    cd.contract.setStockFlag(calculateStockFlag(contractCreateTime, currentFiscalYear));
                }

                if (signDateParsed != null) {
                    cd.contract.setSignDate(signDateParsed);
                }
                cd.contract.setExpectedSignDate(expectedSignDate);
                cd.contract.setRemark(objToStr(row.get("remark")));
                contractDataMap.put(groupKey, cd);
                contractStatusMap.put(parentKey, normalizedStatus);

                String milestoneCode = objToStr(row.get("milestoneCode"));
                String ratioStr = objToStr(row.get("paymentRatio"));
                String planInvoiceDateStr = parseYearMonthStr(row.get("planInvoiceDate"));
                String forecastInvoiceDateStr = parseYearMonthStr(row.get("forecastInvoiceDate"));
                String actualInvoiceDateStr = parseYearMonthStr(row.get("actualInvoiceDate"));
                String invoiceStatusStr = objToStr(row.get("invoiceStatus"));

                List<String> milestoneErrors = new ArrayList<>();

                if (milestoneCode == null || milestoneCode.isEmpty()) {
                    milestoneErrors.add("里程碑节点不能为空");
                }
                if (ratioStr == null || ratioStr.isEmpty()) {
                    milestoneErrors.add("收款比例不能为空");
                } else {
                    try {
                        BigDecimal ratio = parsePercentFlexible(row.get("paymentRatio"));
                        if (ratio == null || ratio.compareTo(BigDecimal.ZERO) < 0 || ratio.compareTo(new BigDecimal("100")) > 0) {
                            milestoneErrors.add("收款比例必须在0-100之间");
                        }
                    } catch (Exception e) {
                        milestoneErrors.add("收款比例格式错误，请输入数字");
                    }
                }
                if (planInvoiceDateStr == null || planInvoiceDateStr.isEmpty()) {
                    milestoneErrors.add("计划开票时间不能为空");
                } else if (!isValidYearMonth(planInvoiceDateStr)) {
                    milestoneErrors.add("计划开票时间格式错误，请使用 yyyy-MM 格式");
                }
                boolean needForecast = "SIGNED".equals(normalizedStatus) || "COMPLETED".equals(normalizedStatus);
                Object forecastRaw = row.get("forecastInvoiceDate");
                String forecastOriginal = objToStr(forecastRaw);
                if (needForecast) {
                    if (forecastInvoiceDateStr == null || forecastInvoiceDateStr.isEmpty()) {
                        milestoneErrors.add("合同状态为已签订/已完成时，预测开票时间不能为空");
                    } else if (!isValidYearMonth(forecastInvoiceDateStr)) {
                        milestoneErrors.add("预测开票时间格式错误，请使用 yyyy-MM 格式");
                    }
                } else if (forecastOriginal != null && !forecastOriginal.isEmpty() && !isValidYearMonth(forecastInvoiceDateStr)) {
                    milestoneErrors.add("预测开票时间格式错误，请使用 yyyy-MM 格式");
                }
                Object actualRaw = row.get("actualInvoiceDate");
                String actualOriginal = objToStr(actualRaw);
                if (actualOriginal != null && !actualOriginal.isEmpty() && !isValidYearMonth(actualInvoiceDateStr)) {
                    milestoneErrors.add("实际开票时间格式错误，请使用 yyyy-MM 格式");
                }
                if (invoiceStatusStr == null || invoiceStatusStr.isEmpty()) {
                    milestoneErrors.add("里程碑开票状态不能为空");
                } else {
                    String normalizedInvoiceStatus = normalizeInvoiceStatus(invoiceStatusStr);
                    if (!validInvoiceStatuses.contains(normalizedInvoiceStatus)) {
                        milestoneErrors.add("里程碑开票状态值无效，有效状态：已开票/未开票");
                    }
                }

                String expectedPaymentDateStr = objToStr(row.get("expectedPaymentDate"));
                LocalDate expectedPaymentDate = parseDateFlexible(row.get("expectedPaymentDate"));
                if (expectedPaymentDateStr != null && !expectedPaymentDateStr.isEmpty() && expectedPaymentDate == null) {
                    milestoneErrors.add("预计回款时间格式错误，请使用 yyyy-MM-dd 格式");
                }

                String actualPaymentDateStr = objToStr(row.get("actualPaymentDate"));
                LocalDate actualPaymentDate = parseDateFlexible(row.get("actualPaymentDate"));
                if (actualPaymentDateStr != null && !actualPaymentDateStr.isEmpty() && actualPaymentDate == null) {
                    milestoneErrors.add("实际回款时间格式错误，请使用 yyyy-MM-dd 格式");
                }

                String expectedPaymentAmtStr = objToStr(row.get("expectedPaymentAmount"));
                BigDecimal expectedPaymentAmt = null;
                if (expectedPaymentAmtStr != null && !expectedPaymentAmtStr.isEmpty()) {
                    try {
                        expectedPaymentAmt = new BigDecimal(expectedPaymentAmtStr.replaceAll(",", "").trim());
                    } catch (Exception e) {
                        milestoneErrors.add("预计回款金额格式错误，请输入数字");
                    }
                }

                String actualPaymentAmtStr = objToStr(row.get("actualAmount"));
                BigDecimal actualPaymentAmt = null;
                if (actualPaymentAmtStr != null && !actualPaymentAmtStr.isEmpty()) {
                    try {
                        actualPaymentAmt = new BigDecimal(actualPaymentAmtStr.replaceAll(",", "").trim());
                    } catch (Exception e) {
                        milestoneErrors.add("实际回款金额格式错误，请输入数字");
                    }
                }

                if (!milestoneErrors.isEmpty()) {
                    cd.hasError = true;
                    cd.errors.add("第" + rowNum + "行: " + String.join("；", milestoneErrors));
                    contractDataMap.put(groupKey, cd);
                    continue;
                }

                ContractMilestone ms = new ContractMilestone();
                ms.setCompanyId(companyId);
                ms.setMilestoneCode(milestoneCode.trim());
                ms.setMilestoneName("节点 " + milestoneCode.trim());

                BigDecimal ratioPercent = parsePercentFlexible(row.get("paymentRatio"));
                if (ratioPercent == null) {
                    ratioPercent = BigDecimal.ZERO;
                }
                BigDecimal ratioDecimal = ratioPercent.divide(new BigDecimal("100"), 4, RoundingMode.HALF_UP);
                ms.setPaymentRatio(ratioDecimal);
                if (contractAmount != null) {
                    BigDecimal msAmount = contractAmount.multiply(ratioDecimal).setScale(2, RoundingMode.HALF_UP);
                    ms.setMilestoneAmount(msAmount);
                }

                String normalizedInvoiceStatus = normalizeInvoiceStatus(invoiceStatusStr);
                ms.setInvoiceStatus(normalizedInvoiceStatus);

                parseYearMonthToDate(planInvoiceDateStr, ms::setPlanInvoiceYear, ms::setPlanMonth, ms::setPlanDate);
                parseYearMonthToDate(forecastInvoiceDateStr, ms::setForecastInvoiceYear, ms::setForecastMonth, ms::setForecastDate);
                parseYearMonthToDate(actualInvoiceDateStr, ms::setActualInvoiceYear, ms::setActualMonth, ms::setActualDate);

                ms.setExpectedPaymentDate(expectedPaymentDate);
                ms.setActualPaymentDate(actualPaymentDate);
                if (expectedPaymentAmt != null) {
                    ms.setExpectedPaymentAmount(expectedPaymentAmt.multiply(WAN).setScale(2, RoundingMode.HALF_UP));
                }
                if (actualPaymentAmt != null) {
                    ms.setActualAmount(actualPaymentAmt.multiply(WAN).setScale(2, RoundingMode.HALF_UP));
                }

                cd.milestones.add(ms);
            } catch (Exception e) {
                failed++;
                String errMsg = "第" + rowNum + "行: " + e.getMessage();
                if (errMsg.length() > 500) {
                    errMsg = errMsg.substring(0, 500) + "...";
                }
                errorMsgs.add(errMsg);
            }
        }

        for (ContractData cd : contractDataMap.values()) {
            if (cd.hasError) {
                failed++;
                errorMsgs.add("合同[" + cd.contract.getContractNo() + "/" + cd.contract.getProductLine() + "/" + cd.contract.getContractType() + "]导入失败: " + String.join("；", cd.errors));
                continue;
            }
            try {
                Contract existing = contractMapper.findByContractNoAndType(companyId,
                        cd.contract.getContractNo(), cd.contract.getOrgId(), cd.contract.getContractTypeId());
                if (existing != null) {
                    failed++;
                    errorMsgs.add("合同[" + cd.contract.getContractNo() + "]在产品线[" + cd.contract.getProductLine()
                            + "]+合同类型[" + cd.contract.getContractType() + "]下已存在（子合同号：" + existing.getSubContractNo() + "）");
                    continue;
                }
                ImportResult ir = saveContractWithMilestones(cd.contract, cd.milestones, companyId);
                if (ir.success) {
                    contractInserted++;
                    milestoneInserted += ir.milestoneCount;
                } else {
                    failed++;
                    errorMsgs.add("合同[" + cd.contract.getContractNo() + "/" + cd.contract.getProductLine() + "/" + cd.contract.getContractType() + "]导入失败: " + ir.error);
                }
            } catch (Exception e) {
                failed++;
                String errMsg = "合同[" + cd.contract.getContractNo() + "/" + cd.contract.getProductLine() + "/" + cd.contract.getContractType() + "]导入失败: " + e.getMessage();
                if (errMsg.length() > 500) {
                    errMsg = errMsg.substring(0, 500) + "...";
                }
                errorMsgs.add(errMsg);
            }
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("total", allRows.size());
        result.put("contractsInserted", contractInserted);
        result.put("milestonesInserted", milestoneInserted);
        result.put("failed", failed);
        if (!errorMsgs.isEmpty()) {
            result.put("errors", errorMsgs);
        }
        return result;
    }

    /**
     * 批量保存合同及其里程碑（导入用）
     */
    @Transactional(rollbackFor = Exception.class)
    public ImportResult saveContractWithMilestones(Contract contract, List<ContractMilestone> milestones, Long companyId) {
        ImportResult ir = new ImportResult();
        try {
            contract.setSubContractNo(generateSubContractNo(companyId, contract.getContractNo()));
            contractMapper.insert(contract);
            ir.success = true;
            ir.milestoneCount = 0;
            for (ContractMilestone ms : milestones) {
                ms.setContractId(contract.getId());
                ms.setCompanyId(companyId);
                milestoneMapper.insert(ms);
                ir.milestoneCount++;
            }
        } catch (Exception e) {
            ir.success = false;
            String msg = e.getMessage();
            if (msg != null && msg.length() > 300) {
                msg = msg.substring(0, 300) + "...";
            }
            ir.error = msg;
            throw e;
        }
        return ir;
    }

    /**
     * 填充合同列表的虚拟字段（核心汇总逻辑）
     * 关键计算：
     * 1. 已开票金额 = 所有"已开票"状态里程碑的金额之和
     * 2. 未开票金额 = 合同总额 - 已开票金额（最小为0）
     * 3. 合同开票状态：无里程碑→未开票；全部已开票→已开票；部分已开票→部分开票
     * 4. 库存/增量标识：往年合同为STOCK，本年合同为INCREMENT
     */
    private void fillVirtualFields(List<ContractVO> records, Integer currentFiscalYear) {
        if (records == null || records.isEmpty()) return;

        // 1. 批量查询所有合同的里程碑，避免N+1查询
        List<Long> contractIds = records.stream().map(ContractVO::getId).collect(Collectors.toList());
        List<ContractMilestoneVO> allMilestones = milestoneMapper.selectByContractIds(contractIds);
        Map<Long, List<ContractMilestoneVO>> msMap = allMilestones.stream()
                .collect(Collectors.groupingBy(ContractMilestoneVO::getContractId));

        for (ContractVO c : records) {
            List<ContractMilestoneVO> msList = msMap.getOrDefault(c.getId(), Collections.emptyList());
            BigDecimal invoiced = BigDecimal.ZERO;
            int invoicedCount = 0;
            int nonInvoicedCount = 0;
            // 2. 汇总已开票里程碑金额
            for (ContractMilestoneVO ms : msList) {
                BigDecimal msAmt = ms.getActualAmount() != null ? ms.getActualAmount() : ms.getMilestoneAmount();
                if (msAmt == null) msAmt = BigDecimal.ZERO;
                if ("INVOICED".equals(ms.getInvoiceStatus())) {
                    invoiced = invoiced.add(msAmt);
                    invoicedCount++;
                } else {
                    nonInvoicedCount++;
                }
            }
            // 3. 计算未开票金额 = 合同总额 - 已开票金额
            BigDecimal contractAmt = c.getContractAmount() != null ? c.getContractAmount() : BigDecimal.ZERO;
            c.setInvoicedAmount(invoiced);
            BigDecimal uninvoiced = contractAmt.subtract(invoiced);
            c.setUninvoicedAmount(uninvoiced);

            // 4. 判断合同整体开票状态
            if (msList.isEmpty()) {
                c.setInvoiceStatus("UNINVOICED");
            } else if (nonInvoicedCount == 0) {
                c.setInvoiceStatus("INVOICED");
            } else if (invoicedCount == 0) {
                c.setInvoiceStatus("UNINVOICED");
            } else {
                c.setInvoiceStatus("PARTIAL");
            }

            // 5. 设置库存/增量标识
            if (c.getContractCreateTime() != null) {
                c.setStockFlag(calculateStockFlag(c.getContractCreateTime(), currentFiscalYear));
            } else {
                c.setStockFlag(null);
            }
        }
    }

    private void writeContractRow(ExcelWriter writer, int row, ContractVO c, ContractMilestoneVO ms, DateTimeFormatter ymFmt) {
        int col = 0;
        writer.writeCellValue(col++, row, c.getContractNo());
        writer.writeCellValue(col++, row, c.getContractName());
        writer.writeCellValue(col++, row, c.getProjectCode());
        writer.writeCellValue(col++, row, c.getProjectName());
        writer.writeCellValue(col++, row, c.getCustomerName());
        writer.writeCellValue(col++, row, c.getManager());
        writer.writeCellValue(col++, row, c.getSalesManager());
        writer.writeCellValue(col++, row, c.getContractAmount() != null
                ? c.getContractAmount().divide(WAN, 2, RoundingMode.HALF_UP) : null);
        writer.writeCellValue(col++, row, c.getInvoicedAmount() != null
                ? c.getInvoicedAmount().divide(WAN, 2, RoundingMode.HALF_UP) : BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP));
        writer.writeCellValue(col++, row, c.getUninvoicedAmount() != null
                ? c.getUninvoicedAmount().divide(WAN, 2, RoundingMode.HALF_UP) : BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP));
        writer.writeCellValue(col++, row, c.getSignDate() != null ? c.getSignDate().toString() : "");
        writer.writeCellValue(col++, row, c.getExpectedSignDate() != null ? c.getExpectedSignDate().toString() : "");
        writer.writeCellValue(col++, row, c.getContractCreateTime() != null ? c.getContractCreateTime().toString() : "");
        writer.writeCellValue(col++, row, c.getContractCompleteTime() != null ? c.getContractCompleteTime().toString() : "");
        writer.writeCellValue(col++, row, c.getProductLine());
        writer.writeCellValue(col++, row, c.getContractType());
        writer.writeCellValue(col++, row, statusToText(c.getContractStatus()));
        if (ms != null) {
            writer.writeCellValue(col++, row, ms.getMilestoneCode());
            writer.writeCellValue(col++, row, ms.getPaymentRatio() != null
                    ? ms.getPaymentRatio().multiply(new BigDecimal("100")).setScale(2, RoundingMode.HALF_UP) : null);
            writer.writeCellValue(col++, row, ms.getPlanDate() != null ? ms.getPlanDate().withDayOfMonth(1).format(ymFmt) : "");
            writer.writeCellValue(col++, row, ms.getForecastDate() != null ? ms.getForecastDate().withDayOfMonth(1).format(ymFmt) : "");
            writer.writeCellValue(col++, row, ms.getActualDate() != null ? ms.getActualDate().withDayOfMonth(1).format(ymFmt) : "");
            writer.writeCellValue(col++, row, ms.getInvoiceStatus() != null
                    ? ("INVOICED".equals(ms.getInvoiceStatus()) ? "已开票" : "未开票") : "未开票");
            writer.writeCellValue(col++, row, ms.getExpectedPaymentDate() != null ? ms.getExpectedPaymentDate().toString() : "");
            writer.writeCellValue(col++, row, ms.getActualPaymentDate() != null ? ms.getActualPaymentDate().toString() : "");
            writer.writeCellValue(col++, row, ms.getExpectedPaymentAmount() != null
                    ? ms.getExpectedPaymentAmount().divide(WAN, 2, RoundingMode.HALF_UP) : null);
            writer.writeCellValue(col++, row, ms.getActualAmount() != null
                    ? ms.getActualAmount().divide(WAN, 2, RoundingMode.HALF_UP) : null);
        } else {
            col += 10;
        }
        writer.writeCellValue(col, row, c.getRemark());
    }

    private void normalizePaymentRatio(ContractMilestone ms) {
        if (ms.getPaymentRatio() != null && ms.getPaymentRatio().compareTo(BigDecimal.ONE) > 0) {
            ms.setPaymentRatio(ms.getPaymentRatio().divide(new BigDecimal("100"), 4, RoundingMode.HALF_UP));
        }
    }

    private void fillMilestoneDateFields(ContractMilestone ms) {
        if (ms.getPlanDate() != null) {
            ms.setPlanInvoiceYear(ms.getPlanDate().getYear());
            ms.setPlanMonth(ms.getPlanDate().getMonthValue());
        } else if (ms.getPlanInvoiceYear() != null && ms.getPlanMonth() != null) {
            ms.setPlanDate(LocalDate.of(ms.getPlanInvoiceYear(), ms.getPlanMonth(), 1));
        }
        if (ms.getForecastDate() != null) {
            ms.setForecastInvoiceYear(ms.getForecastDate().getYear());
            ms.setForecastMonth(ms.getForecastDate().getMonthValue());
        } else if (ms.getForecastInvoiceYear() != null && ms.getForecastMonth() != null) {
            ms.setForecastDate(LocalDate.of(ms.getForecastInvoiceYear(), ms.getForecastMonth(), 1));
        }
        if (ms.getActualDate() != null) {
            ms.setActualInvoiceYear(ms.getActualDate().getYear());
            ms.setActualMonth(ms.getActualDate().getMonthValue());
        } else if (ms.getActualInvoiceYear() != null && ms.getActualMonth() != null) {
            ms.setActualDate(LocalDate.of(ms.getActualInvoiceYear(), ms.getActualMonth(), 1));
        }
        if (ms.getPaymentRatio() != null && ms.getMilestoneAmount() == null) {
            Contract contract = contractMapper.selectById(ms.getContractId());
            if (contract != null && contract.getContractAmount() != null) {
                ms.setMilestoneAmount(contract.getContractAmount().multiply(ms.getPaymentRatio()).setScale(2, RoundingMode.HALF_UP));
            }
        }
        if (ms.getExpectedPaymentAmount() == null && ms.getMilestoneAmount() != null) {
            ms.setExpectedPaymentAmount(ms.getMilestoneAmount());
        }
    }

    @Override
    public String generateSubContractNo(Long companyId, String contractNo) {
        List<Contract> existing = contractMapper.findByParentContractNo(companyId, contractNo);
        int maxSeq = 0;
        for (Contract c : existing) {
            String scn = c.getSubContractNo();
            if (scn != null && scn.startsWith(contractNo + "-")) {
                try {
                    int seq = Integer.parseInt(scn.substring(contractNo.length() + 1));
                    if (seq > maxSeq) maxSeq = seq;
                } catch (NumberFormatException ignored) {}
            }
        }
        return contractNo + "-" + String.format("%02d", maxSeq + 1);
    }

    private void validateExpectedSignDate(Contract contract) {
        String status = normalizeContractStatus(contract.getContractStatus());
        if ("UNSIGNED".equals(status) && contract.getSignDate() == null
                && contract.getExpectedSignDate() == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "合同未签约时，预计签约时间必填");
        }
    }

    private void fillContractRelations(Contract contract) {
        // 客户信息仅保留字符串字段，不做外键关联
        // 合同类型仅保留字符串字段，不做外键关联

        if (contract.getProductLine() != null && !contract.getProductLine().isEmpty()) {
            Org org = orgMapper.findByName(contract.getProductLine().trim());
            if (org != null) {
                contract.setOrgId(org.getId());
                contract.setProductLineCode(org.getOrgCode());
            }
        } else if (contract.getOrgId() != null) {
            Org org = orgMapper.selectById(contract.getOrgId());
            if (org != null) {
                contract.setProductLine(org.getOrgName());
                contract.setProductLineCode(org.getOrgCode());
            }
        }
    }

    private Integer getCurrentFiscalYear() {
        return LocalDate.now().getYear();
    }

    private String calculateStockFlag(LocalDate contractCreateTime, Integer currentFiscalYear) {
        if (contractCreateTime == null || currentFiscalYear == null) {
            return "INCREMENT";
        }
        if (contractCreateTime.getYear() < currentFiscalYear) {
            return "STOCK";
        }
        return "INCREMENT";
    }

    private static class ContractData {
        int rowNum;
        Contract contract;
        List<ContractMilestone> milestones = new ArrayList<>();
        List<String> errors = new ArrayList<>();
        boolean hasError = false;
    }

    private static class ImportResult {
        boolean success;
        int milestoneCount;
        String error;
    }

    private static String sanitizeFilename(String filename) {
        if (filename == null) return null;
        String normalized = filename.replaceAll("[/\\\\:*?\"<>|\\x00-\\x1f]", "_");
        int dotIndex = normalized.lastIndexOf('.');
        String namePart = dotIndex >= 0 ? normalized.substring(0, dotIndex) : normalized;
        String extPart = dotIndex >= 0 ? normalized.substring(dotIndex) : "";
        if (namePart.length() > 100) {
            namePart = namePart.substring(0, 100);
        }
        return namePart + extPart;
    }

    private static String objToStr(Object obj) {
        if (obj == null) return null;
        if (obj instanceof Date) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            return sdf.format((Date) obj);
        }
        if (obj instanceof LocalDate) {
            return ((LocalDate) obj).format(DATE_FMT);
        }
        if (obj instanceof Number) {
            double num = ((Number) obj).doubleValue();
            if (num > 30000 && num < 80000) {
                LocalDate date = EXCEL_EPOCH.plusDays((long) num);
                return date.format(DATE_FMT);
            }
        }
        String s = String.valueOf(obj).trim();
        if (s.isEmpty() || "null".equalsIgnoreCase(s)) return null;
        return s;
    }

    private static LocalDate parseDateFlexible(Object obj) {
        if (obj == null) return null;
        if (obj instanceof LocalDate) return (LocalDate) obj;
        if (obj instanceof Date) {
            return ((Date) obj).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        }
        String s = objToStr(obj);
        if (s == null || s.isEmpty()) return null;
        s = s.trim();
        if (s.matches("\\d+(\\.\\d+)?")) {
            double num = Double.parseDouble(s);
            if (num > 30000 && num < 80000) {
                return EXCEL_EPOCH.plusDays((long) num);
            }
        }
        for (DateTimeFormatter fmt : DATE_FORMATS) {
            try {
                return LocalDate.parse(s, fmt);
            } catch (DateTimeParseException ignored) {}
        }
        for (DateTimeFormatter fmt : YEAR_MONTH_FORMATS) {
            try {
                java.time.YearMonth ym = java.time.YearMonth.parse(s.substring(0, Math.min(s.length(), 7)), fmt);
                return ym.atDay(1);
            } catch (Exception ignored) {}
        }
        return null;
    }

    private static BigDecimal parsePercentFlexible(Object obj) {
        if (obj == null) return null;
        try {
            BigDecimal ratio;
            if (obj instanceof Number) {
                double num = ((Number) obj).doubleValue();
                if (num >= 0 && num <= 1 && Math.abs(num) > 0.000001) {
                    ratio = BigDecimal.valueOf(num * 100);
                } else {
                    ratio = BigDecimal.valueOf(num);
                }
            } else {
                String s = String.valueOf(obj).trim();
                if (s.isEmpty() || "null".equalsIgnoreCase(s)) return null;
                boolean hasPercent = s.contains("%");
                s = s.replaceAll("%", "").replaceAll(",", "").trim();
                ratio = new BigDecimal(s);
                if (hasPercent && ratio.compareTo(BigDecimal.ONE) <= 1 && ratio.compareTo(BigDecimal.ZERO) >= 0) {
                    ratio = ratio.multiply(new BigDecimal("100"));
                } else if (!hasPercent && ratio.compareTo(BigDecimal.ZERO) > 0 && ratio.compareTo(BigDecimal.ONE) <= 0) {
                    ratio = ratio.multiply(new BigDecimal("100"));
                }
            }
            return ratio.setScale(2, RoundingMode.HALF_UP);
        } catch (Exception e) {
            return null;
        }
    }

    private static String parseYearMonthStr(Object obj) {
        if (obj == null) return null;
        if (obj instanceof Date) {
            LocalDate ld = ((Date) obj).toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            return ld.format(YEAR_MONTH_FMT);
        }
        if (obj instanceof LocalDate) {
            return ((LocalDate) obj).format(YEAR_MONTH_FMT);
        }
        String s = objToStr(obj);
        if (s == null || s.isEmpty()) return null;
        s = s.trim();
        if (s.matches("\\d+(\\.\\d+)?")) {
            double num = Double.parseDouble(s);
            if (num > 30000 && num < 80000) {
                LocalDate date = EXCEL_EPOCH.plusDays((long) num);
                return date.format(YEAR_MONTH_FMT);
            }
        }
        if (s.length() >= 7) {
            String ymPart = s.substring(0, 7);
            for (DateTimeFormatter fmt : YEAR_MONTH_FORMATS) {
                try {
                    java.time.YearMonth.parse(ymPart, fmt);
                    if (fmt == YEAR_MONTH_FORMATS[3]) {
                        return s.substring(0, 4) + "-" + s.substring(4, 6);
                    }
                    return ymPart;
                } catch (Exception ignored) {}
            }
            if (s.contains("-") && s.split("-").length >= 2) {
                String[] parts = s.split("-");
                try {
                    int y = Integer.parseInt(parts[0].trim());
                    int m = Integer.parseInt(parts[1].trim());
                    if (y >= 1900 && y <= 2100 && m >= 1 && m <= 12) {
                        return String.format("%04d-%02d", y, m);
                    }
                } catch (Exception ignored) {}
            }
            if (s.contains("/") && s.split("/").length >= 2) {
                String[] parts = s.split("/");
                try {
                    int y = Integer.parseInt(parts[0].trim());
                    int m = Integer.parseInt(parts[1].trim());
                    if (y >= 1900 && y <= 2100 && m >= 1 && m <= 12) {
                        return String.format("%04d-%02d", y, m);
                    }
                } catch (Exception ignored) {}
            }
        }
        return s;
    }

    private static boolean isValidYearMonthFlexible(Object obj) {
        String s = parseYearMonthStr(obj);
        if (s == null) return false;
        return isValidYearMonth(s);
    }

    private static String normalizeContractStatus(String status) {
        if (status == null) return "UNSIGNED";
        String s = status.trim().toUpperCase();
        if ("UNSIGNED".equals(s) || "SIGNED".equals(s) || "COMPLETED".equals(s) || "CANCELED".equals(s)) {
            return s;
        }
        if (s.contains("未签订") || s.contains("DRAFT") || s.contains("NEW")) return "UNSIGNED";
        if (s.contains("已签订") || s.contains("SIGNED") || s.contains("签约")) return "SIGNED";
        if (s.contains("已完成") || s.contains("COMPLETED") || s.contains("完成")) return "COMPLETED";
        if (s.contains("已取消") || s.contains("CANCELED") || s.contains("取消")) return "CANCELED";
        return "UNSIGNED";
    }

    private static String normalizeInvoiceStatus(String status) {
        if (status == null) return "UNINVOICED";
        String s = status.trim().toUpperCase();
        if ("INVOICED".equals(s) || "UNINVOICED".equals(s)) {
            return s;
        }
        if (s.contains("已开票") || s.contains("INVOICE")) return "INVOICED";
        if (s.contains("未开票") || s.contains("UNINVOICE")) return "UNINVOICED";
        return "UNINVOICED";
    }

    private static void parseYearMonthToDate(String dateStr,
                                              java.util.function.IntConsumer yearSetter,
                                              java.util.function.IntConsumer monthSetter,
                                              java.util.function.Consumer<LocalDate> dateSetter) {
        if (dateStr == null || dateStr.isEmpty()) return;
        try {
            String[] parts = dateStr.trim().split("-");
            if (parts.length == 2) {
                int year = Integer.parseInt(parts[0].trim());
                int month = Integer.parseInt(parts[1].trim());
                yearSetter.accept(year);
                monthSetter.accept(month);
                dateSetter.accept(LocalDate.of(year, month, 1));
            }
        } catch (Exception ignored) {}
    }

    private static boolean isValidYearMonth(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) return false;
        try {
            String[] parts = dateStr.trim().split("-");
            if (parts.length == 2) {
                int year = Integer.parseInt(parts[0].trim());
                int month = Integer.parseInt(parts[1].trim());
                return year >= 1900 && year <= 2100 && month >= 1 && month <= 12;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private static String statusToText(String status) {
        if (status == null) return "";
        switch (status) {
            case "UNSIGNED": return "未签订";
            case "SIGNED": return "已签订";
            case "COMPLETED": return "已完成";
            case "CANCELED": return "已取消";
            default: return status;
        }
    }
}
