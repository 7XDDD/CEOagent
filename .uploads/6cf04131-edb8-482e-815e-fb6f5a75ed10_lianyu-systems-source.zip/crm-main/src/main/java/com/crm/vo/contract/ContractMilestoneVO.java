package com.crm.vo.contract;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class ContractMilestoneVO {

    private Long id;

    private Long contractId;

    private Long companyId;

    private String invoiceStatus;

    private String milestoneCode;

    private String milestoneName;

    private BigDecimal paymentRatio;

    private Integer planInvoiceYear;

    private BigDecimal milestoneAmount;

    private Integer planMonth;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate planDate;

    private Integer forecastInvoiceYear;

    private Integer forecastMonth;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate forecastDate;

    private Integer actualInvoiceYear;

    private Integer actualMonth;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate actualDate;

    private BigDecimal actualAmount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedPaymentDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate actualPaymentDate;

    private BigDecimal expectedPaymentAmount;

    private String status;

    private String remark;

    private Long createdBy;

    private Long updatedBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    private Integer version;

    private Integer deleted;
}
