package com.crm.controller.customer;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.annotation.OperationLog;
import com.crm.common.Result;
import com.crm.dto.*;
import com.crm.entity.PmtCustomerAddress;
import com.crm.entity.PmtCustomerContact;
import com.crm.entity.PmtCustomerFollower;
import com.crm.service.CustomerService;
import com.crm.vo.CustomerVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

@Api(tags = "客户管理")
@RestController
@RequestMapping("/crm/customers")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @ApiOperation("分页查询客户(GET)")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:view')")
    @GetMapping("/page")
    public Result<Page<CustomerVO>> pageGet(CustomerQueryDTO queryDTO) {
        if (queryDTO.getPageNum() == null) queryDTO.setPageNum(1);
        if (queryDTO.getPageSize() == null) queryDTO.setPageSize(10);
        if (queryDTO.getStatus() != null && !queryDTO.getStatus().isEmpty()) {
            queryDTO.setStatus(convertStatus(queryDTO.getStatus()));
        }
        return Result.success(customerService.pageList(queryDTO));
    }

    private String convertStatus(String status) {
        if ("1".equals(status)) {
            return "ACTIVE";
        } else if ("0".equals(status)) {
            return "INACTIVE";
        }
        return status;
    }

    @ApiOperation("分页查询客户")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:view')")
    @PostMapping("/page")
    public Result<Page<CustomerVO>> page(@RequestBody CustomerQueryDTO queryDTO) {
        return Result.success(customerService.pageList(queryDTO));
    }

    @ApiOperation("客户公海列表")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:view')")
    @GetMapping("/public-sea")
    public Result<Page<CustomerVO>> publicSeaList(CustomerQueryDTO queryDTO) {
        if (queryDTO.getPageNum() == null) queryDTO.setPageNum(1);
        if (queryDTO.getPageSize() == null) queryDTO.setPageSize(10);
        return Result.success(customerService.publicSeaList(queryDTO));
    }

    @ApiOperation("领取公海客户")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:update')")
    @PutMapping("/{id}/claim")
    @OperationLog("领取客户")
    public Result<Void> claimCustomer(@PathVariable Long id) {
        customerService.claimCustomer(id);
        return Result.success();
    }

    @ApiOperation("客户分析")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:view')")
    @GetMapping("/analysis")
    public Result<Map<String, Object>> analysis(CustomerQueryDTO queryDTO) {
        return Result.success(customerService.analysis(queryDTO));
    }

    @ApiOperation("获取客户详情")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:view')")
    @GetMapping("/{id:\\d+}")
    public Result<CustomerVO> getDetail(@PathVariable Long id) {
        return Result.success(customerService.getDetail(id));
    }

    @ApiOperation("获取所有客户")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:view')")
    @GetMapping("/list")
    public Result<List<CustomerVO>> listAll() {
        return Result.success(customerService.listAll());
    }

    @ApiOperation("创建客户")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:create')")
    @PostMapping
    @OperationLog("创建客户")
    public Result<Long> create(@RequestBody CustomerCreateDTO createDTO) {
        return Result.success(customerService.createCustomer(createDTO));
    }

    @ApiOperation("更新客户")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:update')")
    @PutMapping("/{id}")
    @OperationLog("更新客户")
    public Result<Boolean> update(@PathVariable Long id, @RequestBody CustomerUpdateDTO updateDTO) {
        return Result.success(customerService.updateCustomer(id, updateDTO));
    }

    @ApiOperation("转移客户负责人")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:update')")
    @PostMapping("/{id}/transfer")
    @OperationLog("转移客户负责人")
    public Result<Boolean> transfer(@PathVariable Long id, @RequestBody Map<String, Object> body) {
        Long newOwnerId = body.get("newOwnerId") != null ? Long.valueOf(body.get("newOwnerId").toString()) : null;
        String newOwnerName = body.get("newOwnerName") != null ? body.get("newOwnerName").toString() : null;
        return Result.success("转移成功", customerService.transferCustomer(id, newOwnerId, newOwnerName));
    }

    @ApiOperation("删除客户")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:delete')")
    @DeleteMapping("/{id}")
    @OperationLog("删除客户")
    public Result<Boolean> delete(@PathVariable Long id) {
        return Result.success(customerService.deleteCustomer(id));
    }

    @ApiOperation("批量删除客户")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:delete')")
    @PostMapping("/batch-delete")
    @OperationLog("批量删除客户")
    public Result<Boolean> batchDelete(@RequestBody List<Long> ids) {
        return Result.success(customerService.deleteBatch(ids));
    }

    @ApiOperation("导出客户")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:export')")
    @PostMapping("/export")
    @OperationLog("导出客户")
    public void export(@RequestBody(required = false) CustomerQueryDTO queryDTO, HttpServletResponse response) throws Exception {
        customerService.exportCustomers(queryDTO, response);
    }

    @ApiOperation("导出客户(GET)")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:export')")
    @GetMapping("/export")
    @OperationLog("导出客户")
    public void exportGet(HttpServletResponse response) throws Exception {
        customerService.exportCustomers(null, response);
    }

    @ApiOperation("下载客户导入模板")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:view')")
    @GetMapping("/import-template")
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        customerService.downloadImportTemplate(response);
    }

    @ApiOperation("下载客户导入模板(GET)")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:view')")
    @GetMapping("/template")
    public void downloadTemplate(HttpServletResponse response) throws Exception {
        customerService.downloadImportTemplate(response);
    }

    @ApiOperation("导入客户")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:import')")
    @PostMapping("/import-excel")
    @OperationLog("导入客户")
    public Result<Map<String, Object>> importExcel(@RequestParam("file") MultipartFile file) {
        Map<String, Object> result = customerService.importExcel(file);
        int inserted = (int) result.getOrDefault("inserted", 0);
        int updated = (int) result.getOrDefault("updated", 0);
        int failed = (int) result.getOrDefault("failed", 0);
        String msg = "导入完成，新增 " + inserted + " 条，更新 " + updated + " 条，失败 " + failed + " 条";
        return Result.success(msg, result);
    }

    @ApiOperation("导入客户(POST)")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:import')")
    @PostMapping("/import")
    @OperationLog("导入客户")
    public Result<Map<String, Object>> importCustomer(@RequestParam("file") MultipartFile file) {
        Map<String, Object> result = customerService.importExcel(file);
        int inserted = (int) result.getOrDefault("inserted", 0);
        int updated = (int) result.getOrDefault("updated", 0);
        int failed = (int) result.getOrDefault("failed", 0);
        String msg = "导入完成，新增 " + inserted + " 条，更新 " + updated + " 条，失败 " + failed + " 条";
        return Result.success(msg, result);
    }

    @ApiOperation("获取客户地址列表")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:view')")
    @GetMapping("/{id}/addresses")
    public Result<List<PmtCustomerAddress>> getAddresses(@PathVariable Long id) {
        return Result.success(customerService.getAddresses(id));
    }

    @ApiOperation("获取客户联系人列表")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:view')")
    @GetMapping("/{id}/contacts")
    public Result<List<PmtCustomerContact>> getContacts(@PathVariable Long id) {
        return Result.success(customerService.getContacts(id));
    }

    @ApiOperation("获取客户跟进人列表")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:view')")
    @GetMapping("/{id}/followers")
    public Result<List<PmtCustomerFollower>> getFollowers(@PathVariable Long id) {
        return Result.success(customerService.getFollowers(id));
    }

    @ApiOperation("保存客户地址列表(批量)")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:update')")
    @PostMapping("/{id}/addresses")
    @OperationLog("保存客户地址")
    public Result<Void> saveAddresses(@PathVariable Long id, @RequestBody List<Map<String, Object>> list) {
        customerService.saveAddresses(id, list);
        return Result.success();
    }

    @ApiOperation("保存客户联系人列表(批量)")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:update')")
    @PostMapping("/{id}/contacts")
    @OperationLog("保存客户联系人")
    public Result<Void> saveContacts(@PathVariable Long id, @RequestBody List<Map<String, Object>> list) {
        customerService.saveContacts(id, list);
        return Result.success();
    }

    @ApiOperation("保存客户跟进人列表(批量)")
    @PreAuthorize("@permissionChecker.hasPermission('crm:customer:update')")
    @PostMapping("/{id}/followers")
    @OperationLog("保存客户跟进人")
    public Result<Void> saveFollowers(@PathVariable Long id, @RequestBody List<Map<String, Object>> list) {
        customerService.saveFollowers(id, list);
        return Result.success();
    }
}
