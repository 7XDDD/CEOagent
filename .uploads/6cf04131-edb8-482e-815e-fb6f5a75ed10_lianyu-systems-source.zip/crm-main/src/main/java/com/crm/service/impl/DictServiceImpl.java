package com.crm.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.BusinessException;
import com.crm.dto.system.*;
import com.crm.entity.Dict;
import com.crm.entity.DictItem;
import com.crm.mapper.DictItemMapper;
import com.crm.mapper.DictMapper;
import com.crm.service.DictService;
import com.crm.vo.system.DictItemVO;
import com.crm.vo.system.DictVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class DictServiceImpl implements DictService {

    @Autowired
    private DictMapper dictMapper;

    @Autowired
    private DictItemMapper dictItemMapper;

    @Override
    public Page<DictVO> pageList(DictQueryDTO query) {
        Page<Dict> page = new Page<>(query.getPageNum(), query.getPageSize());
        Page<Dict> dictPage = dictMapper.selectPageList(page, query);
        Page<DictVO> voPage = new Page<>(dictPage.getCurrent(), dictPage.getSize(), dictPage.getTotal());
        List<DictVO> voList = dictPage.getRecords().stream().map(this::convertToVO).collect(Collectors.toList());
        voPage.setRecords(voList);
        return voPage;
    }

    @Override
    public DictVO getDetail(Long id) {
        Dict dict = dictMapper.selectById(id);
        if (dict == null) {
            throw new BusinessException("字典不存在");
        }
        DictVO vo = convertToVO(dict);
        List<DictItem> items = dictItemMapper.findByDictId(id);
        vo.setItems(items.stream().map(this::convertItemToVO).collect(Collectors.toList()));
        return vo;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Dict createDict(DictCreateDTO dto) {
        Dict dict = new Dict();
        BeanUtils.copyProperties(dto, dict);
        if (dict.getStatus() == null) dict.setStatus(1);
        if (dict.getSortOrder() == null) dict.setSortOrder(0);
        dictMapper.insert(dict);
        return dict;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Dict updateDict(Long id, DictUpdateDTO dto) {
        Dict dict = dictMapper.selectById(id);
        if (dict == null) {
            throw new BusinessException("字典不存在");
        }
        BeanUtils.copyProperties(dto, dict);
        dictMapper.updateById(dict);
        return dict;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteDict(Long id) {
        dictItemMapper.softDeleteByDictId(id);
        dictMapper.softDeleteById(id);
    }

    @Override
    public List<DictItemVO> getDictItems(Long dictId) {
        List<DictItem> items = dictItemMapper.findByDictId(dictId);
        return items.stream().map(this::convertItemToVO).collect(Collectors.toList());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public DictItem createDictItem(DictItemCreateDTO dto) {
        Dict dict = dictMapper.selectById(dto.getDictId());
        if (dict == null) {
            throw new BusinessException("字典不存在");
        }
        DictItem item = new DictItem();
        BeanUtils.copyProperties(dto, item);
        if (item.getStatus() == null) item.setStatus(1);
        if (item.getSortOrder() == null) item.setSortOrder(0);
        dictItemMapper.insert(item);
        return item;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public DictItem updateDictItem(Long id, DictItemUpdateDTO dto) {
        DictItem item = dictItemMapper.selectById(id);
        if (item == null) {
            throw new BusinessException("字典项不存在");
        }
        BeanUtils.copyProperties(dto, item);
        dictItemMapper.updateById(item);
        return item;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteDictItem(Long id) {
        dictItemMapper.softDeleteById(id);
    }

    @Override
    public Map<String, List<DictItemVO>> getDictByCodes(List<String> dictCodes) {
        Map<String, List<DictItemVO>> result = new HashMap<>();
        for (String code : dictCodes) {
            List<DictItem> items = dictItemMapper.findByDictCode(code);
            result.put(code, items.stream().map(this::convertItemToVO).collect(Collectors.toList()));
        }
        return result;
    }

    @Override
    public DictVO getTypeByCode(String dictCode, String systemType) {
        Dict dict;
        if (systemType != null && !systemType.isEmpty()) {
            dict = dictMapper.findByDictCodeAndSystemType(dictCode, systemType);
        } else {
            dict = dictMapper.findByDictCode(dictCode);
        }
        if (dict == null) {
            throw new BusinessException("字典类型不存在");
        }
        return convertToVO(dict);
    }

    @Override
    public List<DictItemVO> getItemsByTypeCode(String typeCode) {
        List<DictItem> items = dictItemMapper.findByDictCode(typeCode);
        return items.stream().map(this::convertItemToVO).collect(Collectors.toList());
    }

    @Override
    public DictItemVO getItemByCode(String code) {
        DictItem item = dictItemMapper.findByItemCode(code);
        if (item == null) {
            throw new BusinessException("字典项不存在");
        }
        return convertItemToVO(item);
    }

    @Override
    public Map<String, List<DictItemVO>> getAllItems(String codes) {
        return getAllItems(codes, null);
    }

    @Override
    public Map<String, List<DictItemVO>> getAllItems(String codes, String systemType) {
        Map<String, List<DictItemVO>> result = new HashMap<>();
        if (codes == null || codes.isEmpty()) {
            return result;
        }
        String[] codeArray = codes.split(",");
        StringBuilder inClause = new StringBuilder();
        for (int i = 0; i < codeArray.length; i++) {
            String code = codeArray[i].trim();
            if (!code.isEmpty()) {
                if (inClause.length() > 0) {
                    inClause.append(",");
                }
                inClause.append("'").append(code).append("'");
            }
        }
        if (inClause.length() > 0) {
            List<DictItem> allItems;
            if (systemType != null && !systemType.isEmpty()) {
                allItems = dictItemMapper.findByDictCodesAndSystemType(inClause.toString(), systemType);
            } else {
                allItems = dictItemMapper.findByDictCodes(inClause.toString());
            }
            Map<Long, String> dictIdToCode = new HashMap<>();
            for (String code : codeArray) {
                String trimmed = code.trim();
                if (!trimmed.isEmpty()) {
                    Dict dict;
                    if (systemType != null && !systemType.isEmpty()) {
                        dict = dictMapper.findByDictCodeAndSystemType(trimmed, systemType);
                    } else {
                        dict = dictMapper.findByDictCode(trimmed);
                    }
                    if (dict != null) {
                        dictIdToCode.put(dict.getId(), trimmed);
                        result.putIfAbsent(trimmed, new ArrayList<>());
                    }
                }
            }
            for (DictItem item : allItems) {
                String dictCode = dictIdToCode.get(item.getDictId());
                if (dictCode != null) {
                    result.get(dictCode).add(convertItemToVO(item));
                }
            }
        }
        return result;
    }

    private DictVO convertToVO(Dict dict) {
        DictVO vo = new DictVO();
        BeanUtils.copyProperties(dict, vo);
        return vo;
    }

    private DictItemVO convertItemToVO(DictItem item) {
        DictItemVO vo = new DictItemVO();
        BeanUtils.copyProperties(item, vo);
        return vo;
    }
}
