package com.crm.dto.system;

import com.crm.dto.PageQueryDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class OperationLogQueryDTO extends PageQueryDTO {
    private String keyword;
    private String systemType;
    private String module;
    private String type;
    private Integer status;
    private String username;
    private String realName;
    private String startTime;
    private String endTime;
}
