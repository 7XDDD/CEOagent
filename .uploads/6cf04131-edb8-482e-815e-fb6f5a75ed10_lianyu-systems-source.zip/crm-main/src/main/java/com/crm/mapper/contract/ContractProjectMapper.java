package com.crm.mapper.contract;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.ContractProject;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ContractProjectMapper extends BaseMapper<ContractProject> {
}
