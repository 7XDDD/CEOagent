package com.crm.dto.contract;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
public class ContractUpdateDTO {

    @NotNull(message = "合同ID不能为空")
    private Long id;

    private String contractNo;

    private String contractName;

    private String projectCode;

    private String projectName;

    private Long customerId;

    private String customerName;

    private Long contractTypeId;

    private String contractType;

    private Long orgId;

    private String productLine;

    private String manager;

    private String salesManager;

    private BigDecimal contractAmount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate signDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedSignDate;

    private String contractStatus;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate contractCreateTime;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate contractCompleteTime;

    private String remark;

    /** 父合同ID */
    private Long parentId;

    /** 关联商机ID列表 */
    private List<Long> opportunityIds;

    /** 关联项目ID列表 */
    private List<Long> projectIds;
}
