package com.crm.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crm.common.BusinessException;
import com.crm.common.ResultCode;
import com.crm.common.SecurityContextUtil;
import com.crm.dataperm.DataOwnerResolver;
import com.crm.dataperm.DataPermBits;
import com.crm.entity.DataPermission;
import com.crm.entity.User;
import com.crm.mapper.DataPermissionMapper;
import com.crm.mapper.UserMapper;
import com.crm.service.DataPermissionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
public class DataPermissionServiceImpl implements DataPermissionService {

    @Autowired
    private DataPermissionMapper dataPermissionMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired(required = false)
    private List<DataOwnerResolver> resolvers;

    private boolean isAdmin() {
        return SecurityContextUtil.hasRole("super_admin") || SecurityContextUtil.hasRole("ADMIN");
    }

    private Long uid() {
        return SecurityContextUtil.getCurrentUserId();
    }

    private DataOwnerResolver resolver(String module) {
        if (resolvers == null) return null;
        return resolvers.stream().filter(r -> r.module().equals(module)).findFirst().orElse(null);
    }

    private LambdaQueryWrapper<DataPermission> activeGrantWrapper(String module, Long bizId, Long userId) {
        LambdaQueryWrapper<DataPermission> w = new LambdaQueryWrapper<>();
        w.eq(DataPermission::getModule, module)
                .eq(DataPermission::getBizId, bizId)
                .eq(DataPermission::getGranteeId, userId);
        LocalDate today = LocalDate.now();
        w.and(x -> x.isNull(DataPermission::getExpireDate).or().ge(DataPermission::getExpireDate, today));
        return w;
    }

    @Override
    public void assertWrite(String module, Long bizId, int requiredBit) {
        if (canWrite(module, bizId, requiredBit)) return;
        throw new BusinessException(ResultCode.FORBIDDEN.getCode(), "无权操作该数据（仅被授予查看权限）");
    }

    @Override
    public boolean canWrite(String module, Long bizId, int requiredBit) {
        if (bizId == null) return false;
        if (isAdmin()) return true;
        Long userId = uid();
        if (userId == null) return false;
        DataOwnerResolver resolver = resolver(module);
        if (resolver != null && resolver.isOwner(bizId, userId)) return true;
        DataPermission dp = dataPermissionMapper.selectOne(activeGrantWrapper(module, bizId, userId));
        return dp != null && DataPermBits.has(dp.getPermBits() == null ? 0 : dp.getPermBits(), requiredBit);
    }

    @Override
    public int effectiveBits(String module, Long bizId) {
        if (bizId == null) return 0;
        if (isAdmin()) return DataPermBits.ALL;
        Long userId = uid();
        if (userId == null) return 0;
        DataOwnerResolver resolver = resolver(module);
        if (resolver != null && resolver.isOwner(bizId, userId)) return DataPermBits.ALL;
        DataPermission dp = dataPermissionMapper.selectOne(activeGrantWrapper(module, bizId, userId));
        return dp != null && dp.getPermBits() != null ? dp.getPermBits() : 0;
    }

    @Override
    public Map<Long, Integer> permBitsMap(String module, Collection<Long> bizIds) {
        Map<Long, Integer> result = new HashMap<>();
        if (bizIds == null || bizIds.isEmpty()) return result;
        if (isAdmin()) {
            bizIds.forEach(id -> result.put(id, DataPermBits.ALL));
            return result;
        }
        Long userId = uid();
        if (userId == null) {
            bizIds.forEach(id -> result.put(id, 0));
            return result;
        }
        DataOwnerResolver resolver = resolver(module);
        Set<Long> ownerIds = resolver != null
                ? resolver.findOwnerIds(bizIds, userId)
                : Collections.emptySet();
        // 共享授权
        LambdaQueryWrapper<DataPermission> w = new LambdaQueryWrapper<>();
        w.eq(DataPermission::getModule, module)
                .eq(DataPermission::getGranteeId, userId)
                .in(DataPermission::getBizId, bizIds);
        LocalDate today = LocalDate.now();
        w.and(x -> x.isNull(DataPermission::getExpireDate).or().ge(DataPermission::getExpireDate, today));
        Map<Long, Integer> granted = dataPermissionMapper.selectList(w).stream()
                .collect(Collectors.toMap(DataPermission::getBizId,
                        d -> d.getPermBits() == null ? 0 : d.getPermBits(), (a, b) -> a | b));
        for (Long id : bizIds) {
            if (ownerIds.contains(id)) result.put(id, DataPermBits.ALL);
            else result.put(id, granted.getOrDefault(id, 0));
        }
        return result;
    }

    @Override
    public List<DataPermission> listGrants(String module, Long bizId) {
        LambdaQueryWrapper<DataPermission> w = new LambdaQueryWrapper<>();
        w.eq(DataPermission::getModule, module).eq(DataPermission::getBizId, bizId)
                .orderByAsc(DataPermission::getGranteeId);
        return dataPermissionMapper.selectList(w);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void grant(String module, Long bizId, Long granteeId, Integer permBits, LocalDate expireDate, String remark) {
        if (bizId == null || granteeId == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "数据ID与被授权人不能为空");
        }
        int bits = permBits == null ? DataPermBits.READ_ONLY : permBits;
        if (bits <= 0 || (bits & ~DataPermBits.ALL) != 0) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "权限位非法");
        }
        // 授权人必须是管理员或数据负责人
        if (!isAdmin()) {
            DataOwnerResolver resolver = resolver(module);
            Long me = uid();
            boolean owner = resolver != null && me != null && resolver.isOwner(bizId, me);
            if (!owner) {
                throw new BusinessException(ResultCode.FORBIDDEN.getCode(), "只有负责人或管理员可以授权该数据");
            }
        }
        // 不允许授权给自己（负责人天然全权）
        Long me = uid();
        if (granteeId.equals(me)) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "无需授权给自己");
        }

        User grantee = userMapper.selectById(granteeId);
        String granteeName = grantee != null ? grantee.getRealName() : null;

        LambdaQueryWrapper<DataPermission> exist = new LambdaQueryWrapper<>();
        exist.eq(DataPermission::getModule, module).eq(DataPermission::getBizId, bizId)
                .eq(DataPermission::getGranteeId, granteeId);
        DataPermission old = dataPermissionMapper.selectOne(exist);
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (old != null) {
            old.setPermBits(bits);
            old.setExpireDate(expireDate);
            old.setRemark(remark);
            old.setGranteeName(granteeName);
            dataPermissionMapper.updateById(old);
        } else {
            DataPermission dp = new DataPermission();
            dp.setModule(module);
            dp.setBizId(bizId);
            dp.setGranteeId(granteeId);
            dp.setGranteeName(granteeName);
            dp.setPermBits(bits);
            dp.setExpireDate(expireDate);
            dp.setRemark(remark);
            dp.setCompanyId(companyId == null ? 1L : companyId);
            dp.setGrantedBy(me);
            dataPermissionMapper.insert(dp);
        }
        log.info("数据授权: module={}, bizId={}, granteeId={}, bits={}", module, bizId, granteeId, bits);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void revoke(String module, Long bizId, Long grantId) {
        DataPermission dp = dataPermissionMapper.selectById(grantId);
        if (dp == null || !module.equals(dp.getModule()) || !dp.getBizId().equals(bizId)) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "授权记录不存在");
        }
        if (!isAdmin()) {
            DataOwnerResolver resolver = resolver(module);
            Long me = uid();
            boolean owner = resolver != null && me != null && resolver.isOwner(bizId, me);
            if (!owner) {
                throw new BusinessException(ResultCode.FORBIDDEN.getCode(), "只有负责人或管理员可以收回授权");
            }
        }
        dataPermissionMapper.deleteById(grantId);
        log.info("收回数据授权: id={}, module={}, bizId={}", grantId, module, bizId);
    }
}
