package com.crm.dto.system;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class PermissionCreateDTO {
    private Long parentId;
    @NotBlank(message = "权限编码不能为空")
    private String permissionCode;
    @NotBlank(message = "权限名称不能为空")
    private String permissionName;
    private String permissionType;
    private String path;
    private String routePath;
    private String apiPath;
    private String httpMethod;
    private String icon;
    private String component;
    private Integer sortOrder;
    private Integer status;
}
