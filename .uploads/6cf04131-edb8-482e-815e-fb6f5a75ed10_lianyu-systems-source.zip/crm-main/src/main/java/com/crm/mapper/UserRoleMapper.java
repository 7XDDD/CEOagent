package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.UserRole;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserRoleMapper extends BaseMapper<UserRole> {

    List<Long> findRoleIdsByUserId(@Param("userId") Long userId);

    int countUserRoleByCode(@Param("userId") Long userId, @Param("roleCode") String roleCode);

    List<Long> selectUserIdsByRoleCode(@Param("roleCode") String roleCode);

    int deleteByUserId(@Param("userId") Long userId);
}
