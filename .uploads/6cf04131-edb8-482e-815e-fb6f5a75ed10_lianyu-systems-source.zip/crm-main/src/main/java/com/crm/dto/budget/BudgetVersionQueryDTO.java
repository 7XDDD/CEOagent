package com.crm.dto.budget;

import com.crm.dto.PageQueryDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class BudgetVersionQueryDTO extends PageQueryDTO {
    private Integer fiscalYear;
    private String budgetScene;
    private Integer isActive;
    private Integer isLocked;
}
