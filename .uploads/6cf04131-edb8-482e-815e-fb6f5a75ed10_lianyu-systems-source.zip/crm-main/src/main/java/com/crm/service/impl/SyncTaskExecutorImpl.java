package com.crm.service.impl;

import com.crm.entity.SyncTaskConfig;
import com.crm.service.HrDataService;
import com.crm.service.SyncTaskExecutor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class SyncTaskExecutorImpl implements SyncTaskExecutor {

    private final HrDataService hrDataService;
    private final RestTemplate restTemplate = new RestTemplate();

    @Override
    public SyncExecutionResult execute(SyncTaskConfig task, String triggerType) {
        String syncType = task.getSyncType() != null ? task.getSyncType() : task.getTaskKey();
        try {
            switch (syncType) {
                case "org":
                    return SyncExecutionResult.hrCount(
                            hrDataService.syncOrg(),
                            String.format("组织架构同步成功：新增%d，更新%d，删除%d",
                                    0, 0, 0));
                case "employee":
                    Map<String, Integer> emp = hrDataService.syncEmployee();
                    return SyncExecutionResult.hrCount(emp,
                            String.format("员工数据同步成功：新增%d，更新%d，删除%d",
                                    emp.getOrDefault("added", 0), emp.getOrDefault("updated", 0), emp.getOrDefault("deleted", 0)));
                case "overtime":
                    int ot = hrDataService.syncOvertime();
                    return SyncExecutionResult.hrSingle(ot, "加班数据同步成功，共同步" + ot + "条");
                case "attendance":
                    int at = hrDataService.syncAttendanceCalendar();
                    return SyncExecutionResult.hrSingle(at, "考勤日历同步成功，共同步" + at + "条");
                case "leave":
                    int lv = hrDataService.syncLeave();
                    return SyncExecutionResult.hrSingle(lv, "请假数据同步成功，共同步" + lv + "条");
                case "http":
                    return executeHttp(task);
                default:
                    return SyncExecutionResult.fail("未知的同步类型：" + syncType);
            }
        } catch (Exception e) {
            log.error("执行同步任务[{}]失败：{}", task.getTaskName(), e.getMessage(), e);
            return SyncExecutionResult.fail(e.getMessage());
        }
    }

    private SyncExecutionResult executeHttp(SyncTaskConfig task) {
        String url = task.getTargetUrl();
        if (url == null || url.isEmpty()) {
            return SyncExecutionResult.fail("自定义HTTP任务未配置目标URL");
        }
        String method = task.getHttpMethod() != null ? task.getHttpMethod().toUpperCase() : "POST";
        String body = task.getRequestBody();

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = (body != null && !body.isEmpty())
                    ? new HttpEntity<>(body, headers)
                    : new HttpEntity<>(headers);

            HttpMethod httpMethod = "GET".equalsIgnoreCase(method) ? HttpMethod.GET : HttpMethod.POST;
            ResponseEntity<String> resp = restTemplate.exchange(url, httpMethod, entity, String.class);
            int status = resp.getStatusCodeValue();
            String respBody = resp.getBody();
            boolean success = status >= 200 && status < 300;
            String msg = success
                    ? "HTTP调用成功，响应码：" + status
                    : "HTTP调用失败，响应码：" + status;
            return SyncExecutionResult.http(status, respBody, success, msg);
        } catch (Exception e) {
            log.error("HTTP调用同步任务[{}]失败，URL={}：{}", task.getTaskName(), url, e.getMessage());
            return SyncExecutionResult.fail("HTTP调用失败：" + e.getMessage());
        }
    }
}
