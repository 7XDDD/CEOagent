package com.crm.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.BusinessException;
import com.crm.common.SecurityContextUtil;
import com.crm.dto.system.AddUserFromEmployeeDTO;
import com.crm.dto.system.UserCreateDTO;
import com.crm.dto.system.UserQueryDTO;
import com.crm.dto.system.UserUpdateDTO;
import com.crm.security.RolePermissionPresets;
import com.crm.entity.LoginLog;
import com.crm.entity.Org;
import com.crm.entity.Permission;
import com.crm.entity.Role;
import com.crm.entity.User;
import com.crm.entity.UserRole;
import com.crm.mapper.LoginLogMapper;
import com.crm.mapper.OrgMapper;
import com.crm.mapper.PermissionMapper;
import com.crm.mapper.RoleMapper;
import com.crm.mapper.RolePermissionMapper;
import com.crm.mapper.UserMapper;
import com.crm.mapper.UserRoleMapper;
import com.crm.service.UserService;
import com.crm.vo.system.UserVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class UserServiceImpl implements UserService {

    @Value("${crm.security.login.max-fail-count:5}")
    private int maxFailCount;

    @Value("${crm.security.login.lock-minutes:30}")
    private int lockMinutes;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private RoleMapper roleMapper;

    @Autowired
    private PermissionMapper permissionMapper;

    @Autowired
    private LoginLogMapper loginLogMapper;

    @Autowired
    private UserRoleMapper userRoleMapper;

    @Autowired
    private OrgMapper orgMapper;

    @Autowired
    private RolePermissionMapper rolePermissionMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public LoginResult login(String username, String password, String captchaKey, String captchaCode, String clientIp, String userAgent) {
        long startTime = System.currentTimeMillis();
        LoginLog loginLog = new LoginLog();
        loginLog.setUsername(username);
        loginLog.setClientIp(clientIp);
        loginLog.setIp(clientIp);
        loginLog.setUserAgent(userAgent);
        loginLog.setLoginTime(LocalDateTime.now());
        loginLog.setRequestPath("/api/auth/login");
        loginLog.setLoginType("PASSWORD");
        // 解析浏览器/操作系统
        String[] bo = LoginLogServiceImpl.parseUserAgent(userAgent);
        loginLog.setBrowser(bo[0]);
        loginLog.setOs(bo[1]);

        try {
            User user = userMapper.findByUsernameOrPhone(username);
            if (user == null) {
                user = userMapper.findByUsername(username);
            }
            if (user == null) {
                loginLog.setLoginResult("USER_NOT_EXIST");
                loginLog.setFailReason("用户不存在");
                loginLog.setStatus(0);
                loginLog.setResponseTimeMs(System.currentTimeMillis() - startTime);
                loginLogMapper.insert(loginLog);
                return LoginResult.fail(1001, "用户名或密码错误");
            }

            loginLog.setUserId(user.getId());

            if (user.getStatus() != null && user.getStatus() == 0) {
                loginLog.setLoginResult("ACCOUNT_DISABLED");
                loginLog.setFailReason("账号已被禁用");
                loginLog.setStatus(0);
                loginLog.setResponseTimeMs(System.currentTimeMillis() - startTime);
                loginLogMapper.insert(loginLog);
                return LoginResult.fail(1003, "账号已被禁用, 请联系管理员");
            }

            int failCount = user.getLoginFailCount() == null ? 0 : user.getLoginFailCount();
            LocalDateTime lockTime = user.getLockTime();

            if (failCount >= maxFailCount && lockTime != null) {
                if (lockTime.isAfter(LocalDateTime.now())) {
                    loginLog.setLoginResult("ACCOUNT_LOCKED");
                    loginLog.setFailReason("账号已锁定至" + lockTime);
                    loginLog.setStatus(0);
                    loginLog.setResponseTimeMs(System.currentTimeMillis() - startTime);
                    loginLogMapper.insert(loginLog);
                    long remainingMinutes = java.time.Duration.between(LocalDateTime.now(), lockTime).toMinutes();
                    return LoginResult.fail(1003, "账号已锁定，请" + (remainingMinutes > 0 ? remainingMinutes + "分钟后" : "稍后") + "重试");
                } else {
                    failCount = 0;
                    user.setLoginFailCount(0);
                    user.setLockTime(null);
                    userMapper.updateById(user);
                }
            }

            boolean passwordValid = passwordEncoder.matches(password, user.getPasswordHash());
            if (!passwordValid) {
                failCount = failCount + 1;
                user.setLoginFailCount(failCount);
                if (failCount >= maxFailCount) {
                    user.setLockTime(LocalDateTime.now().plusMinutes(lockMinutes));
                }
                userMapper.updateById(user);

                loginLog.setLoginResult("WRONG_PASSWORD");
                loginLog.setFailReason("密码错误 (第" + failCount + "次失败)");
                loginLog.setStatus(0);
                loginLog.setResponseTimeMs(System.currentTimeMillis() - startTime);
                loginLogMapper.insert(loginLog);
                return LoginResult.fail(1002, "用户名或密码错误");
            }

            List<Role> roles = roleMapper.findRolesByUserId(user.getId());
            List<String> roleCodes = roles.stream()
                    .map(Role::getRoleCode)
                    .collect(Collectors.toList());

            List<String> permissionCodes = permissionMapper.findPermissionCodesByUserId(user.getId());
            permissionCodes = enrichPermissionsWithParents(permissionCodes);
            // 角色兜底：若 DB crm_role_permission 缺行，按 roleCode 补齐 5 个核心业务角色权限（防 403）
            permissionCodes = new ArrayList<>(RolePermissionPresets.mergeRolePresets(roleCodes, permissionCodes));
            permissionCodes = ensureCrossModuleDependencies(permissionCodes);

            user.setLoginFailCount(0);
            user.setLockTime(null);
            user.setLastLoginTime(LocalDateTime.now());
            user.setLastLoginIp(clientIp);
            userMapper.updateById(user);

            loginLog.setLoginResult("SUCCESS");
            loginLog.setStatus(1);
            loginLog.setResponseTimeMs(System.currentTimeMillis() - startTime);
            loginLogMapper.insert(loginLog);

            return LoginResult.success(user, roleCodes, permissionCodes);

        } catch (Exception e) {
            log.error("登录过程中发生异常: username={}, ip={}", username, clientIp, e);
            loginLog.setLoginResult("SYSTEM_ERROR");
            loginLog.setFailReason("系统内部错误: " + e.getMessage());
            loginLog.setStatus(0);
            loginLog.setResponseTimeMs(System.currentTimeMillis() - startTime);
            try {
                loginLogMapper.insert(loginLog);
            } catch (Exception logEx) {
                log.error("写登录日志失败", logEx);
            }
            return LoginResult.fail(500, "系统错误, 请稍后重试");
        }
    }

    private List<String> enrichPermissionsWithParents(List<String> permissionCodes) {
        if (permissionCodes == null || permissionCodes.isEmpty()) {
            return permissionCodes;
        }
        List<Permission> allPerms = permissionMapper.selectAllActive();
        Map<Long, Permission> permMap = allPerms.stream()
                .collect(Collectors.toMap(Permission::getId, p -> p, (a, b) -> a));
        Map<String, Long> codeToIdMap = allPerms.stream()
                .collect(Collectors.toMap(Permission::getPermissionCode, Permission::getId, (a, b) -> a));

        Set<String> enriched = new LinkedHashSet<>(permissionCodes);
        for (String code : permissionCodes) {
            Long permId = codeToIdMap.get(code);
            if (permId == null) continue;
            Permission p = permMap.get(permId);
            while (p != null && p.getParentId() != null && p.getParentId() > 0) {
                Permission parent = permMap.get(p.getParentId());
                if (parent != null && parent.getPermissionCode() != null) {
                    enriched.add(parent.getPermissionCode());
                }
                p = parent;
            }
        }
        return new ArrayList<>(enriched);
    }
    /**
     * 跨模块"隐形依赖"权限补齐。
     * base 项目当前无跨模块隐形依赖，直接返回原权限列表。
     */
    private List<String> ensureCrossModuleDependencies(List<String> permissionCodes) {
        return permissionCodes;
    }

    @Override
    public Page<Map<String, Object>> pageList(UserQueryDTO query) {
        Page<Map<String, Object>> page = new Page<>(query.getPageNum(), query.getPageSize());
        Page<Map<String, Object>> result = userMapper.selectPageList(page, query);
        fillOrgPath(result.getRecords());
        return result;
    }

    @Override
    public List<Map<String, Object>> list(UserQueryDTO query) {
        Page<Map<String, Object>> page = new Page<>(1, Integer.MAX_VALUE);
        Page<Map<String, Object>> result = userMapper.selectPageList(page, query);
        fillOrgPath(result.getRecords());
        return result.getRecords();
    }

    /**
     * 为用户列表记录填充部门层级路径（如"链宇集团/技术有限公司/财务部"）
     */
    private void fillOrgPath(List<Map<String, Object>> records) {
        if (records == null || records.isEmpty()) return;
        // 查询所有组织，构建id->org映射
        List<Org> allOrgs = orgMapper.selectList(new LambdaQueryWrapper<Org>().eq(Org::getDeleted, 0));
        Map<Long, Org> orgMap = allOrgs.stream().collect(Collectors.toMap(Org::getId, o -> o, (a, b) -> a));
        // 为每个用户构建部门层级路径
        for (Map<String, Object> record : records) {
            Object deptIdObj = record.get("deptId");
            if (deptIdObj == null) {
                record.put("deptName", "-");
                continue;
            }
            Long deptId = Long.valueOf(deptIdObj.toString());
            String path = buildOrgPath(deptId, orgMap);
            record.put("deptName", path);
        }
    }

    /**
     * 构建部门层级路径（如"链宇集团/技术有限公司/财务部"）
     * ancestors格式: "0,grandparentId,parentId," 包含从根到直接父级的完整ID链
     */
    private String buildOrgPath(Long orgId, Map<Long, Org> orgMap) {
        List<String> names = new ArrayList<>();
        Org current = orgMap.get(orgId);
        if (current == null) return "-";
        // 先加入ancestors中所有祖先节点的名称（按顺序）
        String ancestors = current.getAncestors();
        if (ancestors != null && !ancestors.isEmpty()) {
            for (String part : ancestors.split(",")) {
                String p = part.trim();
                if (p.isEmpty() || "0".equals(p)) continue;
                try {
                    Long aid = Long.valueOf(p);
                    Org a = orgMap.get(aid);
                    if (a != null) names.add(a.getOrgName());
                } catch (NumberFormatException ignored) {}
            }
        }
        // 最后加入当前组织名称
        names.add(current.getOrgName());
        return names.isEmpty() ? "-" : String.join("/", names);
    }

    @Override
    public UserVO getDetail(Long id) {
        User user = userMapper.selectById(id);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }
        UserVO vo = new UserVO();
        BeanUtils.copyProperties(user, vo);
        List<Long> roleIds = userRoleMapper.findRoleIdsByUserId(id);
        vo.setRoleIdList(roleIds);
        if (!roleIds.isEmpty()) {
            List<Role> roles = roleMapper.selectBatchIds(roleIds);
            vo.setRoleNames(roles.stream().map(Role::getRoleName).collect(Collectors.joining(",")));
        }
        return vo;
    }

    @Override
    public Map<String, Object> getUserWithRoles(Long userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }
        Map<String, Object> result = new HashMap<>();
        result.put("id", user.getId());
        result.put("username", user.getUsername());
        result.put("realName", user.getRealName());
        result.put("employeeNo", user.getEmployeeNo());
        result.put("email", user.getEmail());
        result.put("phone", user.getPhone());
        result.put("avatarUrl", user.getAvatarUrl());
        result.put("gender", user.getGender());
        result.put("deptId", user.getDeptId());
        result.put("position", user.getPosition());
        result.put("userType", user.getUserType());
        result.put("status", user.getStatus());
        result.put("remark", user.getRemark());
        result.put("createTime", user.getCreateTime());
        result.put("updateTime", user.getUpdateTime());

        List<Role> roles = roleMapper.findRolesByUserId(userId);
        List<Long> roleIds = roles.stream().map(Role::getId).collect(Collectors.toList());
        result.put("roles", roles);
        result.put("roleIds", roleIds);
        return result;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void assignRoles(Long userId, List<Long> roleIds) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }
        userRoleMapper.deleteByUserId(userId);
        if (roleIds != null && !roleIds.isEmpty()) {
            saveUserRoles(userId, roleIds);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void changeStatus(Long id, Integer status) {
        User user = userMapper.selectById(id);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }
        user.setStatus(status);
        userMapper.updateById(user);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public User create(UserCreateDTO dto) {
        User existUser = userMapper.findByUsernameExist(dto.getUsername(), null);
        if (existUser != null) {
            throw new BusinessException("用户名已存在");
        }

        User user = new User();
        BeanUtils.copyProperties(dto, user);
        if (dto.getEmployeeNo() != null) {
            user.setEmployeeNo(dto.getEmployeeNo());
        }
        if (StrUtil.isNotBlank(dto.getPassword())) {
            String pwdErr = validatePasswordStrength(dto.getPassword());
            if (pwdErr != null) throw new BusinessException(pwdErr);
            user.setPasswordHash(passwordEncoder.encode(dto.getPassword()));
            user.setInitialPassword(dto.getPassword());
        } else {
            String autoPwd = generateStrongPassword(10);
            user.setPasswordHash(passwordEncoder.encode(autoPwd));
            user.setInitialPassword(autoPwd);
        }
        user.setStatus(1);
        user.setLoginFailCount(0);
        user.setPasswordLastUpdateTime(null);
        user.setNeedChangePassword(1);
        userMapper.insert(user);

        if (dto.getRoleIds() != null && !dto.getRoleIds().isEmpty()) {
            saveUserRoles(user.getId(), dto.getRoleIds());
        }
        return user;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public User update(Long id, UserUpdateDTO dto) {
        User user = userMapper.selectById(id);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }
        if (dto.getEmployeeNo() != null) {
            user.setEmployeeNo(dto.getEmployeeNo());
        }
        if (dto.getRealName() != null) {
            user.setRealName(dto.getRealName());
        }
        if (dto.getEmail() != null) {
            user.setEmail(dto.getEmail());
        }
        if (dto.getPhone() != null) {
            user.setPhone(dto.getPhone());
        }
        if (dto.getStatus() != null) {
            user.setStatus(dto.getStatus());
        }
        if (dto.getEmployeeId() != null) {
            user.setEmployeeId(dto.getEmployeeId());
        }

        LocalDateTime now = LocalDateTime.now();
        Long currentUserId = SecurityContextUtil.getCurrentUserId();

        UpdateWrapper<User> wrapper = new UpdateWrapper<>();
        wrapper.eq("id", id)
                .set("employee_no", user.getEmployeeNo())
                .set("employee_id", user.getEmployeeId())
                .set("real_name", user.getRealName())
                .set("email", user.getEmail())
                .set("phone", user.getPhone())
                .set("status", user.getStatus())
                .set("updated_by", currentUserId)
                .set("update_time", now)
                .setSql("version = IFNULL(version, 0) + 1");
        userMapper.update(null, wrapper);

        if (dto.getRoleIds() != null) {
            userRoleMapper.deleteByUserId(id);
            if (!dto.getRoleIds().isEmpty()) {
                saveUserRoles(id, dto.getRoleIds());
            }
        }
        return user;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public User update(UserUpdateDTO dto) {
        if (dto.getId() == null) {
            throw new BusinessException("用户ID不能为空");
        }
        return update(dto.getId(), dto);
    }

    private void saveUserRoles(Long userId, List<Long> roleIds) {
        for (Long roleId : roleIds) {
            UserRole ur = new UserRole();
            ur.setUserId(userId);
            ur.setRoleId(roleId);
            userRoleMapper.insert(ur);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(Long id) {
        userMapper.deleteById(id);
        userRoleMapper.deleteByUserId(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteBatch(List<Long> ids) {
        for (Long id : ids) {
            delete(id);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public User addFromEmployee(AddUserFromEmployeeDTO dto) {
        throw new BusinessException("PMT系统请直接创建用户");
    }

    @Override
    public List<Map<String, Object>> getAvailableEmployees() {
        return userMapper.selectAvailableEmployees();
    }

    @Override
    public Map<String, Object> getCurrentUserInfo(Long userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            return null;
        }
        Map<String, Object> info = new HashMap<>();
        info.put("userId", user.getId());
        info.put("username", user.getUsername());
        info.put("realName", user.getRealName());
        info.put("email", user.getEmail());
        info.put("phone", user.getPhone());
        info.put("avatar", user.getAvatarUrl());
        info.put("deptId", user.getDeptId());
        info.put("position", user.getPosition());
        info.put("userType", user.getUserType());
        info.put("employeeNo", user.getEmployeeNo());
        info.put("status", user.getStatus());
        info.put("lastLoginIp", user.getLastLoginIp());
        info.put("lastLoginTime", user.getLastLoginTime());
        boolean needChangePassword = (user.getNeedChangePassword() != null && user.getNeedChangePassword() == 1)
                || user.getPasswordLastUpdateTime() == null;
        info.put("needChangePassword", needChangePassword);

        long loginCount = loginLogMapper.countSuccessByUser(userId);
        info.put("loginCount", loginCount);

        List<Role> roles = roleMapper.findRolesByUserId(userId);
        List<String> roleCodes = roles.stream().map(Role::getRoleCode).collect(Collectors.toList());
        List<String> permissions = permissionMapper.findPermissionCodesByUserId(userId);
        permissions = enrichPermissionsWithParents(permissions);
        // 角色兜底：补齐 5 个核心业务角色预设权限（与 login 保持一致）
        permissions = new ArrayList<>(RolePermissionPresets.mergeRolePresets(roleCodes, permissions));
        permissions = ensureCrossModuleDependencies(permissions);

        info.put("roles", roleCodes);
        info.put("permissions", permissions);
        return info;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateProfile(Long userId, Map<String, String> body) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            return false;
        }
        if (body.containsKey("realName") && body.get("realName") != null) {
            user.setRealName(body.get("realName"));
        }
        if (body.containsKey("email") && body.get("email") != null) {
            user.setEmail(body.get("email"));
        }
        if (body.containsKey("phone") && body.get("phone") != null) {
            user.setPhone(body.get("phone"));
        }
        userMapper.updateById(user);
        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String changePassword(Long userId, String oldPassword, String newPassword) {
        if (oldPassword == null || oldPassword.isEmpty()) {
            return "请输入原密码";
        }
        String pwdErr = validatePasswordStrength(newPassword);
        if (pwdErr != null) return pwdErr;
        User user = userMapper.selectById(userId);
        if (user == null) {
            return "用户不存在";
        }
        if (!passwordEncoder.matches(oldPassword, user.getPasswordHash())) {
            return "原密码不正确";
        }
        user.setPasswordHash(passwordEncoder.encode(newPassword));
        user.setLoginFailCount(0);
        user.setLockTime(null);
        user.setPasswordLastUpdateTime(LocalDateTime.now());
        user.setNeedChangePassword(0);
        user.setInitialPassword(null);
        userMapper.updateById(user);
        return null;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String resetPassword(Long userId, String newPassword) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new BusinessException("用户不存在");
        }
        String resetPwd = newPassword;
        if (resetPwd == null || resetPwd.trim().isEmpty()) {
            // 未指定密码时自动生成强密码
            resetPwd = generateStrongPassword(10);
        } else {
            String pwdErr = validatePasswordStrength(resetPwd);
            if (pwdErr != null) throw new BusinessException(pwdErr);
        }
        user.setPasswordHash(passwordEncoder.encode(resetPwd));
        user.setLoginFailCount(0);
        user.setLockTime(null);
        user.setPasswordLastUpdateTime(null);
        user.setNeedChangePassword(1);
        user.setInitialPassword(resetPwd);
        userMapper.updateById(user);
        return resetPwd;
    }

    private static final String PASSWORD_UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String PASSWORD_LOWER = "abcdefghijklmnopqrstuvwxyz";
    private static final String PASSWORD_DIGIT = "0123456789";
    private static final String PASSWORD_SPECIAL = "!@#$%^&*()-_=+";
    private static final String PASSWORD_ALL = PASSWORD_UPPER + PASSWORD_LOWER + PASSWORD_DIGIT + PASSWORD_SPECIAL;
    private static final Random PASSWORD_RANDOM = new Random();

    private String generateStrongPassword(int length) {
        int len = Math.max(length, 8);
        StringBuilder sb = new StringBuilder(len);
        sb.append(PASSWORD_UPPER.charAt(PASSWORD_RANDOM.nextInt(PASSWORD_UPPER.length())));
        sb.append(PASSWORD_LOWER.charAt(PASSWORD_RANDOM.nextInt(PASSWORD_LOWER.length())));
        sb.append(PASSWORD_DIGIT.charAt(PASSWORD_RANDOM.nextInt(PASSWORD_DIGIT.length())));
        sb.append(PASSWORD_SPECIAL.charAt(PASSWORD_RANDOM.nextInt(PASSWORD_SPECIAL.length())));
        for (int i = 4; i < len; i++) {
            sb.append(PASSWORD_ALL.charAt(PASSWORD_RANDOM.nextInt(PASSWORD_ALL.length())));
        }
        char[] chars = sb.toString().toCharArray();
        for (int i = chars.length - 1; i > 0; i--) {
            int j = PASSWORD_RANDOM.nextInt(i + 1);
            char tmp = chars[i];
            chars[i] = chars[j];
            chars[j] = tmp;
        }
        return new String(chars);
    }

    /**
     * 校验密码强度：至少8位，必须包含字母、数字、特殊字符
     */
    private String validatePasswordStrength(String pwd) {
        if (pwd == null || pwd.length() < 8) {
            return "密码长度至少8位";
        }
        boolean hasLetter = false, hasDigit = false, hasSpecial = false;
        for (char c : pwd.toCharArray()) {
            if (Character.isLetter(c)) hasLetter = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else hasSpecial = true;
        }
        if (!hasLetter || !hasDigit || !hasSpecial) {
            return "密码必须包含字母、数字和特殊字符（如@#$%&*!?）";
        }
        return null;
    }

    @Override
    public long countAll() {
        return userMapper.countAll();
    }

    @Override
    public long countActive() {
        return userMapper.countActive();
    }

    @Override
    public List<User> listAllActive() {
        return userMapper.selectList(new LambdaQueryWrapper<User>()
                .eq(User::getStatus, 1)
                .eq(User::getDeleted, 0));
    }
}
