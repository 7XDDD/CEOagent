package com.crm.dto.system;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class DictCreateDTO {
    @NotBlank(message = "字典类型不能为空")
    private String dictType;
    @NotBlank(message = "字典编码不能为空")
    private String dictCode;
    @NotBlank(message = "字典名称不能为空")
    private String dictName;
    private String systemType;
    private Integer sortOrder;
    private Integer status;
    private String remark;
}
