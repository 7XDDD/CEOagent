package com.crm.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 预算计算请求DTO
 */
@Data
public class BudgetCalculateRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 预算年度 (必填)
     */
    @NotNull(message = "预算年度不能为空")
    private Integer fiscalYear;

    /**
     * 预算版本ID (必填)
     */
    @NotNull(message = "预算版本ID不能为空")
    private Long versionId;

    /**
     * 计算数据来源: LIVE=按当前最新合同/里程碑数据计算(默认); SNAPSHOT=按该版本历史快照重算
     */
    private String calcSource;

    /**
     * 按快照重算时指定科目: 101合同额 102收入 103税费 201回款; calcSource=SNAPSHOT时必填
     */
    private String catalogCode;

    /**
     * 注意: companyId不再由前端传入,而是从JWT Token中自动提取
     * 这样可以防止恶意用户篡改companyId访问其他公司数据
     */
}
