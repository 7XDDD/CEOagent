package com.crm.service;

import com.crm.entity.SyncTaskConfig;

public interface SyncTaskExecutor {

    SyncExecutionResult execute(SyncTaskConfig task, String triggerType);

    class SyncExecutionResult {
        private boolean success;
        private String message;
        private int added;
        private int updated;
        private int deleted;
        private int total;
        private Integer httpStatus;
        private String responseBody;
        private String errorMsg;

        public static SyncExecutionResult hrCount(java.util.Map<String, Integer> result, String successMsg) {
            SyncExecutionResult r = new SyncExecutionResult();
            r.success = true;
            r.message = successMsg;
            r.added = result.getOrDefault("added", 0);
            r.updated = result.getOrDefault("updated", 0);
            r.deleted = result.getOrDefault("deleted", 0);
            r.total = r.added + r.updated + r.deleted;
            return r;
        }

        public static SyncExecutionResult hrSingle(int count, String successMsg) {
            SyncExecutionResult r = new SyncExecutionResult();
            r.success = true;
            r.message = successMsg;
            r.updated = count;
            r.total = count;
            return r;
        }

        public static SyncExecutionResult fail(String errorMsg) {
            SyncExecutionResult r = new SyncExecutionResult();
            r.success = false;
            r.message = "执行失败：" + errorMsg;
            r.errorMsg = errorMsg;
            return r;
        }

        public static SyncExecutionResult http(int status, String body, boolean success, String msg) {
            SyncExecutionResult r = new SyncExecutionResult();
            r.success = success;
            r.message = msg;
            r.httpStatus = status;
            r.responseBody = body != null && body.length() > 500 ? body.substring(0, 500) + "..." : body;
            r.total = success ? 1 : 0;
            return r;
        }

        public boolean isSuccess() { return success; }
        public String getMessage() { return message; }
        public int getAdded() { return added; }
        public int getUpdated() { return updated; }
        public int getDeleted() { return deleted; }
        public int getTotal() { return total; }
        public Integer getHttpStatus() { return httpStatus; }
        public String getResponseBody() { return responseBody; }
        public String getErrorMsg() { return errorMsg; }
    }
}
