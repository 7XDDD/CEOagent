package com.crm.controller.base;

import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.annotation.OperationLog;
import com.crm.annotation.OperationLog.OperationType;
import com.crm.common.BusinessException;
import com.crm.common.Result;
import com.crm.common.ResultCode;
import com.crm.config.HrProperties;
import com.crm.dto.EmployeeQueryDTO;
import com.crm.dto.PageResult;
import com.crm.entity.Dict;
import com.crm.entity.DictItem;
import com.crm.entity.Org;
import com.crm.entity.PmtEmployee;
import com.crm.mapper.DictItemMapper;
import com.crm.mapper.DictMapper;
import com.crm.service.EmployeeService;
import com.crm.service.HrDataService;
import com.crm.service.OrgService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

@Api(tags = "员工管理")
@RestController
@RequestMapping("/base/employees")
@RequiredArgsConstructor
public class EmployeeController {

    private final EmployeeService employeeService;
    private final OrgService orgService;
    private final HrDataService hrDataService;
    private final HrProperties hrProperties;
    private final DictMapper dictMapper;
    private final DictItemMapper dictItemMapper;

    @ApiOperation("从HR系统全量同步员工数据")
    @PreAuthorize("@permissionChecker.hasPermission('crm:employee:update')")
    @OperationLog(module = "员工管理", description = "HR同步员工", type = OperationType.OTHER)
    @PostMapping("/sync")
    public Result<Map<String, Integer>> syncFromHr() {
        if (!hrProperties.isEnabled()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR系统集成未启用（crm.hr.enabled=false），无法执行同步操作");
        }
        Map<String, Integer> result = hrDataService.syncEmployee();
        return Result.success(String.format("同步成功：新增%d，更新%d，删除%d",
                result.get("added"), result.get("updated"), result.get("deleted")), result);
    }

    @ApiOperation("获取HR模式状态")
    @GetMapping("/hr-mode")
    public Result<Map<String, Object>> getHrMode() {
        Map<String, Object> result = new HashMap<>();
        result.put("hrMode", employeeService.isHrMode());
        result.put("readOnly", employeeService.isHrMode());
        return Result.success(result);
    }

    @ApiOperation("分页查询员工")
    @PreAuthorize("@permissionChecker.hasPermission('crm:employee:view')")
    @GetMapping("/page")
    public Result<PageResult<PmtEmployee>> page(EmployeeQueryDTO queryDTO) {
        if (queryDTO.getPageNum() == null) queryDTO.setPageNum(1);
        if (queryDTO.getPageSize() == null) queryDTO.setPageSize(10);
        Page<PmtEmployee> page = employeeService.pageList(queryDTO);
        PageResult<PmtEmployee> pageResult = new PageResult<>(page.getRecords(), page.getTotal(),
                queryDTO.getPageNum(), queryDTO.getPageSize());
        return Result.success(pageResult);
    }

    @ApiOperation("获取员工列表")
    @GetMapping("/list")
    public Result<List<PmtEmployee>> list(EmployeeQueryDTO queryDTO) {
        return Result.success(employeeService.listAll(queryDTO));
    }

    @ApiOperation("获取在职员工列表(下拉用)")
    @GetMapping("/active")
    public Result<List<PmtEmployee>> listActive(@RequestParam(required = false) String keyword) {
        return Result.success(employeeService.listActive(keyword));
    }

    @ApiOperation("获取员工详情")
    @GetMapping("/{id}")
    public Result<PmtEmployee> getById(@PathVariable Long id) {
        return Result.success(employeeService.getById(id));
    }

    @ApiOperation("新增员工")
    @PreAuthorize("@permissionChecker.hasPermission('crm:employee:create')")
    @OperationLog(module = "员工管理", description = "新增员工", type = OperationType.INSERT)
    @PostMapping
    public Result<PmtEmployee> create(@RequestBody PmtEmployee employee) {
        employeeService.createEmployee(employee);
        return Result.success(employee);
    }

    @ApiOperation("更新员工")
    @PreAuthorize("@permissionChecker.hasPermission('crm:employee:update')")
    @OperationLog(module = "员工管理", description = "修改员工", type = OperationType.UPDATE)
    @PutMapping("/{id:\\d+}")
    public Result<PmtEmployee> update(@PathVariable Long id, @RequestBody PmtEmployee employee) {
        employeeService.updateEmployee(id, employee);
        return Result.success(employee);
    }

    @ApiOperation("删除员工")
    @PreAuthorize("@permissionChecker.hasPermission('crm:employee:delete')")
    @OperationLog(module = "员工管理", description = "删除员工", type = OperationType.DELETE)
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
        return Result.success();
    }

    @ApiOperation("获取部门树(员工选择用)")
    @GetMapping("/department-tree")
    public Result<List<Map<String, Object>>> departmentTree() {
        List<PmtEmployee> employees = employeeService.listActive(null);
        List<Org> orgTree = orgService.getTree();

        Map<Long, List<PmtEmployee>> orgEmpMap = employees.stream()
                .filter(e -> e.getOrgId() != null)
                .collect(Collectors.groupingBy(PmtEmployee::getOrgId));

        List<Map<String, Object>> result = buildOrgTreeWithEmployees(orgTree, orgEmpMap);
        return Result.success(result);
    }

    private List<Map<String, Object>> buildOrgTreeWithEmployees(List<Org> orgs, Map<Long, List<PmtEmployee>> orgEmpMap) {
        List<Map<String, Object>> tree = new java.util.ArrayList<>();
        for (Org org : orgs) {
            Map<String, Object> node = new HashMap<>();
            node.put("id", org.getId());
            node.put("name", org.getOrgName());
            node.put("type", "org");

            List<Map<String, Object>> children = new java.util.ArrayList<>();
            if (org.getChildren() != null) {
                children.addAll(buildOrgTreeWithEmployees(org.getChildren(), orgEmpMap));
            }
            List<PmtEmployee> emps = orgEmpMap.get(org.getId());
            if (emps != null) {
                for (PmtEmployee emp : emps) {
                    Map<String, Object> empNode = new HashMap<>();
                    empNode.put("id", emp.getId());
                    empNode.put("name", emp.getEmployeeName());
                    empNode.put("jobNumber", emp.getJobNumber());
                    empNode.put("email", emp.getEmail());
                    empNode.put("mobilePhone", emp.getMobilePhone());
                    empNode.put("type", "employee");
                    children.add(empNode);
                }
            }
            if (!children.isEmpty()) {
                node.put("children", children);
            }
            tree.add(node);
        }
        return tree;
    }

    @ApiOperation("导出员工数据")
    @PreAuthorize("@permissionChecker.hasPermission('crm:employee:export')")
    @OperationLog(module = "员工管理", description = "导出员工", type = OperationType.EXPORT)
    @PostMapping("/export")
    public void export(@RequestBody(required = false) Map<String, Object> params, HttpServletResponse response) throws Exception {
        writeEmployeeExcel(response);
    }

    @ApiOperation("导出员工数据(GET)")
    @PreAuthorize("@permissionChecker.hasPermission('crm:employee:export')")
    @GetMapping("/export")
    public void exportGet(HttpServletResponse response) throws Exception {
        writeEmployeeExcel(response);
    }

    private Map<String, List<DictItem>> getEmployeeDictItems() {
        Map<String, List<DictItem>> result = new HashMap<>();
        try {
            String systemType = employeeService.isHrMode() ? "HR" : "PMT";
            // 分别查询每个字典类型，确保正确
            Dict empTypeDict = dictMapper.findByDictCodeAndSystemType("employment_type", systemType);
            Dict empStatusDict = dictMapper.findByDictCodeAndSystemType("employee_status", systemType);
            Dict consultantDict = dictMapper.findByDictCodeAndSystemType("is_consultant", systemType);

            result.put("employment_type", empTypeDict != null ?
                    dictItemMapper.findByDictId(empTypeDict.getId()).stream()
                            .filter(item -> item.getStatus() != null && item.getStatus() == 1 && item.getDeleted() == 0)
                            .collect(Collectors.toList()) : Collections.emptyList());
            result.put("employee_status", empStatusDict != null ?
                    dictItemMapper.findByDictId(empStatusDict.getId()).stream()
                            .filter(item -> item.getStatus() != null && item.getStatus() == 1 && item.getDeleted() == 0)
                            .collect(Collectors.toList()) : Collections.emptyList());
            result.put("is_consultant", consultantDict != null ?
                    dictItemMapper.findByDictId(consultantDict.getId()).stream()
                            .filter(item -> item.getStatus() != null && item.getStatus() == 1 && item.getDeleted() == 0)
                            .collect(Collectors.toList()) : Collections.emptyList());
        } catch (Exception e) {
            result.put("employment_type", Collections.emptyList());
            result.put("employee_status", Collections.emptyList());
            result.put("is_consultant", Collections.emptyList());
        }
        return result;
    }

    private void writeEmployeeExcel(HttpServletResponse response) throws Exception {
        EmployeeQueryDTO q = new EmployeeQueryDTO();
        q.setPageNum(1);
        q.setPageSize(10000);
        List<PmtEmployee> list = employeeService.pageList(q).getRecords();

        List<Org> allOrgs = orgService.listAll();
        Map<Long, String> orgIdToName = allOrgs.stream().collect(Collectors.toMap(Org::getId, Org::getOrgName, (a, b) -> a));

        Map<String, List<DictItem>> dictItems = getEmployeeDictItems();
        Map<String, String> empTypeValueToName = dictItems.get("employment_type").stream()
                .collect(Collectors.toMap(DictItem::getItemValue, DictItem::getItemName, (a, b) -> a));
        Map<String, String> empStatusValueToName = dictItems.get("employee_status").stream()
                .collect(Collectors.toMap(DictItem::getItemValue, DictItem::getItemName, (a, b) -> a));

        List<List<String>> rows = new ArrayList<>();
        rows.add(Arrays.asList("工号", "姓名", "邮箱", "手机号", "组织部门", "员工类型", "员工状态", "是否顾问", "备注"));
        for (PmtEmployee e : list) {
            rows.add(Arrays.asList(
                    e.getJobNumber() == null ? "" : e.getJobNumber(),
                    e.getEmployeeName() == null ? "" : e.getEmployeeName(),
                    e.getEmail() == null ? "" : e.getEmail(),
                    e.getMobilePhone() == null ? "" : e.getMobilePhone(),
                    e.getOrgId() != null ? orgIdToName.getOrDefault(e.getOrgId(), "") : "",
                    e.getEmploymentType() == null ? "" : empTypeValueToName.getOrDefault(e.getEmploymentType(), e.getEmploymentType()),
                    e.getWorkStatus() == null ? "" : empStatusValueToName.getOrDefault(e.getWorkStatus(), e.getWorkStatus()),
                    e.getIsConsultant() != null && e.getIsConsultant() == 1 ? "是" : "否",
                    e.getRemark() == null ? "" : e.getRemark()
            ));
        }

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        String fileName = URLEncoder.encode("员工数据", "UTF-8").replaceAll("\\+", "%20");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");

        ExcelWriter writer = ExcelUtil.getWriter();
        writer.write(rows, true);
        setHeaderStyle(writer, 9);
        writer.flush(response.getOutputStream(), true);
        writer.close();
    }

    @ApiOperation("下载员工导入模板")
    @GetMapping("/import-template")
    public void downloadTemplate(HttpServletResponse response) throws Exception {
        writeEmployeeTemplate(response);
    }

    @ApiOperation("下载员工导入模板(GET)")
    @GetMapping("/template")
    public void downloadTemplateAlias(HttpServletResponse response) throws Exception {
        writeEmployeeTemplate(response);
    }

    private void writeEmployeeTemplate(HttpServletResponse response) throws Exception {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        String fileName = URLEncoder.encode("员工导入模板", "UTF-8").replaceAll("\\+", "%20");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");

        // 获取组织名称列表
        List<Org> allOrgs = orgService.listAll();
        List<String> orgNames = allOrgs.stream()
                .map(Org::getOrgName)
                .filter(name -> name != null && !name.isEmpty())
                .distinct()
                .collect(Collectors.toList());

        // 获取员工类型和状态字典
        Map<String, List<DictItem>> dictItems = getEmployeeDictItems();
        List<DictItem> empTypeItems = dictItems.get("employment_type");
        List<DictItem> empStatusItems = dictItems.get("employee_status");

        List<String> empTypeNames = empTypeItems.stream().map(DictItem::getItemName).collect(Collectors.toList());
        List<String> empStatusNames = empStatusItems.stream().map(DictItem::getItemName).collect(Collectors.toList());

        // 默认示例值
        String defaultOrgName = orgNames.isEmpty() ? "总公司" : orgNames.get(0);
        String defaultTypeName = empTypeNames.isEmpty() ? "全职" : empTypeNames.get(0);
        String defaultStatusName = empStatusNames.isEmpty() ? "在职" : empStatusNames.get(0);

        ExcelWriter writer = ExcelUtil.getWriter();
        List<List<String>> rows = new ArrayList<>();
        rows.add(Arrays.asList("工号*", "姓名*", "邮箱", "手机号", "组织名称*", "员工类型", "员工状态", "是否顾问(是/否)", "备注"));
        rows.add(Arrays.asList("E001", "张三", "zhangsan@", "NOkT4YYwjyD", defaultOrgName, defaultTypeName, defaultStatusName, "否", ""));
        if (orgNames.size() > 1) {
            rows.add(Arrays.asList("E002", "李四", "lisi@", "pPEDIiA7nXf", orgNames.size() > 1 ? orgNames.get(1) : defaultOrgName,
                    empTypeNames.size() > 1 ? empTypeNames.get(1) : defaultTypeName,
                    defaultStatusName, "是", ""));
        }
        writer.write(rows, true);
        setHeaderStyle(writer, 9);

        Sheet sheet = writer.getSheet();
        DataValidationHelper validationHelper = sheet.getDataValidationHelper();

        // 组织名称下拉验证（第5列，索引4）
        if (!orgNames.isEmpty()) {
            try {
                String[] orgNameArr = orgNames.toArray(new String[0]);
                DataValidationConstraint constraint = validationHelper.createExplicitListConstraint(orgNameArr);
                CellRangeAddressList addressList = new CellRangeAddressList(2, 1000, 4, 4);
                DataValidation validation = validationHelper.createValidation(constraint, addressList);
                validation.setShowErrorBox(true);
                validation.setErrorStyle(DataValidation.ErrorStyle.STOP);
                validation.createErrorBox("输入错误", "请从下拉列表中选择有效的组织名称");
                validation.setShowPromptBox(true);
                validation.createPromptBox("组织名称", "请选择所属组织");
                sheet.addValidationData(validation);
            } catch (Exception e) {
                // 下拉验证创建失败不影响模板生成
            }
        }

        // 员工类型下拉验证（第6列，索引5）
        if (!empTypeNames.isEmpty()) {
            try {
                String[] typeNameArr = empTypeNames.toArray(new String[0]);
                DataValidationConstraint constraint = validationHelper.createExplicitListConstraint(typeNameArr);
                CellRangeAddressList addressList = new CellRangeAddressList(2, 1000, 5, 5);
                DataValidation validation = validationHelper.createValidation(constraint, addressList);
                validation.setShowErrorBox(true);
                validation.setErrorStyle(DataValidation.ErrorStyle.STOP);
                validation.createErrorBox("输入错误", "请从下拉列表中选择有效的员工类型\n有效类型：" + String.join("、", empTypeNames));
                validation.setShowPromptBox(true);
                validation.createPromptBox("员工类型", "请选择员工类型");
                sheet.addValidationData(validation);
            } catch (Exception e) {
                // 下拉验证创建失败不影响模板生成
            }
        }

        // 员工状态下拉验证（第7列，索引6）
        if (!empStatusNames.isEmpty()) {
            try {
                String[] statusNameArr = empStatusNames.toArray(new String[0]);
                DataValidationConstraint constraint = validationHelper.createExplicitListConstraint(statusNameArr);
                CellRangeAddressList addressList = new CellRangeAddressList(2, 1000, 6, 6);
                DataValidation validation = validationHelper.createValidation(constraint, addressList);
                validation.setShowErrorBox(true);
                validation.setErrorStyle(DataValidation.ErrorStyle.STOP);
                validation.createErrorBox("输入错误", "请从下拉列表中选择有效的员工状态\n有效状态：" + String.join("、", empStatusNames));
                validation.setShowPromptBox(true);
                validation.createPromptBox("员工状态", "请选择员工状态");
                sheet.addValidationData(validation);
            } catch (Exception e) {
                // 下拉验证创建失败不影响模板生成
            }
        }

        // 是否顾问下拉验证（第8列，索引7）
        try {
            String[] consultantArr = new String[]{"是", "否"};
            DataValidationConstraint constraint = validationHelper.createExplicitListConstraint(consultantArr);
            CellRangeAddressList addressList = new CellRangeAddressList(2, 1000, 7, 7);
            DataValidation validation = validationHelper.createValidation(constraint, addressList);
            validation.setShowErrorBox(true);
            validation.setErrorStyle(DataValidation.ErrorStyle.STOP);
            validation.createErrorBox("输入错误", "请选择 是 或 否");
            sheet.addValidationData(validation);
        } catch (Exception e) {
            // 下拉验证创建失败不影响模板生成
        }

        // 设置列宽
        sheet.setColumnWidth(0, 3000);
        sheet.setColumnWidth(1, 3000);
        sheet.setColumnWidth(2, 5000);
        sheet.setColumnWidth(3, 4000);
        sheet.setColumnWidth(4, 5000);
        sheet.setColumnWidth(5, 3500);
        sheet.setColumnWidth(6, 3000);
        sheet.setColumnWidth(7, 3500);
        sheet.setColumnWidth(8, 5000);

        writer.flush(response.getOutputStream(), true);
        writer.close();
    }

    @ApiOperation("导入员工数据")
    @PreAuthorize("@permissionChecker.hasPermission('crm:employee:import')")
    @OperationLog(module = "员工管理", description = "导入员工", type = OperationType.IMPORT)
    @PostMapping("/import-excel")
    public Result<Map<String, Object>> importExcel(@RequestParam("file") MultipartFile file) {
        if (employeeService.isHrMode()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR集成模式下不允许导入");
        }
        Map<String, Object> result = new HashMap<>();
        int inserted = 0, updated = 0, failed = 0;
        StringBuilder errMsg = new StringBuilder();

        try (InputStream in = file.getInputStream()) {
            List<List<Object>> lines = ExcelUtil.getReader(in).read();
            if (lines == null || lines.size() <= 1) {
                result.put("inserted", 0); result.put("updated", 0); result.put("failed", 0);
                result.put("message", "文件为空或无数据");
                return Result.success(result);
            }

            List<Org> allOrgs = orgService.listAll();
            // 组织名称 -> Org 映射（名称可能重复，取第一个）
            Map<String, Org> nameToOrg = allOrgs.stream()
                    .filter(o -> o.getOrgName() != null)
                    .collect(Collectors.toMap(Org::getOrgName, o -> o, (a, b) -> a));
            // 同时保留编码映射，兼容旧格式
            Map<String, Org> codeToOrg = allOrgs.stream()
                    .filter(o -> o.getOrgCode() != null)
                    .collect(Collectors.toMap(Org::getOrgCode, o -> o, (a, b) -> a));

            // 获取员工类型和状态字典，构建名称->值映射
            Map<String, List<DictItem>> dictItems = getEmployeeDictItems();
            Map<String, String> empTypeNameToValue = dictItems.get("employment_type").stream()
                    .collect(Collectors.toMap(DictItem::getItemName, DictItem::getItemValue, (a, b) -> a));
            Map<String, String> empStatusNameToValue = dictItems.get("employee_status").stream()
                    .collect(Collectors.toMap(DictItem::getItemName, DictItem::getItemValue, (a, b) -> a));
            // 同时构建值->值映射（兼容直接传编码的情况）
            for (DictItem item : dictItems.get("employment_type")) {
                empTypeNameToValue.putIfAbsent(item.getItemValue(), item.getItemValue());
            }
            for (DictItem item : dictItems.get("employee_status")) {
                empStatusNameToValue.putIfAbsent(item.getItemValue(), item.getItemValue());
            }

            List<PmtEmployee> existingEmps = employeeService.listAll(new EmployeeQueryDTO());
            Map<String, PmtEmployee> jobNumMap = existingEmps.stream()
                    .filter(e -> e.getJobNumber() != null)
                    .collect(Collectors.toMap(PmtEmployee::getJobNumber, e -> e, (a, b) -> a));

            for (int i = 1; i < lines.size(); i++) {
                List<Object> row = lines.get(i);
                if (row == null || row.isEmpty()) continue;
                try {
                    String jobNumber = getCellStr(row, 0);
                    String name = getCellStr(row, 1);
                    if (jobNumber.isEmpty() && name.isEmpty()) continue;
                    if (jobNumber.isEmpty() || name.isEmpty()) { failed++; errMsg.append("第").append(i+1).append("行：工号或姓名为空; "); continue; }

                    PmtEmployee emp = jobNumMap.getOrDefault(jobNumber, new PmtEmployee());
                    boolean isNew = emp.getId() == null;
                    emp.setJobNumber(jobNumber);
                    emp.setEmployeeName(name);
                    emp.setEmail(getCellStr(row, 2));
                    emp.setMobilePhone(getCellStr(row, 3));

                    String orgNameOrCode = getCellStr(row, 4);
                    if (!orgNameOrCode.isEmpty()) {
                        // 先按名称匹配，再按编码匹配
                        Org org = nameToOrg.get(orgNameOrCode);
                        if (org == null) {
                            org = codeToOrg.get(orgNameOrCode);
                        }
                        if (org != null) {
                            emp.setOrgId(org.getId());
                            emp.setOrgName(org.getOrgName());
                        } else {
                            failed++;
                            errMsg.append("第").append(i+1).append("行：组织[").append(orgNameOrCode).append("]不存在; ");
                            continue;
                        }
                    }

                    String empTypeName = getCellStr(row, 5);
                    if (!empTypeName.isEmpty()) {
                        String empTypeValue = empTypeNameToValue.get(empTypeName);
                        if (empTypeValue != null) {
                            emp.setEmploymentType(empTypeValue);
                        } else {
                            failed++;
                            errMsg.append("第").append(i+1).append("行：员工类型[").append(empTypeName).append("]无效; ");
                            continue;
                        }
                    }

                    String workStatusName = getCellStr(row, 6);
                    if (!workStatusName.isEmpty()) {
                        String workStatusValue = empStatusNameToValue.get(workStatusName);
                        if (workStatusValue != null) {
                            emp.setWorkStatus(workStatusValue);
                        } else {
                            failed++;
                            errMsg.append("第").append(i+1).append("行：员工状态[").append(workStatusName).append("]无效; ");
                            continue;
                        }
                    }

                    String isConsultant = getCellStr(row, 7);
                    emp.setIsConsultant("是".equals(isConsultant) || "1".equals(isConsultant) || "YES".equalsIgnoreCase(isConsultant) ? 1 : 0);
                    emp.setRemark(getCellStr(row, 8));
                    if (isNew) {
                        if (emp.getWorkStatus() == null || emp.getWorkStatus().isEmpty()) {
                            emp.setWorkStatus("ACTIVE");
                        }
                        employeeService.createEmployee(emp);
                        inserted++;
                    } else {
                        employeeService.updateEmployee(emp.getId(), emp);
                        updated++;
                    }
                } catch (Exception e) {
                    failed++;
                    errMsg.append("第").append(i+1).append("行：").append(e.getMessage()).append("; ");
                }
            }
            result.put("inserted", inserted);
            result.put("updated", updated);
            result.put("failed", failed);
            result.put("message", errMsg.length() > 0 ? errMsg.toString() : "导入成功");
        } catch (Exception e) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "导入失败: " + e.getMessage());
        }
        return Result.success(result);
    }

    private String getCellStr(List<Object> row, int idx) {
        if (idx >= row.size()) return "";
        Object v = row.get(idx);
        return v == null ? "" : String.valueOf(v).trim();
    }

    private void setHeaderStyle(ExcelWriter writer, int colCount) {
        for (int i = 0; i < colCount; i++) writer.setColumnWidth(i, 18);
        CellStyle headerStyle = writer.getWorkbook().createCellStyle();
        Font font = writer.getWorkbook().createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        writer.getOrCreateRow(0).cellIterator().forEachRemaining(c -> c.setCellStyle(headerStyle));
    }
}
