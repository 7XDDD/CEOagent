package com.crm.vo.system;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class DictItemVO {
    private Long id;
    private Long dictId;
    private String itemCode;
    private String itemName;
    private String itemValue;
    private Integer sortOrder;
    private Integer status;
    private String remark;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
}
