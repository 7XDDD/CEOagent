package com.crm.vo.budget;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class BudgetSheetSummaryVO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long contractCount;

    private BigDecimal totalContractAmount;

    private BigDecimal totalBudgetAmount;

    private BigDecimal[] monthAmounts;

    private BigDecimal[] quarterAmounts;

    public BudgetSheetSummaryVO() {
        this.contractCount = 0L;
        this.totalContractAmount = BigDecimal.ZERO;
        this.totalBudgetAmount = BigDecimal.ZERO;
        this.monthAmounts = new BigDecimal[13];
        this.quarterAmounts = new BigDecimal[5];
        for (int i = 1; i <= 12; i++) {
            this.monthAmounts[i] = BigDecimal.ZERO;
        }
        for (int i = 1; i <= 4; i++) {
            this.quarterAmounts[i] = BigDecimal.ZERO;
        }
    }
}
