package com.crm.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@TableName("crm_contract")
public class Contract implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    private Long parentId;

    private String contractNo;

    private String subContractNo;

    private String projectCode;

    private String projectName;

    private String contractName;

    private Long customerId;

    private String customerCode;

    private String customerName;

    private Long contractTypeId;

    private String contractTypeCode;

    private String contractType;

    private Long orgId;

    private String productLineCode;

    private String productLine;

    private String manager;

    private String salesManager;

    private BigDecimal contractAmount;

    private LocalDate signDate;

    @TableField("expected_sign_date")
    private LocalDate expectedSignDate;

    private String contractStatus;
    
    @TableField("contract_create_time")
    private LocalDate contractCreateTime;
    
    @TableField("contract_complete_time")
    private LocalDate contractCompleteTime;
    
    private String sourceType;

    private String sourceFileName;

    private String remark;

    private Long ownerId;

    private Long deptId;

    @TableField(value = "created_by", fill = FieldFill.INSERT)
    private Long createdBy;

    @TableField(value = "updated_by", fill = FieldFill.INSERT)
    private Long updatedBy;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    @Version
    @TableField(fill = FieldFill.INSERT)
    private Integer version = 0;

    @TableLogic
    @TableField(fill = FieldFill.INSERT)
    private Integer deleted = 0;

    @TableField(exist = false)
    private String contractTypeName;
    
    @TableField(exist = false)
    private String stockFlag;

    @TableField(exist = false)
    private BigDecimal invoicedAmount;

    @TableField(exist = false)
    private BigDecimal uninvoicedAmount;

    @TableField(exist = false)
    private String invoiceStatus;
    
    public String getStockFlag() {
        return stockFlag;
    }
    
    public void setStockFlag(String stockFlag) {
        this.stockFlag = stockFlag;
    }
    
    public LocalDate getContractCreateTime() {
        return contractCreateTime;
    }
    
    public void setContractCreateTime(LocalDate contractCreateTime) {
        this.contractCreateTime = contractCreateTime;
    }
    
    public LocalDate getContractCompleteTime() {
        return contractCompleteTime;
    }
    
    public void setContractCompleteTime(LocalDate contractCompleteTime) {
        this.contractCompleteTime = contractCompleteTime;
    }
    
}
