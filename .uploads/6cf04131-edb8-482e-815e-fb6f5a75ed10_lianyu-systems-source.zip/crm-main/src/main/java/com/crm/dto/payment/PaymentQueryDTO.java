package com.crm.dto.payment;

import lombok.Data;

/**
 * 回款记录查询条件
 * 数据来源：已签订合同（SIGNED）的收款里程碑
 */
@Data
public class PaymentQueryDTO {

    private Integer pageNum = 1;
    private Integer pageSize = 10;

    /** 数据范围：all=全部，mine=我的回款，viewable=我可以查看的回款 */
    private String scope;

    /** 关键字：合同编号 / 合同名称 / 客户名称 */
    private String keyword;

    /** 回款状态：UNPAID=未回款，PARTIAL=部分回款，PAID=已回款，OVERDUE=已逾期 */
    private String paymentStatus;

    /** 客户ID */
    private Long customerId;

    /** 产品线 */
    private String productLine;

    /** 计划回款日期起（yyyy-MM-dd） */
    private String expectedDateFrom;

    /** 计划回款日期止（yyyy-MM-dd） */
    private String expectedDateTo;
}
