package com.crm.vo;

import com.crm.entity.PmtCustomerAddress;
import com.crm.entity.PmtCustomerContact;
import com.crm.entity.PmtCustomerFollower;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class CustomerVO implements Serializable {
    private Long id;
    private String customerCode;
    private String customerName;
    private String standardName;
    private String customerShortName;
    private String customerAddress;
    private String mapLocation;
    private String customerType;
    private String customerLevel;
    private String customerSource;
    private String customerClassify;
    private String customerScale;
    private String customerNature;
    private String customerStatus;
    private String callStatus;
    private String customerIndustry;
    private String industry;
    private String industryL1;
    private String industryL2;
    private String industryL3;
    private String region;
    private String province;
    private String city;
    private String listingStatus;
    private String revenueYear;
    private String profit;
    private String revenueScale;
    private String marketValue;
    private String employeeCount;
    private String cooperationStatus;
    private String mainProduct;
    private String developmentStage;
    private BigDecimal totalSales;
    private LocalDate firstOrderDate;
    private String highestCustomerRelation;
    private String ongoingOpportunity;
    private String matchStatus;
    private String website;
    private String dataSource;
    private String companyProduct;
    private String companyTel;
    private String salesman;
    private String originalSalesman;
    private String industryManager;
    private String csoTrainingClass;
    private String mainContact;
    private String secondContact;
    private Long managerId;
    private String managerName;
    private Long followerId;
    private String followerName;
    private String contactName;
    private String contactPosition;
    private String contactMobile;
    private String contactTel;
    private String contactEmail;
    private String contactWechat;
    private String contactRemark;
    private String unifiedSocialCredit;
    private String taxNumber;
    private String contactPerson;
    private String contactPhone;
    private String address;
    private String registerAddress;
    private String creditLevel;
    private String bankName;
    private String bankAccount;
    private Long parentId;
    private String status;
    private String dataStatus;
    private Integer statusValue;
    private String remark;
    private String customerTags;
    private Integer dealFlag;
    private Integer inPublicSea;
    private LocalDateTime lastFollowTime;
    private LocalDateTime recycleTime;
    private Long tenantId;
    private String createdBy;
    private String updatedBy;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    private List<PmtCustomerAddress> addresses;
    private List<PmtCustomerContact> contacts;
    private List<PmtCustomerFollower> followers;

    /** 当前登录用户对该客户的有效数据权限位(1看2改4删, 7全权, 0无) */
    private Integer permBits;

    public void setStatus(String status) {
        this.status = status;
        if ("ACTIVE".equals(status)) {
            this.statusValue = 1;
        } else if ("INACTIVE".equals(status)) {
            this.statusValue = 0;
        } else {
            this.statusValue = null;
        }
    }

    @JsonIgnore
    public String getStatusForDb() {
        if (this.statusValue != null) {
            return this.statusValue == 1 ? "ACTIVE" : "INACTIVE";
        }
        return this.status;
    }
}
