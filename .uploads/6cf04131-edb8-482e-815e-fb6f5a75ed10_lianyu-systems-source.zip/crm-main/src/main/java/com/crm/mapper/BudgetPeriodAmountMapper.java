package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.BudgetPeriodAmount;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Delete;

import java.util.List;

@Mapper
public interface BudgetPeriodAmountMapper extends BaseMapper<BudgetPeriodAmount> {

    @Delete("DELETE FROM crm_budget_period_amount WHERE company_id = #{companyId} AND fiscal_year = #{fiscalYear}")
    int physicalDeleteByCompanyYear(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);
    
    @Delete("DELETE FROM crm_budget_period_amount WHERE budget_sheet_id IN (SELECT id FROM crm_budget_sheet WHERE company_id = #{companyId} AND fiscal_year = #{fiscalYear} AND version_id = #{versionId})")
    int physicalDeleteByVersion(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("versionId") Long versionId);

    @Delete("DELETE FROM crm_budget_period_amount WHERE budget_sheet_id IN (SELECT id FROM (SELECT id FROM crm_budget_sheet WHERE company_id = #{companyId} AND fiscal_year = #{fiscalYear} AND version_id = #{versionId} AND catalog_code = #{catalogCode}) AS tmp_sheet)")
    int physicalDeleteByVersionAndCatalog(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("versionId") Long versionId, @Param("catalogCode") String catalogCode);

    List<BudgetPeriodAmount> selectBySheetId(@Param("sheetId") Long sheetId);

    List<BudgetPeriodAmount> selectBySheetIds(@Param("sheetIds") List<Long> sheetIds);

    List<BudgetPeriodAmount> selectBySheetIdsAndPeriod(@Param("sheetIds") List<Long> sheetIds, @Param("periodCode") String periodCode);

    List<BudgetPeriodAmount> selectByVersion(@Param("companyId") Long companyId, @Param("versionId") Long versionId);

    List<BudgetPeriodAmount> listMonthlyBySheetIds(@Param("sheetIds") List<Long> sheetIds);
}