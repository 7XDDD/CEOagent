package com.crm.dto.system;

import lombok.Data;

@Data
public class DictItemUpdateDTO {
    private String itemCode;
    private String itemName;
    private String itemValue;
    private Integer sortOrder;
    private Integer status;
    private String remark;
}
