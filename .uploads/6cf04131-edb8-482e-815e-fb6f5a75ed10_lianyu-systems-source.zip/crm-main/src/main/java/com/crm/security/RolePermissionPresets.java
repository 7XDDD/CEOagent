package com.crm.security;

import java.util.*;

/**
 * 核心业务角色的预设权限码映射（仅保留 base 项目实际存在的功能权限）。
 *
 * 设计原则：
 *  1. admin/super_admin 拥有全部权限，不在本兜底范围。
 *  2. 兜底触发条件：DB 返回 null 或空集合（无权限记录）时按 roleCodes 注入预设；
 *     当 DB 返回非空集合时，严格尊重 DB 配置，不私自膨胀权限。
 *  3. 所有权限码统一使用 base: 前缀。
 */
public final class RolePermissionPresets {

    private RolePermissionPresets() {}

    private static final Map<String, Set<String>> ROLE_PERMS = new LinkedHashMap<>();

    /** 普通员工：可查看组织架构和员工信息 */
    private static final Set<String> EMPLOYEE = new LinkedHashSet<>(Arrays.asList(
            "crm:home",
            "crm:org:view",
            "crm:employee:view"
    ));

    /** 项目成员：同员工 */
    private static final Set<String> MEMBER = new LinkedHashSet<>(EMPLOYEE);

    /** 项目经理/管理员：可管理组织架构和员工 */
    private static final Set<String> PM = new LinkedHashSet<>(Arrays.asList(
            "crm:home",
            "crm:org:view", "crm:org:create", "crm:org:update", "crm:org:delete",
            "crm:org:status", "crm:org:import", "crm:org:export",
            "crm:employee:view", "crm:employee:create", "crm:employee:update",
            "crm:employee:delete", "crm:employee:import", "crm:employee:export"
    ));

    private static final Set<String> MANAGER = new LinkedHashSet<>(PM);

    /** 财务人员：可查看组织和员工 */
    private static final Set<String> FINANCE = new LinkedHashSet<>(Arrays.asList(
            "crm:home",
            "crm:org:view",
            "crm:employee:view"
    ));

    static {
        ROLE_PERMS.put("crm_PM",       Collections.unmodifiableSet(PM));
        ROLE_PERMS.put("crm_MANAGER",  Collections.unmodifiableSet(MANAGER));
        ROLE_PERMS.put("crm_FINANCE",  Collections.unmodifiableSet(FINANCE));
        ROLE_PERMS.put("crm_MEMBER",   Collections.unmodifiableSet(MEMBER));
        ROLE_PERMS.put("crm_EMPLOYEE", Collections.unmodifiableSet(EMPLOYEE));
    }

    public static Set<String> mergeRolePresets(Collection<String> roleCodes,
                                               Collection<String> permissions) {
        Set<String> result = new LinkedHashSet<>();
        boolean dbEmpty = (permissions == null) || permissions.isEmpty();
        if (dbEmpty) {
            if (roleCodes != null) {
                for (String rc : roleCodes) {
                    if (rc == null) continue;
                    Set<String> preset = ROLE_PERMS.get(rc);
                    if (preset != null) result.addAll(preset);
                }
            }
            return result;
        }
        result.addAll(permissions);
        return result;
    }

    public static Set<String> presetRoleCodes() {
        return Collections.unmodifiableSet(ROLE_PERMS.keySet());
    }
}
