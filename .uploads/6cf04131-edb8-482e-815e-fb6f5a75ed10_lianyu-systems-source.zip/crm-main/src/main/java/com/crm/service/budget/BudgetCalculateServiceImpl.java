package com.crm.service.budget;

import com.crm.common.BusinessException;
import com.crm.common.ResultCode;
import com.crm.dto.BudgetCalculateRequest;
import com.crm.entity.BudgetLine;
import com.crm.entity.BudgetPeriod;
import com.crm.entity.BudgetPeriodAmount;
import com.crm.entity.BudgetSheet;
import com.crm.entity.BudgetVersion;
import com.crm.entity.Contract;
import com.crm.mapper.BudgetLineMapper;
import com.crm.mapper.BudgetPeriodAmountMapper;
import com.crm.mapper.BudgetPeriodMapper;
import com.crm.mapper.BudgetVersionMapper;
import com.crm.mapper.budget.BudgetSheetMapper;
import com.crm.mapper.contract.ContractMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 合同预算计算服务（精简版）
 * 仅计算"合同额预算"（科目编码 101）：
 * 取本会计年度签约（或预计签约）的有效合同，将合同额全额归属到签约月份，
 * 生成 预算单(BudgetSheet) + 单行预算明细(BudgetLine, SIGN) + 月度期间金额(BudgetPeriodAmount)。
 * 直接读取实时合同数据，不使用快照，也不做收入/税费/回款等其他科目预算。
 */
@Service
public class BudgetCalculateServiceImpl implements BudgetCalculateService {

    private static final Logger log = LoggerFactory.getLogger(BudgetCalculateServiceImpl.class);

    private static final String CATALOG_CODE_CONTRACT_AMOUNT = "101";
    private static final Long CATALOG_ID_CONTRACT_AMOUNT = 1L;
    private static final String PERIOD_TYPE_MONTHLY = "MONTHLY";

    @Autowired
    private BudgetVersionMapper versionMapper;
    @Autowired
    private BudgetPeriodMapper periodMapper;
    @Autowired
    private BudgetPeriodAmountMapper periodAmountMapper;
    @Autowired
    private BudgetLineMapper lineMapper;
    @Autowired
    private BudgetSheetMapper sheetMapper;
    @Autowired
    private ContractMapper contractMapper;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String calculateBudget(Long companyId, BudgetCalculateRequest request) {
        int fiscalYear = request.getFiscalYear() != null ? request.getFiscalYear() : 0;
        Long versionId = request.getVersionId();

        if (versionId == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "预算版本ID不能为空");
        }
        BudgetVersion version = versionMapper.selectById(versionId);
        if (version == null || version.getDeleted() == 1) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "预算版本不存在");
        }
        if (version.getIsLocked() != null && version.getIsLocked() == 1) {
            throw new BusinessException(ResultCode.FORBIDDEN.getCode(), "该预算版本已锁定，不能重新计算");
        }
        if (version.getCompanyId() != null && !version.getCompanyId().equals(companyId)) {
            throw new BusinessException(ResultCode.FORBIDDEN.getCode(), "无权操作该版本");
        }

        log.info("开始计算合同额预算, companyId={}, fiscalYear={}, versionId={}", companyId, fiscalYear, versionId);

        LocalDate fiscalYearStart = LocalDate.of(fiscalYear, 1, 1);

        // 确保12个月度期间存在（不存在则自动补齐）
        Map<Integer, BudgetPeriod> monthToPeriod = ensureMonthlyPeriods(companyId, fiscalYear);

        // 清空该版本历史预算数据（仅有合同额预算）
        periodAmountMapper.physicalDeleteByVersion(companyId, fiscalYear, versionId);
        lineMapper.physicalDeleteByVersion(companyId, fiscalYear, versionId);
        sheetMapper.physicalDeleteByVersion(companyId, fiscalYear, versionId);

        List<Contract> contracts = contractMapper.findForContractBudget(companyId, fiscalYear);
        log.info("合同额预算合同数: {}", contracts.size());

        int sheetCount = 0;
        List<BudgetPeriodAmount> batchAmounts = new ArrayList<>();

        for (Contract contract : contracts) {
            String normStatus = normalizeStatus(contract.getContractStatus());
            String stockFlag = determineStockFlag(contract, fiscalYearStart);

            // 归属月份：优先签约日期，其次预计签约日期，默认1月
            LocalDate signBaseDate = null;
            int contractMonth = 1;
            String dateSource = "默认";
            if (contract.getSignDate() != null && contract.getSignDate().getYear() == fiscalYear) {
                signBaseDate = contract.getSignDate();
                contractMonth = signBaseDate.getMonthValue();
                dateSource = "签约日期";
            } else if (contract.getExpectedSignDate() != null && contract.getExpectedSignDate().getYear() == fiscalYear) {
                signBaseDate = contract.getExpectedSignDate();
                contractMonth = signBaseDate.getMonthValue();
                dateSource = "预计签约日期";
            }

            BigDecimal contractAmtYuan = nvl(contract.getContractAmount());
            String contractType = contract.getContractType();

            BudgetSheet sheet = new BudgetSheet();
            sheet.setCompanyId(companyId);
            sheet.setFiscalYear(fiscalYear);
            sheet.setVersionId(versionId);
            sheet.setCatalogId(CATALOG_ID_CONTRACT_AMOUNT);
            sheet.setCatalogCode(CATALOG_CODE_CONTRACT_AMOUNT);
            sheet.setContractId(contract.getId());
            sheet.setContractNo(contract.getContractNo());
            sheet.setContractName(contract.getContractName());
            sheet.setProjectCode(contract.getProjectCode());
            sheet.setProjectName(contract.getProjectName());
            sheet.setCustomerId(contract.getCustomerId());
            sheet.setCustomerName(contract.getCustomerName());
            sheet.setContractTypeId(contract.getContractTypeId());
            sheet.setContractType(contractType);
            sheet.setContractTypeName(contractType);
            sheet.setProductLine(contract.getProductLine());
            sheet.setOrgId(contract.getOrgId());
            sheet.setProductLineId(contract.getOrgId());
            sheet.setStockFlag(stockFlag);
            sheet.setManager(contract.getManager());
            sheet.setSalesManager(contract.getSalesManager());
            sheet.setContractStatus(normStatus);
            sheet.setApprovalStatus("DRAFT");
            sheet.setIsSummaryRow(0);
            sheet.setTotalAmount(BigDecimal.ZERO);
            sheet.setCalcRule("合同额预算");
            sheet.setContractAmount(contractAmtYuan);
            sheetMapper.insert(sheet);

            BudgetLine line = new BudgetLine();
            line.setBudgetSheetId(sheet.getId());
            line.setCompanyId(companyId);
            line.setFiscalYear(fiscalYear);
            line.setVersionId(versionId);
            line.setMilestoneId(0L);
            line.setMilestoneCode("SIGN");
            line.setLineNo(0);
            line.setPaymentRatio(BigDecimal.ONE);
            line.setContractAmount(contractAmtYuan);
            line.setLineAmount(contractAmtYuan);
            line.setTaxRate(BigDecimal.ZERO);
            line.setSurtaxRate(BigDecimal.ZERO);
            line.setCalcFormula("合同额(万元) = " + toWan(contractAmtYuan).setScale(6, RoundingMode.HALF_UP)
                    + ", 归属月份: " + contractMonth + "月 (依据" + dateSource + ")");
            lineMapper.insert(line);

            if (contractMonth >= 1 && contractMonth <= 12) {
                BudgetPeriod period = monthToPeriod.get(contractMonth);
                if (period != null) {
                    batchAmounts.add(buildPeriodAmount(line.getId(), sheet.getId(), companyId, fiscalYear, versionId,
                            period, "M" + contractMonth, contractAmtYuan));
                }
            }

            sheet.setTotalAmount(contractAmtYuan);
            sheetMapper.updateById(sheet);
            sheetCount++;
        }

        for (BudgetPeriodAmount pa : batchAmounts) {
            periodAmountMapper.insert(pa);
        }

        String resultMsg = "合同额预算计算完成：" + contracts.size() + " 份合同/" + sheetCount
                + " 条预算行，期间数据 " + batchAmounts.size() + " 条";
        log.info(resultMsg);
        return resultMsg;
    }

    /**
     * 确保指定公司、年度的12个月度期间存在，返回 月份(1-12) -> BudgetPeriod
     */
    private Map<Integer, BudgetPeriod> ensureMonthlyPeriods(Long companyId, int fiscalYear) {
        List<BudgetPeriod> existing = periodMapper.listByCompanyAndYearAndType(companyId, fiscalYear, PERIOD_TYPE_MONTHLY);
        Map<Integer, BudgetPeriod> monthToPeriod = new HashMap<>();
        for (BudgetPeriod p : existing) {
            if (p.getPeriodNo() != null) monthToPeriod.put(p.getPeriodNo(), p);
        }
        for (int m = 1; m <= 12; m++) {
            if (!monthToPeriod.containsKey(m)) {
                LocalDate start = LocalDate.of(fiscalYear, m, 1);
                LocalDate end = start.withDayOfMonth(start.lengthOfMonth());
                BudgetPeriod p = new BudgetPeriod();
                p.setCompanyId(companyId);
                p.setFiscalYear(fiscalYear);
                p.setPeriodType(PERIOD_TYPE_MONTHLY);
                p.setPeriodCode("M" + m);
                p.setPeriodName(m + "月");
                p.setPeriodNo(m);
                p.setStartDate(start);
                p.setEndDate(end);
                p.setSortOrder(m);
                p.setStatus(1);
                periodMapper.insert(p);
                monthToPeriod.put(m, p);
            }
        }
        return monthToPeriod;
    }

    private BudgetPeriodAmount buildPeriodAmount(Long lineId, Long sheetId, Long companyId, int fiscalYear, Long versionId,
                                                 BudgetPeriod period, String periodCode, BigDecimal amountYuan) {
        BudgetPeriodAmount pa = new BudgetPeriodAmount();
        pa.setBudgetLineId(lineId);
        pa.setBudgetSheetId(sheetId);
        pa.setCompanyId(companyId);
        pa.setFiscalYear(fiscalYear);
        pa.setVersionId(versionId);
        pa.setPeriodId(period.getId());
        pa.setPeriodType(PERIOD_TYPE_MONTHLY);
        pa.setPeriodCode(periodCode);
        pa.setBudgetAmount(amountYuan.setScale(2, RoundingMode.HALF_UP));
        pa.setAmountType("ORIGINAL");
        pa.setTimeOffsetMonths(0);
        return pa;
    }

    private String determineStockFlag(Contract contract, LocalDate fiscalYearStart) {
        if (contract.getContractCreateTime() != null && contract.getContractCreateTime().isBefore(fiscalYearStart)) {
            return "STOCK";
        }
        return "INCREMENT";
    }

    private static String normalizeStatus(String status) {
        if (status == null) return "UNSIGNED";
        String s = status.trim().toUpperCase();
        if ("UNSIGNED".equals(s) || "SIGNED".equals(s) || "COMPLETED".equals(s) || "CANCELED".equals(s)) {
            return s;
        }
        if (s.contains("取消") || s.contains("CANCEL")) return "CANCELED";
        if (s.contains("完成") || s.contains("DONE")) return "COMPLETED";
        if (s.contains("签") || s.contains("SIGNED")) return "SIGNED";
        return "UNSIGNED";
    }

    private static BigDecimal nvl(BigDecimal v) {
        return v != null ? v : BigDecimal.ZERO;
    }

    private static BigDecimal toWan(BigDecimal yuan) {
        if (yuan == null) return BigDecimal.ZERO;
        return yuan.divide(new BigDecimal("10000"), 6, RoundingMode.HALF_UP);
    }
}
