package com.crm.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@TableName("crm_customer")
public class PmtCustomer implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 客户编号 */
    private String customerCode;

    /** 客户名称 */
    private String customerName;

    /** 客户标准全称 */
    private String standardName;

    /** 客户地址 */
    private String customerAddress;

    /** 地图位置 */
    private String mapLocation;

    /** 客户类型 */
    private String customerType;

    /** 客户级别 */
    private String customerLevel;

    /** 客户来源 */
    private String customerSource;

    /** 客户行业 */
    private String customerIndustry;

    /** 行业 */
    private String industry;

    /** 行业L1 */
    private String industryL1;

    /** 行业L2 */
    private String industryL2;

    /** 行业L3 */
    private String industryL3;

    /** 客户规模 */
    private String customerScale;

    /** 客户性质 */
    private String customerNature;

    /** 客户状态 */
    private String customerStatus;

    /** 通话状态 */
    private String callStatus;

    /** 区域 */
    private String region;

    /** 省份 */
    private String province;

    /** 城市 */
    private String city;

    /** 上市状态 */
    private String listingStatus;

    /** 营收年份 */
    private String revenueYear;

    /** 盈利 */
    private String profit;

    /** 营收规模 */
    private String revenueScale;

    /** 市值 */
    private String marketValue;

    /** 员工数 */
    private String employeeCount;

    /** 合作状态 */
    private String cooperationStatus;

    /** 主要产品 */
    private String mainProduct;

    /** 当前开发阶段 */
    private String developmentStage;

    /** 累计销售额 */
    private BigDecimal totalSales;

    /** 首次产单时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate firstOrderDate;

    /** 最高客户关系 */
    private String highestCustomerRelation;

    /** 进行中商机 */
    private String ongoingOpportunity;

    /** 匹配情况 */
    private String matchStatus;

    /** 官网 */
    private String website;

    /** 数据来源 */
    private String dataSource;

    /** 公司产品 */
    private String companyProduct;

    /** 公司总机 */
    private String companyTel;

    /** 销售员 */
    private String salesman;

    /** 原销售人员 */
    private String originalSalesman;

    /** 行业负责人 */
    private String industryManager;

    /** CSO培训班 */
    private String csoTrainingClass;

    /** 主要联系人 */
    private String mainContact;

    /** 第二联系人 */
    private String secondContact;

    /** 客户负责人ID */
    private Long managerId;

    /** 客户负责人 */
    private String managerName;

    /** 跟进人ID */
    private Long followerId;

    /** 跟进人 */
    private String followerName;

    /** 联系人姓名 */
    private String contactName;

    /** 联系人职务 */
    private String contactPosition;

    /** 联系人手机 */
    private String contactMobile;

    /** 联系人座机 */
    private String contactTel;

    /** 联系人邮箱 */
    private String contactEmail;

    /** 联系人微信 */
    private String contactWechat;

    /** 联系人备注 */
    private String contactRemark;

    /** 客户备注 */
    private String remark;

    /** 客户标签(逗号分隔) */
    private String customerTags;

    /** 是否已成交 0-否 1-是 */
    private Integer dealFlag;

    /** 是否在公海 0-否 1-是 */
    private Integer inPublicSea;

    /** 最后跟进时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastFollowTime;

    /** 回收时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime recycleTime;

    /** 租户ID */
    private Long tenantId;

    @TableField(value = "create_by", fill = FieldFill.INSERT)
    private Long createBy;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @TableField(value = "update_by", fill = FieldFill.INSERT_UPDATE)
    private Long updateBy;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    @Version
    @TableField(fill = FieldFill.INSERT)
    private Integer version = 0;

    @TableLogic
    @TableField(fill = FieldFill.INSERT)
    private Long deleted = 0L;
}
