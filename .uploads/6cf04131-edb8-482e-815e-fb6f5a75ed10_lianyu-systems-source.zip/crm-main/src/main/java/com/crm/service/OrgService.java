package com.crm.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.crm.entity.Org;

import java.util.List;

public interface OrgService extends IService<Org> {

    List<Org> getTree();

    List<Org> listAll();

    boolean isHrMode();

    /**
     * 保存 org 的 manager 姓名字段到数据库（仅在 manager 列已存在时生效，旧库会自动 no-op）。
     * 注意：MyBatis-Plus 默认 entity 映射不负责写入 manager（exist=false），需单独调用此方法。
     */
    void saveManagerName(Org org);

    /**
     * 批量把 org list 的 manager 姓名字段从数据库（或 manager_id 关联）加载回 entity。
     */
    void loadManagerNames(List<Org> orgs);
}
