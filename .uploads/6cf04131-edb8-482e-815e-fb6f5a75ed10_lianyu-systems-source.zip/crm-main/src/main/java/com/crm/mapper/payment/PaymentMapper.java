package com.crm.mapper.payment;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.crm.dto.payment.PaymentQueryDTO;
import com.crm.vo.payment.PaymentRecordVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PaymentMapper {

    /**
     * 分页查询回款记录（已签订合同的收款里程碑）
     */
    IPage<PaymentRecordVO> selectPaymentPage(IPage<PaymentRecordVO> page,
                                             @Param("companyId") Long companyId,
                                             @Param("currentUserId") Long currentUserId,
                                             @Param("query") PaymentQueryDTO query);
}
