package com.crm.mapper.contract;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.crm.dto.contract.ContractQueryDTO;
import com.crm.entity.Contract;
import com.crm.vo.contract.ContractVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;

@Mapper
public interface ContractMapper extends BaseMapper<Contract> {

    IPage<ContractVO> selectPageList(IPage<ContractVO> page,
                                     @Param("companyId") Long companyId,
                                     @Param("query") ContractQueryDTO query,
                                     @Param("fiscalYearStart") String fiscalYearStart,
                                     @Param("currentFiscalYear") Integer currentFiscalYear);

    List<ContractVO> selectListByQuery(@Param("companyId") Long companyId,
                                       @Param("query") ContractQueryDTO query,
                                       @Param("fiscalYearStart") String fiscalYearStart,
                                       @Param("currentFiscalYear") Integer currentFiscalYear);

    ContractVO selectDetailById(@Param("id") Long id);

    Contract findByContractNo(@Param("companyId") Long companyId, @Param("contractNo") String contractNo);

    List<Contract> selectValidByCompany(@Param("companyId") Long companyId);

    List<Contract> findSignedInYear(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    List<Contract> findSignedInMonth(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("month") Integer month);

    List<Contract> findForBudgetCalc(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("fiscalYearStart") java.time.LocalDate fiscalYearStart);

    List<Contract> findForContractBudget(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    List<Contract> findForRevenueBudget(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("fiscalYearStart") java.time.LocalDate fiscalYearStart);

    List<Contract> findForTaxBudget(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    long countAllContracts(@Param("companyId") Long companyId);

    BigDecimal sumContractAmount(@Param("companyId") Long companyId);

    BigDecimal sumContractAmountByCompany(@Param("companyId") Long companyId);

    Contract findByContractNoAndType(@Param("companyId") Long companyId,
                                      @Param("contractNo") String contractNo,
                                      @Param("orgId") Long orgId,
                                      @Param("contractTypeId") Long contractTypeId);

    List<Contract> findByParentContractNo(@Param("companyId") Long companyId,
                                           @Param("contractNo") String contractNo);
}