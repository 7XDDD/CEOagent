package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.system.UserQueryDTO;
import com.crm.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper extends BaseMapper<User> {

    User findByUsername(@Param("username") String username);

    User findByUsernameOrPhone(@Param("keyword") String keyword);

    User findByEmployeeId(@Param("employeeId") Long employeeId);

    User findByUsernameExist(@Param("username") String username, @Param("excludeId") Long excludeId);

    Page<Map<String, Object>> selectPageList(Page<Map<String, Object>> page, @Param("q") UserQueryDTO query);

    List<Map<String, Object>> selectAvailableEmployees();

    long countAll();

    long countActive();
}
