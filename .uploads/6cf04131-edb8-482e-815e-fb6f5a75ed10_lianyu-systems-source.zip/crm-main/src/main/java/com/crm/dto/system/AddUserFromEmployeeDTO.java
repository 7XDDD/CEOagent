package com.crm.dto.system;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class AddUserFromEmployeeDTO {
    @NotNull(message = "员工ID不能为空")
    private Long employeeId;

    private String password = "123456";

    private String appCode = "SYSTEM";
}
