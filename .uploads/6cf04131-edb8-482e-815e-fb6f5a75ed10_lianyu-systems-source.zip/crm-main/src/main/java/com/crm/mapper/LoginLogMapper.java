package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.system.LoginLogQueryDTO;
import com.crm.entity.LoginLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface LoginLogMapper extends BaseMapper<LoginLog> {

    Page<LoginLog> selectPageList(Page<LoginLog> page, @Param("q") LoginLogQueryDTO query);

    long countSuccessByUser(@Param("userId") Long userId);
}
