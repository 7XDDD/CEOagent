package com.crm.dataperm.resolver;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crm.dataperm.DataOwnerResolver;
import com.crm.dataperm.DataPermModule;
import com.crm.entity.Project;
import com.crm.mapper.ProjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

/** 项目负责人：pm_id / sales_id / owner_id / 创建人 */
@Component
public class ProjectOwnerResolver implements DataOwnerResolver {

    @Autowired
    private ProjectMapper projectMapper;

    @Override
    public String module() {
        return DataPermModule.PROJECT;
    }

    @Override
    public boolean isOwner(Long bizId, Long userId) {
        if (bizId == null || userId == null) return false;
        LambdaQueryWrapper<Project> w = new LambdaQueryWrapper<>();
        w.eq(Project::getId, bizId)
                .and(x -> x.eq(Project::getPmId, userId)
                        .or().eq(Project::getSalesId, userId)
                        .or().eq(Project::getOwnerId, userId)
                        .or().eq(Project::getCreatedBy, userId));
        return projectMapper.selectCount(w) > 0;
    }

    @Override
    public Set<Long> findOwnerIds(Collection<Long> bizIds, Long userId) {
        if (bizIds == null || bizIds.isEmpty() || userId == null) return Collections.emptySet();
        LambdaQueryWrapper<Project> w = new LambdaQueryWrapper<>();
        w.in(Project::getId, bizIds)
                .and(x -> x.eq(Project::getPmId, userId)
                        .or().eq(Project::getSalesId, userId)
                        .or().eq(Project::getOwnerId, userId)
                        .or().eq(Project::getCreatedBy, userId));
        return projectMapper.selectList(w).stream().map(Project::getId).collect(Collectors.toSet());
    }
}
