package com.crm.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.crm.dto.opportunity.OpportunityFollowCreateDTO;
import com.crm.entity.OpportunityFollow;

import java.util.List;

public interface OpportunityFollowService {

    IPage<OpportunityFollow> page(Integer pageNum, Integer pageSize, String keyword, String scope);

    /** 跟进计划：仅包含填写了下次计划的记录，按计划时间排序 */
    IPage<OpportunityFollow> planPage(Integer pageNum, Integer pageSize, String keyword, String scope, String planStatus);

    /** 标记计划完成 */
    void markPlanDone(Long id);

    List<OpportunityFollow> listByOpportunityId(Long opportunityId);

    OpportunityFollow save(OpportunityFollowCreateDTO dto);

    void deleteById(Long id);
}
