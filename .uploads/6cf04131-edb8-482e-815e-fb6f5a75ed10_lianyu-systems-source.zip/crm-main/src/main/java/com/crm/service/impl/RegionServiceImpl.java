package com.crm.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.crm.entity.Region;
import com.crm.mapper.RegionMapper;
import com.crm.service.RegionService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RegionServiceImpl extends ServiceImpl<RegionMapper, Region> implements RegionService {

    @Override
    public List<Region> getChildren(Long parentId) {
        return baseMapper.findByParentId(parentId);
    }

    @Override
    public List<Region> getTree() {
        List<Region> all = this.list(new LambdaQueryWrapper<Region>()
                .eq(Region::getStatus, 1)
                .orderByAsc(Region::getSortOrder)
                .orderByAsc(Region::getId));
        return buildTree(all, 0L);
    }

    @Override
    public List<Region> getByLevel(Integer level) {
        return baseMapper.findByLevel(level);
    }

    private List<Region> buildTree(List<Region> all, Long parentId) {
        return all.stream()
                .filter(r -> Objects.equals(r.getParentId(), parentId))
                .peek(r -> {
                    List<Region> children = buildTree(all, r.getId());
                    r.setChildren(children);
                })
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void initChinaData() {
        Long count = this.count(new LambdaQueryWrapper<Region>().eq(Region::getDeleted, 0));
        if (count > 0) return;

        // 1. 国家
        Region china = new Region();
        china.setParentId(0L);
        china.setLevel(1);
        china.setRegionCode("100000");
        china.setRegionName("中华人民共和国");
        china.setShortName("中国");
        china.setPinyin("Zhongguo");
        china.setSortOrder(1);
        china.setStatus(1);
        this.save(china);
        Long chinaId = china.getId();

        // 2. 省份/直辖市/自治区/特别行政区
        List<Object[]> provinces = new ArrayList<>();
        provinces.add(new Object[]{"110000", "北京市", "北京", "Beijing", 1});
        provinces.add(new Object[]{"120000", "天津市", "天津", "Tianjin", 2});
        provinces.add(new Object[]{"130000", "河北省", "河北", "Hebei", 3});
        provinces.add(new Object[]{"140000", "山西省", "山西", "Shanxi", 4});
        provinces.add(new Object[]{"150000", "内蒙古自治区", "内蒙古", "Neimenggu", 5});
        provinces.add(new Object[]{"210000", "辽宁省", "辽宁", "Liaoning", 6});
        provinces.add(new Object[]{"220000", "吉林省", "吉林", "Jilin", 7});
        provinces.add(new Object[]{"230000", "黑龙江省", "黑龙江", "Heilongjiang", 8});
        provinces.add(new Object[]{"310000", "上海市", "上海", "Shanghai", 9});
        provinces.add(new Object[]{"320000", "江苏省", "江苏", "Jiangsu", 10});
        provinces.add(new Object[]{"330000", "浙江省", "浙江", "Zhejiang", 11});
        provinces.add(new Object[]{"340000", "安徽省", "安徽", "Anhui", 12});
        provinces.add(new Object[]{"350000", "福建省", "福建", "Fujian", 13});
        provinces.add(new Object[]{"360000", "江西省", "江西", "Jiangxi", 14});
        provinces.add(new Object[]{"370000", "山东省", "山东", "Shandong", 15});
        provinces.add(new Object[]{"410000", "河南省", "河南", "Henan", 16});
        provinces.add(new Object[]{"420000", "湖北省", "湖北", "Hubei", 17});
        provinces.add(new Object[]{"430000", "湖南省", "湖南", "Hunan", 18});
        provinces.add(new Object[]{"440000", "广东省", "广东", "Guangdong", 19});
        provinces.add(new Object[]{"450000", "广西壮族自治区", "广西", "Guangxi", 20});
        provinces.add(new Object[]{"460000", "海南省", "海南", "Hainan", 21});
        provinces.add(new Object[]{"500000", "重庆市", "重庆", "Chongqing", 22});
        provinces.add(new Object[]{"510000", "四川省", "四川", "Sichuan", 23});
        provinces.add(new Object[]{"520000", "贵州省", "贵州", "Guizhou", 24});
        provinces.add(new Object[]{"530000", "云南省", "云南", "Yunnan", 25});
        provinces.add(new Object[]{"540000", "西藏自治区", "西藏", "Xizang", 26});
        provinces.add(new Object[]{"610000", "陕西省", "陕西", "Shaanxi", 27});
        provinces.add(new Object[]{"620000", "甘肃省", "甘肃", "Gansu", 28});
        provinces.add(new Object[]{"630000", "青海省", "青海", "Qinghai", 29});
        provinces.add(new Object[]{"640000", "宁夏回族自治区", "宁夏", "Ningxia", 30});
        provinces.add(new Object[]{"650000", "新疆维吾尔自治区", "新疆", "Xinjiang", 31});
        provinces.add(new Object[]{"710000", "台湾省", "台湾", "Taiwan", 32});
        provinces.add(new Object[]{"810000", "香港特别行政区", "香港", "Xianggang", 33});
        provinces.add(new Object[]{"820000", "澳门特别行政区", "澳门", "Aomen", 34});

        Map<String, Long> provinceIdMap = new LinkedHashMap<>();
        int sortOrder = 1;
        for (Object[] p : provinces) {
            Region province = new Region();
            province.setParentId(chinaId);
            province.setLevel(2);
            province.setRegionCode((String) p[0]);
            province.setRegionName((String) p[1]);
            province.setShortName((String) p[2]);
            province.setPinyin((String) p[3]);
            province.setSortOrder((Integer) p[4]);
            province.setStatus(1);
            this.save(province);
            provinceIdMap.put((String) p[0], province.getId());
            sortOrder++;
        }

        // 3. 主要城市（简化版，每个省份添加几个主要城市和市辖区）
        Map<String, List<Object[]>> cityMap = new LinkedHashMap<>();

        // 北京
        cityMap.put("110000", Arrays.asList(new Object[][]{{"110100", "北京市", "北京", 1}}));
        // 天津
        cityMap.put("120000", Arrays.asList(new Object[][]{{"120100", "天津市", "天津", 1}}));
        // 河北
        cityMap.put("130000", Arrays.asList(new Object[][]{
                {"130100", "石家庄市", "石家庄", 1}, {"130200", "唐山市", "唐山", 2}, {"130300", "秦皇岛市", "秦皇岛", 3},
                {"130400", "邯郸市", "邯郸", 4}, {"130500", "邢台市", "邢台", 5}, {"130600", "保定市", "保定", 6}
        }));
        // 山西
        cityMap.put("140000", Arrays.asList(new Object[][]{
                {"140100", "太原市", "太原", 1}, {"140200", "大同市", "大同", 2}, {"140300", "阳泉市", "阳泉", 3},
                {"140400", "长治市", "长治", 4}
        }));
        // 内蒙古
        cityMap.put("150000", Arrays.asList(new Object[][]{
                {"150100", "呼和浩特市", "呼和浩特", 1}, {"150200", "包头市", "包头", 2}, {"150300", "乌海市", "乌海", 3}
        }));
        // 辽宁
        cityMap.put("210000", Arrays.asList(new Object[][]{
                {"210100", "沈阳市", "沈阳", 1}, {"210200", "大连市", "大连", 2}, {"210300", "鞍山市", "鞍山", 3},
                {"210400", "抚顺市", "抚顺", 4}
        }));
        // 吉林
        cityMap.put("220000", Arrays.asList(new Object[][]{
                {"220100", "长春市", "长春", 1}, {"220200", "吉林市", "吉林", 2}, {"220300", "四平市", "四平", 3}
        }));
        // 黑龙江
        cityMap.put("230000", Arrays.asList(new Object[][]{
                {"230100", "哈尔滨市", "哈尔滨", 1}, {"230200", "齐齐哈尔市", "齐齐哈尔", 2}, {"230300", "鸡西市", "鸡西", 3},
                {"230600", "大庆市", "大庆", 4}
        }));
        // 上海
        cityMap.put("310000", Arrays.asList(new Object[][]{{"310100", "上海市", "上海", 1}}));
        // 江苏
        cityMap.put("320000", Arrays.asList(new Object[][]{
                {"320100", "南京市", "南京", 1}, {"320200", "无锡市", "无锡", 2}, {"320300", "徐州市", "徐州", 3},
                {"320400", "常州市", "常州", 4}, {"320500", "苏州市", "苏州", 5}, {"320600", "南通市", "南通", 6}
        }));
        // 浙江
        cityMap.put("330000", Arrays.asList(new Object[][]{
                {"330100", "杭州市", "杭州", 1}, {"330200", "宁波市", "宁波", 2}, {"330300", "温州市", "温州", 3},
                {"330400", "嘉兴市", "嘉兴", 4}, {"330500", "湖州市", "湖州", 5}, {"330600", "绍兴市", "绍兴", 6}
        }));
        // 安徽
        cityMap.put("340000", Arrays.asList(new Object[][]{
                {"340100", "合肥市", "合肥", 1}, {"340200", "芜湖市", "芜湖", 2}, {"340300", "蚌埠市", "蚌埠", 3},
                {"340400", "淮南市", "淮南", 4}
        }));
        // 福建
        cityMap.put("350000", Arrays.asList(new Object[][]{
                {"350100", "福州市", "福州", 1}, {"350200", "厦门市", "厦门", 2}, {"350300", "莆田市", "莆田", 3},
                {"350400", "三明市", "三明", 4}, {"350500", "泉州市", "泉州", 5}
        }));
        // 江西
        cityMap.put("360000", Arrays.asList(new Object[][]{
                {"360100", "南昌市", "南昌", 1}, {"360200", "景德镇市", "景德镇", 2}, {"360300", "萍乡市", "萍乡", 3},
                {"360400", "九江市", "九江", 4}
        }));
        // 山东
        cityMap.put("370000", Arrays.asList(new Object[][]{
                {"370100", "济南市", "济南", 1}, {"370200", "青岛市", "青岛", 2}, {"370300", "淄博市", "淄博", 3},
                {"370400", "枣庄市", "枣庄", 4}, {"370500", "东营市", "东营", 5}, {"370600", "烟台市", "烟台", 6}
        }));
        // 河南
        cityMap.put("410000", Arrays.asList(new Object[][]{
                {"410100", "郑州市", "郑州", 1}, {"410200", "开封市", "开封", 2}, {"410300", "洛阳市", "洛阳", 3},
                {"410400", "平顶山市", "平顶山", 4}, {"410500", "安阳市", "安阳", 5}
        }));
        // 湖北
        cityMap.put("420000", Arrays.asList(new Object[][]{
                {"420100", "武汉市", "武汉", 1}, {"420200", "黄石市", "黄石", 2}, {"420300", "十堰市", "十堰", 3},
                {"420500", "宜昌市", "宜昌", 4}, {"420600", "襄阳市", "襄阳", 5}
        }));
        // 湖南
        cityMap.put("430000", Arrays.asList(new Object[][]{
                {"430100", "长沙市", "长沙", 1}, {"430200", "株洲市", "株洲", 2}, {"430300", "湘潭市", "湘潭", 3},
                {"430400", "衡阳市", "衡阳", 4}, {"430500", "邵阳市", "邵阳", 5}
        }));
        // 广东
        cityMap.put("440000", Arrays.asList(new Object[][]{
                {"440100", "广州市", "广州", 1}, {"440200", "韶关市", "韶关", 2}, {"440300", "深圳市", "深圳", 3},
                {"440400", "珠海市", "珠海", 4}, {"440500", "汕头市", "汕头", 5}, {"440600", "佛山市", "佛山", 6},
                {"440700", "江门市", "江门", 7}, {"440800", "湛江市", "湛江", 8}, {"441900", "东莞市", "东莞", 9}
        }));
        // 广西
        cityMap.put("450000", Arrays.asList(new Object[][]{
                {"450100", "南宁市", "南宁", 1}, {"450200", "柳州市", "柳州", 2}, {"450300", "桂林市", "桂林", 3},
                {"450400", "梧州市", "梧州", 4}
        }));
        // 海南
        cityMap.put("460000", Arrays.asList(new Object[][]{
                {"460100", "海口市", "海口", 1}, {"460200", "三亚市", "三亚", 2}
        }));
        // 重庆
        cityMap.put("500000", Arrays.asList(new Object[][]{{"500100", "重庆市", "重庆", 1}}));
        // 四川
        cityMap.put("510000", Arrays.asList(new Object[][]{
                {"510100", "成都市", "成都", 1}, {"510300", "自贡市", "自贡", 2}, {"510400", "攀枝花市", "攀枝花", 3},
                {"510500", "泸州市", "泸州", 4}, {"510600", "德阳市", "德阳", 5}, {"510700", "绵阳市", "绵阳", 6}
        }));
        // 贵州
        cityMap.put("520000", Arrays.asList(new Object[][]{
                {"520100", "贵阳市", "贵阳", 1}, {"520200", "六盘水市", "六盘水", 2}, {"520300", "遵义市", "遵义", 3}
        }));
        // 云南
        cityMap.put("530000", Arrays.asList(new Object[][]{
                {"530100", "昆明市", "昆明", 1}, {"530300", "曲靖市", "曲靖", 2}, {"530400", "玉溪市", "玉溪", 3}
        }));
        // 西藏
        cityMap.put("540000", Arrays.asList(new Object[][]{
                {"540100", "拉萨市", "拉萨", 1}, {"540200", "日喀则市", "日喀则", 2}
        }));
        // 陕西
        cityMap.put("610000", Arrays.asList(new Object[][]{
                {"610100", "西安市", "西安", 1}, {"610200", "铜川市", "铜川", 2}, {"610300", "宝鸡市", "宝鸡", 3},
                {"610400", "咸阳市", "咸阳", 4}
        }));
        // 甘肃
        cityMap.put("620000", Arrays.asList(new Object[][]{
                {"620100", "兰州市", "兰州", 1}, {"620200", "嘉峪关市", "嘉峪关", 2}, {"620300", "金昌市", "金昌", 3}
        }));
        // 青海
        cityMap.put("630000", Arrays.asList(new Object[][]{
                {"630100", "西宁市", "西宁", 1}, {"630200", "海东市", "海东", 2}
        }));
        // 宁夏
        cityMap.put("640000", Arrays.asList(new Object[][]{
                {"640100", "银川市", "银川", 1}, {"640200", "石嘴山市", "石嘴山", 2}, {"640300", "吴忠市", "吴忠", 3}
        }));
        // 新疆
        cityMap.put("650000", Arrays.asList(new Object[][]{
                {"650100", "乌鲁木齐市", "乌鲁木齐", 1}, {"650200", "克拉玛依市", "克拉玛依", 2}, {"650400", "吐鲁番市", "吐鲁番", 3}
        }));
        // 台湾
        cityMap.put("710000", Arrays.asList(new Object[][]{{"710100", "台北市", "台北", 1}, {"710200", "高雄市", "高雄", 2}}));
        // 香港
        cityMap.put("810000", Arrays.asList(new Object[][]{{"810100", "香港岛", "香港岛", 1}, {"810200", "九龙", "九龙", 2}, {"810300", "新界", "新界", 3}}));
        // 澳门
        cityMap.put("820000", Arrays.asList(new Object[][]{{"820100", "花地玛堂区", "花地玛堂区", 1}}));

        // 添加城市
        Map<String, Long> cityIdMap = new LinkedHashMap<>();
        for (Map.Entry<String, List<Object[]>> entry : cityMap.entrySet()) {
            Long pId = provinceIdMap.get(entry.getKey());
            if (pId == null) continue;
            for (Object[] c : entry.getValue()) {
                Region city = new Region();
                city.setParentId(pId);
                city.setLevel(3);
                city.setRegionCode((String) c[0]);
                city.setRegionName((String) c[1]);
                city.setShortName((String) c[2]);
                city.setPinyin("");
                city.setSortOrder((Integer) c[3]);
                city.setStatus(1);
                this.save(city);
                cityIdMap.put((String) c[0], city.getId());
            }
        }

        // 4. 区/县（为主要城市添加几个区）
        List<Object[]> districts = new ArrayList<>();
        // 北京
        districts.add(new Object[]{"110101", "东城区", "东城", "110100", 1});
        districts.add(new Object[]{"110102", "西城区", "西城", "110100", 2});
        districts.add(new Object[]{"110105", "朝阳区", "朝阳", "110100", 3});
        districts.add(new Object[]{"110106", "丰台区", "丰台", "110100", 4});
        districts.add(new Object[]{"110107", "石景山区", "石景山", "110100", 5});
        districts.add(new Object[]{"110108", "海淀区", "海淀", "110100", 6});
        // 天津
        districts.add(new Object[]{"120101", "和平区", "和平", "120100", 1});
        districts.add(new Object[]{"120102", "河东区", "河东", "120100", 2});
        districts.add(new Object[]{"120103", "河西区", "河西", "120100", 3});
        districts.add(new Object[]{"120104", "南开区", "南开", "120100", 4});
        // 石家庄
        districts.add(new Object[]{"130102", "长安区", "长安", "130100", 1});
        districts.add(new Object[]{"130104", "桥西区", "桥西", "130100", 2});
        districts.add(new Object[]{"130105", "新华区", "新华", "130100", 3});
        // 太原
        districts.add(new Object[]{"140105", "小店区", "小店", "140100", 1});
        districts.add(new Object[]{"140106", "迎泽区", "迎泽", "140100", 2});
        districts.add(new Object[]{"140107", "杏花岭区", "杏花岭", "140100", 3});
        // 呼和浩特
        districts.add(new Object[]{"150102", "新城区", "新城", "150100", 1});
        districts.add(new Object[]{"150103", "回民区", "回民", "150100", 2});
        districts.add(new Object[]{"150104", "玉泉区", "玉泉", "150100", 3});
        // 沈阳
        districts.add(new Object[]{"210102", "和平区", "和平", "210100", 1});
        districts.add(new Object[]{"210103", "沈河区", "沈河", "210100", 2});
        districts.add(new Object[]{"210104", "大东区", "大东", "210100", 3});
        // 大连
        districts.add(new Object[]{"210202", "中山区", "中山", "210200", 1});
        districts.add(new Object[]{"210203", "西岗区", "西岗", "210200", 2});
        districts.add(new Object[]{"210204", "沙河口区", "沙河口", "210200", 3});
        // 长春
        districts.add(new Object[]{"220102", "南关区", "南关", "220100", 1});
        districts.add(new Object[]{"220103", "宽城区", "宽城", "220100", 2});
        districts.add(new Object[]{"220104", "朝阳区", "朝阳", "220100", 3});
        // 哈尔滨
        districts.add(new Object[]{"230102", "道里区", "道里", "230100", 1});
        districts.add(new Object[]{"230103", "南岗区", "南岗", "230100", 2});
        districts.add(new Object[]{"230104", "道外区", "道外", "230100", 3});
        // 上海
        districts.add(new Object[]{"310101", "黄浦区", "黄浦", "310100", 1});
        districts.add(new Object[]{"310104", "徐汇区", "徐汇", "310100", 2});
        districts.add(new Object[]{"310105", "长宁区", "长宁", "310100", 3});
        districts.add(new Object[]{"310106", "静安区", "静安", "310100", 4});
        districts.add(new Object[]{"310107", "普陀区", "普陀", "310100", 5});
        districts.add(new Object[]{"310109", "虹口区", "虹口", "310100", 6});
        districts.add(new Object[]{"310110", "杨浦区", "杨浦", "310100", 7});
        districts.add(new Object[]{"310112", "闵行区", "闵行", "310100", 8});
        districts.add(new Object[]{"310115", "浦东新区", "浦东", "310100", 9});
        // 南京
        districts.add(new Object[]{"320102", "玄武区", "玄武", "320100", 1});
        districts.add(new Object[]{"320104", "秦淮区", "秦淮", "320100", 2});
        districts.add(new Object[]{"320105", "建邺区", "建邺", "320100", 3});
        districts.add(new Object[]{"320106", "鼓楼区", "鼓楼", "320100", 4});
        // 无锡
        districts.add(new Object[]{"320205", "锡山区", "锡山", "320200", 1});
        districts.add(new Object[]{"320206", "惠山区", "惠山", "320200", 2});
        districts.add(new Object[]{"320211", "滨湖区", "滨湖", "320200", 3});
        // 苏州
        districts.add(new Object[]{"320505", "虎丘区", "虎丘", "320500", 1});
        districts.add(new Object[]{"320506", "吴中区", "吴中", "320500", 2});
        districts.add(new Object[]{"320507", "相城区", "相城", "320500", 3});
        districts.add(new Object[]{"320508", "姑苏区", "姑苏", "320500", 4});
        // 杭州
        districts.add(new Object[]{"330102", "上城区", "上城", "330100", 1});
        districts.add(new Object[]{"330105", "拱墅区", "拱墅", "330100", 2});
        districts.add(new Object[]{"330106", "西湖区", "西湖", "330100", 3});
        districts.add(new Object[]{"330108", "滨江区", "滨江", "330100", 4});
        districts.add(new Object[]{"330110", "余杭区", "余杭", "330100", 5});
        // 宁波
        districts.add(new Object[]{"330203", "海曙区", "海曙", "330200", 1});
        districts.add(new Object[]{"330205", "江北区", "江北", "330200", 2});
        districts.add(new Object[]{"330206", "北仑区", "北仑", "330200", 3});
        // 温州
        districts.add(new Object[]{"330302", "鹿城区", "鹿城", "330300", 1});
        districts.add(new Object[]{"330303", "龙湾区", "龙湾", "330300", 2});
        districts.add(new Object[]{"330304", "瓯海区", "瓯海", "330300", 3});
        // 合肥
        districts.add(new Object[]{"340102", "瑶海区", "瑶海", "340100", 1});
        districts.add(new Object[]{"340103", "庐阳区", "庐阳", "340100", 2});
        districts.add(new Object[]{"340104", "蜀山区", "蜀山", "340100", 3});
        districts.add(new Object[]{"340111", "包河区", "包河", "340100", 4});
        // 福州
        districts.add(new Object[]{"350102", "鼓楼区", "鼓楼", "350100", 1});
        districts.add(new Object[]{"350103", "台江区", "台江", "350100", 2});
        districts.add(new Object[]{"350104", "仓山区", "仓山", "350100", 3});
        // 厦门
        districts.add(new Object[]{"350203", "思明区", "思明", "350200", 1});
        districts.add(new Object[]{"350205", "海沧区", "海沧", "350200", 2});
        districts.add(new Object[]{"350206", "湖里区", "湖里", "350200", 3});
        // 泉州
        districts.add(new Object[]{"350503", "丰泽区", "丰泽", "350500", 1});
        districts.add(new Object[]{"350504", "洛江区", "洛江", "350500", 2});
        districts.add(new Object[]{"350582", "晋江市", "晋江", "350500", 3});
        // 南昌
        districts.add(new Object[]{"360102", "东湖区", "东湖", "360100", 1});
        districts.add(new Object[]{"360103", "西湖区", "西湖", "360100", 2});
        districts.add(new Object[]{"360104", "青云谱区", "青云谱", "360100", 3});
        // 济南
        districts.add(new Object[]{"370102", "历下区", "历下", "370100", 1});
        districts.add(new Object[]{"370103", "市中区", "市中", "370100", 2});
        districts.add(new Object[]{"370104", "槐荫区", "槐荫", "370100", 3});
        districts.add(new Object[]{"370105", "天桥区", "天桥", "370100", 4});
        // 青岛
        districts.add(new Object[]{"370202", "市南区", "市南", "370200", 1});
        districts.add(new Object[]{"370203", "市北区", "市北", "370200", 2});
        districts.add(new Object[]{"370211", "黄岛区", "黄岛", "370200", 3});
        districts.add(new Object[]{"370212", "崂山区", "崂山", "370200", 4});
        // 烟台
        districts.add(new Object[]{"370602", "芝罘区", "芝罘", "370600", 1});
        districts.add(new Object[]{"370611", "福山区", "福山", "370600", 2});
        districts.add(new Object[]{"370613", "莱山区", "莱山", "370600", 3});
        // 郑州
        districts.add(new Object[]{"410102", "中原区", "中原", "410100", 1});
        districts.add(new Object[]{"410103", "二七区", "二七", "410100", 2});
        districts.add(new Object[]{"410104", "管城回族区", "管城", "410100", 3});
        districts.add(new Object[]{"410105", "金水区", "金水", "410100", 4});
        // 洛阳
        districts.add(new Object[]{"410302", "老城区", "老城", "410300", 1});
        districts.add(new Object[]{"410303", "西工区", "西工", "410300", 2});
        districts.add(new Object[]{"410304", "瀍河回族区", "瀍河", "410300", 3});
        districts.add(new Object[]{"410305", "涧西区", "涧西", "410300", 4});
        // 武汉
        districts.add(new Object[]{"420102", "江岸区", "江岸", "420100", 1});
        districts.add(new Object[]{"420103", "江汉区", "江汉", "420100", 2});
        districts.add(new Object[]{"420104", "硚口区", "硚口", "420100", 3});
        districts.add(new Object[]{"420105", "汉阳区", "汉阳", "420100", 4});
        districts.add(new Object[]{"420106", "武昌区", "武昌", "420100", 5});
        districts.add(new Object[]{"420111", "洪山区", "洪山", "420100", 6});
        // 长沙
        districts.add(new Object[]{"430102", "芙蓉区", "芙蓉", "430100", 1});
        districts.add(new Object[]{"430103", "天心区", "天心", "430100", 2});
        districts.add(new Object[]{"430104", "岳麓区", "岳麓", "430100", 3});
        districts.add(new Object[]{"430105", "开福区", "开福", "430100", 4});
        districts.add(new Object[]{"430111", "雨花区", "雨花", "430100", 5});
        // 广州
        districts.add(new Object[]{"440103", "荔湾区", "荔湾", "440100", 1});
        districts.add(new Object[]{"440104", "越秀区", "越秀", "440100", 2});
        districts.add(new Object[]{"440105", "海珠区", "海珠", "440100", 3});
        districts.add(new Object[]{"440106", "天河区", "天河", "440100", 4});
        districts.add(new Object[]{"440111", "白云区", "白云", "440100", 5});
        districts.add(new Object[]{"440112", "黄埔区", "黄埔", "440100", 6});
        districts.add(new Object[]{"440113", "番禺区", "番禺", "440100", 7});
        // 深圳
        districts.add(new Object[]{"440303", "罗湖区", "罗湖", "440300", 1});
        districts.add(new Object[]{"440304", "福田区", "福田", "440300", 2});
        districts.add(new Object[]{"440305", "南山区", "南山", "440300", 3});
        districts.add(new Object[]{"440306", "宝安区", "宝安", "440300", 4});
        districts.add(new Object[]{"440307", "龙岗区", "龙岗", "440300", 5});
        districts.add(new Object[]{"440308", "盐田区", "盐田", "440300", 6});
        // 珠海
        districts.add(new Object[]{"440402", "香洲区", "香洲", "440400", 1});
        districts.add(new Object[]{"440403", "斗门区", "斗门", "440400", 2});
        // 佛山
        districts.add(new Object[]{"440604", "禅城区", "禅城", "440600", 1});
        districts.add(new Object[]{"440605", "南海区", "南海", "440600", 2});
        districts.add(new Object[]{"440606", "顺德区", "顺德", "440600", 3});
        // 东莞（不设区，直辖街道）
        districts.add(new Object[]{"441901", "莞城街道", "莞城", "441900", 1});
        districts.add(new Object[]{"441902", "南城街道", "南城", "441900", 2});
        districts.add(new Object[]{"441903", "东城街道", "东城", "441900", 3});
        // 南宁
        districts.add(new Object[]{"450102", "兴宁区", "兴宁", "450100", 1});
        districts.add(new Object[]{"450103", "青秀区", "青秀", "450100", 2});
        districts.add(new Object[]{"450105", "江南区", "江南", "450100", 3});
        // 桂林
        districts.add(new Object[]{"450302", "秀峰区", "秀峰", "450300", 1});
        districts.add(new Object[]{"450303", "叠彩区", "叠彩", "450300", 2});
        districts.add(new Object[]{"450304", "象山区", "象山", "450300", 3});
        // 海口
        districts.add(new Object[]{"460105", "秀英区", "秀英", "460100", 1});
        districts.add(new Object[]{"460106", "龙华区", "龙华", "460100", 2});
        districts.add(new Object[]{"460107", "琼山区", "琼山", "460100", 3});
        districts.add(new Object[]{"460108", "美兰区", "美兰", "460100", 4});
        // 三亚
        districts.add(new Object[]{"460202", "海棠区", "海棠", "460200", 1});
        districts.add(new Object[]{"460203", "吉阳区", "吉阳", "460200", 2});
        // 重庆
        districts.add(new Object[]{"500101", "万州区", "万州", "500100", 1});
        districts.add(new Object[]{"500103", "渝中区", "渝中", "500100", 2});
        districts.add(new Object[]{"500105", "江北区", "江北", "500100", 3});
        districts.add(new Object[]{"500106", "沙坪坝区", "沙坪坝", "500100", 4});
        districts.add(new Object[]{"500107", "九龙坡区", "九龙坡", "500100", 5});
        districts.add(new Object[]{"500108", "南岸区", "南岸", "500100", 6});
        // 成都
        districts.add(new Object[]{"510104", "锦江区", "锦江", "510100", 1});
        districts.add(new Object[]{"510105", "青羊区", "青羊", "510100", 2});
        districts.add(new Object[]{"510106", "金牛区", "金牛", "510100", 3});
        districts.add(new Object[]{"510107", "武侯区", "武侯", "510100", 4});
        districts.add(new Object[]{"510108", "成华区", "成华", "510100", 5});
        districts.add(new Object[]{"510112", "龙泉驿区", "龙泉驿", "510100", 6});
        // 绵阳
        districts.add(new Object[]{"510703", "涪城区", "涪城", "510700", 1});
        districts.add(new Object[]{"510704", "游仙区", "游仙", "510700", 2});
        // 贵阳
        districts.add(new Object[]{"520102", "南明区", "南明", "520100", 1});
        districts.add(new Object[]{"520103", "云岩区", "云岩", "520100", 2});
        districts.add(new Object[]{"520111", "花溪区", "花溪", "520100", 3});
        // 昆明
        districts.add(new Object[]{"530102", "五华区", "五华", "530100", 1});
        districts.add(new Object[]{"530103", "盘龙区", "盘龙", "530100", 2});
        districts.add(new Object[]{"530111", "官渡区", "官渡", "530100", 3});
        districts.add(new Object[]{"530112", "西山区", "西山", "530100", 4});
        // 拉萨
        districts.add(new Object[]{"540102", "城关区", "城关", "540100", 1});
        districts.add(new Object[]{"540103", "堆龙德庆区", "堆龙德庆", "540100", 2});
        // 西安
        districts.add(new Object[]{"610102", "新城区", "新城", "610100", 1});
        districts.add(new Object[]{"610103", "碑林区", "碑林", "610100", 2});
        districts.add(new Object[]{"610104", "莲湖区", "莲湖", "610100", 3});
        districts.add(new Object[]{"610111", "灞桥区", "灞桥", "610100", 4});
        districts.add(new Object[]{"610113", "雁塔区", "雁塔", "610100", 5});
        // 兰州
        districts.add(new Object[]{"620102", "城关区", "城关", "620100", 1});
        districts.add(new Object[]{"620103", "七里河区", "七里河", "620100", 2});
        districts.add(new Object[]{"620104", "西固区", "西固", "620100", 3});
        // 西宁
        districts.add(new Object[]{"630102", "城东区", "城东", "630100", 1});
        districts.add(new Object[]{"630103", "城中区", "城中", "630100", 2});
        districts.add(new Object[]{"630104", "城西区", "城西", "630100", 3});
        // 银川
        districts.add(new Object[]{"640104", "兴庆区", "兴庆", "640100", 1});
        districts.add(new Object[]{"640105", "西夏区", "西夏", "640100", 2});
        districts.add(new Object[]{"640106", "金凤区", "金凤", "640100", 3});
        // 乌鲁木齐
        districts.add(new Object[]{"650102", "天山区", "天山", "650100", 1});
        districts.add(new Object[]{"650103", "沙依巴克区", "沙依巴克", "650100", 2});
        districts.add(new Object[]{"650104", "新市区", "新市", "650100", 3});
        // 台北
        districts.add(new Object[]{"710101", "中正区", "中正", "710100", 1});
        districts.add(new Object[]{"710102", "大同区", "大同", "710100", 2});
        // 高雄
        districts.add(new Object[]{"710201", "楠梓区", "楠梓", "710200", 1});
        districts.add(new Object[]{"710202", "左营区", "左营", "710200", 2});
        // 香港
        districts.add(new Object[]{"810101", "中西区", "中西区", "810100", 1});
        districts.add(new Object[]{"810102", "湾仔区", "湾仔", "810100", 2});
        districts.add(new Object[]{"810103", "东区", "东区", "810100", 3});
        // 澳门
        districts.add(new Object[]{"820101", "花地玛堂区", "花地玛堂区", "820100", 1});
        districts.add(new Object[]{"820102", "花王堂区", "花王堂区", "820100", 2});

        for (Object[] d : districts) {
            Long cId = cityIdMap.get((String) d[3]);
            if (cId == null) continue;
            Region district = new Region();
            district.setParentId(cId);
            district.setLevel(4);
            district.setRegionCode((String) d[0]);
            district.setRegionName((String) d[1]);
            district.setShortName((String) d[2]);
            district.setPinyin("");
            district.setSortOrder((Integer) d[4]);
            district.setStatus(1);
            this.save(district);
        }
    }
}
