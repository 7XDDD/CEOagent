package com.crm.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.BusinessException;
import com.crm.dto.system.RoleCreateDTO;
import com.crm.dto.system.RoleQueryDTO;
import com.crm.dto.system.RoleUpdateDTO;
import com.crm.entity.Role;
import com.crm.entity.RolePermission;
import com.crm.entity.SysRoleProject;
import com.crm.mapper.RoleMapper;
import com.crm.mapper.RolePermissionMapper;
import com.crm.mapper.SysRoleProjectMapper;
import com.crm.service.RoleService;
import com.crm.vo.system.RoleVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleMapper roleMapper;

    @Autowired
    private RolePermissionMapper rolePermissionMapper;

    @Autowired
    private SysRoleProjectMapper roleProjectMapper;

    @Override
    public Page<RoleVO> pageList(RoleQueryDTO query) {
        Page<Role> page = new Page<>(query.getPageNum(), query.getPageSize());
        Page<Role> rolePage = roleMapper.selectPageList(page, query);
        Page<RoleVO> voPage = new Page<>(rolePage.getCurrent(), rolePage.getSize(), rolePage.getTotal());
        List<RoleVO> voList = rolePage.getRecords().stream().map(this::convertToVO).collect(Collectors.toList());
        voPage.setRecords(voList);
        return voPage;
    }

    @Override
    public List<Role> listAll() {
        return roleMapper.selectList(null);
    }

    @Override
    public RoleVO getDetail(Long id) {
        Role role = roleMapper.selectById(id);
        if (role == null) {
            throw new BusinessException("角色不存在");
        }
        RoleVO vo = convertToVO(role);
        vo.setPermissionIds(rolePermissionMapper.findPermissionIdsByRoleId(id));
        return vo;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Role create(RoleCreateDTO dto) {
        Role existRole = roleMapper.findByRoleCode(dto.getRoleCode());
        if (existRole != null) {
            throw new BusinessException("角色编码已存在");
        }
        Role role = new Role();
        BeanUtils.copyProperties(dto, role);
        if (role.getStatus() == null) role.setStatus(1);
        if (role.getSortOrder() == null) role.setSortOrder(0);
        roleMapper.insert(role);

        if (dto.getPermissionIds() != null && !dto.getPermissionIds().isEmpty()) {
            saveRolePermissions(role.getId(), dto.getPermissionIds());
        }
        return role;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Role update(Long id, RoleUpdateDTO dto) {
        Role role = roleMapper.selectById(id);
        if (role == null) {
            throw new BusinessException("角色不存在");
        }
        BeanUtils.copyProperties(dto, role);
        roleMapper.updateById(role);

        if (dto.getPermissionIds() != null) {
            rolePermissionMapper.deleteByRoleId(id);
            if (!dto.getPermissionIds().isEmpty()) {
                saveRolePermissions(id, dto.getPermissionIds());
            }
        }
        return role;
    }

    private void saveRolePermissions(Long roleId, List<Long> permissionIds) {
        for (Long permId : permissionIds) {
            RolePermission rp = new RolePermission();
            rp.setRoleId(roleId);
            rp.setPermissionId(permId);
            rolePermissionMapper.insert(rp);
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(Long id) {
        roleMapper.deleteById(id);
        rolePermissionMapper.deleteByRoleId(id);
        roleProjectMapper.deleteByRoleId(id);
    }

    @Override
    public List<Long> getPermissionIds(Long roleId) {
        return rolePermissionMapper.findPermissionIdsByRoleId(roleId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void assignPermissions(Long roleId, List<Long> permissionIds) {
        rolePermissionMapper.deleteByRoleId(roleId);
        if (permissionIds != null && !permissionIds.isEmpty()) {
            saveRolePermissions(roleId, permissionIds);
        }
    }

    @Override
    public List<Long> getProjectIds(Long roleId) {
        return roleProjectMapper.findProjectIdsByRoleId(roleId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void assignProjects(Long roleId, List<Long> projectIds) {
        roleProjectMapper.deleteByRoleId(roleId);
        if (projectIds != null && !projectIds.isEmpty()) {
            for (Long projectId : projectIds) {
                SysRoleProject rp = new SysRoleProject();
                rp.setRoleId(roleId);
                rp.setProjectId(projectId);
                roleProjectMapper.insert(rp);
            }
        }
    }

    private RoleVO convertToVO(Role role) {
        RoleVO vo = new RoleVO();
        BeanUtils.copyProperties(role, vo);
        return vo;
    }
}
