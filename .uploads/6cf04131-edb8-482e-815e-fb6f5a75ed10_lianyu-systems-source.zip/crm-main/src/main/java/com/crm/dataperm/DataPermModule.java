package com.crm.dataperm;

/**
 * 数据权限模块常量
 */
public final class DataPermModule {
    private DataPermModule() {}

    public static final String CUSTOMER = "CUSTOMER";
    public static final String OPPORTUNITY = "OPPORTUNITY";
    public static final String CONTRACT = "CONTRACT";
    public static final String PROJECT = "PROJECT";
}
