package com.crm.controller;

import cn.hutool.captcha.CaptchaUtil;
import cn.hutool.captcha.LineCaptcha;
import com.crm.common.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@RestController
@RequestMapping("/auth")
public class CaptchaController {

    private static final long CAPTCHA_EXPIRE_MS = 5 * 60 * 1000L;
    private static final int CAPTCHA_WIDTH = 100;
    private static final int CAPTCHA_HEIGHT = 30;
    private static final int CAPTCHA_CODE_COUNT = 4;
    private static final int CAPTCHA_LINE_COUNT = 10;

    private static final Map<String, CaptchaEntry> CAPTCHA_STORE = new ConcurrentHashMap<>();

    public static class CaptchaEntry {
        String code;
        long expireTime;

        CaptchaEntry(String code, long expireTime) {
            this.code = code;
            this.expireTime = expireTime;
        }
    }

    public static boolean validateCaptcha(String key, String inputCode) {
        if (key == null || inputCode == null) return false;
        CaptchaEntry entry = CAPTCHA_STORE.remove(key);
        if (entry == null) return false;
        if (System.currentTimeMillis() > entry.expireTime) return false;
        return entry.code.equalsIgnoreCase(inputCode.trim());
    }

    @GetMapping("/captcha")
    public void getCaptcha(HttpServletResponse response) throws IOException {
        response.setContentType("image/png");
        response.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
        response.setHeader("Pragma", "no-cache");

        LineCaptcha captcha = CaptchaUtil.createLineCaptcha(CAPTCHA_WIDTH, CAPTCHA_HEIGHT, CAPTCHA_CODE_COUNT, CAPTCHA_LINE_COUNT);
        String captchaKey = UUID.randomUUID().toString().replace("-", "");
        String code = captcha.getCode();

        CAPTCHA_STORE.put(captchaKey, new CaptchaEntry(code, System.currentTimeMillis() + CAPTCHA_EXPIRE_MS));
        cleanExpiredCaptchas();

        response.setHeader("Captcha-Key", captchaKey);
        response.setHeader("Access-Control-Expose-Headers", "Captcha-Key");

        ServletOutputStream out = response.getOutputStream();
        captcha.write(out);
        out.flush();
        out.close();
    }

    @GetMapping("/captcha-key")
    public Result<Map<String, String>> getCaptchaKey() {
        LineCaptcha captcha = CaptchaUtil.createLineCaptcha(CAPTCHA_WIDTH, CAPTCHA_HEIGHT, CAPTCHA_CODE_COUNT, CAPTCHA_LINE_COUNT);
        String captchaKey = UUID.randomUUID().toString().replace("-", "");
        String code = captcha.getCode();
        String imageBase64 = captcha.getImageBase64Data();

        CAPTCHA_STORE.put(captchaKey, new CaptchaEntry(code, System.currentTimeMillis() + CAPTCHA_EXPIRE_MS));
        cleanExpiredCaptchas();

        Map<String, String> result = new HashMap<>();
        result.put("captchaKey", captchaKey);
        result.put("captchaImage", imageBase64);
        return Result.success("获取成功", result);
    }

    private void cleanExpiredCaptchas() {
        long now = System.currentTimeMillis();
        CAPTCHA_STORE.entrySet().removeIf(e -> e.getValue().expireTime < now);
    }
}
