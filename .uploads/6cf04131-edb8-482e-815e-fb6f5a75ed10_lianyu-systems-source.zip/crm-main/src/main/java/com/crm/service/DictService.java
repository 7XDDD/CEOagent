package com.crm.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.system.*;
import com.crm.entity.Dict;
import com.crm.entity.DictItem;
import com.crm.vo.system.DictItemVO;
import com.crm.vo.system.DictVO;

import java.util.List;
import java.util.Map;

public interface DictService {

    Page<DictVO> pageList(DictQueryDTO query);

    DictVO getDetail(Long id);

    Dict createDict(DictCreateDTO dto);

    Dict updateDict(Long id, DictUpdateDTO dto);

    void deleteDict(Long id);

    List<DictItemVO> getDictItems(Long dictId);

    DictItem createDictItem(DictItemCreateDTO dto);

    DictItem updateDictItem(Long id, DictItemUpdateDTO dto);

    void deleteDictItem(Long id);

    Map<String, List<DictItemVO>> getDictByCodes(List<String> dictCodes);

    DictVO getTypeByCode(String dictCode, String systemType);

    List<DictItemVO> getItemsByTypeCode(String typeCode);

    DictItemVO getItemByCode(String code);

    Map<String, List<DictItemVO>> getAllItems(String codes);

    Map<String, List<DictItemVO>> getAllItems(String codes, String systemType);
}
