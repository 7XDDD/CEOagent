package com.crm.service.budget.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.BusinessException;
import com.crm.common.ResultCode;
import com.crm.common.SecurityContextUtil;
import com.crm.dto.PageResult;
import com.crm.dto.budget.BudgetVersionCreateDTO;
import com.crm.dto.budget.BudgetVersionQueryDTO;
import com.crm.dto.budget.BudgetVersionUpdateDTO;
import com.crm.entity.BudgetVersion;
import com.crm.mapper.BudgetVersionMapper;
import com.crm.service.budget.BudgetVersionService;
import com.crm.vo.budget.BudgetVersionVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 预算版本服务实现类
 * 负责预算版本的创建、查询、激活、锁定、删除等生命周期管理
 * 核心业务逻辑：
 * 1. 激活版本时，同一财年下的其他版本自动失效（同一财年仅允许一个生效版本）
 * 2. 锁定/解锁机制：锁定后版本不可编辑
 * 3. 删除前校验（当前使用软删除，存在关联数据时由业务层控制）
 */
@Service
public class BudgetVersionServiceImpl implements BudgetVersionService {

    private static final Logger log = LoggerFactory.getLogger(BudgetVersionServiceImpl.class);

    @Autowired
    private BudgetVersionMapper budgetVersionMapper;

    /**
     * 根据ID查询预算版本详情
     * @param id 版本ID
     * @return 预算版本VO对象
     */
    @Override
    public BudgetVersionVO getById(Serializable id) {
        BudgetVersion entity = budgetVersionMapper.selectById(id);
        if (entity == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "预算版本不存在");
        }
        return convertToVO(entity);
    }

    /**
     * 分页查询预算版本列表
     * @param query 查询条件DTO
     * @return 分页结果
     */
    @Override
    public PageResult<BudgetVersionVO> page(BudgetVersionQueryDTO query) {
        if (query == null) query = new BudgetVersionQueryDTO();
        int pageNum = query.getPageNum() != null ? query.getPageNum() : 1;
        int pageSize = query.getPageSize() != null ? query.getPageSize() : 10;

        Page<BudgetVersion> page = new Page<>(pageNum, pageSize);
        Page<BudgetVersion> result = budgetVersionMapper.selectPageList(page, query);

        List<BudgetVersionVO> voList = result.getRecords().stream()
                .map(this::convertToVO).collect(Collectors.toList());
        return new PageResult<>(voList, result.getTotal(), pageNum, pageSize);
    }

    /**
     * 根据条件查询预算版本列表（不分页）
     * @param query 查询条件DTO
     * @return 版本列表
     */
    @Override
    public List<BudgetVersionVO> list(BudgetVersionQueryDTO query) {
        List<BudgetVersion> entities = budgetVersionMapper.selectListByCondition(query);
        return entities.stream().map(this::convertToVO).collect(Collectors.toList());
    }

    /**
     * 获取指定公司、财年的当前激活版本
     * @param companyId 公司ID
     * @param fiscalYear 财年
     * @return 激活的版本VO，不存在则返回null
     */
    @Override
    public BudgetVersionVO getActiveVersion(Long companyId, Integer fiscalYear) {
        BudgetVersion entity = budgetVersionMapper.findActiveVersion(companyId, fiscalYear);
        return entity != null ? convertToVO(entity) : null;
    }

    /**
     * 获取滚动预算版本列表
     * @param fiscalYear 财年
     * @return 滚动版本列表
     */
    @Override
    public List<BudgetVersionVO> getRollingVersions(Integer fiscalYear) {
        List<BudgetVersion> entities = budgetVersionMapper.selectRollingVersions(fiscalYear);
        return entities.stream().map(this::convertToVO).collect(Collectors.toList());
    }

    /**
     * 创建新的预算版本
     * 关键逻辑：
     * 1. 校验版本编码唯一性（同一公司下编码不可重复）
     * 2. 新创建的版本默认为未激活、未锁定、草稿状态
     * @param dto 创建DTO
     * @return 创建后的版本VO
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public BudgetVersionVO create(BudgetVersionCreateDTO dto) {
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        // 1. 校验版本编码唯一性
        int existing = budgetVersionMapper.countByCode(dto.getVersionCode().trim(), null, companyId);
        if (existing > 0) {
            throw new BusinessException(ResultCode.DATA_DUPLICATE.getCode(), "版本编码 [" + dto.getVersionCode() + "] 已存在");
        }

        // 2. 构建版本实体，设置默认状态
        BudgetVersion entity = new BudgetVersion();
        entity.setFiscalYear(dto.getFiscalYear());
        entity.setVersionCode(dto.getVersionCode().trim());
        entity.setVersionName(dto.getVersionName());
        entity.setBudgetScene(dto.getBudgetScene());
        entity.setRollingMonth(dto.getRollingMonth());
        // 定稿标记仅调整预算（年中调整版）使用，其余版本类型强制为0（未定稿）
        boolean finalized = "ADJUST".equals(dto.getBudgetScene())
                && dto.getIsFinalized() != null && dto.getIsFinalized() == 1;
        if (finalized) {
            // 同一财年仅允许一个已定稿的调整预算版本
            int finalizedCount = budgetVersionMapper.countFinalizedAdjust(companyId, dto.getFiscalYear(), null);
            if (finalizedCount > 0) {
                throw new BusinessException(ResultCode.DATA_DUPLICATE.getCode(),
                        dto.getFiscalYear() + " 财年已存在已定稿的调整预算版本，同一财年仅允许一个定稿版本");
            }
        }
        entity.setIsFinalized(finalized ? 1 : 0);
        entity.setIsActive(0);
        entity.setIsLocked(0);
        entity.setApprovalStatus("DRAFT");
        entity.setEffectiveDate(dto.getEffectiveDate());
        entity.setExpireDate(dto.getExpireDate());
        entity.setParentVersionId(dto.getParentVersionId());
        entity.setRemark(dto.getRemark());
        entity.setOwnerId(dto.getOwnerId());
        entity.setCompanyId(companyId);
        entity.setDeleted(0);
        entity.setVersion(0);

        budgetVersionMapper.insert(entity);
        log.info("新增预算版本成功: id={}, code={}", entity.getId(), entity.getVersionCode());
        return convertToVO(entity);
    }

    /**
     * 更新预算版本信息
     * 关键逻辑：若修改版本编码，需重新校验编码唯一性
     * @param dto 更新DTO
     * @return 更新后的版本VO
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public BudgetVersionVO update(BudgetVersionUpdateDTO dto) {
        BudgetVersion entity = budgetVersionMapper.selectById(dto.getId());
        if (entity == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "预算版本不存在");
        }

        // 1. 若修改版本编码，校验新编码唯一性
        if (dto.getVersionCode() != null && !dto.getVersionCode().trim().equals(entity.getVersionCode())) {
            String code = dto.getVersionCode().trim();
            Long companyId = entity.getCompanyId();
            int existing = budgetVersionMapper.countByCode(code, dto.getId(), companyId);
            if (existing > 0) {
                throw new BusinessException(ResultCode.DATA_DUPLICATE.getCode(), "版本编码 [" + code + "] 已存在");
            }
            entity.setVersionCode(code);
        }

        // 2. 更新非空字段
        if (dto.getFiscalYear() != null) entity.setFiscalYear(dto.getFiscalYear());
        if (dto.getVersionName() != null) entity.setVersionName(dto.getVersionName());
        if (dto.getBudgetScene() != null) entity.setBudgetScene(dto.getBudgetScene());
        if (dto.getRollingMonth() != null) entity.setRollingMonth(dto.getRollingMonth());
        // 定稿标记：仅调整预算（ADJUST）可定稿，其余版本类型强制为0（未定稿）
        if ("ADJUST".equals(entity.getBudgetScene())) {
            if (dto.getIsFinalized() != null) {
                int newFinalized = dto.getIsFinalized() == 1 ? 1 : 0;
                if (newFinalized == 1) {
                    // 同一财年仅允许一个已定稿的调整预算版本（排除自身）
                    int finalizedCount = budgetVersionMapper.countFinalizedAdjust(
                            entity.getCompanyId(), entity.getFiscalYear(), entity.getId());
                    if (finalizedCount > 0) {
                        throw new BusinessException(ResultCode.DATA_DUPLICATE.getCode(),
                                entity.getFiscalYear() + " 财年已存在已定稿的调整预算版本，同一财年仅允许一个定稿版本");
                    }
                }
                entity.setIsFinalized(newFinalized);
            }
        } else {
            entity.setIsFinalized(0);
        }
        if (dto.getApprovalStatus() != null) entity.setApprovalStatus(dto.getApprovalStatus());
        if (dto.getEffectiveDate() != null) entity.setEffectiveDate(dto.getEffectiveDate());
        if (dto.getExpireDate() != null) entity.setExpireDate(dto.getExpireDate());
        if (dto.getParentVersionId() != null) entity.setParentVersionId(dto.getParentVersionId());
        if (dto.getRemark() != null) entity.setRemark(dto.getRemark());
        if (dto.getOwnerId() != null) entity.setOwnerId(dto.getOwnerId());

        budgetVersionMapper.updateById(entity);
        log.info("更新预算版本成功: id={}, code={}", entity.getId(), entity.getVersionCode());
        return convertToVO(entity);
    }

    /**
     * 激活指定预算版本
     * 关键逻辑：
     * 1. 先将同一财年、同一公司下的所有版本重置为未激活状态
     * 2. 再将当前版本设置为激活状态
     * 确保同一财年只有一个生效版本
     * @param id 要激活的版本ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void setActive(Long id) {
        BudgetVersion version = budgetVersionMapper.selectById(id);
        if (version == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "版本不存在");
        }

        // 1. 重置同财年所有版本为未激活状态
        budgetVersionMapper.resetActiveByFiscalYear(version.getFiscalYear(), version.getCompanyId());
        // 2. 激活当前版本
        int rows = budgetVersionMapper.setActive(id);
        if (rows == 0) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "版本不存在");
        }
        log.info("设置生效版本: id={}, fiscalYear={}", id, version.getFiscalYear());
    }

    /**
     * 锁定预算版本
     * 关键逻辑：锁定后的版本不可进行预算数据编辑操作
     * 幂等操作：已锁定的版本重复锁定不报错
     * @param id 版本ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void lock(Long id) {
        BudgetVersion version = budgetVersionMapper.selectById(id);
        if (version == null || version.getDeleted() != 0) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "版本不存在");
        }
        // 幂等处理：已锁定直接返回
        if (version.getIsLocked() != null && version.getIsLocked() == 1) {
            return;
        }
        budgetVersionMapper.lockById(id);
        log.info("锁定版本: id={}", id);
    }

    /**
     * 解锁预算版本
     * 关键逻辑：解锁后版本可继续编辑预算数据
     * 幂等操作：未锁定的版本重复解锁不报错
     * @param id 版本ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void unlock(Long id) {
        BudgetVersion version = budgetVersionMapper.selectById(id);
        if (version == null || version.getDeleted() != 0) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "版本不存在");
        }
        // 幂等处理：未锁定直接返回
        if (version.getIsLocked() == null || version.getIsLocked() == 0) {
            return;
        }
        budgetVersionMapper.unlockById(id);
        log.info("解锁版本: id={}", id);
    }

    /**
     * 删除预算版本（软删除）
     * 关键逻辑：使用软删除，标记deleted字段；存在关联预算数据时由业务层或数据库约束控制
     * @param id 版本ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Serializable id) {
        BudgetVersion entity = budgetVersionMapper.selectById(id);
        if (entity == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "预算版本不存在");
        }
        // 软删除
        int rows = budgetVersionMapper.softDeleteById(Long.valueOf(id.toString()));
        if (rows == 0) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "预算版本不存在或已删除");
        }
        log.info("删除预算版本成功: id={}", id);
    }

    /**
     * 批量删除预算版本（软删除）
     * @param ids 版本ID列表
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteBatch(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请选择要删除的数据");
        }
        budgetVersionMapper.softDeleteByIds(ids);
        log.info("批量删除预算版本成功: ids={}", ids);
    }

    /**
     * 实体转VO对象
     * @param e BudgetVersion实体
     * @return BudgetVersionVO视图对象
     */
    private BudgetVersionVO convertToVO(BudgetVersion e) {
        BudgetVersionVO vo = new BudgetVersionVO();
        vo.setId(e.getId());
        vo.setCompanyId(e.getCompanyId());
        vo.setFiscalYear(e.getFiscalYear());
        vo.setVersionCode(e.getVersionCode());
        vo.setVersionName(e.getVersionName());
        vo.setBudgetScene(e.getBudgetScene());
        vo.setRollingMonth(e.getRollingMonth());
        vo.setIsActive(e.getIsActive());
        vo.setIsLocked(e.getIsLocked());
        vo.setIsFinalized(e.getIsFinalized() != null ? e.getIsFinalized() : 0);
        vo.setApprovalStatus(e.getApprovalStatus());
        vo.setEffectiveDate(e.getEffectiveDate());
        vo.setExpireDate(e.getExpireDate());
        vo.setParentVersionId(e.getParentVersionId());
        vo.setRemark(e.getRemark());
        vo.setOwnerId(e.getOwnerId());
        vo.setCreatedBy(e.getCreatedBy());
        vo.setUpdatedBy(e.getUpdatedBy());
        vo.setCreateTime(e.getCreateTime());
        vo.setUpdateTime(e.getUpdateTime());
        vo.setVersion(e.getVersion());
        return vo;
    }
}
