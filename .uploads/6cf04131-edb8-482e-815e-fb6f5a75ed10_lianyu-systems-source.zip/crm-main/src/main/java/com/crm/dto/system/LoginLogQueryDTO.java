package com.crm.dto.system;

import com.crm.dto.PageQueryDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class LoginLogQueryDTO extends PageQueryDTO {
    private String keyword;
    private String username;
    private Integer status;
    private String loginResult;
    private String startTime;
    private String endTime;
}
