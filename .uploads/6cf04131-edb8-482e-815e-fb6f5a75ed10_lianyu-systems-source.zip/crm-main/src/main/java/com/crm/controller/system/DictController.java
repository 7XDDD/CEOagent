package com.crm.controller.system;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.annotation.OperationLog;
import com.crm.annotation.OperationLog.OperationType;
import com.crm.common.Result;
import com.crm.dto.system.*;
import com.crm.entity.Dict;
import com.crm.entity.DictItem;
import com.crm.service.DictService;
import com.crm.vo.system.DictItemVO;
import com.crm.vo.system.DictVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Api(tags = "系统管理-字典管理")
@RestController
@RequestMapping("/system/dict")
public class DictController {

    @Autowired
    private DictService dictService;

    @ApiOperation("分页查询字典列表")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:view')")
    @GetMapping("/page")
    public Result<Page<DictVO>> page(DictQueryDTO query) {
        return Result.success(dictService.pageList(query));
    }

    @ApiOperation("字典类型分页列表")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:view')")
    @GetMapping("/types")
    public Result<Page<DictVO>> pageTypes(DictQueryDTO query) {
        return Result.success(dictService.pageList(query));
    }

    @ApiOperation("获取字典详情")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:view')")
    @GetMapping("/{id}")
    public Result<DictVO> getDetail(@PathVariable Long id) {
        return Result.success(dictService.getDetail(id));
    }

    @ApiOperation("字典类型详情")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:view')")
    @GetMapping("/type/{id}")
    public Result<DictVO> getTypeDetail(@PathVariable Long id) {
        return Result.success(dictService.getDetail(id));
    }

    @ApiOperation("新增字典")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:create')")
    @OperationLog(module = "业务字典", description = "新增字典", type = OperationType.INSERT)
    @PostMapping
    public Result<?> create(@Validated @RequestBody DictCreateDTO dto) {
        dictService.createDict(dto);
        return Result.success("创建成功");
    }

    @ApiOperation("新增字典类型")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:create')")
    @OperationLog(module = "业务字典", description = "新增字典", type = OperationType.INSERT)
    @PostMapping("/types")
    public Result<?> createType(@Validated @RequestBody DictCreateDTO dto) {
        dictService.createDict(dto);
        return Result.success("创建成功");
    }

    @ApiOperation("修改字典")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:update')")
    @OperationLog(module = "业务字典", description = "修改字典", type = OperationType.UPDATE)
    @PutMapping("/{id}")
    public Result<?> update(@PathVariable Long id, @RequestBody DictUpdateDTO dto) {
        dictService.updateDict(id, dto);
        return Result.success("修改成功");
    }

    @ApiOperation("修改字典类型")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:update')")
    @OperationLog(module = "业务字典", description = "修改字典", type = OperationType.UPDATE)
    @PutMapping("/types/{id}")
    public Result<?> updateType(@PathVariable Long id, @RequestBody DictUpdateDTO dto) {
        dictService.updateDict(id, dto);
        return Result.success("修改成功");
    }

    @ApiOperation("删除字典")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:delete')")
    @OperationLog(module = "业务字典", description = "删除字典", type = OperationType.DELETE)
    @DeleteMapping("/{id:\\d+}")
    public Result<?> delete(@PathVariable Long id) {
        dictService.deleteDict(id);
        return Result.success("删除成功");
    }

    @ApiOperation("删除字典类型")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:delete')")
    @OperationLog(module = "业务字典", description = "删除字典", type = OperationType.DELETE)
    @DeleteMapping("/types/{id}")
    public Result<?> deleteType(@PathVariable Long id) {
        dictService.deleteDict(id);
        return Result.success("删除成功");
    }

    @ApiOperation("按编码获取字典类型")
    @GetMapping("/type-by-code/{dictType}")
    public Result<DictVO> getTypeByCode(@PathVariable String dictType, @RequestParam(required = false) String systemType) {
        return Result.success(dictService.getTypeByCode(dictType, systemType));
    }

    @ApiOperation("获取字典项列表")
    @GetMapping("/{id}/items")
    public Result<List<DictItemVO>> getDictItems(@PathVariable Long id) {
        return Result.success(dictService.getDictItems(id));
    }

    @ApiOperation("按类型编码获取字典项列表")
    @GetMapping("/items/type/{typeCode}")
    public Result<List<DictItemVO>> getItemsByTypeCode(@PathVariable String typeCode) {
        return Result.success(dictService.getItemsByTypeCode(typeCode));
    }

    @ApiOperation("按item code获取单个字典项")
    @GetMapping("/items/code/{code}")
    public Result<DictItemVO> getItemByCode(@PathVariable String code) {
        return Result.success(dictService.getItemByCode(code));
    }

    @ApiOperation("批量获取字典项")
    @GetMapping("/all-items")
    public Result<Map<String, List<DictItemVO>>> getAllItems(@RequestParam String codes,
                                                              @RequestParam(required = false) String systemType) {
        return Result.success(dictService.getAllItems(codes, systemType));
    }

    @ApiOperation("新增字典项")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:create')")
    @OperationLog(module = "业务字典", description = "新增字典项", type = OperationType.INSERT)
    @PostMapping("/item")
    public Result<?> createItem(@Validated @RequestBody DictItemCreateDTO dto) {
        dictService.createDictItem(dto);
        return Result.success("创建成功");
    }

    @ApiOperation("新增字典项")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:create')")
    @OperationLog(module = "业务字典", description = "新增字典项", type = OperationType.INSERT)
    @PostMapping("/items")
    public Result<?> createItemNew(@Validated @RequestBody DictItemCreateDTO dto) {
        dictService.createDictItem(dto);
        return Result.success("创建成功");
    }

    @ApiOperation("修改字典项")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:update')")
    @OperationLog(module = "业务字典", description = "修改字典项", type = OperationType.UPDATE)
    @PutMapping("/item/{id}")
    public Result<?> updateItem(@PathVariable Long id, @RequestBody DictItemUpdateDTO dto) {
        dictService.updateDictItem(id, dto);
        return Result.success("修改成功");
    }

    @ApiOperation("修改字典项")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:update')")
    @OperationLog(module = "业务字典", description = "修改字典项", type = OperationType.UPDATE)
    @PutMapping("/items/{id}")
    public Result<?> updateItemNew(@PathVariable Long id, @RequestBody DictItemUpdateDTO dto) {
        dictService.updateDictItem(id, dto);
        return Result.success("修改成功");
    }

    @ApiOperation("删除字典项")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:delete')")
    @OperationLog(module = "业务字典", description = "删除字典项", type = OperationType.DELETE)
    @DeleteMapping("/item/{id}")
    public Result<?> deleteItem(@PathVariable Long id) {
        dictService.deleteDictItem(id);
        return Result.success("删除成功");
    }

    @ApiOperation("删除字典项")
    @PreAuthorize("@permissionChecker.hasPermission('crm:dict:delete')")
    @OperationLog(module = "业务字典", description = "删除字典项", type = OperationType.DELETE)
    @DeleteMapping("/items/{id}")
    public Result<?> deleteItemNew(@PathVariable Long id) {
        dictService.deleteDictItem(id);
        return Result.success("删除成功");
    }

    @ApiOperation("根据字典编码获取字典项")
    @PostMapping("/by-codes")
    public Result<Map<String, List<DictItemVO>>> getDictByCodes(@RequestBody List<String> dictCodes) {
        return Result.success(dictService.getDictByCodes(dictCodes));
    }
}
