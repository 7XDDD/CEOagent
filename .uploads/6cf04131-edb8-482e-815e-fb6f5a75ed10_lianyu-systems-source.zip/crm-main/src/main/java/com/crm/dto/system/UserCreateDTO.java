package com.crm.dto.system;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

@Data
public class UserCreateDTO {
    @NotBlank(message = "用户名不能为空")
    private String username;
    private String password;
    @NotBlank(message = "真实姓名不能为空")
    private String realName;
    private String employeeNo;
    private String email;
    private String phone;
    private Integer gender;
    private Long deptId;
    private String position;
    private String userType;
    private Integer status;
    private String remark;
    private List<Long> roleIds;
    private Long employeeId;
}
