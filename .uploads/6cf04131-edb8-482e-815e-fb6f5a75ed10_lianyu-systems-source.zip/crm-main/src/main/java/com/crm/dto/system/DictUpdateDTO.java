package com.crm.dto.system;

import lombok.Data;

@Data
public class DictUpdateDTO {
    private String dictType;
    private String dictCode;
    private String dictName;
    private String systemType;
    private Integer sortOrder;
    private Integer status;
    private String remark;
}
