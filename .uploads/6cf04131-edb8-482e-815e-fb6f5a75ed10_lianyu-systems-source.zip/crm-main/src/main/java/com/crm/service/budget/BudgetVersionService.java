package com.crm.service.budget;

import com.crm.dto.PageResult;
import com.crm.dto.budget.BudgetVersionCreateDTO;
import com.crm.dto.budget.BudgetVersionQueryDTO;
import com.crm.dto.budget.BudgetVersionUpdateDTO;
import com.crm.vo.budget.BudgetVersionVO;

import java.io.Serializable;
import java.util.List;

public interface BudgetVersionService {

    BudgetVersionVO getById(Serializable id);

    PageResult<BudgetVersionVO> page(BudgetVersionQueryDTO query);

    List<BudgetVersionVO> list(BudgetVersionQueryDTO query);

    BudgetVersionVO getActiveVersion(Long companyId, Integer fiscalYear);

    List<BudgetVersionVO> getRollingVersions(Integer fiscalYear);

    BudgetVersionVO create(BudgetVersionCreateDTO dto);

    BudgetVersionVO update(BudgetVersionUpdateDTO dto);

    void setActive(Long id);

    void lock(Long id);

    void unlock(Long id);

    void deleteById(Serializable id);

    void deleteBatch(List<Long> ids);
}
