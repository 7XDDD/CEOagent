package com.crm.dto.base;

import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDate;

@Data
public class FiscalYearUpdateDTO {

    @NotNull(message = "ID不能为空")
    private Long id;

    private Integer fiscalYear;

    private Integer budgetMonth;

    @Size(max = 20, message = "状态长度不能超过20")
    private String yearStatus;

    private Integer isCurrentYear;

    @Size(max = 200, message = "描述长度不能超过200")
    private String description;

    private LocalDate startDate;

    private LocalDate endDate;

    private Integer version;
}
