package com.crm.aspect;

import com.crm.annotation.OperationLog;
import com.crm.common.Result;
import com.crm.mapper.OperationLogMapper;
import com.crm.common.SecurityContextUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

@Slf4j
@Aspect
@Component
public class OperationLogAspect {

    @Autowired
    private OperationLogMapper operationLogMapper;

    @Autowired
    private ObjectMapper objectMapper;

    @Pointcut("@annotation(com.crm.annotation.OperationLog)")
    public void operationLogPointcut() {
    }

    @Around("operationLogPointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object result = null;
        Exception exception = null;

        try {
            result = joinPoint.proceed();
            return result;
        } catch (Exception e) {
            exception = e;
            throw e;
        } finally {
            long costTime = System.currentTimeMillis() - startTime;
            try {
                saveOperationLog(joinPoint, result, exception, costTime);
            } catch (Exception e) {
                log.error("保存操作日志失败", e);
            }
        }
    }

    private void saveOperationLog(ProceedingJoinPoint joinPoint, Object result, Exception exception, long costTime) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        com.crm.annotation.OperationLog operationLogAnnotation = method.getAnnotation(com.crm.annotation.OperationLog.class);

        if (operationLogAnnotation == null) {
            return;
        }

        String username = getCurrentUsername();
        Long userId = getCurrentUserId();
        HttpServletRequest request = getCurrentRequest();
        String ip = request != null ? getIpAddress(request) : "unknown";
        String requestUri = request != null ? request.getRequestURI() : "";

        com.crm.entity.OperationLog logEntity = new com.crm.entity.OperationLog();
        logEntity.setUsername(username);
        logEntity.setModule(operationLogAnnotation.module());
        logEntity.setType(operationLogAnnotation.type().name());

        // 生成详细的操作描述
        String operationDesc = buildOperationDescription(joinPoint, operationLogAnnotation, requestUri);
        logEntity.setDescription(operationDesc);
        logEntity.setMethod(signature.getDeclaringType().getSimpleName() + "." + signature.getName());
        logEntity.setIp(ip);
        logEntity.setDuration(costTime);
        logEntity.setRequestUrl(requestUri);
        logEntity.setRequestMethod(request != null ? request.getMethod() : "");

        if (operationLogAnnotation.recordParams()) {
            String params = getParamsJson(joinPoint, signature);
            logEntity.setRequestParams(params.length() > 2000 ? params.substring(0, 2000) : params);
        }

        if (operationLogAnnotation.recordResult() && result != null) {
            String resultJson = toJson(result);
            logEntity.setResponseResult(resultJson.length() > 2000 ? resultJson.substring(0, 2000) : resultJson);
        }

        if (exception != null) {
            logEntity.setStatus(0);
            logEntity.setErrorMsg(exception.getMessage() != null && exception.getMessage().length() > 2000 ? 
                exception.getMessage().substring(0, 2000) : exception.getMessage());
        } else if (result instanceof Result) {
            Result<?> r = (Result<?>) result;
            logEntity.setStatus(r.getCode() == 200 ? 1 : 0);
        } else {
            logEntity.setStatus(1);
        }

        try {
            operationLogMapper.insert(logEntity);
        } catch (Exception e) {
            log.error("保存操作日志到数据库失败", e);
        }
    }

    private String buildOperationDescription(ProceedingJoinPoint joinPoint, OperationLog annotation, String requestUri) {
        StringBuilder desc = new StringBuilder();
        desc.append(annotation.description());
        
        String targetInfo = extractTargetInfo(joinPoint, requestUri);
        if (!targetInfo.isEmpty()) {
            desc.append(" [").append(targetInfo).append("]");
        }
        
        return desc.toString();
    }

    private String extractTargetInfo(ProceedingJoinPoint joinPoint, String requestUri) {
        StringBuilder info = new StringBuilder();
        
        // 优先从请求路径提取表名
        String tableName = guessTableNameFromUri(requestUri);
        
        // 如果路径无法识别，再从类名推断
        if (tableName.isEmpty()) {
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            tableName = guessTableName(signature.getDeclaringType().getSimpleName());
        }
        
        if (!tableName.isEmpty()) {
            info.append(tableName);
        }

        // 提取参数信息
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Parameter[] parameters = signature.getMethod().getParameters();
        Object[] args = joinPoint.getArgs();

        for (int i = 0; i < parameters.length; i++) {
            Object arg = args[i];
            if (arg == null) continue;

            String paramName = parameters[i].getName();
            if ("id".equalsIgnoreCase(paramName)) {
                if (info.length() > 0) info.append(" ");
                info.append("ID=").append(arg);
            } else if (arg instanceof Long && paramName.toLowerCase().endsWith("id")) {
                if (info.length() > 0) info.append(" ");
                info.append(paramName).append("=").append(arg);
            } else if (paramName.contains("ids") || paramName.contains("Ids")) {
                if (info.length() > 0) info.append(" ");
                info.append(paramName).append("=").append(toJson(arg));
            } else if (arg instanceof Integer || arg instanceof String) {
                if (paramName.equalsIgnoreCase("companyId") || paramName.equalsIgnoreCase("contractTypeId")) {
                    if (info.length() > 0) info.append(" ");
                    info.append(paramName).append("=").append(arg);
                }
            }
        }

        return info.toString();
    }

    private String guessTableNameFromUri(String requestUri) {
        if (requestUri == null || requestUri.isEmpty()) {
            return "";
        }
        
        // 提取路径中的资源名
        String resourceName = "";
        String[] parts = requestUri.split("/");
        for (String part : parts) {
            if (!part.isEmpty() && !part.equals("api") && !part.equals("system") && !part.equals("base") && 
                !part.equals("contract") && !part.equals("budget") && !part.equals("business")) {
                resourceName = part;
                break;
            }
        }
        
        // 根据资源名映射到表名
        switch (resourceName.toLowerCase()) {
            case "user": return "crm_user";
            case "users": return "crm_user";
            case "role": return "crm_role";
            case "roles": return "crm_role";
            case "permission": return "crm_permission";
            case "permissions": return "crm_permission";
            case "organization": return "crm_org";
            case "organizations": return "crm_org";
            case "dictionary": return "crm_dict";
            case "dictionaries": return "crm_dict";
            case "company": return "crm_company";
            case "companies": return "crm_company";
            case "contract-type": return "contract_type";
            case "contract": return "crm_contract";
            case "contracts": return "crm_contract";
            case "product-line": return "crm_product";
            case "product": return "crm_product";
            case "customer": return "crm_customer";
            case "customers": return "crm_customer";
            case "budget": return "crm_budget_sheet";
            case "milestone": return "crm_contract_milestone";
            case "operation-log": return "crm_operation_log";
            case "login-log": return "crm_login_log";
            default: return "";
        }
    }

    private String guessTableName(String className) {
        if (className.contains("User")) return "crm_user";
        if (className.contains("Role")) return "crm_role";
        if (className.contains("Permission")) return "crm_permission";
        if (className.contains("Contract")) return "crm_contract";
        if (className.contains("Budget")) return "crm_budget_sheet";
        if (className.contains("Product")) return "crm_product";
        if (className.contains("Customer")) return "crm_customer";
        if (className.contains("Organization")) return "crm_org";
        if (className.contains("Dictionary")) return "crm_dict";
        if (className.contains("Company")) return "crm_company";
        if (className.contains("ContractType")) return "contract_type";
        return "";
    }

    private String getCurrentUsername() {
        try {
            return SecurityContextUtil.getCurrentUsername();
        } catch (Exception e) {
            return "unknown";
        }
    }

    private Long getCurrentUserId() {
        try {
            return SecurityContextUtil.getCurrentUserId();
        } catch (Exception e) {
            return null;
        }
    }

    private HttpServletRequest getCurrentRequest() {
        try {
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            return attributes != null ? attributes.getRequest() : null;
        } catch (Exception e) {
            return null;
        }
    }

    private String getIpAddress(HttpServletRequest request) {
        if (request == null) {
            return "unknown";
        }
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        return ip;
    }

    private String getParamsJson(ProceedingJoinPoint joinPoint, MethodSignature signature) {
        Object[] args = joinPoint.getArgs();
        Parameter[] parameters = signature.getMethod().getParameters();
        
        if (args == null || args.length == 0 || parameters == null || parameters.length == 0) {
            return "";
        }
        
        StringBuilder params = new StringBuilder("{");
        for (int i = 0; i < parameters.length; i++) {
            if (i > 0) params.append(", ");
            params.append("\"").append(parameters[i].getName()).append("\":");
            
            Object arg = args[i];
            if (arg == null) {
                params.append("null");
            } else if (arg instanceof String || arg instanceof Number || arg instanceof Boolean) {
                params.append(toJson(arg));
            } else {
                String json = toJson(arg);
                params.append(json.length() > 500 ? "\"数据对象\"" : json);
            }
        }
        params.append("}");
        
        return params.toString();
    }

    private String toJson(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            return "序列化失败";
        }
    }
}