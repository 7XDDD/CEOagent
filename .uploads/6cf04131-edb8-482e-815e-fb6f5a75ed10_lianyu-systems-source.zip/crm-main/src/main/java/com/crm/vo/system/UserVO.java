package com.crm.vo.system;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class UserVO {
    private Long id;
    private Long employeeId;
    private String username;
    private String realName;
    private String employeeNo;
    private String email;
    private String phone;
    private String avatarUrl;
    private Integer gender;
    private Long deptId;
    private String deptName;
    private String position;
    private String userType;
    private Integer status;
    private String remark;
    private String roleIds;
    private String roleNames;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastLoginTime;
    private String lastLoginIp;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;
    private List<Long> roleIdList;
}
