package com.crm.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@TableName("crm_budget_sheet")
public class BudgetSheet implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    private Integer fiscalYear;

    private Long versionId;

    private Long catalogId;

    private String catalogCode;

    private Long contractId;

    private String contractNo;

    private String contractName;

    @TableField(exist = false)
    private String projectCode;

    private String projectName;

    private BigDecimal contractAmount;

    private Long customerId;

    private String customerName;

    private Long contractTypeId;

    private String contractType;

    private String contractTypeName;

    private Long orgId;

    private Long productLineId;

    private String productLine;

    private String stockFlag;

    private String manager;

    private String salesManager;

    private String contractStatus;

    private BigDecimal totalAmount;

    private String calcRule;

    private String approvalStatus;

    private Integer isSummaryRow;

    private String remark;

    private Long ownerId;

    @TableField(value = "created_by", fill = FieldFill.INSERT)
    private Long createdBy;

    @TableField(value = "updated_by", fill = FieldFill.INSERT)
    private Long updatedBy;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    @Version
    @TableField(fill = FieldFill.INSERT)
    private Integer version = 0;

    @TableLogic
    @TableField(fill = FieldFill.INSERT)
    private Integer deleted = 0;

}
