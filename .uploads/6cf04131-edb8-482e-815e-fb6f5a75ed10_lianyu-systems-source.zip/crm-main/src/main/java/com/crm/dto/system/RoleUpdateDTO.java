package com.crm.dto.system;

import lombok.Data;

import java.util.List;

@Data
public class RoleUpdateDTO {
    private String roleName;
    private String roleType;
    private String description;
    private Integer sortOrder;
    private Integer status;
    private List<Long> permissionIds;
}
