package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.crm.dto.project.ProjectQueryDTO;
import com.crm.entity.Project;
import com.crm.vo.project.ProjectVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ProjectMapper extends BaseMapper<Project> {

    IPage<ProjectVO> selectPageList(IPage<ProjectVO> page,
                                    @Param("companyId") Long companyId,
                                    @Param("query") ProjectQueryDTO query);
}
