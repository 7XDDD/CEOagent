package com.crm.dataperm.resolver;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crm.dataperm.DataOwnerResolver;
import com.crm.dataperm.DataPermModule;
import com.crm.entity.Contract;
import com.crm.mapper.contract.ContractMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

/** 合同负责人：owner_id / 创建人 */
@Component
public class ContractOwnerResolver implements DataOwnerResolver {

    @Autowired
    private ContractMapper contractMapper;

    @Override
    public String module() {
        return DataPermModule.CONTRACT;
    }

    @Override
    public boolean isOwner(Long bizId, Long userId) {
        if (bizId == null || userId == null) return false;
        LambdaQueryWrapper<Contract> w = new LambdaQueryWrapper<>();
        w.eq(Contract::getId, bizId)
                .and(x -> x.eq(Contract::getOwnerId, userId).or().eq(Contract::getCreatedBy, userId));
        return contractMapper.selectCount(w) > 0;
    }

    @Override
    public Set<Long> findOwnerIds(Collection<Long> bizIds, Long userId) {
        if (bizIds == null || bizIds.isEmpty() || userId == null) return Collections.emptySet();
        LambdaQueryWrapper<Contract> w = new LambdaQueryWrapper<>();
        w.in(Contract::getId, bizIds)
                .and(x -> x.eq(Contract::getOwnerId, userId).or().eq(Contract::getCreatedBy, userId));
        return contractMapper.selectList(w).stream().map(Contract::getId).collect(Collectors.toSet());
    }
}
