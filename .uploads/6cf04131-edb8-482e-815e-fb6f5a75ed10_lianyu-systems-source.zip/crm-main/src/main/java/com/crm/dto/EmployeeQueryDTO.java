package com.crm.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class EmployeeQueryDTO extends PageQueryDTO {
    private String keyword;
    private Long orgId;
    private String workStatus;
    private String employmentType;
    private Integer isConsultant;
}
