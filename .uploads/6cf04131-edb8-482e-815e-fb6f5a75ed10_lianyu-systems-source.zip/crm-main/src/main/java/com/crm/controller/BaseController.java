package com.crm.controller;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.annotation.OperationLog;
import com.crm.common.Result;
import com.crm.dto.PageQueryDTO;
import com.crm.dto.PageResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
public abstract class BaseController<T, M extends BaseMapper<T>> {

    @Autowired
    protected M mapper;

    @GetMapping("/{id}")
    public Result<T> getById(@PathVariable Serializable id) {
        T entity = mapper.selectById(id);
        return Result.success("查询成功", entity);
    }

    @PostMapping("/page")
    public Result<PageResult<T>> page(@RequestBody(required = false) PageQueryDTO query) {
        if (query == null) query = new PageQueryDTO();
        int pageNum = query.getPageNum() != null ? query.getPageNum() : 1;
        int pageSize = query.getPageSize() != null ? query.getPageSize() : 10;
        Page<T> page = new Page<>(pageNum, pageSize);
        QueryWrapper<T> wrapper = buildQueryWrapper(query);
        Page<T> result = mapper.selectPage(page, wrapper);
        PageResult<T> pr = new PageResult<>(result.getRecords(), result.getTotal(), pageNum, pageSize);
        return Result.success("查询成功", pr);
    }

    @PostMapping("/list")
    public Result<List<T>> list(@RequestBody(required = false) PageQueryDTO query) {
        if (query == null) query = new PageQueryDTO();
        QueryWrapper<T> wrapper = buildQueryWrapper(query);
        List<T> list = mapper.selectList(wrapper);
        return Result.success("查询成功", list);
    }

    @PostMapping
    @OperationLog(module = "系统管理", description = "新增数据", type = OperationLog.OperationType.INSERT)
    public Result<T> save(@RequestBody T entity) {
        mapper.insert(entity);
        return Result.success("保存成功", entity);
    }

    @PutMapping
    @OperationLog(module = "系统管理", description = "更新数据", type = OperationLog.OperationType.UPDATE)
    public Result<T> update(@RequestBody T entity) {
        mapper.updateById(entity);
        return Result.success("更新成功", entity);
    }

    @DeleteMapping("/{id}")
    @OperationLog(module = "系统管理", description = "删除数据", type = OperationLog.OperationType.DELETE)
    public Result<String> delete(@PathVariable Serializable id) {
        softDeleteById(id);
        return Result.success("删除成功", null);
    }

    @DeleteMapping("/batch")
    @OperationLog(module = "系统管理", description = "批量删除数据", type = OperationLog.OperationType.DELETE)
    public Result<String> deleteBatch(@RequestBody List<Long> ids) {
        if (ids == null || ids.isEmpty()) return Result.error("请选择要删除的数据");
        for (Long id : ids) {
            softDeleteById(id);
        }
        return Result.success("批量删除成功", null);
    }

    protected QueryWrapper<T> buildQueryWrapper(PageQueryDTO query) {
        return new QueryWrapper<>();
    }

    protected void softDeleteById(Serializable id) {
        UpdateWrapper<T> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", id).eq("deleted", 0);
        updateWrapper.setSql("deleted = id");
        mapper.update(null, updateWrapper);
    }
}
