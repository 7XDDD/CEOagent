package com.crm.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.crm.common.SecurityContextUtil;
import com.crm.entity.Contract;
import com.crm.entity.ContractMilestone;
import com.crm.entity.PmtCustomer;
import com.crm.entity.Opportunity;
import com.crm.entity.OpportunityFollow;
import com.crm.entity.User;
import com.crm.mapper.contract.ContractMilestoneMapper;
import com.crm.mapper.contract.ContractMapper;
import com.crm.mapper.PmtCustomerMapper;
import com.crm.mapper.OpportunityFollowMapper;
import com.crm.mapper.OpportunityMapper;
import com.crm.mapper.UserMapper;
import com.crm.service.DashboardService;
import com.crm.vo.dashboard.DashboardStatsVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class DashboardServiceImpl implements DashboardService {

    @Autowired
    private PmtCustomerMapper customerMapper;
    @Autowired
    private ContractMapper contractMapper;
    @Autowired
    private OpportunityMapper opportunityMapper;
    @Autowired
    private OpportunityFollowMapper followMapper;
    @Autowired
    private ContractMilestoneMapper milestoneMapper;
    @Autowired
    private UserMapper userMapper;

    @Override
    public DashboardStatsVO stats(String range, String rankTab) {
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        if (rankTab == null || rankTab.isEmpty()) rankTab = "customer";

        LocalDateTime start;
        LocalDate today = LocalDate.now();
        if ("week".equalsIgnoreCase(range)) {
            LocalDate monday = today.with(DayOfWeek.MONDAY);
            start = monday.atStartOfDay();
        } else if ("year".equalsIgnoreCase(range)) {
            start = today.withDayOfYear(1).atStartOfDay();
        } else {
            start = today.withDayOfMonth(1).atStartOfDay();
        }
        LocalDateTime end = LocalDateTime.now();

        DashboardStatsVO vo = new DashboardStatsVO();

        // 客户统计
        QueryWrapper<PmtCustomer> cw = new QueryWrapper<>();
        cw.eq("deleted", 0);
        long totalCust = customerMapper.selectCount(cw);
        QueryWrapper<PmtCustomer> cwNew = new QueryWrapper<>();
        cwNew.eq("deleted", 0).ge("create_time", start).le("create_time", end);
        vo.getCustomer().setCreated(customerMapper.selectCount(cwNew));
        QueryWrapper<PmtCustomer> cwAssigned = new QueryWrapper<>();
        cwAssigned.eq("deleted", 0).isNotNull("follower_id");
        vo.getCustomer().setAssigned(customerMapper.selectCount(cwAssigned));
        // 跟进客户数：有跟进记录的客户
        QueryWrapper<OpportunityFollow> fw = new QueryWrapper<>();
        fw.eq("company_id", companyId).eq("deleted", 0).select("DISTINCT customer_id");
        List<OpportunityFollow> follows = followMapper.selectList(fw);
        long followedCust = follows.stream().map(OpportunityFollow::getCustomerId).filter(java.util.Objects::nonNull).distinct().count();
        vo.getCustomer().setFollowed(followedCust);

        // 成交统计（已签合同，signDate在范围内）
        QueryWrapper<Contract> ctSigned = new QueryWrapper<>();
        ctSigned.eq("company_id", companyId).eq("deleted", 0)
                .and(w -> w.eq("contract_status", "SIGNED").or().eq("contract_status", "COMPLETED"))
                .ge("sign_date", start.toLocalDate()).le("sign_date", end.toLocalDate());
        List<Contract> signed = contractMapper.selectList(ctSigned);
        vo.getDeal().setOrders((long) signed.size());
        vo.getDeal().setAmount(signed.stream().map(Contract::getContractAmount)
                .filter(java.util.Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add));
        vo.getDeal().setCustomers(signed.stream().map(Contract::getCustomerId)
                .filter(java.util.Objects::nonNull).distinct().count());

        // 商机统计
        QueryWrapper<Opportunity> owNew = new QueryWrapper<>();
        owNew.eq("company_id", companyId).eq("deleted", 0).ge("create_time", start).le("create_time", end);
        vo.getOpp().setCreated(opportunityMapper.selectCount(owNew));
        QueryWrapper<OpportunityFollow> fwIn = new QueryWrapper<>();
        fwIn.eq("company_id", companyId).eq("deleted", 0).ge("follow_time", start).le("follow_time", end)
                .select("DISTINCT opportunity_id");
        long followedOpp = followMapper.selectList(fwIn).stream()
                .map(OpportunityFollow::getOpportunityId).filter(java.util.Objects::nonNull).distinct().count();
        vo.getOpp().setFollowed(followedOpp);
        QueryWrapper<Opportunity> owProg = new QueryWrapper<>();
        owProg.eq("company_id", companyId).eq("deleted", 0).ge("stage_rate", 25).ne("status", "LOST");
        vo.getOpp().setProgress(opportunityMapper.selectCount(owProg));

        // 业绩预估（进行中商机按赢率加权 TOP8）
        QueryWrapper<Opportunity> owActive = new QueryWrapper<>();
        owActive.eq("company_id", companyId).eq("deleted", 0).eq("status", "IN_PROGRESS");
        List<Opportunity> active = opportunityMapper.selectList(owActive);
        List<DashboardStatsVO.ForecastItem> forecast = active.stream()
                .map(o -> {
                    DashboardStatsVO.ForecastItem it = new DashboardStatsVO.ForecastItem();
                    it.setName(o.getOpportunityName());
                    it.setRate(o.getStageRate() == null ? 0 : o.getStageRate());
                    it.setAmount(o.getAmount() == null ? BigDecimal.ZERO : o.getAmount());
                    it.setWeighted(it.getAmount().multiply(new BigDecimal(it.getRate()))
                            .divide(new BigDecimal(100), 2, java.math.RoundingMode.HALF_UP));
                    return it;
                })
                .sorted(Comparator.comparing(DashboardStatsVO.ForecastItem::getWeighted).reversed())
                .limit(8).collect(Collectors.toList());
        vo.getForecast().setList(forecast);
        vo.getForecast().setTotal(forecast.stream().map(DashboardStatsVO.ForecastItem::getWeighted)
                .reduce(BigDecimal.ZERO, BigDecimal::add));

        // 回款统计（里程碑 actualAmount>0 且 actualDate 在范围内）
        QueryWrapper<ContractMilestone> mw = new QueryWrapper<>();
        mw.eq("company_id", companyId).eq("deleted", 0)
                .gt("actual_amount", 0).ge("actual_date", start.toLocalDate()).le("actual_date", end.toLocalDate());
        List<ContractMilestone> milestones = milestoneMapper.selectList(mw);
        vo.getPayment().setTimes((long) milestones.size());
        vo.getPayment().setAmount(milestones.stream().map(ContractMilestone::getActualAmount)
                .filter(java.util.Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add));
        vo.getPayment().setOrders(milestones.stream().map(ContractMilestone::getContractId)
                .filter(java.util.Objects::nonNull).distinct().count());
        // 回款客户数
        if (!milestones.isEmpty()) {
            List<Long> contractIds = milestones.stream().map(ContractMilestone::getContractId)
                    .filter(java.util.Objects::nonNull).distinct().collect(Collectors.toList());
            QueryWrapper<Contract> cw2 = new QueryWrapper<>();
            cw2.in("id", contractIds).select("customer_id");
            long payCust = contractMapper.selectList(cw2).stream().map(Contract::getCustomerId)
                    .filter(java.util.Objects::nonNull).distinct().count();
            vo.getPayment().setCustomers(payCust);
        }

        // 销售排行榜
        vo.setRankTab(rankTab);
        vo.setRankList(buildRank(rankTab, companyId, start, end));

        return vo;
    }

    private List<DashboardStatsVO.RankItem> buildRank(String tab, Long companyId,
                                                      LocalDateTime start, LocalDateTime end) {
        Map<String, BigDecimal> map = new HashMap<>();
        if ("customer".equals(tab)) {
            QueryWrapper<PmtCustomer> cw = new QueryWrapper<>();
            cw.eq("deleted", 0).ge("create_time", start).le("create_time", end);
            customerMapper.selectList(cw).forEach(c -> {
                String n = nameOf(c.getFollowerId());
                map.merge(n, BigDecimal.ONE, BigDecimal::add);
            });
        } else if ("follow".equals(tab)) {
            QueryWrapper<OpportunityFollow> fw = new QueryWrapper<>();
            fw.eq("company_id", companyId).eq("deleted", 0).ge("follow_time", start).le("follow_time", end);
            followMapper.selectList(fw).forEach(f -> {
                String n = f.getFollower() != null ? f.getFollower() : "未知";
                map.merge(n, BigDecimal.ONE, BigDecimal::add);
            });
        } else if ("amount".equals(tab)) {
            QueryWrapper<Contract> cw = new QueryWrapper<>();
            cw.eq("company_id", companyId).eq("deleted", 0)
                    .and(w -> w.eq("contract_status", "SIGNED").or().eq("contract_status", "COMPLETED"))
                    .ge("sign_date", start.toLocalDate()).le("sign_date", end.toLocalDate());
            contractMapper.selectList(cw).forEach(c -> {
                String n = c.getManager() != null ? c.getManager() : "未知";
                map.merge(n, c.getContractAmount() == null ? BigDecimal.ZERO : c.getContractAmount(), BigDecimal::add);
            });
        } else if ("payment".equals(tab)) {
            QueryWrapper<ContractMilestone> mw = new QueryWrapper<>();
            mw.eq("company_id", companyId).eq("deleted", 0).gt("actual_amount", 0)
                    .ge("actual_date", start.toLocalDate()).le("actual_date", end.toLocalDate());
            List<ContractMilestone> ms = milestoneMapper.selectList(mw);
            if (!ms.isEmpty()) {
                List<Long> cids = ms.stream().map(ContractMilestone::getContractId)
                        .filter(java.util.Objects::nonNull).distinct().collect(Collectors.toList());
                Map<Long, String> cManager = new HashMap<>();
                contractMapper.selectList(new QueryWrapper<Contract>().in("id", cids))
                        .forEach(c -> cManager.put(c.getId(), c.getManager()));
                ms.forEach(m -> {
                    String n = cManager.getOrDefault(m.getContractId(), "未知");
                    map.merge(n, m.getActualAmount() == null ? BigDecimal.ZERO : m.getActualAmount(), BigDecimal::add);
                });
            }
        }
        List<DashboardStatsVO.RankItem> list = new ArrayList<>();
        map.forEach((k, v) -> {
            DashboardStatsVO.RankItem it = new DashboardStatsVO.RankItem();
            it.setName(k);
            it.setValue(v);
            list.add(it);
        });
        list.sort(Comparator.comparing(DashboardStatsVO.RankItem::getValue).reversed());
        return list;
    }

    private String nameOf(Long userId) {
        if (userId == null) return "未分配";
        User u = userMapper.selectById(userId);
        return u != null && u.getRealName() != null ? u.getRealName() : "未分配";
    }
}
