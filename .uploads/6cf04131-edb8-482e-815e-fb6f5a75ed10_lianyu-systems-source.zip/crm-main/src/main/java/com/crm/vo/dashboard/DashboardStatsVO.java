package com.crm.vo.dashboard;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class DashboardStatsVO {

    private CustomerStat customer = new CustomerStat();
    private DealStat deal = new DealStat();
    private OppStat opp = new OppStat();
    private ForecastStat forecast = new ForecastStat();
    private PaymentStat payment = new PaymentStat();
    private List<RankItem> rankList;
    private String rankTab;

    @Data
    public static class CustomerStat {
        private Long created = 0L;
        private Long assigned = 0L;
        private Long followed = 0L;
    }

    @Data
    public static class DealStat {
        private Long orders = 0L;
        private BigDecimal amount = BigDecimal.ZERO;
        private Long customers = 0L;
    }

    @Data
    public static class OppStat {
        private Long created = 0L;
        private Long followed = 0L;
        private Long progress = 0L;
    }

    @Data
    public static class ForecastStat {
        private BigDecimal total = BigDecimal.ZERO;
        private List<ForecastItem> list;
    }

    @Data
    public static class ForecastItem {
        private String name;
        private Integer rate;
        private BigDecimal amount;
        private BigDecimal weighted;
    }

    @Data
    public static class PaymentStat {
        private Long times = 0L;
        private BigDecimal amount = BigDecimal.ZERO;
        private Long orders = 0L;
        private Long customers = 0L;
    }

    @Data
    public static class RankItem {
        private String name;
        private BigDecimal value;
    }
}
