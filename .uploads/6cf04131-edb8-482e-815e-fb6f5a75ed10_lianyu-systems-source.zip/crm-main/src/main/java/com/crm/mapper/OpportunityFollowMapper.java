package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.OpportunityFollow;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface OpportunityFollowMapper extends BaseMapper<OpportunityFollow> {

    List<OpportunityFollow> selectByOpportunityId(@Param("opportunityId") Long opportunityId);
}
