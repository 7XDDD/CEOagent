package com.crm.dto.opportunity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Data
public class OpportunityFollowCreateDTO {

    @NotNull(message = "商机ID不能为空")
    private Long opportunityId;

    private String opportunityName;
    private Long customerId;
    private String customerName;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime followTime;

    private String follower;
    private String contactPerson;
    private String content;
    private String planTitle;
    private String planContent;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime planTime;
    private String remark;
}
