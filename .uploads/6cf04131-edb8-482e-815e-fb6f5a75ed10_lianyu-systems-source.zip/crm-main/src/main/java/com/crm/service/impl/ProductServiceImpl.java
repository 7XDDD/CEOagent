package com.crm.service.impl;

import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.BusinessException;
import com.crm.common.ResultCode;
import com.crm.common.SecurityContextUtil;
import com.crm.dto.PageResult;
import com.crm.dto.product.ProductCreateDTO;
import com.crm.dto.product.ProductQueryDTO;
import com.crm.dto.product.ProductUpdateDTO;
import com.crm.entity.Product;
import com.crm.mapper.ProductMapper;
import com.crm.service.ProductService;
import com.crm.vo.product.ProductVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductMapper productMapper;

    @Override
    public PageResult<ProductVO> page(ProductQueryDTO query) {
        if (query == null) query = new ProductQueryDTO();
        int pageNum = query.getPageNum() != null ? query.getPageNum() : 1;
        int pageSize = query.getPageSize() != null ? query.getPageSize() : 10;

        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;

        Page<ProductVO> page = new Page<>(pageNum, pageSize);
        IPage<ProductVO> result = productMapper.selectPageList(page, companyId, query);
        return new PageResult<>(result.getRecords(), result.getTotal(), pageNum, pageSize);
    }

    @Override
    public List<ProductVO> list(ProductQueryDTO query) {
        if (query == null) query = new ProductQueryDTO();
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        return productMapper.selectListByQuery(companyId, query);
    }

    @Override
    public ProductVO getById(Long id) {
        ProductVO vo = productMapper.selectDetailById(id);
        if (vo == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "商品不存在");
        }
        return vo;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ProductVO save(ProductCreateDTO dto) {
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;

        Product dup = productMapper.findByProductCode(companyId, dto.getProductCode());
        if (dup != null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(),
                    String.format("商品编号[%s]已存在", dto.getProductCode()));
        }

        Product entity = new Product();
        BeanUtils.copyProperties(dto, entity);
        entity.setCompanyId(companyId);
        if (entity.getStatus() == null || entity.getStatus().isEmpty()) {
            entity.setStatus("ON_SHELF");
        }
        productMapper.insert(entity);
        log.info("新增商品成功: id={}, productCode={}", entity.getId(), entity.getProductCode());
        return getById(entity.getId());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ProductVO update(ProductUpdateDTO dto) {
        Product old = productMapper.selectById(dto.getId());
        if (old == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "商品不存在");
        }

        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;

        if (dto.getProductCode() != null && !dto.getProductCode().equals(old.getProductCode())) {
            Product dup = productMapper.findByProductCode(companyId, dto.getProductCode());
            if (dup != null && !dup.getId().equals(old.getId())) {
                throw new BusinessException(ResultCode.PARAM_ERROR.getCode(),
                        String.format("商品编号[%s]已存在", dto.getProductCode()));
            }
        }

        Product entity = new Product();
        BeanUtils.copyProperties(dto, entity);
        entity.setVersion(old.getVersion());
        entity.setCompanyId(companyId);
        productMapper.updateById(entity);
        log.info("更新商品成功: id={}", entity.getId());
        return getById(entity.getId());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Long id) {
        productMapper.deleteById(id);
        log.info("删除商品成功: id={}", id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteBatch(List<Long> ids) {
        productMapper.deleteBatchIds(ids);
        log.info("批量删除商品成功: ids={}", ids);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public ProductVO changeStatus(Long id, String status) {
        if (status == null || status.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请指定目标状态");
        }
        if (!"ON_SHELF".equals(status) && !"OFF_SHELF".equals(status)) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "状态值无效，仅支持 ON_SHELF/OFF_SHELF");
        }
        Product product = productMapper.selectById(id);
        if (product == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "商品不存在");
        }
        product.setStatus(status);
        productMapper.updateById(product);
        log.info("更新商品状态成功: id={}, status={}", id, status);
        return getById(id);
    }

    @Override
    public void exportProducts(ProductQueryDTO query, HttpServletResponse response) throws Exception {
        List<ProductVO> list = list(query);
        ExcelWriter writer = ExcelUtil.getWriter();
        String[] headers = {"商品编号*", "商品名称*", "单位", "销售价(元)", "状态*", "商品分类", "商品描述", "备注"};
        for (int i = 0; i < headers.length; i++) {
            writer.writeCellValue(i, 0, headers[i]);
        }
        int rowNum = 1;
        for (ProductVO p : list) {
            writer.writeCellValue(0, rowNum, p.getProductCode());
            writer.writeCellValue(1, rowNum, p.getProductName());
            writer.writeCellValue(2, rowNum, p.getUnit());
            writer.writeCellValue(3, rowNum, p.getSalesPrice() != null ? p.getSalesPrice().doubleValue() : null);
            writer.writeCellValue(4, rowNum, statusToLabel(p.getStatus()));
            writer.writeCellValue(5, rowNum, p.getCategory());
            writer.writeCellValue(6, rowNum, p.getDescription());
            writer.writeCellValue(7, rowNum, p.getRemark());
            rowNum++;
        }
        for (int i = 0; i < headers.length; i++) {
            writer.setColumnWidth(i, i == 1 || i == 6 ? 25 : 16);
        }
        String fileName = URLEncoder.encode("商品数据_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".xlsx", "UTF-8");
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    @Override
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        ExcelWriter writer = ExcelUtil.getWriter();
        writer.addHeaderAlias("商品编号*", "productCode");
        writer.addHeaderAlias("商品名称*", "productName");
        writer.addHeaderAlias("单位", "unit");
        writer.addHeaderAlias("销售价(元)", "salesPrice");
        writer.addHeaderAlias("状态*", "status");
        writer.addHeaderAlias("商品分类", "category");
        writer.addHeaderAlias("商品描述", "description");
        writer.addHeaderAlias("备注", "remark");

        List<Map<String, Object>> demo = new ArrayList<>();
        Map<String, Object> row1 = new LinkedHashMap<>();
        row1.put("商品编号*", "SP000001");
        row1.put("商品名称*", "示例软件产品");
        row1.put("单位", "套");
        row1.put("销售价(元)", 50000.00);
        row1.put("状态*", "上架中");
        row1.put("商品分类", "软件产品");
        row1.put("商品描述", "示例商品描述");
        row1.put("备注", "示例数据-删除后填写实际商品");
        demo.add(row1);

        Map<String, Object> row2 = new LinkedHashMap<>();
        row2.put("商品编号*", "SP000002");
        row2.put("商品名称*", "示例咨询服务");
        row2.put("单位", "人天");
        row2.put("销售价(元)", 2000.00);
        row2.put("状态*", "上架中");
        row2.put("商品分类", "咨询服务");
        row2.put("商品描述", "");
        row2.put("备注", "");
        demo.add(row2);

        writer.write(demo, true);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode("商品导入模板.xlsx", "UTF-8"));
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    @Override
    public Map<String, Object> importExcel(Long companyId, MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请选择要上传的文件");
        }
        int success = 0;
        int failed = 0;
        List<String> errorMsgs = new ArrayList<>();
        List<Map<String, Object>> allRows;
        try {
            ExcelReader reader = ExcelUtil.getReader(file.getInputStream());
            reader.addHeaderAlias("商品编号*", "productCode");
            reader.addHeaderAlias("商品编号", "productCode");
            reader.addHeaderAlias("商品名称*", "productName");
            reader.addHeaderAlias("商品名称", "productName");
            reader.addHeaderAlias("单位", "unit");
            reader.addHeaderAlias("销售价(元)", "salesPrice");
            reader.addHeaderAlias("销售价", "salesPrice");
            reader.addHeaderAlias("状态*", "status");
            reader.addHeaderAlias("状态", "status");
            reader.addHeaderAlias("商品分类", "category");
            reader.addHeaderAlias("商品描述", "description");
            reader.addHeaderAlias("备注", "remark");
            allRows = reader.readAll();
        } catch (Exception e) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "Excel 解析失败: " + e.getMessage());
        }
        if (allRows == null || allRows.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "Excel 文件为空");
        }

        int rowNum = 1;
        for (Map<String, Object> row : allRows) {
            rowNum++;
            try {
                String productCode = objToStr(row.get("productCode"));
                String productName = objToStr(row.get("productName"));
                String unit = objToStr(row.get("unit"));
                String salesPriceStr = objToStr(row.get("salesPrice"));
                String statusStr = objToStr(row.get("status"));
                String category = objToStr(row.get("category"));
                String description = objToStr(row.get("description"));
                String remark = objToStr(row.get("remark"));

                if (productCode == null || productCode.isEmpty()) {
                    errorMsgs.add("第" + rowNum + "行: 商品编号不能为空");
                    failed++;
                    continue;
                }
                if (productName == null || productName.isEmpty()) {
                    errorMsgs.add("第" + rowNum + "行: 商品名称不能为空");
                    failed++;
                    continue;
                }
                String normalizedStatus = normalizeStatus(statusStr);
                if (normalizedStatus == null) {
                    errorMsgs.add("第" + rowNum + "行: 状态值无效，仅支持 上架中/已下架");
                    failed++;
                    continue;
                }

                Product dup = productMapper.findByProductCode(companyId, productCode.trim());
                if (dup != null) {
                    errorMsgs.add("第" + rowNum + "行: 商品编号[" + productCode + "]已存在");
                    failed++;
                    continue;
                }

                Product entity = new Product();
                entity.setCompanyId(companyId);
                entity.setProductCode(productCode.trim());
                entity.setProductName(productName.trim());
                entity.setUnit(unit != null ? unit.trim() : null);
                if (salesPriceStr != null && !salesPriceStr.isEmpty()) {
                    try {
                        entity.setSalesPrice(new BigDecimal(salesPriceStr.replaceAll(",", "").trim()));
                    } catch (Exception e) {
                        errorMsgs.add("第" + rowNum + "行: 销售价格式错误，请输入数字");
                        failed++;
                        continue;
                    }
                }
                entity.setStatus(normalizedStatus);
                entity.setCategory(category != null ? category.trim() : null);
                entity.setDescription(description);
                entity.setRemark(remark);
                entity.setSourceType("EXCEL");
                productMapper.insert(entity);
                success++;
            } catch (Exception e) {
                errorMsgs.add("第" + rowNum + "行: " + e.getMessage());
                failed++;
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("total", allRows.size());
        result.put("success", success);
        result.put("failed", failed);
        result.put("errors", errorMsgs);
        log.info("商品导入完成: 成功={}, 失败={}", success, failed);
        return result;
    }

    private String statusToLabel(String status) {
        if ("ON_SHELF".equals(status)) return "上架中";
        if ("OFF_SHELF".equals(status)) return "已下架";
        return status;
    }

    private String normalizeStatus(String status) {
        if (status == null) return null;
        String s = status.trim();
        if ("上架中".equals(s) || "ON_SHELF".equalsIgnoreCase(s)) return "ON_SHELF";
        if ("已下架".equals(s) || "OFF_SHELF".equalsIgnoreCase(s)) return "OFF_SHELF";
        return null;
    }

    private String objToStr(Object obj) {
        if (obj == null) return null;
        return String.valueOf(obj).trim();
    }
}
