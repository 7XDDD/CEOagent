package com.crm.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.system.AddUserFromEmployeeDTO;
import com.crm.dto.system.UserCreateDTO;
import com.crm.dto.system.UserQueryDTO;
import com.crm.dto.system.UserUpdateDTO;
import com.crm.entity.User;
import com.crm.vo.system.UserVO;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

public interface UserService {

    LoginResult login(String username, String password, String captchaKey, String captchaCode, String clientIp, String userAgent);

    Page<Map<String, Object>> pageList(UserQueryDTO query);

    List<Map<String, Object>> list(UserQueryDTO query);

    UserVO getDetail(Long id);

    Map<String, Object> getUserWithRoles(Long userId);

    void assignRoles(Long userId, List<Long> roleIds);

    void changeStatus(Long id, Integer status);

    User create(UserCreateDTO dto);

    User update(Long id, UserUpdateDTO dto);

    User update(UserUpdateDTO dto);

    void delete(Long id);

    void deleteBatch(List<Long> ids);

    User addFromEmployee(AddUserFromEmployeeDTO dto);

    List<Map<String, Object>> getAvailableEmployees();

    Map<String, Object> getCurrentUserInfo(Long userId);

    boolean updateProfile(Long userId, Map<String, String> body);

    String changePassword(Long userId, String oldPassword, String newPassword);

    String resetPassword(Long userId, String newPassword);

    long countAll();

    long countActive();

    List<User> listAllActive();

    static String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        if ("0:0:0:0:0:0:0:1".equals(ip)) {
            ip = "127.0.0.1";
        }
        return ip;
    }

    class LoginResult {
        private boolean success;
        private int code;
        private String message;
        private User user;
        private List<String> roles;
        private List<String> permissions;

        public static LoginResult success(User user, List<String> roles, List<String> permissions) {
            LoginResult r = new LoginResult();
            r.success = true;
            r.code = 200;
            r.message = "登录成功";
            r.user = user;
            r.roles = roles;
            r.permissions = permissions;
            return r;
        }

        public static LoginResult fail(int code, String message) {
            LoginResult r = new LoginResult();
            r.success = false;
            r.code = code;
            r.message = message;
            return r;
        }

        public boolean isSuccess() { return success; }
        public int getCode() { return code; }
        public String getMessage() { return message; }
        public User getUser() { return user; }
        public List<String> getRoles() { return roles; }
        public List<String> getPermissions() { return permissions; }
    }
}
