package com.crm.service.base.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.BusinessException;
import com.crm.common.ResultCode;
import com.crm.dto.PageResult;
import com.crm.dto.base.FiscalYearCreateDTO;
import com.crm.dto.base.FiscalYearQueryDTO;
import com.crm.dto.base.FiscalYearUpdateDTO;
import com.crm.entity.FiscalYear;
import com.crm.mapper.FiscalYearMapper;
import com.crm.service.base.FiscalYearService;
import com.crm.vo.base.FiscalYearVO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 财年管理服务实现类
 * 提供财年的增删改查，支持当前激活财年互斥逻辑（同一时间只能有一个激活财年）
 */
@Service
public class FiscalYearServiceImpl implements FiscalYearService {

    private static final Logger log = LoggerFactory.getLogger(FiscalYearServiceImpl.class);

    @Autowired
    private FiscalYearMapper fiscalYearMapper;

    /**
     * 根据ID查询财年详情
     * @param id 财年ID
     * @return 财年视图对象
     */
    @Override
    public FiscalYearVO getById(Serializable id) {
        FiscalYear entity = fiscalYearMapper.selectById(id);
        if (entity == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "财年不存在");
        }
        return convertToVO(entity);
    }

    /**
     * 分页查询财年列表
     * @param query 查询条件
     * @return 分页结果
     */
    @Override
    public PageResult<FiscalYearVO> page(FiscalYearQueryDTO query) {
        // 1. 处理查询参数默认值
        if (query == null) query = new FiscalYearQueryDTO();
        int pageNum = query.getPageNum() != null ? query.getPageNum() : 1;
        int pageSize = query.getPageSize() != null ? query.getPageSize() : 10;

        // 2. 执行分页查询
        Page<FiscalYear> page = new Page<>(pageNum, pageSize);
        Page<FiscalYear> result = fiscalYearMapper.selectPageList(page, query);

        // 3. 实体转VO
        List<FiscalYearVO> voList = result.getRecords().stream()
                .map(this::convertToVO)
                .collect(Collectors.toList());

        return new PageResult<>(voList, result.getTotal(), pageNum, pageSize);
    }

    /**
     * 根据条件查询财年列表
     * @param query 查询条件
     * @return 财年列表
     */
    @Override
    public List<FiscalYearVO> list(FiscalYearQueryDTO query) {
        if (query == null) query = new FiscalYearQueryDTO();
        List<FiscalYear> entities = fiscalYearMapper.selectListByCondition(query);
        return entities.stream().map(this::convertToVO).collect(Collectors.toList());
    }

    /**
     * 创建财年
     * 若设置为当前激活财年，先清空其他财年的激活状态（互斥逻辑）
     * @param dto 创建参数
     * @return 创建后的财年信息
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public FiscalYearVO create(FiscalYearCreateDTO dto) {
        // 1. 构建财年实体
        FiscalYear entity = new FiscalYear();
        entity.setCompanyId(dto.getCompanyId());
        entity.setFiscalYear(dto.getFiscalYear());
        entity.setBudgetMonth(dto.getBudgetMonth());
        entity.setYearStatus(dto.getYearStatus());
        entity.setIsCurrentYear(dto.getIsCurrentYear() != null ? dto.getIsCurrentYear() : 0);
        entity.setDescription(dto.getDescription());
        entity.setStartDate(dto.getStartDate());
        entity.setEndDate(dto.getEndDate());
        entity.setDeleted(0);
        entity.setVersion(0);

        // 2. 激活财年互斥处理：如果要设为当前财年，先清空其他所有财年的激活标记
        if (entity.getIsCurrentYear() != null && entity.getIsCurrentYear() == 1) {
            fiscalYearMapper.clearCurrentYear();
        }

        // 3. 插入数据库
        fiscalYearMapper.insert(entity);
        log.info("创建财年成功: id={}, fiscalYear={}", entity.getId(), entity.getFiscalYear());
        return convertToVO(entity);
    }

    /**
     * 更新财年信息
     * 若设置为当前激活财年，先清空其他财年的激活状态（互斥逻辑）
     * @param dto 更新参数
     * @return 更新后的财年信息
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public FiscalYearVO update(FiscalYearUpdateDTO dto) {
        // 1. 校验财年是否存在
        FiscalYear entity = fiscalYearMapper.selectById(dto.getId());
        if (entity == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "财年不存在");
        }

        // 2. 按需更新普通字段
        if (dto.getFiscalYear() != null) entity.setFiscalYear(dto.getFiscalYear());
        if (dto.getBudgetMonth() != null) entity.setBudgetMonth(dto.getBudgetMonth());
        if (dto.getYearStatus() != null) entity.setYearStatus(dto.getYearStatus());
        if (dto.getDescription() != null) entity.setDescription(dto.getDescription());
        if (dto.getStartDate() != null) entity.setStartDate(dto.getStartDate());
        if (dto.getEndDate() != null) entity.setEndDate(dto.getEndDate());

        // 3. 当前财年互斥处理
        if (dto.getIsCurrentYear() != null && dto.getIsCurrentYear() == 1) {
            // 要设为当前财年：先清空其他所有财年的激活标记
            fiscalYearMapper.clearCurrentYear();
            entity.setIsCurrentYear(1);
        } else if (dto.getIsCurrentYear() != null) {
            entity.setIsCurrentYear(dto.getIsCurrentYear());
        }

        // 4. 执行更新
        fiscalYearMapper.updateById(entity);
        log.info("更新财年成功: id={}, fiscalYear={}", entity.getId(), entity.getFiscalYear());
        return convertToVO(entity);
    }

    /**
     * 根据ID删除财年（软删除）
     * @param id 财年ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Serializable id) {
        // 1. 校验财年是否存在
        FiscalYear entity = fiscalYearMapper.selectById(id);
        if (entity == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "财年不存在");
        }
        // 2. 执行软删除
        int rows = fiscalYearMapper.softDeleteById(Long.valueOf(id.toString()));
        if (rows == 0) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "财年不存在或已删除");
        }
        log.info("删除财年成功: id={}", id);
    }

    /**
     * 批量删除财年（软删除）
     * @param ids 财年ID列表
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteBatch(List<Long> ids) {
        // 1. 参数校验
        if (ids == null || ids.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请选择要删除的数据");
        }
        // 2. 逐个执行软删除
        for (Long id : ids) {
            int rows = fiscalYearMapper.softDeleteById(id);
            if (rows == 0) {
                throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "财年ID=" + id + "不存在或已删除");
            }
        }
        log.info("批量删除财年成功: ids={}", ids);
    }

    /**
     * 查询所有启用状态的财年
     * @return 启用状态财年列表
     */
    @Override
    public List<FiscalYearVO> listAllActive() {
        List<FiscalYear> entities = fiscalYearMapper.selectAllActive();
        return entities.stream().map(this::convertToVO).collect(Collectors.toList());
    }

    /**
     * 获取当前激活的财年
     * @return 当前财年信息，不存在则返回null
     */
    @Override
    public FiscalYearVO getCurrent() {
        FiscalYear entity = fiscalYearMapper.selectCurrent();
        return entity != null ? convertToVO(entity) : null;
    }

    /**
     * 实体对象转视图对象
     */
    private FiscalYearVO convertToVO(FiscalYear entity) {
        FiscalYearVO vo = new FiscalYearVO();
        vo.setId(entity.getId());
        vo.setCompanyId(entity.getCompanyId());
        vo.setFiscalYear(entity.getFiscalYear());
        vo.setBudgetMonth(entity.getBudgetMonth());
        vo.setYearStatus(entity.getYearStatus());
        vo.setIsCurrentYear(entity.getIsCurrentYear());
        vo.setDescription(entity.getDescription());
        vo.setStartDate(entity.getStartDate());
        vo.setEndDate(entity.getEndDate());
        vo.setCreateTime(entity.getCreateTime());
        vo.setUpdateTime(entity.getUpdateTime());
        vo.setVersion(entity.getVersion());
        return vo;
    }
}
