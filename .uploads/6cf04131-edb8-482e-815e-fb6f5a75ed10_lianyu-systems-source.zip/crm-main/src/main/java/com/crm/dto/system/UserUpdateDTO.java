package com.crm.dto.system;

import lombok.Data;

import java.util.List;

@Data
public class UserUpdateDTO {
    private Long id;
    private Long employeeId;
    private String employeeNo;
    private String realName;
    private String email;
    private String phone;
    private Integer gender;
    private Long deptId;
    private String position;
    private String userType;
    private Integer status;
    private String remark;
    private List<Long> roleIds;
}
