package com.crm.annotation;

import java.lang.annotation.*;

/**
 * 操作日志注解
 * 用于标记需要记录操作日志的接口方法
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface OperationLog {

    /**
     * 操作描述（value 别名，兼容 @OperationLog("xxx") 写法）
     */
    String value() default "";

    /**
     * 模块名称
     */
    String module() default "";

    /**
     * 操作描述
     */
    String description() default "";

    /**
     * 操作类型
     */
    OperationType type() default OperationType.OTHER;

    /**
     * 是否记录请求参数
     */
    boolean recordParams() default true;

    /**
     * 是否记录返回结果
     */
    boolean recordResult() default false;

    /**
     * 操作类型枚举
     */
    enum OperationType {
        /** 查询 */
        QUERY,
        /** 新增 */
        INSERT,
        /** 更新 */
        UPDATE,
        /** 删除 */
        DELETE,
        /** 导入 */
        IMPORT,
        /** 导出 */
        EXPORT,
        /** 其他 */
        OTHER
    }
}