package com.crm.controller.budget;

import com.crm.annotation.OperationLog;
import com.crm.common.Result;
import com.crm.dto.PageResult;
import com.crm.dto.budget.BudgetVersionCreateDTO;
import com.crm.dto.budget.BudgetVersionQueryDTO;
import com.crm.dto.budget.BudgetVersionUpdateDTO;
import com.crm.service.budget.BudgetVersionService;
import com.crm.vo.budget.BudgetVersionVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/budget/version")
public class BudgetVersionController {

    @Autowired
    private BudgetVersionService budgetVersionService;

    @GetMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:view')")
    public Result<BudgetVersionVO> getById(@PathVariable Long id) {
        return Result.success(budgetVersionService.getById(id));
    }

    @PostMapping("/page")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:view')")
    public Result<PageResult<BudgetVersionVO>> page(@RequestBody(required = false) BudgetVersionQueryDTO query) {
        return Result.success(budgetVersionService.page(query));
    }

    @PostMapping("/list")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:view')")
    public Result<List<BudgetVersionVO>> list(@RequestBody(required = false) BudgetVersionQueryDTO query) {
        return Result.success(budgetVersionService.list(query));
    }

    @PostMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:edit')")
    @OperationLog(module = "预算版本", description = "新增预算版本", type = OperationLog.OperationType.INSERT)
    public Result<BudgetVersionVO> save(@Valid @RequestBody BudgetVersionCreateDTO dto) {
        return Result.success(budgetVersionService.create(dto));
    }

    @PutMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:edit')")
    @OperationLog(module = "预算版本", description = "更新预算版本", type = OperationLog.OperationType.UPDATE)
    public Result<BudgetVersionVO> update(@Valid @RequestBody BudgetVersionUpdateDTO dto) {
        return Result.success(budgetVersionService.update(dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:edit')")
    @OperationLog(module = "预算版本", description = "删除预算版本", type = OperationLog.OperationType.DELETE)
    public Result<String> delete(@PathVariable Long id) {
        budgetVersionService.deleteById(id);
        return Result.success("删除成功", null);
    }

    @DeleteMapping("/batch")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:edit')")
    @OperationLog(module = "预算版本", description = "批量删除预算版本", type = OperationLog.OperationType.DELETE)
    public Result<String> deleteBatch(@RequestBody List<Long> ids) {
        budgetVersionService.deleteBatch(ids);
        return Result.success("批量删除成功", null);
    }

    @GetMapping("/active")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:view')")
    public Result<BudgetVersionVO> getActiveVersion(@RequestParam(required = false) Long companyId,
                                                    @RequestParam(required = false) Integer fiscalYear) {
        return Result.success("查询成功", budgetVersionService.getActiveVersion(companyId, fiscalYear));
    }

    @GetMapping("/rolling")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:view')")
    public Result<List<BudgetVersionVO>> getRollingVersions(@RequestParam(required = false) Integer fiscalYear) {
        return Result.success("查询成功", budgetVersionService.getRollingVersions(fiscalYear));
    }

    @PostMapping("/{id}/set-active")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:activate')")
    @OperationLog(module = "预算版本", description = "设置生效版本", type = OperationLog.OperationType.UPDATE)
    public Result<String> setActive(@PathVariable Long id) {
        budgetVersionService.setActive(id);
        return Result.success("已设为生效版本", null);
    }

    @PostMapping("/{id}/lock")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:lock')")
    @OperationLog(module = "预算版本", description = "锁定版本", type = OperationLog.OperationType.UPDATE)
    public Result<String> lock(@PathVariable Long id) {
        budgetVersionService.lock(id);
        return Result.success("版本已锁定，锁定后不能重新计算", null);
    }

    @PostMapping("/{id}/unlock")
    @PreAuthorize("@permissionChecker.hasPermission('crm:budget:version:lock')")
    @OperationLog(module = "预算版本", description = "解锁版本", type = OperationLog.OperationType.UPDATE)
    public Result<String> unlock(@PathVariable Long id) {
        budgetVersionService.unlock(id);
        return Result.success("版本已解锁，可重新计算", null);
    }
}
