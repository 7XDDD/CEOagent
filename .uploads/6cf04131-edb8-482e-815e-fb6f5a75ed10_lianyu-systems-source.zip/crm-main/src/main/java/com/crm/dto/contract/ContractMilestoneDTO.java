package com.crm.dto.contract;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class ContractMilestoneDTO {

    private Long id;

    @NotNull(message = "合同ID不能为空")
    private Long contractId;

    @NotBlank(message = "里程碑编号不能为空")
    private String milestoneCode;

    private String milestoneName;

    private BigDecimal paymentRatio;

    private BigDecimal milestoneAmount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate planDate;

    private Integer planInvoiceYear;

    private Integer planMonth;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate forecastDate;

    private Integer forecastInvoiceYear;

    private Integer forecastMonth;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate actualDate;

    private Integer actualInvoiceYear;

    private Integer actualMonth;

    private BigDecimal actualAmount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedPaymentDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate actualPaymentDate;

    private BigDecimal expectedPaymentAmount;

    private String invoiceStatus;

    private String remark;
}
