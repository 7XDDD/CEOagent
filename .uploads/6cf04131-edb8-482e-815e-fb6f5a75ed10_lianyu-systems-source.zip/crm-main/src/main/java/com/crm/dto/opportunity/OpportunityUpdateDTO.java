package com.crm.dto.opportunity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class OpportunityUpdateDTO {

    @NotNull(message = "商机ID不能为空")
    private Long id;

    private String opportunityName;
    private Long customerId;
    private String customerCode;
    private String customerName;
    private String stage;
    private Integer stageRate;
    private BigDecimal amount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedDealDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedSignDate;

    private String source;
    private String customerType;
    private String industry;
    private String productLine;
    private String competitor;
    private String nextAction;
    private String decisionMaker;
    private String status;
    private String salesStatus;
    private String projectLevel;
    private String salesPerson;
    private Long salesPersonId;
    private String companyOwner;
    private Long companyOwnerId;
    private String winRecord;
    private String projectDetail;
    private String stageSummary;
    private String closeReason;
    private String demandProduct;
    private String presalesResource;
    private String resourceConfig;
    private String opportunityType;
    private String projectAddress;
    private String salesResource;
    private String followPlan;
    private String followStatus;
    private String remark;
}
