package com.crm.controller.report;

import com.crm.common.Result;
import com.crm.service.report.AchievementRateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.Map;

@RestController
@RequestMapping("/report/achievement")
@Slf4j
public class AchievementRateController {

    @Autowired
    private AchievementRateService achievementRateService;

    @GetMapping("/query")
    @PreAuthorize("@permissionChecker.hasPermission('crm:report:achievement:view')")
    public Result<Map<String, Object>> query(@RequestParam(required = false) Long companyId,
                                              @RequestParam(defaultValue = "2026") Integer fiscalYear,
                                              @RequestParam(defaultValue = "6") Integer endMonth) {
        try {
            Map<String, Object> result = achievementRateService.query(companyId, fiscalYear, endMonth);
            return Result.success(result);
        } catch (Exception e) {
            log.error("订收达成率查询失败", e);
            return Result.error("查询失败: " + e.getMessage());
        }
    }

    @GetMapping("/export")
    @PreAuthorize("@permissionChecker.hasPermission('crm:report:achievement:export')")
    public void export(@RequestParam(required = false) Long companyId,
                       @RequestParam(defaultValue = "2026") Integer fiscalYear,
                       @RequestParam(defaultValue = "6") Integer endMonth,
                       HttpServletResponse response) throws Exception {
        achievementRateService.export(companyId, fiscalYear, endMonth, response);
    }
}
