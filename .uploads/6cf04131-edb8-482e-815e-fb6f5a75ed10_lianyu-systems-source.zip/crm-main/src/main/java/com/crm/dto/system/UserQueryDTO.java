package com.crm.dto.system;

import com.crm.dto.PageQueryDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class UserQueryDTO extends PageQueryDTO {
    private String keyword;
    private String username;
    private String realName;
    private String employeeNo;
    private String phone;
    private Integer status;
    private Long deptId;
    private Long orgId;
    private String userType;
}
