package com.crm.vo.payment;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * 回款记录 VO（已签订合同的收款里程碑展开）
 */
@Data
public class PaymentRecordVO {

    /** 里程碑ID */
    private Long id;

    private Long contractId;

    private String contractNo;

    private String contractName;

    private Long customerId;

    private String customerName;

    private String productLine;

    private String salesManager;

    /** 合同负责人ID（用于数据范围判断） */
    private Long ownerId;

    private String milestoneCode;

    private String milestoneName;

    /** 收款比例（小数，0.3 = 30%） */
    private BigDecimal paymentRatio;

    /** 里程碑金额（元） */
    private BigDecimal milestoneAmount;

    /** 合同金额（元） */
    private BigDecimal contractAmount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedPaymentDate;

    /** 预计回款金额（元） */
    private BigDecimal expectedPaymentAmount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate actualPaymentDate;

    /** 实际回款金额（元） */
    private BigDecimal actualAmount;

    /** 里程碑开票状态 NOT_INVOICED / INVOICED / PAID */
    private String invoiceStatus;

    /** 回款状态（派生）：UNPAID / PARTIAL / PAID / OVERDUE */
    private String paymentStatus;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate signDate;

    /** 记录级权限位 */
    private Integer permBits;
}
