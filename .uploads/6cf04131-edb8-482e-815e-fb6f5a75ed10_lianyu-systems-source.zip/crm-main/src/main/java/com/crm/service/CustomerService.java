package com.crm.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.*;
import com.crm.vo.CustomerVO;
import com.crm.entity.PmtCustomerAddress;
import com.crm.entity.PmtCustomerContact;
import com.crm.entity.PmtCustomerFollower;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

public interface CustomerService {

    Page<CustomerVO> pageList(CustomerQueryDTO queryDTO);

    Page<CustomerVO> publicSeaList(CustomerQueryDTO queryDTO);

    void claimCustomer(Long id);

    Map<String, Object> analysis(CustomerQueryDTO queryDTO);

    CustomerVO getDetail(Long id);

    List<CustomerVO> listAll();

    Long createCustomer(CustomerCreateDTO createDTO);

    boolean updateCustomer(Long id, CustomerUpdateDTO updateDTO);

    /** 转移客户负责人给其他用户 */
    boolean transferCustomer(Long id, Long newOwnerId, String newOwnerName);

    boolean deleteCustomer(Long id);

    boolean deleteBatch(List<Long> ids);

    void exportCustomers(CustomerQueryDTO query, HttpServletResponse response) throws Exception;

    void downloadImportTemplate(HttpServletResponse response) throws Exception;

    Map<String, Object> importExcel(MultipartFile file);

    List<PmtCustomerAddress> getAddresses(Long customerId);

    List<PmtCustomerContact> getContacts(Long customerId);

    List<PmtCustomerFollower> getFollowers(Long customerId);

    void saveAddresses(Long customerId, List<Map<String, Object>> list);

    void saveContacts(Long customerId, List<Map<String, Object>> list);

    void saveFollowers(Long customerId, List<Map<String, Object>> list);
}
