package com.crm.service;

import com.crm.dto.PageResult;
import com.crm.dto.project.ProjectQueryDTO;
import com.crm.vo.project.ProjectVO;

public interface ProjectService {
    PageResult<ProjectVO> page(ProjectQueryDTO query);
    ProjectVO getById(Long id);
}
