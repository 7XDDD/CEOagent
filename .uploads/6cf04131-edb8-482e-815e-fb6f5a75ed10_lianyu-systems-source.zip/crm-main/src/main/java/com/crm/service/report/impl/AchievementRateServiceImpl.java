package com.crm.service.report.impl;

import com.crm.common.SecurityContextUtil;
import com.crm.entity.BudgetPeriodAmount;
import com.crm.entity.BudgetSheet;
import com.crm.entity.BudgetVersion;
import com.crm.entity.Company;
import com.crm.entity.Contract;
import com.crm.mapper.BudgetPeriodAmountMapper;
import com.crm.mapper.BudgetVersionMapper;
import com.crm.mapper.CompanyMapper;
import com.crm.mapper.budget.BudgetSheetMapper;
import com.crm.mapper.contract.ContractMapper;
import com.crm.service.report.AchievementRateService;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 签单达成率报表服务实现类（精简版）
 * 仅提供签单达成率：按月份统计签单合同金额实际值与合同额预算目标值(科目101)的对比。
 * 包含KPI指标计算（年度/累计达成率、缺口）与POI Excel导出。
 * 目标基准版本：优先取已定稿的调整预算版本，无则取年度第一个版本。
 * 金额单位统一为万元。
 */
@Service
@Slf4j
public class AchievementRateServiceImpl implements AchievementRateService {

    private static final BigDecimal WAN = new BigDecimal("10000");

    @Autowired
    private CompanyMapper companyMapper;
    @Autowired
    private BudgetVersionMapper budgetVersionMapper;
    @Autowired
    private BudgetSheetMapper budgetSheetMapper;
    @Autowired
    private BudgetPeriodAmountMapper periodAmountMapper;
    @Autowired
    private ContractMapper contractMapper;

    @Override
    public Map<String, Object> query(Long companyId, Integer fiscalYear, Integer endMonth) {
        Long cid = resolveCompanyId(companyId);
        if (endMonth == null || endMonth < 1 || endMonth > 12) endMonth = 12;
        BudgetVersion targetVersion = findTargetVersion(cid, fiscalYear, endMonth);
        Map<String, Object> signData = buildSignAchievement(cid, fiscalYear, endMonth, targetVersion);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("sign", signData);
        result.put("fiscalYear", fiscalYear);
        result.put("endMonth", endMonth);
        result.put("versionName", targetVersion != null ? targetVersion.getVersionName() : "");
        return result;
    }

    @Override
    public void export(Long companyId, Integer fiscalYear, Integer endMonth,
                       HttpServletResponse response) throws Exception {
        try {
            Long cid = resolveCompanyId(companyId);
            if (endMonth == null || endMonth < 1 || endMonth > 12) endMonth = 12;
            Map<String, Object> data = query(cid, fiscalYear, endMonth);
            exportExcel(data, fiscalYear, endMonth, response);
        } catch (Exception e) {
            log.error("签单达成率导出失败", e);
            throw e;
        }
    }

    /**
     * 构建签单达成率数据：截止endMonth的已签单合同金额（按月），并加载合同额预算目标值
     */
    private Map<String, Object> buildSignAchievement(Long cid, Integer fiscalYear, Integer endMonth, BudgetVersion firstVersion) {
        BigDecimal[] monthlyActual = zeroArray();
        BigDecimal[] monthlyTarget = zeroNullArray();

        LocalDate endDate = LocalDate.of(fiscalYear, endMonth, 1).plusMonths(1).minusDays(1);
        List<Contract> contracts = contractMapper.findSignedInYear(cid, fiscalYear);
        for (Contract c : contracts) {
            LocalDate signDate = c.getSignDate();
            if (signDate == null) continue;
            if (signDate.isAfter(endDate)) continue;
            int month = signDate.getMonthValue();
            BigDecimal amt = c.getContractAmount() != null ? c.getContractAmount() : BigDecimal.ZERO;
            amt = amt.divide(WAN, 6, RoundingMode.HALF_UP);
            if (month >= 1 && month <= 12) {
                monthlyActual[month - 1] = monthlyActual[month - 1].add(amt);
            }
        }

        for (int i = endMonth; i < 12; i++) {
            monthlyActual[i] = BigDecimal.ZERO;
        }

        if (firstVersion != null) {
            loadBudgetTargets(firstVersion, "101", monthlyTarget);
        }
        return buildKPI(monthlyActual, monthlyTarget, endMonth);
    }

    /**
     * 从指定预算版本读取科目101（合同额）的月度预算目标值（万元），无预算的月份保持null
     */
    private void loadBudgetTargets(BudgetVersion version, String catalogCode, BigDecimal[] monthlyTarget) {
        List<BudgetSheet> sheets = budgetSheetMapper.selectByVersionAndCatalog(version.getId(), catalogCode);
        if (sheets.isEmpty()) return;
        List<Long> sheetIds = sheets.stream().map(BudgetSheet::getId).collect(Collectors.toList());
        List<BudgetPeriodAmount> pas = periodAmountMapper.selectBySheetIds(sheetIds);
        boolean[] hasData = new boolean[12];
        for (BudgetPeriodAmount pa : pas) {
            String pc = pa.getPeriodCode();
            if (pc == null || !pc.startsWith("M")) continue;
            try {
                int m = Integer.parseInt(pc.substring(1));
                BigDecimal a = pa.getBudgetAmount() != null ? pa.getBudgetAmount().divide(WAN, 6, RoundingMode.HALF_UP) : BigDecimal.ZERO;
                if (m >= 1 && m <= 12) {
                    if (monthlyTarget[m - 1] == null) monthlyTarget[m - 1] = BigDecimal.ZERO;
                    monthlyTarget[m - 1] = monthlyTarget[m - 1].add(a);
                    hasData[m - 1] = true;
                }
            } catch (Exception ignored) {}
        }
        for (int i = 0; i < 12; i++) {
            if (!hasData[i]) monthlyTarget[i] = null;
        }
    }

    private Map<String, Object> buildKPI(BigDecimal[] monthlyActual, BigDecimal[] monthlyTarget, int endMonth) {
        BigDecimal[] safeTarget = new BigDecimal[12];
        for (int i = 0; i < 12; i++) safeTarget[i] = nvl(monthlyTarget[i]);

        BigDecimal[] cumActual = new BigDecimal[12];
        BigDecimal[] cumTarget = new BigDecimal[12];
        cumActual[0] = monthlyActual[0];
        cumTarget[0] = safeTarget[0];
        for (int i = 1; i < 12; i++) {
            cumActual[i] = cumActual[i - 1].add(monthlyActual[i]);
            cumTarget[i] = cumTarget[i - 1].add(safeTarget[i]);
        }
        BigDecimal totalActual = cumActual[11];
        BigDecimal totalTarget = cumTarget[11];
        BigDecimal endCumActual = endMonth >= 1 && endMonth <= 12 ? cumActual[endMonth - 1] : BigDecimal.ZERO;
        BigDecimal endCumTarget = endMonth >= 1 && endMonth <= 12 ? cumTarget[endMonth - 1] : BigDecimal.ZERO;

        BigDecimal annualRate = pct(totalActual, totalTarget);
        BigDecimal cumRate = pct(endCumActual, endCumTarget);
        BigDecimal annualGap = totalTarget.subtract(totalActual);
        BigDecimal cumGap = endCumTarget.subtract(endCumActual);

        BigDecimal[] monthlyRates = new BigDecimal[12];
        BigDecimal[] cumRates = new BigDecimal[12];
        for (int i = 0; i < 12; i++) {
            monthlyRates[i] = scale2(pct(monthlyActual[i], safeTarget[i]));
            cumRates[i] = scale2(pct(cumActual[i], cumTarget[i]));
        }

        Map<String, Object> r = new LinkedHashMap<>();
        r.put("monthlyActual", scale6Arr(monthlyActual));
        r.put("cumulativeActual", scale6Arr(cumActual));
        r.put("monthlyTarget", scale6ArrNullable(monthlyTarget));
        r.put("cumulativeTarget", scale6Arr(cumTarget));
        r.put("monthlyRates", monthlyRates);
        r.put("cumRates", cumRates);
        r.put("totalActual", scale6(totalActual));
        r.put("totalTarget", scale6(totalTarget));
        r.put("annualRate", scale2(annualRate));
        r.put("cumRate", scale2(cumRate));
        r.put("annualGap", scale6(annualGap));
        r.put("cumGap", scale6(cumGap));
        return r;
    }

    private BigDecimal pct(BigDecimal num, BigDecimal den) {
        if (den == null || den.compareTo(BigDecimal.ZERO) == 0) return BigDecimal.ZERO;
        return num.divide(den, 6, RoundingMode.HALF_UP).multiply(new BigDecimal("100"));
    }

    private BigDecimal scale2(BigDecimal v) {
        return v != null ? v.setScale(2, RoundingMode.HALF_UP) : BigDecimal.ZERO;
    }

    private BigDecimal scale6(BigDecimal v) {
        return v != null ? v.setScale(6, RoundingMode.HALF_UP) : BigDecimal.ZERO.setScale(6, RoundingMode.HALF_UP);
    }

    private BigDecimal[] scale6Arr(BigDecimal[] arr) {
        BigDecimal[] r = new BigDecimal[arr.length];
        for (int i = 0; i < arr.length; i++) r[i] = scale6(arr[i]);
        return r;
    }

    private Object[] scale6ArrNullable(BigDecimal[] arr) {
        Object[] r = new Object[arr.length];
        for (int i = 0; i < arr.length; i++) {
            r[i] = arr[i] != null ? arr[i].setScale(6, RoundingMode.HALF_UP) : null;
        }
        return r;
    }

    private BigDecimal[] zeroArray() {
        BigDecimal[] a = new BigDecimal[12];
        for (int i = 0; i < 12; i++) a[i] = BigDecimal.ZERO;
        return a;
    }

    private BigDecimal[] zeroNullArray() {
        return new BigDecimal[12];
    }

    private BigDecimal nvl(BigDecimal v) {
        return v != null ? v : BigDecimal.ZERO;
    }

    /**
     * 查找目标基准预算版本：1-6月用年初版；7-12月优先定稿调整版，无则回退年初版
     */
    private BudgetVersion findTargetVersion(Long cid, Integer fiscalYear, Integer endMonth) {
        BudgetVersion yearStart = budgetVersionMapper.findFirstNonRolling(cid, fiscalYear);
        if (yearStart == null) {
            yearStart = budgetVersionMapper.findFirstAny(cid, fiscalYear);
        }
        if (endMonth != null && endMonth >= 7) {
            BudgetVersion finalizedAdjust = budgetVersionMapper.findFinalizedAdjust(cid, fiscalYear);
            if (finalizedAdjust != null) {
                return finalizedAdjust;
            }
        }
        return yearStart;
    }

    private Long resolveCompanyId(Long cid) {
        if (cid != null) return cid;
        Long userCompanyId = SecurityContextUtil.getCurrentCompanyId();
        if (userCompanyId != null) return userCompanyId;
        Company c = companyMapper.findFirst();
        return c != null ? c.getId() : 1L;
    }

    private void exportExcel(Map<String, Object> data, Integer fiscalYear, Integer endMonth,
                             HttpServletResponse response) throws Exception {
        @SuppressWarnings("unchecked")
        Map<String, Object> sign = (Map<String, Object>) data.get("sign");

        Workbook wb = new XSSFWorkbook();
        writeAchievementSheet(wb, "签单达成率", fiscalYear, endMonth, sign);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        String fileName = URLEncoder.encode("签单达成率_" + fiscalYear + "年" + endMonth + "月.xlsx", StandardCharsets.UTF_8.name()).replace("+", "%20");
        response.setHeader("Content-Disposition", "attachment; filename*=UTF-8''" + fileName);
        OutputStream out = response.getOutputStream();
        wb.write(out);
        wb.close();
        out.flush();
    }

    private void writeAchievementSheet(Workbook wb, String sheetName, Integer fiscalYear, Integer endMonth,
                                       Map<String, Object> d) {
        Sheet sheet = wb.createSheet(sheetName);
        CellStyle headerStyle = createHeaderStyle(wb);
        CellStyle titleStyle = createTitleStyle(wb);
        CellStyle labelStyle = createLabelStyle(wb);
        CellStyle dataStyle = createDataStyle(wb);
        CellStyle pctStyle = createPercentStyle(wb);
        CellStyle kpiLabelStyle = createKpiLabelStyle(wb);
        CellStyle kpiValueStyle = createKpiValueStyle(wb);

        BigDecimal totalTarget = (BigDecimal) d.get("totalTarget");
        BigDecimal totalActual = (BigDecimal) d.get("totalActual");
        BigDecimal annualGap = (BigDecimal) d.get("annualGap");
        BigDecimal cumRate = (BigDecimal) d.get("cumRate");
        BigDecimal annualRate = (BigDecimal) d.get("annualRate");
        BigDecimal endCumActual = ((BigDecimal[]) d.get("cumulativeActual"))[endMonth - 1];
        BigDecimal endCumTarget = ((BigDecimal[]) d.get("cumulativeTarget"))[endMonth - 1];
        BigDecimal cumGap = endCumTarget.subtract(endCumActual);

        Row titleRow = sheet.createRow(0);
        titleRow.setHeightInPoints(30);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue(sheetName + " · " + fiscalYear + "年1-" + endMonth + "月达成情况");
        titleCell.setCellStyle(titleStyle);
        sheet.addMergedRegion(new org.apache.poi.ss.util.CellRangeAddress(0, 0, 0, 16));

        int tableStart = 2;
        Row header = sheet.createRow(tableStart);
        header.setHeightInPoints(22);
        Cell h0 = header.createCell(0);
        h0.setCellValue("项目");
        h0.setCellStyle(headerStyle);
        for (int m = 0; m < 12; m++) {
            Cell c = header.createCell(m + 1);
            c.setCellValue((m + 1) + "月");
            c.setCellStyle(headerStyle);
        }
        Cell hSum = header.createCell(13);
        hSum.setCellValue("累计/全年");
        hSum.setCellStyle(headerStyle);

        String[] labels = {"当月实际(万元)", "累计实际(万元)", "月度目标(万元)", "累计目标(万元)", "月度达成率", "累计达成率"};
        String[] dataKeys = {"monthlyActual", "cumulativeActual", "monthlyTarget", "cumulativeTarget", "monthlyRates", "cumRates"};
        CellStyle[] styles = {dataStyle, dataStyle, dataStyle, dataStyle, pctStyle, pctStyle};
        for (int ri = 0; ri < labels.length; ri++) {
            Row r = sheet.createRow(tableStart + 1 + ri);
            r.setHeightInPoints(20);
            Cell label = r.createCell(0);
            label.setCellValue(labels[ri]);
            label.setCellStyle(labelStyle);
            Object rawArr = d.get(dataKeys[ri]);
            for (int m = 0; m < 12; m++) {
                Cell c = r.createCell(m + 1);
                BigDecimal val;
                if (rawArr instanceof BigDecimal[]) {
                    val = ((BigDecimal[]) rawArr)[m];
                } else if (rawArr instanceof Object[]) {
                    Object v = ((Object[]) rawArr)[m];
                    val = v instanceof BigDecimal ? (BigDecimal) v : null;
                } else {
                    val = null;
                }
                if (val == null) val = BigDecimal.ZERO;
                if (ri >= 4) {
                    c.setCellValue(val.divide(new BigDecimal("100"), 6, RoundingMode.HALF_UP).doubleValue());
                } else {
                    c.setCellValue(val.setScale(6, RoundingMode.HALF_UP).doubleValue());
                }
                c.setCellStyle(styles[ri]);
            }
            Cell sc = r.createCell(13);
            if (ri == 0 || ri == 2 || ri == 4) {
                sc.setCellValue("—");
            } else if (ri == 1) {
                sc.setCellValue(scale6(endCumActual).doubleValue());
            } else if (ri == 3) {
                sc.setCellValue(scale6(endCumTarget).doubleValue());
            } else {
                sc.setCellValue(scale2(cumRate).divide(new BigDecimal("100"), 6, RoundingMode.HALF_UP).doubleValue());
            }
            sc.setCellStyle(styles[ri]);
        }

        int kpiRow = tableStart;
        String[][] kpis = {
            {"年度目标(万元)", scale6(totalTarget).toPlainString()},
            {"年度实际(万元)", scale6(totalActual).toPlainString()},
            {"年度缺口(万元)", scale6(annualGap).toPlainString()},
            {"年度达成率", scale2(annualRate).toPlainString() + "%"},
            {"截止月累计目标(万元)", scale6(endCumTarget).toPlainString()},
            {"截止月累计实际(万元)", scale6(endCumActual).toPlainString()},
            {"累计缺口(万元)", scale6(cumGap).toPlainString()},
            {"累计达成率", scale2(cumRate).toPlainString() + "%"},
            {"截止月份", endMonth + "月"}
        };
        for (int ki = 0; ki < kpis.length; ki++) {
            Row r = sheet.getRow(kpiRow + ki);
            if (r == null) r = sheet.createRow(kpiRow + ki);
            Cell lc = r.createCell(15);
            lc.setCellValue(kpis[ki][0]);
            lc.setCellStyle(kpiLabelStyle);
            Cell vc = r.createCell(16);
            vc.setCellValue(kpis[ki][1]);
            vc.setCellStyle(kpiValueStyle);
        }

        sheet.setColumnWidth(0, 16 * 256);
        for (int i = 1; i <= 13; i++) sheet.setColumnWidth(i, 12 * 256);
        sheet.setColumnWidth(15, 20 * 256);
        sheet.setColumnWidth(16, 16 * 256);

        Row note = sheet.createRow(tableStart + labels.length + 2);
        Cell noteCell = note.createCell(0);
        noteCell.setCellValue("说明：目标值按截止月份选择版本——1-6月取年初基准版，7-12月优先取年中定稿版（无则回退年初版）；实际值为" + endMonth + "月及之前已签单合同金额，截止月份后实际数据清零；金额单位为万元。");
        sheet.addMergedRegion(new org.apache.poi.ss.util.CellRangeAddress(note.getRowNum(), note.getRowNum(), 0, 13));
    }

    private CellStyle createTitleStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle();
        Font f = wb.createFont();
        f.setBold(true);
        f.setFontHeightInPoints((short) 16);
        f.setColor(IndexedColors.DARK_BLUE.getIndex());
        s.setFont(f);
        s.setAlignment(HorizontalAlignment.CENTER);
        s.setVerticalAlignment(VerticalAlignment.CENTER);
        return s;
    }

    private CellStyle createHeaderStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle();
        Font f = wb.createFont();
        f.setBold(true);
        f.setFontHeightInPoints((short) 11);
        f.setColor(IndexedColors.WHITE.getIndex());
        s.setFont(f);
        s.setFillForegroundColor(IndexedColors.ROYAL_BLUE.getIndex());
        s.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        s.setAlignment(HorizontalAlignment.CENTER);
        s.setVerticalAlignment(VerticalAlignment.CENTER);
        s.setBorderTop(BorderStyle.THIN);
        s.setBorderBottom(BorderStyle.THIN);
        s.setBorderLeft(BorderStyle.THIN);
        s.setBorderRight(BorderStyle.THIN);
        return s;
    }

    private CellStyle createLabelStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle();
        Font f = wb.createFont();
        f.setBold(true);
        f.setFontHeightInPoints((short) 11);
        s.setFont(f);
        s.setFillForegroundColor(IndexedColors.LIGHT_CORNFLOWER_BLUE.getIndex());
        s.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        s.setAlignment(HorizontalAlignment.CENTER);
        s.setVerticalAlignment(VerticalAlignment.CENTER);
        s.setBorderTop(BorderStyle.THIN);
        s.setBorderBottom(BorderStyle.THIN);
        s.setBorderLeft(BorderStyle.THIN);
        s.setBorderRight(BorderStyle.THIN);
        return s;
    }

    private CellStyle createDataStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle();
        s.setAlignment(HorizontalAlignment.RIGHT);
        s.setVerticalAlignment(VerticalAlignment.CENTER);
        s.setBorderTop(BorderStyle.THIN);
        s.setBorderBottom(BorderStyle.THIN);
        s.setBorderLeft(BorderStyle.THIN);
        s.setBorderRight(BorderStyle.THIN);
        DataFormat df = wb.createDataFormat();
        s.setDataFormat(df.getFormat("#,##0.000000"));
        return s;
    }

    private CellStyle createPercentStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle();
        s.setAlignment(HorizontalAlignment.RIGHT);
        s.setVerticalAlignment(VerticalAlignment.CENTER);
        s.setBorderTop(BorderStyle.THIN);
        s.setBorderBottom(BorderStyle.THIN);
        s.setBorderLeft(BorderStyle.THIN);
        s.setBorderRight(BorderStyle.THIN);
        DataFormat df = wb.createDataFormat();
        s.setDataFormat(df.getFormat("0.00%"));
        return s;
    }

    private CellStyle createKpiLabelStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle();
        Font f = wb.createFont();
        f.setColor(IndexedColors.DARK_RED.getIndex());
        f.setFontHeightInPoints((short) 11);
        s.setFont(f);
        s.setAlignment(HorizontalAlignment.LEFT);
        return s;
    }

    private CellStyle createKpiValueStyle(Workbook wb) {
        CellStyle s = wb.createCellStyle();
        Font f = wb.createFont();
        f.setBold(true);
        f.setColor(IndexedColors.DARK_RED.getIndex());
        f.setFontHeightInPoints((short) 12);
        s.setFont(f);
        s.setAlignment(HorizontalAlignment.RIGHT);
        s.setBorderTop(BorderStyle.THIN);
        s.setBorderBottom(BorderStyle.THIN);
        s.setBorderLeft(BorderStyle.THIN);
        s.setBorderRight(BorderStyle.THIN);
        return s;
    }
}
