package com.crm.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.crm.config.HrProperties;
import com.crm.entity.Org;
import com.crm.entity.PmtEmployee;
import com.crm.mapper.OrgMapper;
import com.crm.mapper.PmtEmployeeMapper;
import com.crm.service.OrgService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OrgServiceImpl extends ServiceImpl<OrgMapper, Org> implements OrgService {

    private final HrProperties hrProperties;
    private final PmtEmployeeMapper employeeMapper;

    private static final String COL_MANAGER = "manager";

    /** crm_org.manager 列是否在当前库中存在（带缓存结果，避免每次请求判列） */
    private volatile Boolean managerColumnCached;

    @Override
    public boolean isHrMode() {
        return hrProperties.isEnabled();
    }

    @Override
    public List<Org> getTree() {
        List<Org> all = this.list(new LambdaQueryWrapper<Org>()
                .eq(Org::getStatus, 1)
                .eq(Org::getDeleted, 0)
                .orderByAsc(Org::getSortOrder));
        enrichDisplayFields(all);
        return buildTree(all, 0L);
    }

    @Override
    public List<Org> listAll() {
        List<Org> all = this.list(new LambdaQueryWrapper<Org>()
                .eq(Org::getDeleted, 0)
                .orderByAsc(Org::getSortOrder));
        enrichDisplayFields(all);
        return all;
    }

    @Override
    public void saveManagerName(Org org) {
        if (org == null || org.getId() == null) return;
        if (!isManagerColumnPresent()) return;
        try {
            baseMapper.updateManagerName(org.getId(), org.getManager());
        } catch (Exception ignore) {
            // 理论上 isManagerColumnPresent() 已判列存在，兜底防止 race DDL
        }
    }

    @Override
    public void loadManagerNames(List<Org> orgs) {
        if (orgs == null || orgs.isEmpty()) return;
        // 优先：如果 manager 列在 DB 存在，直接批量 SELECT manager 文本
        if (isManagerColumnPresent()) {
            try {
                List<Map<String, Object>> rows = baseMapper.selectAllManagerNames();
                if (rows != null) {
                    Map<Long, String> id2Mgr = new HashMap<>();
                    for (Map<String, Object> r : rows) {
                        Object id = r.get("id");
                        Object mgr = r.get("mgr_name");
                        if (id != null && mgr != null) {
                            try { id2Mgr.put(Long.valueOf(id.toString()), String.valueOf(mgr)); }
                            catch (Exception ignore) {}
                        }
                    }
                    for (Org o : orgs) {
                        if (o == null || o.getId() == null) continue;
                        String mgr = id2Mgr.get(o.getId());
                        if (mgr != null && !mgr.isEmpty()) {
                            o.setManager(mgr);
                            if (o.getLeaderName() == null || o.getLeaderName().isEmpty()) o.setLeaderName(mgr);
                        }
                    }
                }
            } catch (Exception ignore) {}
        }
        // 兜底：用 managerId（=job_number 字符串，需求"manager_id 用工号"）反查 PmtEmployee，
        // 补 manager（若为空）/ leaderName / managerJobNumber。
        // 只要 managerId 非空（有工号）就收集，确保 manager 文本已有的行也能反查出 jobNumber（之前的 Bug 场景）
        List<String> needJobNos = new ArrayList<>();
        for (Org o : orgs) {
            if (o == null) continue;
            String mgrNo = o.getManagerId();
            if (mgrNo != null && !mgrNo.trim().isEmpty() && o.getManagerJobNumber() == null) {
                needJobNos.add(mgrNo.trim());
            }
        }
        if (!needJobNos.isEmpty()) {
            try {
                // 按 crm_employee.job_number IN (...) 批查（不再按自增 id 查）
                com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<PmtEmployee> w =
                        new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<>();
                w.in(PmtEmployee::getJobNumber, needJobNos).eq(PmtEmployee::getDeleted, 0);
                List<PmtEmployee> emps = employeeMapper.selectList(w);
                // key: job_number，value: 员工对象
                Map<String, PmtEmployee> jobNo2Emp = new HashMap<>();
                for (PmtEmployee e : emps) {
                    if (e.getJobNumber() != null && !e.getJobNumber().isEmpty()) {
                        jobNo2Emp.put(e.getJobNumber(), e);
                    }
                }
                for (Org o : orgs) {
                    if (o == null) continue;
                    String mgrNo = o.getManagerId();
                    if (mgrNo == null || mgrNo.trim().isEmpty()) continue;
                    PmtEmployee e = jobNo2Emp.get(mgrNo.trim());
                    if (e == null) continue;
                    // 1) manager 文本为空 → 用 employeeName 回填 manager 和 leaderName
                    String curMgr = o.getManager();
                    if (curMgr == null || curMgr.isEmpty()) {
                        if (e.getEmployeeName() != null) {
                            o.setManager(e.getEmployeeName());
                            o.setLeaderName(e.getEmployeeName());
                        }
                    }
                    // 2) managerJobNumber 为空 → 无论 manager 是否有值，都补 jobNumber（前端显示「工号·姓名」）
                    if (o.getManagerJobNumber() == null && e.getJobNumber() != null) {
                        o.setManagerJobNumber(e.getJobNumber());
                    }
                }
            } catch (Exception ignore) {}
        }
        // 最后兜底：leaderName 始终与 manager 一致
        for (Org o : orgs) {
            if (o == null) continue;
            if ((o.getLeaderName() == null || o.getLeaderName().isEmpty()) && o.getManager() != null && !o.getManager().isEmpty()) {
                o.setLeaderName(o.getManager());
            }
        }
    }

    /**
     * 判 manager 列是否在当前库存在。首次请求会读 INFORMATION_SCHEMA，之后缓存结果。
     */
    private boolean isManagerColumnPresent() {
        Boolean r = managerColumnCached;
        if (r != null) return r;
        synchronized (this) {
            r = managerColumnCached;
            if (r != null) return r;
            try {
                int c = baseMapper.countOrgColumn(COL_MANAGER);
                r = c > 0;
            } catch (Exception e) {
                r = false;
            }
            managerColumnCached = r;
            return r;
        }
    }

    /**
     * 为 Org 列表补充前端展示字段：
     * - parentName：上级组织名称（由 parentId 反查）
     * - treeLevel：层级（1 起），优先用 level DB列，否则按 ancestors 逗号数兜底
     * - manager / leaderName：负责人姓名（DB manager列 或 managerId 反查 PmtEmployee）
     */
    private void enrichDisplayFields(List<Org> all) {
        if (all == null || all.isEmpty()) return;

        // 1) parentName
        Map<Long, Org> idMap = new HashMap<>();
        for (Org o : all) if (o.getId() != null) idMap.put(o.getId(), o);
        Map<Long, String> extraParentNames = null;
        for (Org o : all) {
            Long pid = o.getParentId();
            if (pid == null || pid <= 0) continue;
            Org parent = idMap.get(pid);
            if (parent != null) {
                o.setParentName(parent.getOrgName());
            } else {
                if (extraParentNames == null) extraParentNames = new HashMap<>();
                if (!extraParentNames.containsKey(pid)) {
                    Org p = this.getById(pid);
                    extraParentNames.put(pid, p != null ? p.getOrgName() : null);
                }
                o.setParentName(extraParentNames.get(pid));
            }
        }

        // 2) treeLevel
        for (Org o : all) {
            Integer lv = o.getLevel();
            if (lv != null && lv > 0) {
                o.setTreeLevel(lv);
            } else if (o.getAncestors() != null && !o.getAncestors().isEmpty()) {
                int cnt = 0;
                for (int i = 0; i < o.getAncestors().length(); i++) {
                    if (o.getAncestors().charAt(i) == ',') cnt++;
                }
                o.setTreeLevel(cnt);
            } else if (o.getParentId() == null || o.getParentId() <= 0) {
                o.setTreeLevel(1);
            }
        }

        // 3) manager / leaderName
        loadManagerNames(all);
    }

    private List<Org> buildTree(List<Org> all, Long parentId) {
        List<Org> result = new ArrayList<>();
        List<Org> children = all.stream()
                .filter(o -> parentId.equals(o.getParentId()))
                .collect(Collectors.toList());
        for (Org child : children) {
            List<Org> childChildren = buildTree(all, child.getId());
            if (!childChildren.isEmpty()) child.setChildren(childChildren);
            else child.setChildren(null);
            result.add(child);
        }
        return result;
    }
}
