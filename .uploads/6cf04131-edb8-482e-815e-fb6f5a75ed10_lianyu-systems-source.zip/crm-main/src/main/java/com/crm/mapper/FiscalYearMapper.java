package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.base.FiscalYearQueryDTO;
import com.crm.entity.FiscalYear;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface FiscalYearMapper extends BaseMapper<FiscalYear> {

    Page<FiscalYear> selectPageList(Page<FiscalYear> page, @Param("query") FiscalYearQueryDTO query);

    List<FiscalYear> selectListByCondition(@Param("query") FiscalYearQueryDTO query);

    List<FiscalYear> selectAllActive();

    FiscalYear selectCurrent();

    int clearCurrentYear();

    int softDeleteById(@Param("id") Long id);

    List<FiscalYear> listAll();

    FiscalYear findCurrentYear();
}
