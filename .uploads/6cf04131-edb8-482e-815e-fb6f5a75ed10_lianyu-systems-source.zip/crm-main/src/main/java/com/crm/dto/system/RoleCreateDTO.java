package com.crm.dto.system;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.util.List;

@Data
public class RoleCreateDTO {
    @NotBlank(message = "角色编码不能为空")
    private String roleCode;
    @NotBlank(message = "角色名称不能为空")
    private String roleName;
    private String roleType;
    private String description;
    private Integer sortOrder;
    private Integer status;
    private List<Long> permissionIds;
}
