package com.crm.dto.base;

import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.LocalDate;

@Data
public class FiscalYearCreateDTO {

    private Long companyId;

    @NotNull(message = "财年不能为空")
    private Integer fiscalYear;

    private Integer budgetMonth;

    @Size(max = 20, message = "状态长度不能超过20")
    private String yearStatus;

    private Integer isCurrentYear;

    @Size(max = 200, message = "描述长度不能超过200")
    private String description;

    private LocalDate startDate;

    private LocalDate endDate;
}
