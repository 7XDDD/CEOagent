package com.crm.common;

import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Pattern MYSQL_COLUMN_PATTERN = Pattern.compile("Column\\s+'([^']+)'\\s+cannot\\s+be\\s+null", Pattern.CASE_INSENSITIVE);
    private static final Pattern MYSQL_DUP_ENTRY_PATTERN = Pattern.compile("Duplicate\\s+entry\\s+'([^']+)'\\s+for\\s+key\\s+'([^']+)'", Pattern.CASE_INSENSITIVE);
    private static final Pattern MYSQL_DATA_TOO_LONG_PATTERN = Pattern.compile("Data\\s+too\\s+long\\s+for\\s+column\\s+'([^']+)'", Pattern.CASE_INSENSITIVE);
    private static final Pattern MYSQL_FOREIGN_KEY_PATTERN = Pattern.compile("Cannot\\s+add\\s+or\\s+update\\s+a\\s+child\\s+row:\\s+a\\s+foreign\\s+key\\s+constraint\\s+fails", Pattern.CASE_INSENSITIVE);

    /**
     * 递归从异常链中查找最底层的 SQLException
     */
    private SQLException findSQLException(Throwable t) {
        while (t != null) {
            if (t instanceof SQLException) return (SQLException) t;
            t = t.getCause();
        }
        return null;
    }

    /**
     * 根据 SQLException 提取用户可理解的错误信息
     */
    private String extractUserMessage(SQLException sqlEx) {
        String sqlMsg = sqlEx.getMessage();
        if (sqlMsg == null) return null;

        Matcher m = MYSQL_COLUMN_PATTERN.matcher(sqlMsg);
        if (m.find()) return "字段 [" + m.group(1) + "] 不能为空，请填写后重试";

        m = MYSQL_DUP_ENTRY_PATTERN.matcher(sqlMsg);
        if (m.find()) return "数据重复: 字段 [" + m.group(2) + "] 值 [" + m.group(1) + "] 已存在，请修改后重试";

        m = MYSQL_DATA_TOO_LONG_PATTERN.matcher(sqlMsg);
        if (m.find()) return "字段 [" + m.group(1) + "] 内容过长，请缩短后重试";

        m = MYSQL_FOREIGN_KEY_PATTERN.matcher(sqlMsg);
        if (m.find()) return "关联数据错误: 引用的关联数据不存在，请检查";

        return null;
    }

    @ExceptionHandler(BusinessException.class)
    public Result<?> handleBusinessException(BusinessException e, HttpServletRequest request) {
        log.warn("业务异常: {} -> {}", request.getRequestURI(), e.getMessage());
        return Result.error(e.getCode(), e.getMessage());
    }

    @ExceptionHandler(AuthenticationException.class)
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public Result<?> handleAuthenticationException(AuthenticationException e, HttpServletRequest request) {
        log.warn("认证异常: {} -> {}", request.getRequestURI(), e.getMessage());
        return Result.unauthorized();
    }

    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public Result<?> handleAccessDeniedException(AccessDeniedException e, HttpServletRequest request) {
        log.warn("权限异常: {} -> {}", request.getRequestURI(), e.getMessage());
        return Result.forbidden();
    }

    @ExceptionHandler({MethodArgumentNotValidException.class, BindException.class})
    public Result<?> handleValidationException(Exception e) {
        String message;
        if (e instanceof MethodArgumentNotValidException) {
            MethodArgumentNotValidException ex = (MethodArgumentNotValidException) e;
            message = ex.getBindingResult().getFieldErrors().stream()
                    .map(fe -> {
                        String field = fe.getField();
                        String defaultMsg = fe.getDefaultMessage() == null ? "无效值" : fe.getDefaultMessage();
                        return field + ": " + defaultMsg;
                    })
                    .collect(Collectors.joining("; "));
        } else if (e instanceof BindException) {
            BindException ex = (BindException) e;
            message = ex.getBindingResult().getFieldErrors().stream()
                    .map(fe -> {
                        String field = fe.getField();
                        String defaultMsg = fe.getDefaultMessage() == null ? "无效值" : fe.getDefaultMessage();
                        return field + ": " + defaultMsg;
                    })
                    .collect(Collectors.joining("; "));
        } else {
            message = "参数校验失败";
        }
        log.warn("参数校验异常: {}", message);
        return Result.error(ResultCode.VALIDATE_FAILED.getCode(), "参数校验失败: " + message);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public Result<?> handleConstraintViolationException(ConstraintViolationException e) {
        String message = e.getConstraintViolations().stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining("; "));
        log.warn("约束校验异常: {}", message);
        return Result.error(ResultCode.VALIDATE_FAILED.getCode(), "约束校验失败: " + message);
    }

    @ExceptionHandler(DuplicateKeyException.class)
    public Result<?> handleDuplicateKeyException(DuplicateKeyException e, HttpServletRequest request) {
        SQLException sqlEx = findSQLException(e);
        String message = sqlEx != null ? extractUserMessage(sqlEx) : null;
        if (message == null) message = "数据重复: 已存在相同的记录，请检查唯一字段";
        log.error("唯一约束异常: {} -> {}", request.getRequestURI(), message, e);
        return Result.error(ResultCode.ERROR.getCode(), message);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    public Result<?> handleDataIntegrityViolationException(DataIntegrityViolationException e, HttpServletRequest request) {
        SQLException sqlEx = findSQLException(e);
        String message = sqlEx != null ? extractUserMessage(sqlEx) : null;
        if (message == null) message = "数据完整性校验失败，请检查必填字段是否正确填写";
        log.error("数据完整性异常: {} -> {}", request.getRequestURI(), message, e);
        return Result.error(ResultCode.ERROR.getCode(), message);
    }

    @ExceptionHandler(BadSqlGrammarException.class)
    public Result<?> handleBadSqlGrammarException(BadSqlGrammarException e, HttpServletRequest request) {
        log.error("SQL语法异常: {} -> {}", request.getRequestURI(), e.getMessage(), e);
        return Result.error(ResultCode.ERROR.getCode(), "SQL语法错误，请联系管理员");
    }

    /**
     * 通用数据访问异常 (MyBatis PersistenceException, Spring DataAccessException 的子类)
     * 很多情况下 MyBatis 会用 org.apache.ibatis.exceptions.PersistenceException 包装真实的异常
     */
    @ExceptionHandler(DataAccessException.class)
    public Result<?> handleDataAccessException(DataAccessException e, HttpServletRequest request) {
        SQLException sqlEx = findSQLException(e);
        String message = sqlEx != null ? extractUserMessage(sqlEx) : null;
        if (message == null) message = "数据访问失败，请联系管理员";
        log.error("数据访问异常: {} -> {}", request.getRequestURI(), message, e);
        return Result.error(ResultCode.ERROR.getCode(), message);
    }

    @ExceptionHandler(Exception.class)
    public Result<?> handleException(Exception e, HttpServletRequest request) {
        // 先尝试从异常链中提取 SQLException, 处理未被具体处理器捕获的情况
        SQLException sqlEx = findSQLException(e);
        if (sqlEx != null) {
            String message = extractUserMessage(sqlEx);
            if (message != null) {
                log.error("SQL异常: {} -> {}", request.getRequestURI(), message, e);
                return Result.error(ResultCode.ERROR.getCode(), message);
            }
        }

        log.error("系统异常: {} -> {}", request.getRequestURI(), e.getMessage(), e);
        String message = e.getMessage();
        if (message == null || message.length() > 200) {
            message = "系统内部错误，请联系管理员";
        } else if (message.contains("Exception") || message.contains("java.") || message.contains("com.") || message.contains("at ")) {
            message = "系统内部错误，请联系管理员";
        }
        return Result.error(ResultCode.ERROR.getCode(), message);
    }
}


