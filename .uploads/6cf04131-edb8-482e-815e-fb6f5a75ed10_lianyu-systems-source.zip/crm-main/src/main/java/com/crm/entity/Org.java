package com.crm.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Data
@TableName("crm_org")
public class Org implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long parentId;

    private String ancestors;

    private String orgCode;

    private String orgName;

    private String orgType;

    /** 负责人工号：crm_employee.job_number（字符串，如 E001/E002）。
     *  <p>需求"manager_id 用工号"：不再存 crm_employee.id（自增数字），改为存 job_number，
     *  便于直接通过工号关联员工，避免重名冲突且用户可直接看懂。
     *  数据库对应列 VARCHAR(64)，允许 NULL（挂名负责人或员工被删除时留空）。
     */
    private String managerId;

    @TableField(exist = false)
    private String leaderName;

    /**
     * 负责人姓名。
     * <p>注意：该字段使用 exist=false，避免 MyBatis-Plus 自动生成 SQL 时在旧库（尚未执行
     * 补丁 pmt20260827_add_org_manager_column.sql 加列）直接引用 manager 导致 SQL 错误。
     * manager 的持久化/读取统一通过 {@link com.crm.mapper.OrgMapper} 自定义
     * SQL + INFORMATION_SCHEMA 判列存在的方式进行，新老库均可无缝兼容。
     */
    @TableField(exist = false)
    private String manager;

    /** 负责人工号（由 crm_employee.job_number 反查填充，exist=false 不参与 MyBatis-Plus 自动 SQL）。
     *  用于前端显示「工号 姓名」格式（如 E001 张三），与需求"manager_id 用工号"对齐：
     *  - 匹配时 job_number 优先（防 employeeName='E001' 与 E001.jobNumber 冲突时选错人）
     *  - 显示时工号作为主标识附在姓名左侧
     */
    @TableField(exist = false)
    private String managerJobNumber;

    private String description;

    private Integer level;

    private Integer sortOrder;

    private Integer status;

    private String remark;

    @TableField(value = "created_by", fill = FieldFill.INSERT)
    private Long createdBy;

    @TableField(value = "updated_by", fill = FieldFill.INSERT_UPDATE)
    private Long updatedBy;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    @Version
    @TableField(fill = FieldFill.INSERT)
    private Integer version = 0;

    @TableLogic
    @TableField(fill = FieldFill.INSERT)
    private Long deleted = 0L;

    @TableField(exist = false)
    private String parentName;

    @TableField(exist = false)
    private Integer treeLevel;

    @TableField(exist = false)
    private List<Org> children;
}
