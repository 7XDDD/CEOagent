package com.crm.controller;

import com.crm.common.Result;
import com.crm.service.DashboardService;
import com.crm.vo.dashboard.DashboardStatsVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/stats")
    public Result<DashboardStatsVO> stats(@RequestParam(required = false, defaultValue = "month") String range,
                                          @RequestParam(required = false, defaultValue = "customer") String rankTab) {
        return Result.success(dashboardService.stats(range, rankTab));
    }
}
