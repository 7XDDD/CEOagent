package com.crm.service.base;

import com.crm.dto.PageResult;
import com.crm.dto.base.FiscalYearCreateDTO;
import com.crm.dto.base.FiscalYearQueryDTO;
import com.crm.dto.base.FiscalYearUpdateDTO;
import com.crm.vo.base.FiscalYearVO;

import java.io.Serializable;
import java.util.List;

public interface FiscalYearService {

    FiscalYearVO getById(Serializable id);

    PageResult<FiscalYearVO> page(FiscalYearQueryDTO query);

    List<FiscalYearVO> list(FiscalYearQueryDTO query);

    FiscalYearVO create(FiscalYearCreateDTO dto);

    FiscalYearVO update(FiscalYearUpdateDTO dto);

    void deleteById(Serializable id);

    void deleteBatch(List<Long> ids);

    List<FiscalYearVO> listAllActive();

    FiscalYearVO getCurrent();
}
