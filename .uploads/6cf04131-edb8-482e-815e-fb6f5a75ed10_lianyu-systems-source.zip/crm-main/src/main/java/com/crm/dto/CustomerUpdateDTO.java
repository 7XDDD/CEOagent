package com.crm.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class CustomerUpdateDTO {
    private String customerCode;
    private String customerName;
    private String standardName;
    private String customerAddress;
    private String mapLocation;
    private String customerType;
    private String customerLevel;
    private String customerSource;
    private String customerIndustry;
    private String industry;
    private String industryL1;
    private String industryL2;
    private String industryL3;
    private String customerScale;
    private String customerNature;
    private String customerStatus;
    private String callStatus;
    private String region;
    private String province;
    private String city;
    private String listingStatus;
    private String revenueYear;
    private String profit;
    private String revenueScale;
    private String marketValue;
    private String employeeCount;
    private String cooperationStatus;
    private String mainProduct;
    private String developmentStage;
    private BigDecimal totalSales;
    private LocalDate firstOrderDate;
    private String highestCustomerRelation;
    private String ongoingOpportunity;
    private String matchStatus;
    private String website;
    private String dataSource;
    private String companyProduct;
    private String companyTel;
    private String salesman;
    private String originalSalesman;
    private String industryManager;
    private String csoTrainingClass;
    private String mainContact;
    private String secondContact;
    private Long managerId;
    private String managerName;
    private Long followerId;
    private String followerName;
    private String contactName;
    private String contactPosition;
    private String contactMobile;
    private String contactTel;
    private String contactEmail;
    private String contactWechat;
    private String contactRemark;
    private String remark;
    private String customerTags;
    private Integer dealFlag;
    private Integer inPublicSea;
}
