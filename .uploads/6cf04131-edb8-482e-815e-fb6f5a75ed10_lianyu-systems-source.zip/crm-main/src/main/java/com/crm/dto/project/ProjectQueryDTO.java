package com.crm.dto.project;

import lombok.Data;

@Data
public class ProjectQueryDTO {
    private String keyword;
    private String projectCode;
    private String projectName;
    private String customerName;
    private String status;
    private String pmName;
    private Integer pageNum = 1;
    private Integer pageSize = 20;
    /** 当前登录用户ID(行级权限) */
    private Long currentUserId;
}
