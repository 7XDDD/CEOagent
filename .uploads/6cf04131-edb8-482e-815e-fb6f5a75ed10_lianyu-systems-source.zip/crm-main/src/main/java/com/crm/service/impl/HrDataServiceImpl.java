package com.crm.service.impl;

import com.crm.service.HrDataService;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Map;

/**
 * HR 数据服务存根实现。
 * 基础版本不集成 HR 系统，同步操作返回空结果。
 * 如需启用 HR 集成，请配置 crm.hr.enabled=true 并提供真实实现。
 */
@Service
public class HrDataServiceImpl implements HrDataService {

    @Override
    public Map<String, Integer> syncOrg() {
        return Collections.emptyMap();
    }

    @Override
    public Map<String, Integer> syncEmployee() {
        return Collections.emptyMap();
    }

    @Override
    public int syncOvertime() {
        return 0;
    }

    @Override
    public int syncAttendanceCalendar() {
        return 0;
    }

    @Override
    public int syncLeave() {
        return 0;
    }
}
