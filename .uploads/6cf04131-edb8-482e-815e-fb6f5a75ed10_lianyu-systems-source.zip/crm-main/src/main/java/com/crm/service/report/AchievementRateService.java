package com.crm.service.report;

import javax.servlet.http.HttpServletResponse;
import java.util.Map;

public interface AchievementRateService {

    Map<String, Object> query(Long companyId, Integer fiscalYear, Integer endMonth);

    void export(Long companyId, Integer fiscalYear, Integer endMonth,
                HttpServletResponse response) throws Exception;
}
