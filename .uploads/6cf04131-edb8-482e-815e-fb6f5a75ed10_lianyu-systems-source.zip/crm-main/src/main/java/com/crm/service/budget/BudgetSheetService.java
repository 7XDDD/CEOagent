package com.crm.service.budget;

import com.crm.dto.BudgetCalculateRequest;
import com.crm.dto.PageResult;
import com.crm.dto.budget.BudgetSheetQueryDTO;
import com.crm.entity.BudgetLine;
import com.crm.entity.BudgetPeriodAmount;
import com.crm.entity.BudgetSheet;
import com.crm.vo.budget.BudgetSheetVO;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

public interface BudgetSheetService {

    PageResult<BudgetSheetVO> page(BudgetSheetQueryDTO query);

    List<BudgetSheetVO> getByContract(Long contractId);

    String calculateBudget(BudgetCalculateRequest request);

    List<BudgetLine> getLines(Long sheetId);

    List<BudgetPeriodAmount> getPeriodAmounts(Long sheetId);

    Map<Long, List<BudgetPeriodAmount>> getPeriodAmountsBatch(String sheetIdsStr);

    void exportBudgetSheets(Integer fiscalYear, Long versionId, String catalogCode, Long orgId, Long productLineId, String orgName, String productLineName, HttpServletResponse response) throws Exception;

    void exportAll(Integer fiscalYear, Long versionId, Long orgId, Long productLineId, String orgName, String productLineName, HttpServletResponse response) throws Exception;

    void exportOverview(Integer fiscalYear, Long versionId, Long orgId, Long productLineId, String orgName, String productLineName, HttpServletResponse response) throws Exception;

    void exportDimension(Integer fiscalYear, Long versionId, String catalogCode, String stockFlag, String productLine, String contractType, String customerName, String projectName, String manager, List<String> dimFields, HttpServletResponse response) throws Exception;

    Map<String, Object> getOverviewData(Integer fiscalYear, Long versionId, String dimensions);

    BudgetSheetVO getById(Long id);

    boolean save(BudgetSheet entity);

    boolean update(BudgetSheet entity);

    boolean deleteById(Long id);

    boolean deleteBatch(List<Long> ids);
}
