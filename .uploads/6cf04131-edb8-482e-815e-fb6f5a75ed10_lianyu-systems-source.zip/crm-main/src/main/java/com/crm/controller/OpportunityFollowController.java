package com.crm.controller;

import com.crm.annotation.OperationLog;
import com.crm.common.Result;
import com.crm.dto.PageResult;
import com.crm.dto.opportunity.OpportunityFollowCreateDTO;
import com.crm.entity.OpportunityFollow;
import com.crm.service.OpportunityFollowService;
import com.baomidou.mybatisplus.core.metadata.IPage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/opportunity-follow")
@Slf4j
public class OpportunityFollowController {

    @Autowired
    private OpportunityFollowService followService;

    @PostMapping("/page")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:view')")
    public Result<PageResult<OpportunityFollow>> page(@RequestBody(required = false) Map<String, Object> params) {
        Integer pageNum = params != null && params.get("pageNum") != null ? Integer.valueOf(params.get("pageNum").toString()) : 1;
        Integer pageSize = params != null && params.get("pageSize") != null ? Integer.valueOf(params.get("pageSize").toString()) : 10;
        String keyword = params != null && params.get("keyword") != null ? params.get("keyword").toString() : null;
        String scope = params != null && params.get("scope") != null ? params.get("scope").toString() : null;
        IPage<OpportunityFollow> result = followService.page(pageNum, pageSize, keyword, scope);
        return Result.success("查询成功", new PageResult<>(result.getRecords(), result.getTotal(), pageNum, pageSize));
    }

    @GetMapping("/opportunity/{opportunityId}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:view')")
    public Result<List<OpportunityFollow>> listByOpportunity(@PathVariable Long opportunityId) {
        return Result.success("查询成功", followService.listByOpportunityId(opportunityId));
    }

    @PostMapping("/plan-page")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:view')")
    public Result<PageResult<OpportunityFollow>> planPage(@RequestBody(required = false) Map<String, Object> params) {
        Integer pageNum = params != null && params.get("pageNum") != null ? Integer.valueOf(params.get("pageNum").toString()) : 1;
        Integer pageSize = params != null && params.get("pageSize") != null ? Integer.valueOf(params.get("pageSize").toString()) : 10;
        String keyword = params != null && params.get("keyword") != null ? params.get("keyword").toString() : null;
        String scope = params != null && params.get("scope") != null ? params.get("scope").toString() : null;
        String planStatus = params != null && params.get("planStatus") != null ? params.get("planStatus").toString() : null;
        IPage<OpportunityFollow> result = followService.planPage(pageNum, pageSize, keyword, scope, planStatus);
        return Result.success("查询成功", new PageResult<>(result.getRecords(), result.getTotal(), pageNum, pageSize));
    }

    @PostMapping("/{id}/plan-done")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:edit')")
    @OperationLog(module = "商机管理", description = "跟进计划标记完成")
    public Result<String> planDone(@PathVariable Long id) {
        followService.markPlanDone(id);
        return Result.success("已完成", null);
    }

    @PostMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:edit')")
    @OperationLog(module = "商机管理", description = "新增商机跟进记录")
    public Result<OpportunityFollow> save(@Valid @RequestBody OpportunityFollowCreateDTO dto) {
        return Result.success("保存成功", followService.save(dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:opportunity:edit')")
    @Transactional(rollbackFor = Exception.class)
    @OperationLog(module = "商机管理", description = "删除商机跟进记录")
    public Result<String> deleteById(@PathVariable Long id) {
        followService.deleteById(id);
        return Result.success("删除成功", null);
    }
}
