package com.crm.controller.base;

import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crm.annotation.OperationLog;
import com.crm.annotation.OperationLog.OperationType;
import com.crm.common.BusinessException;
import com.crm.common.Result;
import com.crm.common.ResultCode;
import com.crm.config.HrProperties;
import com.crm.entity.Dict;
import com.crm.entity.DictItem;
import com.crm.entity.Org;
import com.crm.entity.PmtEmployee;
import com.crm.entity.User;
import com.crm.mapper.DictItemMapper;
import com.crm.mapper.DictMapper;
import com.crm.mapper.PmtEmployeeMapper;
import com.crm.mapper.UserMapper;
import com.crm.service.HrDataService;
import com.crm.service.OrgService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

@Api(tags = "组织架构管理")
@RestController
@RequestMapping("/base/org")
@RequiredArgsConstructor
public class OrgController {

    private final OrgService orgService;
    private final HrDataService hrDataService;
    private final HrProperties hrProperties;
    private final DictMapper dictMapper;
    private final DictItemMapper dictItemMapper;
    private final PmtEmployeeMapper employeeMapper;
    private final UserMapper userMapper;

    @ApiOperation("从HR系统全量同步组织架构")
    @PreAuthorize("@permissionChecker.hasPermission('crm:org:update')")
    @OperationLog(module = "组织架构", description = "HR同步组织", type = OperationType.OTHER)
    @PostMapping("/sync")
    public Result<Map<String, Integer>> syncFromHr() {
        if (!hrProperties.isEnabled()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR系统集成未启用（crm.hr.enabled=false），无法执行同步操作");
        }
        Map<String, Integer> result = hrDataService.syncOrg();
        return Result.success(String.format("同步成功：新增%d，更新%d，删除%d",
                result.get("added"), result.get("updated"), result.get("deleted")), result);
    }

    @ApiOperation("获取HR模式状态")
    @GetMapping("/hr-mode")
    public Result<Map<String, Object>> getHrMode() {
        Map<String, Object> result = new HashMap<>();
        result.put("hrMode", orgService.isHrMode());
        result.put("readOnly", orgService.isHrMode());
        return Result.success(result);
    }

    @ApiOperation("获取组织树")
    @GetMapping("/tree")
    public Result<List<Org>> tree() {
        return Result.success(orgService.getTree());
    }

    @ApiOperation("获取组织列表")
    @GetMapping("/list")
    public Result<List<Org>> list() {
        return Result.success(orgService.listAll());
    }

    @ApiOperation("获取签约主体公司列表")
    @GetMapping("/sign-companies")
    public Result<List<Org>> signCompanies() {
        List<Org> allOrgs = orgService.listAll();
        // 筛选组织类型为SIGN_MAIN（主体签约公司）或COMPANY（公司）的启用组织
        List<Org> result = allOrgs.stream()
                .filter(o -> o.getStatus() != null && o.getStatus() == 1)
                .filter(o -> "SIGN_MAIN".equals(o.getOrgType()) || "COMPANY".equals(o.getOrgType()))
                .sorted(Comparator.comparing(o -> o.getSortOrder() == null ? 0 : o.getSortOrder()))
                .collect(Collectors.toList());
        return Result.success(result);
    }

    @ApiOperation("获取组织详情")
    @GetMapping("/{id}")
    public Result<Org> get(@PathVariable Long id) {
        return Result.success(orgService.getById(id));
    }

    @ApiOperation("新增组织")
    @PreAuthorize("@permissionChecker.hasPermission('crm:org:create')")
    @OperationLog(module = "组织架构", description = "新增组织", type = OperationType.INSERT)
    @PostMapping
    public Result<Org> add(@RequestBody Org org) {
        if (orgService.isHrMode()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR集成模式下不允许手动管理组织架构");
        }
        if (org.getParentId() == null) org.setParentId(0L);
        if (org.getStatus() == null) org.setStatus(1);
        if (org.getSortOrder() == null) org.setSortOrder(0);
        if (org.getDeleted() == null) org.setDeleted(0L);
        if (org.getParentId() != null && org.getParentId() > 0) {
            Org parent = orgService.getById(org.getParentId());
            if (parent != null) {
                org.setLevel((parent.getLevel() == null ? 1 : parent.getLevel()) + 1);
                org.setAncestors((parent.getAncestors() == null ? "" : parent.getAncestors()) + parent.getId() + ",");
            } else {
                org.setLevel(1);
                org.setAncestors("0,");
            }
        } else {
            org.setParentId(0L);
            org.setLevel(1);
            org.setAncestors("0,");
        }
        resolveManagerId(org);
        orgService.save(org);
        // manager 为 exist=false 字段，MyBatis-Plus save 时不会写库 → 单独通过原生 SQL 落表（自动兼容列不存在的旧库）
        orgService.saveManagerName(org);
        return Result.success(org);
    }

    @ApiOperation("修改组织")
    @PreAuthorize("@permissionChecker.hasPermission('crm:org:update')")
    @OperationLog(module = "组织架构", description = "修改组织", type = OperationType.UPDATE)
    @PutMapping
    public Result<Org> update(@RequestBody Org org) {
        if (orgService.isHrMode()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR集成模式下不允许手动管理组织架构");
        }
        resolveManagerId(org);
        orgService.updateById(org);
        orgService.saveManagerName(org);
        return Result.success(org);
    }

    @ApiOperation("删除组织")
    @PreAuthorize("@permissionChecker.hasPermission('crm:org:delete')")
    @OperationLog(module = "组织架构", description = "删除组织", type = OperationType.DELETE)
    @DeleteMapping("/{id:\\d+}")
    public Result<?> delete(@PathVariable Long id) {
        if (orgService.isHrMode()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR集成模式下不允许手动管理组织架构");
        }
        long childCount = orgService.count(new LambdaQueryWrapper<Org>()
                .eq(Org::getParentId, id)
                .eq(Org::getDeleted, 0));
        if (childCount > 0) {
            return Result.error("存在下级组织，无法删除");
        }
        orgService.removeById(id);
        return Result.success();
    }

    @ApiOperation("修改组织状态")
    @PreAuthorize("@permissionChecker.hasPermission('crm:org:status')")
    @OperationLog(module = "组织架构", description = "修改组织状态", type = OperationType.UPDATE)
    @PostMapping("/{id}/status")
    public Result<?> changeStatus(@PathVariable Long id, @RequestParam Integer status) {
        if (orgService.isHrMode()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR集成模式下不允许手动管理组织架构");
        }
        Org org = new Org();
        org.setId(id);
        org.setStatus(status);
        orgService.updateById(org);
        return Result.success();
    }

    @ApiOperation("导出组织架构")
    @PreAuthorize("@permissionChecker.hasPermission('crm:org:export')")
    @OperationLog(module = "组织架构", description = "导出组织", type = OperationType.EXPORT)
    @PostMapping("/export")
    public void export(@RequestBody(required = false) Map<String, Object> params, HttpServletResponse response) throws Exception {
        writeOrgExcel(response);
    }

    @ApiOperation("导出组织架构(GET)")
    @PreAuthorize("@permissionChecker.hasPermission('crm:org:export')")
    @GetMapping("/export")
    public void exportGet(HttpServletResponse response) throws Exception {
        writeOrgExcel(response);
    }

    private void writeOrgExcel(HttpServletResponse response) throws Exception {
        List<Org> allOrgs = orgService.listAll();

        List<List<String>> rows = new ArrayList<>();
        rows.add(Arrays.asList("组织编码", "组织名称", "上级组织编码", "组织类型", "负责人", "排序", "状态", "描述"));
        for (Org o : allOrgs) {
            String parentCode = "";
            if (o.getParentId() != null && o.getParentId() > 0) {
                Org parent = orgService.getById(o.getParentId());
                parentCode = parent != null ? (parent.getOrgCode() != null ? parent.getOrgCode() : "") : "";
            }
            rows.add(Arrays.asList(
                    o.getOrgCode() == null ? "" : o.getOrgCode(),
                    o.getOrgName() == null ? "" : o.getOrgName(),
                    parentCode,
                    o.getOrgType() == null ? "" : o.getOrgType(),
                    o.getManager() == null ? "" : o.getManager(),
                    String.valueOf(o.getSortOrder() == null ? 0 : o.getSortOrder()),
                    o.getStatus() != null && o.getStatus() == 1 ? "启用" : "禁用",
                    o.getDescription() == null ? "" : o.getDescription()
            ));
        }

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        String fileName = URLEncoder.encode("组织架构数据", "UTF-8").replaceAll("\\+", "%20");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");

        ExcelWriter writer = ExcelUtil.getWriter();
        writer.write(rows, true);
        setHeaderStyle(writer, 8);
        writer.flush(response.getOutputStream(), true);
        writer.close();
    }

    @ApiOperation("下载组织架构导入模板")
    @GetMapping("/import-template")
    public void downloadTemplate(HttpServletResponse response) throws Exception {
        writeOrgTemplate(response);
    }

    @ApiOperation("下载组织架构导入模板(GET)")
    @GetMapping("/template")
    public void downloadTemplateAlias(HttpServletResponse response) throws Exception {
        writeOrgTemplate(response);
    }

    private void writeOrgTemplate(HttpServletResponse response) throws Exception {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("utf-8");
        String fileName = URLEncoder.encode("组织架构导入模板", "UTF-8").replaceAll("\\+", "%20");
        response.setHeader("Content-disposition", "attachment;filename*=utf-8''" + fileName + ".xlsx");

        // 获取有效组织类型
        List<String[]> orgTypeList = getOrgTypeItems(); // [ [value, name], ... ]

        ExcelWriter writer = ExcelUtil.getWriter();
        List<List<String>> rows = new ArrayList<>();
        rows.add(Arrays.asList("组织编码*", "组织名称*", "上级组织编码", "组织类型", "负责人", "排序", "状态(启用/禁用)", "描述"));

        // 根据字典动态生成示例数据
        if (!orgTypeList.isEmpty()) {
            // 取前3个类型生成层级示例
            String rootCode = "ORG001";
            String rootType = orgTypeList.get(0)[0];
            String rootTypeName = orgTypeList.get(0)[1];
            rows.add(Arrays.asList(rootCode, "示例" + rootTypeName, "", rootType, "张三", "1", "启用", "顶级组织示例"));
            if (orgTypeList.size() > 1) {
                String childCode = "ORG002";
                String childType = orgTypeList.get(1)[0];
                String childTypeName = orgTypeList.get(1)[1];
                rows.add(Arrays.asList(childCode, "示例" + childTypeName, rootCode, childType, "李四", "1", "启用", "二级组织示例"));
                if (orgTypeList.size() > 2) {
                    String grandType = orgTypeList.get(2)[0];
                    String grandTypeName = orgTypeList.get(2)[1];
                    rows.add(Arrays.asList("ORG003", "示例" + grandTypeName, childCode, grandType, "王五", "1", "启用", "三级组织示例"));
                }
            }
        } else {
            rows.add(Arrays.asList("ORG001", "示例集团", "", "GROUP", "张三", "1", "启用", "顶级组织"));
            rows.add(Arrays.asList("ORG002", "示例子公司", "ORG001", "COMPANY", "李四", "1", "启用", ""));
        }
        writer.write(rows, true);
        setHeaderStyle(writer, 8);

        // 添加组织类型列下拉验证（第4列，索引3）
        if (!orgTypeList.isEmpty()) {
            Sheet sheet = writer.getSheet();
            DataValidationHelper validationHelper = sheet.getDataValidationHelper();
            // 下拉值只用编码，避免解析问题；示例数据展示编码-名称格式便于理解
            String[] typeValues = orgTypeList.stream().map(t -> t[0]).toArray(String[]::new);
            try {
                DataValidationConstraint constraint = validationHelper.createExplicitListConstraint(typeValues);
                CellRangeAddressList addressList = new CellRangeAddressList(2, 1000, 3, 3); // D3:D1001
                DataValidation validation = validationHelper.createValidation(constraint, addressList);
                validation.setShowErrorBox(true);
                validation.setErrorStyle(DataValidation.ErrorStyle.STOP);
                String hint = "有效类型：" + orgTypeList.stream().map(t -> t[0] + "(" + t[1] + ")").collect(Collectors.joining(", "));
                validation.createErrorBox("输入错误", "请从下拉列表中选择有效的组织类型编码\n" + hint);
                validation.setShowPromptBox(true);
                validation.createPromptBox("组织类型", "请选择组织类型编码");
                sheet.addValidationData(validation);
            } catch (Exception e) {
                // 下拉验证创建失败不影响模板生成
            }
        }

        // 设置列宽
        Sheet sheet = writer.getSheet();
        sheet.setColumnWidth(0, 4000);
        sheet.setColumnWidth(1, 5000);
        sheet.setColumnWidth(2, 4000);
        sheet.setColumnWidth(3, 4500);
        sheet.setColumnWidth(4, 3000);
        sheet.setColumnWidth(5, 2000);
        sheet.setColumnWidth(6, 3500);
        sheet.setColumnWidth(7, 5000);

        writer.flush(response.getOutputStream(), true);
        writer.close();
    }

    private List<String[]> getOrgTypeItems() {
        List<String[]> items = new ArrayList<>();
        try {
            String dictCode = orgService.isHrMode() ? "hr_org_type" : "org_type";
            String systemType = orgService.isHrMode() ? "HR" : "PMT";
            Dict dict = dictMapper.findByDictCodeAndSystemType(dictCode, systemType);
            if (dict != null) {
                List<DictItem> dictItems = dictItemMapper.findByDictId(dict.getId());
                for (DictItem item : dictItems) {
                    if (item.getStatus() != null && item.getStatus() == 1 && item.getDeleted() == 0) {
                        String value = item.getItemValue() != null ? item.getItemValue() : item.getItemCode();
                        String name = item.getItemName() != null ? item.getItemName() : "";
                        if (value != null) {
                            items.add(new String[]{value, name});
                        }
                    }
                }
            }
        } catch (Exception e) {
            // 忽略字典读取错误，使用默认示例
        }
        return items;
    }

    @ApiOperation("导入组织架构")
    @PreAuthorize("@permissionChecker.hasPermission('crm:org:import')")
    @OperationLog(module = "组织架构", description = "导入组织", type = OperationType.IMPORT)
    @PostMapping("/import-excel")
    public Result<Map<String, Object>> importExcel(@RequestParam("file") MultipartFile file) {
        if (orgService.isHrMode()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR集成模式下不允许导入");
        }
        Map<String, Object> result = new HashMap<>();
        int inserted = 0, updated = 0, failed = 0;
        StringBuilder errMsg = new StringBuilder();

        try (InputStream in = file.getInputStream()) {
            List<List<Object>> lines = ExcelUtil.getReader(in).read();
            if (lines == null || lines.size() <= 1) {
                result.put("inserted", 0); result.put("updated", 0); result.put("failed", 0);
                result.put("message", "文件为空或无数据");
                return Result.success(result);
            }

            // 获取有效组织类型集合（用于校验）
            Set<String> validOrgTypes = getValidOrgTypes();

            // 加载已有组织
            List<Org> existingList = orgService.listAll();
            Map<String, Org> codeMap = new LinkedHashMap<>();
            for (Org o : existingList) {
                if (o.getOrgCode() != null) codeMap.put(o.getOrgCode(), o);
            }

            // 第一阶段：解析所有行，创建Org对象（包括新的和更新的），记录parentCode
            List<Org> parsedOrgs = new ArrayList<>();
            Map<String, String> parentCodeMap = new HashMap<>(); // code -> parentCode
            for (int i = 1; i < lines.size(); i++) {
                List<Object> row = lines.get(i);
                if (row == null || row.isEmpty()) continue;
                try {
                    String code = getCellStr(row, 0);
                    String name = getCellStr(row, 1);
                    if (code.isEmpty() && name.isEmpty()) continue;
                    if (code.isEmpty() || name.isEmpty()) { failed++; errMsg.append("第").append(i+1).append("行：编码或名称为空; "); continue; }

                    Org org = codeMap.getOrDefault(code, new Org());
                    boolean isNew = org.getId() == null;
                    org.setOrgCode(code);
                    org.setOrgName(name);

                    String parentCode = getCellStr(row, 2);
                    parentCodeMap.put(code, parentCode);

                    String type = getCellStr(row, 3);
                    if (!type.isEmpty()) {
                        // 支持 "编码-名称" 或 "编码(名称)" 格式，提取编码部分
                        if (type.contains("-")) type = type.substring(0, type.indexOf("-")).trim();
                        else if (type.contains("(")) type = type.substring(0, type.indexOf("(")).trim();
                        else if (type.contains("（")) type = type.substring(0, type.indexOf("（")).trim();
                        if (!validOrgTypes.isEmpty() && !validOrgTypes.contains(type)) {
                            failed++; errMsg.append("第").append(i+1).append("行：组织类型[").append(type).append("]无效; ");
                            continue;
                        }
                        org.setOrgType(type);
                    }
                    String manager = getCellStr(row, 4);
                    org.setManager(manager);
                    String sortStr = getCellStr(row, 5);
                    try { org.setSortOrder(Integer.parseInt(sortStr.isEmpty() ? "0" : sortStr)); } catch (Exception e) { org.setSortOrder(0); }
                    String statusStr = getCellStr(row, 6);
                    org.setStatus("禁用".equals(statusStr) ? 0 : 1);
                    org.setDescription(getCellStr(row, 7));
                    if (isNew) {
                        org.setDeleted(0L);
                        org.setParentId(0L);
                        inserted++;
                    } else {
                        updated++;
                    }
                    parsedOrgs.add(org);
                    codeMap.put(code, org); // 新的也放入map，供后续引用
                } catch (Exception e) {
                    failed++;
                    errMsg.append("第").append(i+1).append("行：").append(e.getMessage()).append("; ");
                }
            }

            // 第二阶段：先保存所有新组织（parentId暂为0），获取id
            for (Org o : parsedOrgs) {
                if (o.getId() == null) {
                    resolveManagerId(o);
                    orgService.save(o);
                    orgService.saveManagerName(o);
                }
            }

            // 第三阶段：根据parentCode设置正确的parentId、level、ancestors，然后更新
            for (Org o : parsedOrgs) {
                String parentCode = parentCodeMap.get(o.getOrgCode());
                Org parent = null;
                if (parentCode != null && !parentCode.isEmpty()) {
                    parent = codeMap.get(parentCode);
                }
                if (parent != null && parent.getId() != null && !parent.getId().equals(o.getId())) {
                    o.setParentId(parent.getId());
                    Integer parentLevel = parent.getLevel() == null ? 1 : parent.getLevel();
                    o.setLevel(parentLevel + 1);
                    String parentAncestors = parent.getAncestors() == null ? "0," : parent.getAncestors();
                    o.setAncestors(parentAncestors + parent.getId() + ",");
                } else {
                    o.setParentId(0L);
                    o.setLevel(1);
                    o.setAncestors("0,");
                }
                resolveManagerId(o);
                orgService.updateById(o);
                orgService.saveManagerName(o);
            }

            result.put("inserted", inserted);
            result.put("updated", updated);
            result.put("failed", failed);
            result.put("message", errMsg.length() > 0 ? errMsg.toString() : "导入成功");
        } catch (Exception e) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "导入失败: " + e.getMessage());
        }
        return Result.success(result);
    }

    private Set<String> getValidOrgTypes() {
        Set<String> validTypes = new HashSet<>();
        try {
            String dictCode = orgService.isHrMode() ? "hr_org_type" : "org_type";
            String systemType = orgService.isHrMode() ? "HR" : "PMT";
            Dict dict = dictMapper.findByDictCodeAndSystemType(dictCode, systemType);
            if (dict != null) {
                List<DictItem> items = dictItemMapper.findByDictId(dict.getId());
                for (DictItem item : items) {
                    if (item.getStatus() != null && item.getStatus() == 1 && item.getDeleted() == 0) {
                        if (item.getItemValue() != null) validTypes.add(item.getItemValue());
                        if (item.getItemCode() != null) validTypes.add(item.getItemCode());
                    }
                }
            }
        } catch (Exception e) {
            // 如果字典不存在，不做校验
        }
        return validTypes;
    }

    private String getCellStr(List<Object> row, int idx) {
        if (idx >= row.size()) return "";
        Object v = row.get(idx);
        return v == null ? "" : String.valueOf(v).trim();
    }

    private void setHeaderStyle(ExcelWriter writer, int colCount) {
        for (int i = 0; i < colCount; i++) {
            writer.setColumnWidth(i, 18);
        }
        CellStyle headerStyle = writer.getWorkbook().createCellStyle();
        Font font = writer.getWorkbook().createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        writer.getOrCreateRow(0).cellIterator().forEachRemaining(c -> c.setCellStyle(headerStyle));
    }

    /**
     * 把 org.manager 负责人文本（用户手动输入的姓名/工号/登录名）解析成 manager_id。
     * <p>对外委托给 {@link #resolveManagerKey}，【工号优先】策略对齐测试用例
     * {@code OrgManagerResolverTest.t01_jobNumber_priority_wins_over_employeeName_conflict}。
     */
    private void resolveManagerId(Org org) {
        if (org == null) return;
        // 构造基于 Mapper 的查找器（允许 resolveManagerKey 纯函数化、便于 JUnit 直接测）
        java.util.function.BiFunction<String, String, PmtEmployee> findEmp = (field, key) -> {
            com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<PmtEmployee> w =
                    new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<>();
            if ("jobNumber".equals(field)) w.eq(PmtEmployee::getJobNumber, key);
            else if ("employeeName".equals(field)) w.eq(PmtEmployee::getEmployeeName, key);
            else return null;
            w.eq(PmtEmployee::getDeleted, 0).last("LIMIT 1");
            return employeeMapper.selectOne(w);
        };
        java.util.function.Function<Long, PmtEmployee> findEmpById = id -> id == null ? null : employeeMapper.selectById(id);
        java.util.function.BiFunction<String, String, User> findUsr = (field, key) -> {
            if (key == null || key.length() > 64) return null;
            com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<User> w =
                    new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<>();
            if ("username".equals(field)) w.eq(User::getUsername, key);
            else if ("realName".equals(field)) w.eq(User::getRealName, key);
            else return null;
            w.eq(User::getDeleted, 0).last("LIMIT 1");
            return userMapper.selectOne(w);
        };
        ManagerResolve rr;
        try {
            rr = resolveManagerKey(org.getManager(), findEmp, findEmpById, findUsr);
            // 补：User 分支命中但 employeeId 为空时，仍按旧逻辑反查 PmtEmployee.user_id = u.id
            //   （resolveManagerKey 纯函数不做隐式 DB 查询，因此由外层补）
            if ((rr == null || rr.getManagerId() == null) && org.getManager() != null && !org.getManager().trim().isEmpty()) {
                final String k2 = org.getManager().trim();
                if (k2.length() <= 64) {
                    LambdaQueryWrapper<User> uw2 = new LambdaQueryWrapper<>();
                    uw2.and(w -> w.eq(User::getUsername, k2).or().eq(User::getRealName, k2))
                       .eq(User::getDeleted, 0).last("LIMIT 1");
                    User u2 = userMapper.selectOne(uw2);
                    if (u2 != null && (u2.getEmployeeId() == null) && u2.getId() != null) {
                        LambdaQueryWrapper<PmtEmployee> q2 = new LambdaQueryWrapper<>();
                        q2.eq(PmtEmployee::getUserId, u2.getId()).eq(PmtEmployee::getDeleted, 0).last("LIMIT 1");
                        PmtEmployee e2 = employeeMapper.selectOne(q2);
                        // manager_id 存工号（job_number 字符串），不存 e2.getId()
                        if (e2 != null && e2.getJobNumber() != null && !e2.getJobNumber().isEmpty()) {
                            rr = new ManagerResolve(e2.getJobNumber(),
                                    e2.getEmployeeName() != null ? e2.getEmployeeName() : rr != null ? rr.getManager() : k2,
                                    e2.getJobNumber());
                        }
                    }
                }
            }
        } catch (Exception ex) {
            // DB 查询异常：保留原始文本，manager_id/jobNumber 留空（不让保存动作因解析失败中断）
            return;
        }
        org.setManagerId(rr.managerId);
        if (rr.manager != null) org.setManager(rr.manager);
        org.setManagerJobNumber(rr.managerJobNumber);
    }

    /**
     * 纯函数化的负责人解析核心（可脱离 DB/容器做单元测试）。
     * <p>需求"manager_id 用工号"→ 【工号优先】匹配顺序：
     * <ol>
     *     <li>PmtEmployee.jobNumber    精确 → managerId=emp.id，manager=employeeName，返回 jobNumber</li>
     *     <li>PmtEmployee.employeeName 精确 → 同上</li>
     *     <li>PmtUser.username / realName 精确 → 通过 user.employeeId 反查员工，返回三者；
     *         若 employeeId 为空则允许用 findEmpByUserId（参数 findEmpById 不负责 userId 映射，
     *         但调用方通常会在 findEmp 之外补 userId 反查）</li>
     * </ol>
     * 全部不命中 → managerId=null，manager=原输入（允许"挂名"负责人显示），jobNumber=null。
     * 空输入 → 全清。
     *
     * @param rawInput   用户原始输入（姓名/工号/登录名任一，可 null）
     * @param findEmp    (field: "jobNumber"|"employeeName", key) → PmtEmployee or null
     * @param findEmpById empId → PmtEmployee（User 分支用 employeeId 反查拿 jobNumber/name 时用）
     * @param findUsr    (field: "username"|"realName", key) → PmtUser or null
     * @return 三元结果结构 managerId / manager / managerJobNumber（后两者用于显示与回填列）
     */
    public static ManagerResolve resolveManagerKey(String rawInput,
                                                   java.util.function.BiFunction<String, String, PmtEmployee> findEmp,
                                                   java.util.function.Function<Long, PmtEmployee> findEmpById,
                                                   java.util.function.BiFunction<String, String, User> findUsr) {
        if (rawInput == null || rawInput.trim().isEmpty()) {
            return new ManagerResolve(null, null, null);
        }
        final String key = rawInput.trim();
        try {
            PmtEmployee emp;
            // 【1 优先级最高：job_number】— 满足用户"manager_id 用工号"
            if (key.length() <= 32) {
                emp = findEmp.apply("jobNumber", key);
                if (emp != null && emp.getJobNumber() != null && !emp.getJobNumber().isEmpty()) {
                    String name = emp.getEmployeeName() != null ? emp.getEmployeeName() : key;
                    return new ManagerResolve(emp.getJobNumber(), name, emp.getJobNumber());
                }
            }
            // 【2：employee_name】
            emp = findEmp.apply("employeeName", key);
            if (emp != null && emp.getJobNumber() != null && !emp.getJobNumber().isEmpty()) {
                String name = emp.getEmployeeName() != null ? emp.getEmployeeName() : key;
                return new ManagerResolve(emp.getJobNumber(), name, emp.getJobNumber());
            }
            // 【3/4：username / realName】
            User u = findUsr.apply("username", key);
            if (u == null) u = findUsr.apply("realName", key);
            if (u != null) {
                Long empId = u.getEmployeeId();
                PmtEmployee byId = empId != null ? findEmpById.apply(empId) : null;
                String jn = null, nm = null;
                if (byId != null && byId.getJobNumber() != null && !byId.getJobNumber().isEmpty()) {
                    jn = byId.getJobNumber();   // 这里取 jobNumber 作为 manager_id（不存 emp.id）
                    nm = byId.getEmployeeName();
                } else {
                    // findEmpById 未命中（employeeId 可能没同步），调用方 resolveManagerId 会额外反查
                    //   employee.user_id = u.id，此处纯函数不做隐式查询。
                }
                String displayName = (u.getRealName() != null && !u.getRealName().isEmpty()) ? u.getRealName() : key;
                // managerId 取 jn（job_number 字符串），而非 empId（数字自增 id）
                return new ManagerResolve(jn, nm != null ? nm : displayName, jn);
            }
            // 全部未命中 → 保留文本，不填 managerId
            return new ManagerResolve(null, key, null);
        } catch (Exception ex) {
            // 解析/查询异常 → 保守处理：保留文本，其余留空
            return new ManagerResolve(null, key, null);
        }
    }

    /** resolveManagerKey 的返回值：managerId（=job_number 字符串）+ 规范化姓名 manager + 工号 managerJobNumber（冗余用于列表渲染）。 */
    @lombok.Data
    @lombok.AllArgsConstructor
    @lombok.NoArgsConstructor
    public static class ManagerResolve {
        /** crm_org.manager_id 列的值：存储 crm_employee.job_number（字符串工号，如 E001），非自增数字 ID */
        private String managerId;
        private String manager;
        private String managerJobNumber;
    }
}
