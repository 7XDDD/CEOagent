package com.crm.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.system.LoginLogQueryDTO;
import com.crm.entity.LoginLog;
import com.crm.entity.User;
import com.crm.mapper.LoginLogMapper;
import com.crm.mapper.UserMapper;
import com.crm.service.LoginLogService;
import com.crm.vo.system.LoginLogVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
public class LoginLogServiceImpl implements LoginLogService {

    @Autowired
    private LoginLogMapper loginLogMapper;

    @Autowired
    private UserMapper userMapper;

    @Override
    public Page<LoginLogVO> pageList(LoginLogQueryDTO query) {
        Page<LoginLog> page = new Page<>(query.getPageNum(), query.getPageSize());
        Page<LoginLog> logPage = loginLogMapper.selectPageList(page, query);
        Page<LoginLogVO> voPage = new Page<>(logPage.getCurrent(), logPage.getSize(), logPage.getTotal());

        List<LoginLog> records = logPage.getRecords();
        // 批量查询用户姓名，避免N+1
        Set<Long> userIds = records.stream()
                .map(LoginLog::getUserId)
                .filter(id -> id != null)
                .collect(Collectors.toSet());
        Map<Long, String> nameMap = new HashMap<>();
        if (!userIds.isEmpty()) {
            List<User> users = userMapper.selectBatchIds(userIds);
            nameMap = users.stream()
                    .filter(u -> u.getRealName() != null && !u.getRealName().isEmpty())
                    .collect(Collectors.toMap(User::getId, User::getRealName, (a, b) -> a));
        }

        Map<Long, String> finalNameMap = nameMap;
        List<LoginLogVO> voList = records.stream().map(ll -> convertToVO(ll, finalNameMap)).collect(Collectors.toList());
        voPage.setRecords(voList);
        return voPage;
    }

    private LoginLogVO convertToVO(LoginLog ll, Map<Long, String> nameMap) {
        LoginLogVO vo = new LoginLogVO();
        BeanUtils.copyProperties(ll, vo);
        // 姓名
        if (ll.getUserId() != null && nameMap != null) {
            vo.setRealName(nameMap.getOrDefault(ll.getUserId(), null));
        }
        // IP地址优先用ip字段，回退到clientIp
        if (vo.getIp() == null || vo.getIp().isEmpty()) {
            vo.setIp(ll.getClientIp());
        }
        // 登录地点：简单判断本地/内网
        vo.setIpLocation(resolveIpLocation(vo.getIp()));
        // 如browser/os为空，从userAgent解析
        if ((vo.getBrowser() == null || vo.getOs() == null) && ll.getUserAgent() != null) {
            String[] bo = parseUserAgent(ll.getUserAgent());
            if (vo.getBrowser() == null) vo.setBrowser(bo[0]);
            if (vo.getOs() == null) vo.setOs(bo[1]);
        }
        return vo;
    }

    private String resolveIpLocation(String ip) {
        if (ip == null || ip.isEmpty()) return "未知";
        if ("0:0:0:0:0:0:0:1".equals(ip) || "127.0.0.1".equals(ip) || "localhost".equalsIgnoreCase(ip)) {
            return "本机";
        }
        if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.16.")
                || ip.startsWith("172.17.") || ip.startsWith("172.18.") || ip.startsWith("172.19.")
                || ip.startsWith("172.2") || ip.startsWith("172.30.") || ip.startsWith("172.31.")) {
            return "内网IP";
        }
        return "外网";
    }

    /**
     * 简易User-Agent解析，不引入额外依赖
     * 返回 [browser, os]
     */
    public static String[] parseUserAgent(String ua) {
        if (ua == null) return new String[]{"未知", "未知"};
        String browser = "未知";
        String os = "未知";
        String u = ua.toLowerCase();

        // OS
        if (u.contains("windows nt 10")) os = "Windows 10/11";
        else if (u.contains("windows nt 6.3")) os = "Windows 8.1";
        else if (u.contains("windows nt 6.2")) os = "Windows 8";
        else if (u.contains("windows nt 6.1")) os = "Windows 7";
        else if (u.contains("windows phone")) os = "Windows Phone";
        else if (u.contains("windows")) os = "Windows";
        else if (u.contains("android")) os = "Android";
        else if (u.contains("iphone") || u.contains("ipad") || u.contains("ipod")) {
            if (u.contains("ipad")) os = "iPadOS";
            else os = "iOS";
        } else if (u.contains("mac os x")) os = "macOS";
        else if (u.contains("linux")) os = "Linux";
        else if (u.contains("x11")) os = "Unix";

        // Browser (检测顺序重要：Chrome在Safari字符串里，Edg在Chrome前面)
        if (u.contains("edg/") || u.contains("edge/")) browser = "Edge";
        else if (u.contains("micromessenger")) browser = "微信内置";
        else if (u.contains("qqbrowser")) browser = "QQ浏览器";
        else if (u.contains("chrome/") && u.contains("safari/")) browser = "Chrome";
        else if (u.contains("firefox/")) browser = "Firefox";
        else if (u.contains("safari/") && !u.contains("chrome/")) browser = "Safari";
        else if (u.contains("msie") || u.contains("trident/")) browser = "IE";
        else if (u.contains("opera") || u.contains("opr/")) browser = "Opera";

        return new String[]{browser, os};
    }
}
