package com.crm.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.crm.common.Result;
import com.crm.common.ResultCode;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private static final String NEW_TOKEN_HEADER = "New-Token";
    private static final double REFRESH_THRESHOLD_RATIO = 0.5;

    private final JwtTokenUtil jwtTokenUtil;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${crm.security.jwt.expiration}")
    private Long expiration;

    public JwtAuthenticationFilter(JwtTokenUtil jwtTokenUtil) {
        this.jwtTokenUtil = jwtTokenUtil;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String header = request.getHeader(jwtTokenUtil.getHeader());

        if (!StringUtils.hasText(header) || !header.startsWith(jwtTokenUtil.getPrefix())) {
            chain.doFilter(request, response);
            return;
        }

        String token = header.substring(jwtTokenUtil.getPrefix().length());
        try {
            Claims claims = jwtTokenUtil.parseToken(token);
            if (claims != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                String username = claims.getSubject();
                Object userIdObj = claims.get("userId");
                Object companyIdObj = claims.get("companyId");
                Object orgIdObj = claims.get("orgId");
                Object rolesObj = claims.get("roles");
                Object permsObj = claims.get("permissions");

                if (userIdObj == null || !StringUtils.hasText(username)) {
                    log.warn("JWT token missing userId or username");
                    sendErrorResponse(request, response, ResultCode.TOKEN_INVALID.getCode(), ResultCode.TOKEN_INVALID.getMessage());
                    return;
                }

                String userId = userIdObj.toString();
                String companyId = companyIdObj != null ? companyIdObj.toString() : null;
                String orgId = orgIdObj != null ? orgIdObj.toString() : null;
                String rolesStr = rolesObj != null ? rolesObj.toString() : null;
                String permsStr = permsObj != null ? permsObj.toString() : null;

                List<SimpleGrantedAuthority> authorities = new ArrayList<>();

                if (StringUtils.hasText(rolesStr)) {
                    Arrays.stream(rolesStr.split(","))
                            .filter(StringUtils::hasText)
                            .map(role -> role.startsWith("ROLE_") ? role : "ROLE_" + role)
                            .map(SimpleGrantedAuthority::new)
                            .forEach(authorities::add);
                }

                if (StringUtils.hasText(permsStr)) {
                    Arrays.stream(permsStr.split(","))
                            .filter(StringUtils::hasText)
                            .map(SimpleGrantedAuthority::new)
                            .forEach(authorities::add);
                }

                List<String> roleList = rolesStr != null && !rolesStr.isEmpty()
                        ? Arrays.stream(rolesStr.split(",")).filter(StringUtils::hasText).collect(Collectors.toList())
                        : Collections.emptyList();
                List<String> permList = permsStr != null && !permsStr.isEmpty()
                        ? Arrays.stream(permsStr.split(",")).filter(StringUtils::hasText).collect(Collectors.toList())
                        : Collections.emptyList();

                Map<String, Object> principal = new HashMap<>();
                principal.put("userId", Long.parseLong(userId));
                principal.put("username", username);
                principal.put("companyId", companyId != null ? Long.parseLong(companyId) : null);
                principal.put("orgId", orgId != null ? Long.parseLong(orgId) : null);
                principal.put("roles", roleList);
                principal.put("permissions", permList);

                UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(principal, null, authorities);
                SecurityContextHolder.getContext().setAuthentication(authentication);

                Date expirationDate = claims.getExpiration();
                long now = System.currentTimeMillis();
                long remainingMs = expirationDate.getTime() - now;
                long thresholdMs = (long) (expiration * 1000 * REFRESH_THRESHOLD_RATIO);
                
                if (remainingMs > 0 && remainingMs < thresholdMs) {
                    String newToken = jwtTokenUtil.generateToken(
                            Long.parseLong(userId),
                            username,
                            companyId != null ? Long.parseLong(companyId) : null,
                            orgId != null ? Long.parseLong(orgId) : null,
                            roleList,
                            permList
                    );
                    response.setHeader(NEW_TOKEN_HEADER, newToken);
                    response.setHeader("Access-Control-Expose-Headers", NEW_TOKEN_HEADER);
                }
            }
            chain.doFilter(request, response);
        } catch (ExpiredJwtException e) {
            log.warn("JWT token expired: {}", e.getMessage());
            sendErrorResponse(request, response, ResultCode.TOKEN_EXPIRED.getCode(), ResultCode.TOKEN_EXPIRED.getMessage());
        } catch (JwtException | IllegalArgumentException e) {
            log.warn("Invalid JWT token: {}", e.getMessage());
            sendErrorResponse(request, response, ResultCode.TOKEN_INVALID.getCode(), ResultCode.TOKEN_INVALID.getMessage());
        }
    }

    private void sendErrorResponse(HttpServletRequest request, HttpServletResponse response, int code, String message) throws IOException {
        SecurityContextHolder.clearContext();
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setCharacterEncoding("UTF-8");
        String origin = request.getHeader("Origin");
        if (origin != null && !origin.isEmpty()) {
            response.setHeader("Access-Control-Allow-Origin", origin);
            response.setHeader("Access-Control-Allow-Credentials", "true");
            response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
            response.setHeader("Access-Control-Allow-Headers", "*");
            response.setHeader("Access-Control-Expose-Headers", NEW_TOKEN_HEADER + ", Content-Disposition");
        }
        response.getWriter().write(objectMapper.writeValueAsString(Result.error(code, message)));
    }
}
