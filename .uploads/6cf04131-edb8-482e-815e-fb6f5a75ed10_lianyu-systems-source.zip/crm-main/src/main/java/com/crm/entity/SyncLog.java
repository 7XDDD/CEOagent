package com.crm.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@TableName("crm_sync_log")
public class SyncLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long id;

    @TableField("task_key")
    private String taskKey;

    @TableField("task_name")
    private String taskName;

    @TableField("trigger_type")
    private String triggerType;

    private Integer status;

    private String message;

    @TableField("added_count")
    private Integer addedCount;

    @TableField("updated_count")
    private Integer updatedCount;

    @TableField("deleted_count")
    private Integer deletedCount;

    @TableField("total_count")
    private Integer totalCount;

    private Long duration;

    @TableField("error_msg")
    private String errorMsg;

    private String operator;

    @TableField("http_status")
    private Integer httpStatus;

    @TableField("response_body")
    private String responseBody;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @TableField(value = "created_by", fill = FieldFill.INSERT)
    private Long createdBy;

    @Version
    @TableField(fill = FieldFill.INSERT)
    private Integer version = 0;

    @TableLogic
    @TableField(fill = FieldFill.INSERT)
    private Long deleted = 0L;
}
