package com.crm.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.BusinessException;
import com.crm.common.ResultCode;
import com.crm.common.SecurityContextUtil;
import com.crm.dataperm.DataPermModule;
import com.crm.dto.PageResult;
import com.crm.dto.project.ProjectQueryDTO;
import com.crm.entity.Project;
import com.crm.mapper.ProjectMapper;
import com.crm.service.DataPermissionService;
import com.crm.service.ProjectService;
import com.crm.vo.project.ProjectVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ProjectServiceImpl implements ProjectService {

    @Autowired
    private ProjectMapper projectMapper;

    @Autowired
    private DataPermissionService dataPermissionService;

    @Override
    public PageResult<ProjectVO> page(ProjectQueryDTO query) {
        if (query == null) query = new ProjectQueryDTO();
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        boolean isAdmin = SecurityContextUtil.hasRole("super_admin") || SecurityContextUtil.hasRole("ADMIN");
        if (!isAdmin) {
            query.setCurrentUserId(SecurityContextUtil.getCurrentUserId());
        }
        int pageNum = query.getPageNum() == null ? 1 : query.getPageNum();
        int pageSize = query.getPageSize() == null ? 20 : query.getPageSize();
        Page<ProjectVO> page = new Page<>(pageNum, pageSize);
        IPage<ProjectVO> result = projectMapper.selectPageList(page, companyId, query);
        List<ProjectVO> records = result.getRecords();
        if (records != null && !records.isEmpty()) {
            Map<Long, Integer> bits = dataPermissionService.permBitsMap(
                    DataPermModule.PROJECT,
                    records.stream().map(ProjectVO::getId).collect(Collectors.toList()));
            records.forEach(vo -> vo.setPermBits(bits.getOrDefault(vo.getId(), 0)));
        }
        return new PageResult<>(records, result.getTotal(), pageNum, pageSize);
    }

    @Override
    public ProjectVO getById(Long id) {
        Project p = projectMapper.selectById(id);
        if (p == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "项目不存在");
        }
        ProjectVO vo = new ProjectVO();
        org.springframework.beans.BeanUtils.copyProperties(p, vo);
        vo.setPermBits(dataPermissionService.effectiveBits(DataPermModule.PROJECT, id));
        return vo;
    }
}
