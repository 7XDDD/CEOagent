package com.crm.dataperm;

/**
 * 数据级操作权限位（位掩码，可组合）
 * 注意：新增(NEW)属于功能权限(crm:xxx:add)，不在记录级权限内；
 * 一条已存在的数据只有 查看/编辑/删除 三种操作。
 */
public final class DataPermBits {
    private DataPermBits() {}

    public static final int READ = 1;
    public static final int UPDATE = 2;
    public static final int DELETE = 4;
    /** 全权 = 查看+编辑+删除 */
    public static final int ALL = READ | UPDATE | DELETE;
    /** 只读 */
    public static final int READ_ONLY = READ;

    public static boolean has(int bits, int required) {
        return (bits & required) == required;
    }
}
