package com.crm.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.crm.common.BusinessException;
import com.crm.common.ResultCode;
import com.crm.config.HrProperties;
import com.crm.dto.EmployeeQueryDTO;
import com.crm.entity.PmtEmployee;
import com.crm.mapper.PmtEmployeeMapper;
import com.crm.service.EmployeeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmployeeServiceImpl extends ServiceImpl<PmtEmployeeMapper, PmtEmployee> implements EmployeeService {

    private final PmtEmployeeMapper employeeMapper;
    private final HrProperties hrProperties;

    @Override
    public boolean isHrMode() {
        return hrProperties.isEnabled();
    }

    @Override
    public Page<PmtEmployee> pageList(EmployeeQueryDTO queryDTO) {
        if (isHrMode()) {
            return pageListFromHr(queryDTO);
        }
        Page<PmtEmployee> page = new Page<>(queryDTO.getPageNum(), queryDTO.getPageSize());
        return employeeMapper.selectPageList(page, queryDTO);
    }

    private Page<PmtEmployee> pageListFromHr(EmployeeQueryDTO queryDTO) {
        // TODO: HR模式下从hr_employee表查询，暂时返回本地表数据，后续实现多数据源
        Page<PmtEmployee> page = new Page<>(queryDTO.getPageNum(), queryDTO.getPageSize());
        return employeeMapper.selectPageList(page, queryDTO);
    }

    @Override
    public List<PmtEmployee> listAll(EmployeeQueryDTO queryDTO) {
        return employeeMapper.selectListByCondition(queryDTO);
    }

    @Override
    public List<PmtEmployee> listActive(String keyword) {
        EmployeeQueryDTO query = new EmployeeQueryDTO();
        query.setKeyword(keyword);
        query.setWorkStatus("ACTIVE");
        return employeeMapper.selectListByCondition(query);
    }

    @Override
    public PmtEmployee getByJobNumber(String jobNumber) {
        return employeeMapper.selectByJobNumber(jobNumber);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void createEmployee(PmtEmployee employee) {
        if (isHrMode()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR集成模式下不允许手动管理员工数据");
        }
        PmtEmployee existing = employeeMapper.selectByJobNumber(employee.getJobNumber());
        if (existing != null) {
            throw new BusinessException(ResultCode.DATA_DUPLICATE, "工号已存在");
        }
        if (employee.getWorkStatus() == null) {
            employee.setWorkStatus("ACTIVE");
        }
        if (employee.getIsConsultant() == null) {
            employee.setIsConsultant(0);
        }
        employee.setId(null);
        employee.setDeleted(0L);
        employee.setVersion(0);
        employee.setCreateTime(LocalDateTime.now());
        employee.setUpdateTime(LocalDateTime.now());
        employeeMapper.insert(employee);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateEmployee(Long id, PmtEmployee employee) {
        if (isHrMode()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR集成模式下不允许手动管理员工数据");
        }
        PmtEmployee existing = employeeMapper.selectById(id);
        if (existing == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        if (!existing.getJobNumber().equals(employee.getJobNumber())) {
            PmtEmployee byJobNumber = employeeMapper.selectByJobNumber(employee.getJobNumber());
            if (byJobNumber != null && !byJobNumber.getId().equals(id)) {
                throw new BusinessException(ResultCode.DATA_DUPLICATE, "工号已存在");
            }
        }
        employee.setId(id);
        employee.setUpdateTime(LocalDateTime.now());
        employeeMapper.updateById(employee);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteEmployee(Long id) {
        if (isHrMode()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR集成模式下不允许手动管理员工数据");
        }
        PmtEmployee existing = employeeMapper.selectById(id);
        if (existing == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        employeeMapper.deleteById(id);
    }
}

