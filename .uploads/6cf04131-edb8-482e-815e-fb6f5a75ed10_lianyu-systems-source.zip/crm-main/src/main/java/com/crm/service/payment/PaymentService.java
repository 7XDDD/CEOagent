package com.crm.service.payment;

import com.crm.dto.PageResult;
import com.crm.dto.payment.PaymentQueryDTO;
import com.crm.vo.payment.PaymentRecordVO;

public interface PaymentService {

    /**
     * 分页查询回款记录
     */
    PageResult<PaymentRecordVO> page(PaymentQueryDTO query);
}
