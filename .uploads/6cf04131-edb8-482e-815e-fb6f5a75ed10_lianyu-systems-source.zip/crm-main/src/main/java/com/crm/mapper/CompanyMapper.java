package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.Company;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface CompanyMapper extends BaseMapper<Company> {

    List<Company> selectAllActive();

    int softDeleteById(@Param("id") Long id);

    Company findFirst();

    long countAllCompanies();
}
