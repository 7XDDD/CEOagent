package com.crm.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.BusinessException;
import com.crm.common.ResultCode;
import com.crm.common.SecurityContextUtil;
import com.crm.dto.*;
import com.crm.entity.PmtCustomer;
import com.crm.entity.PmtCustomerAddress;
import com.crm.entity.PmtCustomerContact;
import com.crm.entity.PmtCustomerFollower;
import com.crm.entity.Region;
import com.crm.entity.User;
import com.crm.mapper.PmtCustomerAddressMapper;
import com.crm.mapper.PmtCustomerContactMapper;
import com.crm.mapper.PmtCustomerFollowerMapper;
import com.crm.mapper.PmtCustomerMapper;
import com.crm.mapper.RegionMapper;
import com.crm.mapper.UserMapper;
import com.crm.service.CustomerService;
import com.crm.vo.CustomerVO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private final PmtCustomerMapper baseMapper;
    private final PmtCustomerAddressMapper addressMapper;
    private final PmtCustomerContactMapper contactMapper;
    private final PmtCustomerFollowerMapper followerMapper;
    private final UserMapper userMapper;
    private final RegionMapper regionMapper;
    private final com.crm.service.DataPermissionService dataPermissionService;

    private static final Set<String> ALLOWED_EXTENSIONS = new HashSet<>(Arrays.asList(".xlsx", ".xls"));
    private static final Set<String> ALLOWED_MIME_TYPES = new HashSet<>(Arrays.asList(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-excel",
            "application/octet-stream"
    ));
    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024;

    private Long getCurrentUserId() {
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            if (authentication != null && authentication.getPrincipal() != null) {
                Object principal = authentication.getPrincipal();
                if (principal instanceof Map) {
                    Object userId = ((Map<?, ?>) principal).get("userId");
                    if (userId != null) {
                        return Long.valueOf(userId.toString());
                    }
                } else if (principal instanceof Long) {
                    return (Long) principal;
                }
            }
        } catch (Exception e) {
        }
        return 1L;
    }

    private void setCreateFields(Object entity) {
        Long userId = getCurrentUserId();
        LocalDateTime now = LocalDateTime.now();
        if (entity instanceof PmtCustomer) {
            PmtCustomer customer = (PmtCustomer) entity;
            customer.setCreateBy(userId);
            customer.setUpdateBy(userId);
            customer.setCreateTime(now);
            customer.setUpdateTime(now);
            customer.setDeleted(0L);
            customer.setVersion(0);
        } else if (entity instanceof PmtCustomerAddress) {
            PmtCustomerAddress addr = (PmtCustomerAddress) entity;
            addr.setCreatedBy(userId);
            addr.setUpdatedBy(userId);
            addr.setCreateTime(now);
            addr.setUpdateTime(now);
            addr.setDeleted(0L);
        } else if (entity instanceof PmtCustomerContact) {
            PmtCustomerContact contact = (PmtCustomerContact) entity;
            contact.setCreatedBy(userId);
            contact.setUpdatedBy(userId);
            contact.setCreateTime(now);
            contact.setUpdateTime(now);
            contact.setDeleted(0L);
        } else if (entity instanceof PmtCustomerFollower) {
            PmtCustomerFollower follower = (PmtCustomerFollower) entity;
            follower.setCreatedBy(userId);
            follower.setUpdatedBy(userId);
            follower.setCreateTime(now);
            follower.setUpdateTime(now);
            follower.setDeleted(0L);
        }
    }

    private void setUpdateFields(Object entity) {
        Long userId = getCurrentUserId();
        LocalDateTime now = LocalDateTime.now();
        if (entity instanceof PmtCustomer) {
            PmtCustomer customer = (PmtCustomer) entity;
            customer.setUpdateBy(userId);
            customer.setUpdateTime(now);
        } else if (entity instanceof PmtCustomerAddress) {
            PmtCustomerAddress addr = (PmtCustomerAddress) entity;
            addr.setUpdatedBy(userId);
            addr.setUpdateTime(now);
        } else if (entity instanceof PmtCustomerContact) {
            PmtCustomerContact contact = (PmtCustomerContact) entity;
            contact.setUpdatedBy(userId);
            contact.setUpdateTime(now);
        } else if (entity instanceof PmtCustomerFollower) {
            PmtCustomerFollower follower = (PmtCustomerFollower) entity;
            follower.setUpdatedBy(userId);
            follower.setUpdateTime(now);
        }
    }

    @Override
    public Page<CustomerVO> pageList(CustomerQueryDTO queryDTO) {
        // 数据权限：非管理员只能看到自己跟进或创建的客户
        Long currentUserId = getCurrentUserId();
        boolean isAdmin = SecurityContextUtil.hasRole("super_admin") || SecurityContextUtil.hasRole("ADMIN");
        if (!isAdmin && currentUserId != null) {
            queryDTO.setCurrentUserId(currentUserId);
        }
        Page<PmtCustomer> page = new Page<>(queryDTO.getPageNum(), queryDTO.getPageSize());
        Page<PmtCustomer> result = baseMapper.selectPageList(page, queryDTO);
        Page<CustomerVO> voPage = new Page<>(result.getCurrent(), result.getSize(), result.getTotal());
        List<CustomerVO> voList = result.getRecords().stream().map(c -> {
            CustomerVO vo = BeanUtil.copyProperties(c, CustomerVO.class);
            return vo;
        }).collect(Collectors.toList());
        // 填充记录级数据权限位
        if (!voList.isEmpty()) {
            Map<Long, Integer> bits = dataPermissionService.permBitsMap(
                    com.crm.dataperm.DataPermModule.CUSTOMER,
                    voList.stream().map(CustomerVO::getId).collect(Collectors.toList()));
            voList.forEach(vo -> vo.setPermBits(bits.getOrDefault(vo.getId(), 0)));
        }
        voPage.setRecords(voList);
        return voPage;
    }

    @Override
    public Page<CustomerVO> publicSeaList(CustomerQueryDTO queryDTO) {
        Page<PmtCustomer> page = new Page<>(queryDTO.getPageNum(), queryDTO.getPageSize());
        Page<PmtCustomer> result = baseMapper.selectPublicSeaList(page, queryDTO);
        Page<CustomerVO> voPage = new Page<>(result.getCurrent(), result.getSize(), result.getTotal());
        voPage.setRecords(result.getRecords().stream()
                .map(c -> BeanUtil.copyProperties(c, CustomerVO.class)).collect(Collectors.toList()));
        return voPage;
    }

    @Override
    public void claimCustomer(Long id) {
        PmtCustomer customer = baseMapper.selectCustomerById(id);
        if (customer == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        Long userId = getCurrentUserId();
        customer.setInPublicSea(0);
        customer.setFollowerId(userId);
        customer.setRecycleTime(null);
        customer.setUpdateBy(userId);
        customer.setUpdateTime(LocalDateTime.now());
        baseMapper.updateCustomer(customer);
    }

    @Override
    public Map<String, Object> analysis(CustomerQueryDTO queryDTO) {
        Map<String, Object> result = new HashMap<>();
        Map<String, Long> stats = new HashMap<>();

        CustomerQueryDTO allQuery = new CustomerQueryDTO();
        allQuery.setPageNum(1);
        allQuery.setPageSize(10000);
        Page<PmtCustomer> allPage = baseMapper.selectPageList(new Page<>(1, 10000), allQuery);
        List<PmtCustomer> all = allPage.getRecords();

        stats.put("createdCount", all.stream().filter(c -> c.getCreateTime() != null
                && c.getCreateTime().toLocalDate().equals(LocalDate.now())).count());
        stats.put("assignedCount", all.stream().filter(c -> c.getFollowerId() != null
                && c.getCreateTime() != null && c.getCreateTime().toLocalDate().equals(LocalDate.now())).count());
        stats.put("visitedCount", 0L);
        stats.put("followedCount", all.stream().filter(c -> c.getLastFollowTime() != null
                && c.getLastFollowTime().toLocalDate().equals(LocalDate.now())).count());
        stats.put("unfollowedCount", all.stream().filter(c -> c.getInPublicSea() != null && c.getInPublicSea() == 0
                && (c.getLastFollowTime() == null
                || c.getLastFollowTime().isBefore(LocalDateTime.now().minusDays(7)))).count());
        stats.put("dealCount", all.stream().filter(c -> c.getDealFlag() != null && c.getDealFlag() == 1).count());

        result.put("stats", stats);
        result.put("progress", all);
        result.put("deal", all.stream().filter(c -> c.getDealFlag() != null && c.getDealFlag() == 1).collect(Collectors.toList()));
        return result;
    }

    @Override
    public CustomerVO getDetail(Long id) {
        PmtCustomer customer = baseMapper.selectCustomerById(id);
        if (customer == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        CustomerVO vo = BeanUtil.copyProperties(customer, CustomerVO.class);
        vo.setAddresses(getAddresses(id));
        vo.setContacts(getContacts(id));
        vo.setFollowers(getFollowers(id));
        vo.setPermBits(dataPermissionService.effectiveBits(com.crm.dataperm.DataPermModule.CUSTOMER, id));
        return vo;
    }

    @Override
    public List<CustomerVO> listAll() {
        List<PmtCustomer> customers = baseMapper.selectAllActive();
        return customers.stream().map(c -> BeanUtil.copyProperties(c, CustomerVO.class)).collect(Collectors.toList());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long createCustomer(CustomerCreateDTO createDTO) {
        int count = baseMapper.countByCode(createDTO.getCustomerCode(), null);
        if (count > 0) {
            throw new BusinessException(ResultCode.DATA_DUPLICATE, "客户编码已存在");
        }
        PmtCustomer customer = BeanUtil.copyProperties(createDTO, PmtCustomer.class);
        if (customer.getCustomerStatus() == null || customer.getCustomerStatus().isEmpty()) {
            customer.setCustomerStatus("ACTIVE");
        }
        if (customer.getDealFlag() == null) {
            customer.setDealFlag(0);
        }
        if (customer.getInPublicSea() == null) {
            customer.setInPublicSea(0);
        }
        setCreateFields(customer);
        baseMapper.insertCustomer(customer);
        return customer.getId();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateCustomer(Long id, CustomerUpdateDTO updateDTO) {
        PmtCustomer customer = baseMapper.selectCustomerById(id);
        if (customer == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        dataPermissionService.assertWrite(com.crm.dataperm.DataPermModule.CUSTOMER, id, com.crm.dataperm.DataPermBits.UPDATE);
        if (updateDTO.getCustomerCode() != null && !updateDTO.getCustomerCode().equals(customer.getCustomerCode())) {
            int count = baseMapper.countByCode(updateDTO.getCustomerCode(), id);
            if (count > 0) {
                throw new BusinessException(ResultCode.DATA_DUPLICATE, "客户编码已存在");
            }
        }
        BeanUtil.copyProperties(updateDTO, customer);
        setUpdateFields(customer);
        return baseMapper.updateCustomer(customer) > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean transferCustomer(Long id, Long newOwnerId, String newOwnerName) {
        if (newOwnerId == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请指定新负责人");
        }
        PmtCustomer customer = baseMapper.selectCustomerById(id);
        if (customer == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        dataPermissionService.assertWrite(com.crm.dataperm.DataPermModule.CUSTOMER, id, com.crm.dataperm.DataPermBits.UPDATE);
        com.crm.entity.User target = userMapper.selectById(newOwnerId);
        if (target == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "目标用户不存在");
        }
        String name = (newOwnerName != null && !newOwnerName.isEmpty()) ? newOwnerName : target.getRealName();
        customer.setManagerId(newOwnerId);
        customer.setManagerName(name);
        customer.setFollowerId(newOwnerId);
        setUpdateFields(customer);
        return baseMapper.updateCustomer(customer) > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteCustomer(Long id) {
        PmtCustomer customer = baseMapper.selectCustomerById(id);
        if (customer == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND);
        }
        dataPermissionService.assertWrite(com.crm.dataperm.DataPermModule.CUSTOMER, id, com.crm.dataperm.DataPermBits.DELETE);
        addressMapper.deleteByCustomerId(id);
        contactMapper.deleteByCustomerId(id);
        followerMapper.deleteByCustomerId(id);
        return baseMapper.softDeleteById(id) > 0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteBatch(List<Long> ids) {
        for (Long id : ids) {
            deleteCustomer(id);
        }
        return true;
    }

    @Override
    public void exportCustomers(CustomerQueryDTO query, HttpServletResponse response) throws Exception {
        List<PmtCustomer> customers;
        if (query != null) {
            customers = baseMapper.selectListByCondition(query);
        } else {
            customers = baseMapper.selectAllActive();
        }

        Map<Long, List<PmtCustomerAddress>> addressMap = new HashMap<>();
        Map<Long, List<PmtCustomerContact>> contactMap = new HashMap<>();
        Map<Long, List<PmtCustomerFollower>> followerMap = new HashMap<>();

        if (!customers.isEmpty()) {
            List<Long> ids = customers.stream().map(PmtCustomer::getId).collect(Collectors.toList());
            List<PmtCustomerAddress> addrs = addressMapper.selectByCustomerIds(ids);
            addressMap = addrs.stream().collect(Collectors.groupingBy(PmtCustomerAddress::getCustomerId));

            List<PmtCustomerContact> contacts = contactMapper.selectByCustomerIds(ids);
            contactMap = contacts.stream().collect(Collectors.groupingBy(PmtCustomerContact::getCustomerId));

            List<PmtCustomerFollower> followers = followerMapper.selectByCustomerIds(ids);
            List<Long> userIds = followers.stream().map(PmtCustomerFollower::getUserId).filter(Objects::nonNull).distinct().collect(Collectors.toList());
            Map<Long, String> userNameMap = new HashMap<>();
            if (!userIds.isEmpty()) {
                List<User> users = userMapper.selectBatchIds(userIds);
                userNameMap = users.stream().collect(Collectors.toMap(User::getId, u -> u.getRealName() != null ? u.getRealName() : u.getUsername(), (a, b) -> a));
            }
            for (PmtCustomerFollower f : followers) {
                f.setUserName(userNameMap.get(f.getUserId()));
            }
            followerMap = followers.stream().collect(Collectors.groupingBy(PmtCustomerFollower::getCustomerId));
        }

        ExcelWriter writer = ExcelUtil.getWriter();

        writeCustomerSheet(writer, customers);
        writer.setSheet("客户地址信息");
        writeAddressSheet(writer, customers, addressMap);
        writer.setSheet("客户联系人");
        writeContactSheet(writer, customers, contactMap);
        writer.setSheet("客户跟进人");
        writeFollowerSheet(writer, customers, followerMap);
        writer.setSheet("填写说明");
        writeNoteSheet(writer);

        String fileName = URLEncoder.encode("客户数据(多Sheet)_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".xlsx", "UTF-8");
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    private void writeCustomerSheet(ExcelWriter writer, List<PmtCustomer> customers) {
        writer.renameSheet("客户基本信息");
        String[] headers = {"客户编号", "客户名称", "客户标准全称", "客户地址", "客户类型", "客户级别", "客户来源", "客户行业",
                "行业L1", "行业L2", "行业L3", "客户规模", "客户性质", "客户状态", "通话状态", "区域", "省份", "城市",
                "上市状态", "营收年份", "盈利", "营收规模", "市值", "员工数", "合作状态", "主要产品", "当前开发阶段",
                "累计销售额", "首次产单时间", "最高客户关系", "进行中商机", "匹配情况", "官网", "数据来源", "公司产品",
                "公司总机", "销售员", "原销售人员", "行业负责人", "CSO培训班", "主要联系人", "第二联系人", "客户负责人",
                "跟进人", "联系人姓名", "联系人手机", "联系人座机", "联系人邮箱", "联系人微信", "客户备注"};
        for (int i = 0; i < headers.length; i++) writer.writeCellValue(i, 0, headers[i]);

        int row = 1;
        for (PmtCustomer c : customers) {
            int col = 0;
            writer.writeCellValue(col++, row, c.getCustomerCode());
            writer.writeCellValue(col++, row, c.getCustomerName());
            writer.writeCellValue(col++, row, c.getStandardName());
            writer.writeCellValue(col++, row, c.getCustomerAddress());
            writer.writeCellValue(col++, row, getDictName("CUSTOMER_TYPE", c.getCustomerType()));
            writer.writeCellValue(col++, row, getDictName("CUSTOMER_LEVEL", c.getCustomerLevel()));
            writer.writeCellValue(col++, row, getDictName("CUSTOMER_SOURCE", c.getCustomerSource()));
            writer.writeCellValue(col++, row, c.getCustomerIndustry());
            writer.writeCellValue(col++, row, c.getIndustryL1());
            writer.writeCellValue(col++, row, c.getIndustryL2());
            writer.writeCellValue(col++, row, c.getIndustryL3());
            writer.writeCellValue(col++, row, getDictName("CUSTOMER_SCALE", c.getCustomerScale()));
            writer.writeCellValue(col++, row, getDictName("CUSTOMER_NATURE", c.getCustomerNature()));
            writer.writeCellValue(col++, row, getDictName("CUSTOMER_STATUS", c.getCustomerStatus()));
            writer.writeCellValue(col++, row, getDictName("CALL_STATUS", c.getCallStatus()));
            writer.writeCellValue(col++, row, c.getRegion());
            writer.writeCellValue(col++, row, c.getProvince());
            writer.writeCellValue(col++, row, c.getCity());
            writer.writeCellValue(col++, row, getDictName("LISTING_STATUS", c.getListingStatus()));
            writer.writeCellValue(col++, row, c.getRevenueYear());
            writer.writeCellValue(col++, row, getDictName("PROFIT", c.getProfit()));
            writer.writeCellValue(col++, row, getDictName("REVENUE_SCALE", c.getRevenueScale()));
            writer.writeCellValue(col++, row, c.getMarketValue());
            writer.writeCellValue(col++, row, c.getEmployeeCount());
            writer.writeCellValue(col++, row, getDictName("COOPERATION_STATUS", c.getCooperationStatus()));
            writer.writeCellValue(col++, row, c.getMainProduct());
            writer.writeCellValue(col++, row, getDictName("DEVELOPMENT_STAGE", c.getDevelopmentStage()));
            writer.writeCellValue(col++, row, c.getTotalSales());
            writer.writeCellValue(col++, row, c.getFirstOrderDate());
            writer.writeCellValue(col++, row, c.getHighestCustomerRelation());
            writer.writeCellValue(col++, row, c.getOngoingOpportunity());
            writer.writeCellValue(col++, row, c.getMatchStatus());
            writer.writeCellValue(col++, row, c.getWebsite());
            writer.writeCellValue(col++, row, c.getDataSource());
            writer.writeCellValue(col++, row, c.getCompanyProduct());
            writer.writeCellValue(col++, row, c.getCompanyTel());
            writer.writeCellValue(col++, row, c.getSalesman());
            writer.writeCellValue(col++, row, c.getOriginalSalesman());
            writer.writeCellValue(col++, row, c.getIndustryManager());
            writer.writeCellValue(col++, row, c.getCsoTrainingClass());
            writer.writeCellValue(col++, row, c.getMainContact());
            writer.writeCellValue(col++, row, c.getSecondContact());
            writer.writeCellValue(col++, row, c.getManagerName());
            writer.writeCellValue(col++, row, c.getFollowerName());
            writer.writeCellValue(col++, row, c.getContactName());
            writer.writeCellValue(col++, row, c.getContactMobile());
            writer.writeCellValue(col++, row, c.getContactTel());
            writer.writeCellValue(col++, row, c.getContactEmail());
            writer.writeCellValue(col++, row, c.getContactWechat());
            writer.writeCellValue(col, row, c.getRemark());
            row++;
        }
        int[] widths = new int[headers.length];
        for (int i = 0; i < widths.length; i++) widths[i] = 15;
        setSheetWidth(writer.getSheet(), widths);
        setHeaderStyle(writer, headers.length);
    }

    private void writeAddressSheet(ExcelWriter writer, List<PmtCustomer> customers, Map<Long, List<PmtCustomerAddress>> addressMap) {
        String[] headers = {"客户编码*", "客户名称", "数据状态", "地址类型", "国家", "省份", "城市", "区县",
                "街道", "详细地址", "邮编", "经度", "纬度", "收件人", "收件电话", "是否默认地址"};
        for (int i = 0; i < headers.length; i++) writer.writeCellValue(i, 0, headers[i]);

        int row = 1;
        for (PmtCustomer c : customers) {
            List<PmtCustomerAddress> addrs = addressMap.getOrDefault(c.getId(), Collections.emptyList());
            if (addrs.isEmpty()) {
                int col = 0;
                writer.writeCellValue(col++, row, c.getCustomerCode());
                writer.writeCellValue(col++, row, c.getCustomerName());
                col = 15;
                writer.writeCellValue(col, row, "");
                row++;
                continue;
            }
            for (PmtCustomerAddress a : addrs) {
                int col = 0;
                writer.writeCellValue(col++, row, c.getCustomerCode());
                writer.writeCellValue(col++, row, c.getCustomerName());
                writer.writeCellValue(col++, row, a.getStatus() != null && "INACTIVE".equals(a.getStatus()) ? "失效" : "生效");
                writer.writeCellValue(col++, row, getDictName("ADDRESS_TYPE", a.getAddressType()));
                writer.writeCellValue(col++, row, a.getCountryName() != null ? a.getCountryName() : "中国");
                writer.writeCellValue(col++, row, a.getProvinceName());
                writer.writeCellValue(col++, row, a.getCityName());
                writer.writeCellValue(col++, row, a.getDistrictName());
                writer.writeCellValue(col++, row, a.getStreet());
                writer.writeCellValue(col++, row, a.getDetailAddress());
                writer.writeCellValue(col++, row, a.getPostalCode());
                writer.writeCellValue(col++, row, a.getLongitude());
                writer.writeCellValue(col++, row, a.getLatitude());
                writer.writeCellValue(col++, row, a.getContactPerson());
                writer.writeCellValue(col++, row, a.getContactPhone());
                writer.writeCellValue(col, row, a.getIsDefault() != null && a.getIsDefault() == 1 ? "是" : "否");
                row++;
            }
        }
        setSheetWidth(writer.getSheet(), new int[]{18, 25, 10, 12, 10, 12, 12, 12, 15, 30, 10, 12, 12, 12, 15, 12});
        setHeaderStyle(writer, headers.length);
    }

    private void writeContactSheet(ExcelWriter writer, List<PmtCustomer> customers, Map<Long, List<PmtCustomerContact>> contactMap) {
        String[] headers = {"客户编码*", "客户名称", "数据状态", "联系人姓名*", "职位", "性别", "部门", "手机号码",
                "联系电话", "邮箱", "QQ", "微信", "是否主要联系人", "是否决策人"};
        for (int i = 0; i < headers.length; i++) writer.writeCellValue(i, 0, headers[i]);

        int row = 1;
        for (PmtCustomer c : customers) {
            List<PmtCustomerContact> contacts = contactMap.getOrDefault(c.getId(), Collections.emptyList());
            if (contacts.isEmpty()) {
                writer.writeCellValue(0, row, c.getCustomerCode());
                writer.writeCellValue(1, row, c.getCustomerName());
                writer.writeCellValue(13, row, "");
                row++;
                continue;
            }
            for (PmtCustomerContact ct : contacts) {
                int col = 0;
                writer.writeCellValue(col++, row, c.getCustomerCode());
                writer.writeCellValue(col++, row, c.getCustomerName());
                writer.writeCellValue(col++, row, ct.getStatus() != null && "INACTIVE".equals(ct.getStatus()) ? "失效" : "生效");
                writer.writeCellValue(col++, row, ct.getContactName());
                writer.writeCellValue(col++, row, ct.getContactTitle());
                writer.writeCellValue(col++, row, "MALE".equals(ct.getContactGender()) ? "男" : "FEMALE".equals(ct.getContactGender()) ? "女" : "");
                writer.writeCellValue(col++, row, ct.getDepartment());
                writer.writeCellValue(col++, row, ct.getContactMobile());
                writer.writeCellValue(col++, row, ct.getContactPhone());
                writer.writeCellValue(col++, row, ct.getContactEmail());
                writer.writeCellValue(col++, row, ct.getContactQq());
                writer.writeCellValue(col++, row, ct.getContactWechat());
                writer.writeCellValue(col++, row, ct.getIsPrimary() != null && ct.getIsPrimary() == 1 ? "是" : "否");
                writer.writeCellValue(col, row, ct.getIsDecisionMaker() != null && ct.getIsDecisionMaker() == 1 ? "是" : "否");
                row++;
            }
        }
        setSheetWidth(writer.getSheet(), new int[]{18, 25, 10, 14, 14, 8, 14, 14, 14, 22, 14, 14, 14, 12});
        setHeaderStyle(writer, headers.length);
    }

    private void writeFollowerSheet(ExcelWriter writer, List<PmtCustomer> customers, Map<Long, List<PmtCustomerFollower>> followerMap) {
        String[] headers = {"客户编码*", "客户名称", "数据状态", "跟进人用户名/姓名*", "跟进人类型*", "是否主跟进人",
                "开始跟进日期", "结束跟进日期", "描述", "排序"};
        for (int i = 0; i < headers.length; i++) writer.writeCellValue(i, 0, headers[i]);

        int row = 1;
        for (PmtCustomer c : customers) {
            List<PmtCustomerFollower> followers = followerMap.getOrDefault(c.getId(), Collections.emptyList());
            if (followers.isEmpty()) {
                writer.writeCellValue(0, row, c.getCustomerCode());
                writer.writeCellValue(1, row, c.getCustomerName());
                writer.writeCellValue(9, row, "");
                row++;
                continue;
            }
            for (PmtCustomerFollower f : followers) {
                int col = 0;
                writer.writeCellValue(col++, row, c.getCustomerCode());
                writer.writeCellValue(col++, row, c.getCustomerName());
                writer.writeCellValue(col++, row, f.getStatus() != null && "INACTIVE".equals(f.getStatus()) ? "失效" : "生效");
                writer.writeCellValue(col++, row, f.getUserName());
                writer.writeCellValue(col++, row, getDictName("FOLLOWER_TYPE", f.getFollowerType()));
                writer.writeCellValue(col++, row, f.getIsPrimary() != null && f.getIsPrimary() == 1 ? "是" : "否");
                writer.writeCellValue(col++, row, f.getStartDate());
                writer.writeCellValue(col++, row, f.getEndDate());
                writer.writeCellValue(col++, row, f.getRemark());
                writer.writeCellValue(col, row, f.getSortOrder());
                row++;
            }
        }
        setSheetWidth(writer.getSheet(), new int[]{18, 25, 10, 18, 14, 14, 14, 14, 25, 8});
        setHeaderStyle(writer, headers.length);
    }

    private void writeNoteSheet(ExcelWriter writer) {
        String[] notes = {
                "客户导入/导出模板说明（多Sheet页）：",
                "",
                "=== 工作表说明 ===",
                "Sheet1【客户基本信息】：客户主数据，带*为必填",
                "Sheet2【客户地址信息】：客户地址（同一客户可多行），通过客户编码关联",
                "Sheet3【客户联系人】：客户联系人（同一客户可多行），通过客户编码关联",
                "Sheet4【客户跟进人】：客户跟进人（同一客户可多行），通过客户编码关联",
                "",
                "=== 填写规则 ===",
                "1. 客户编码作为唯一标识，必须填写且不可重复",
                "2. 子表（地址/联系人/跟进人）通过【客户编码】列与主表关联",
                "3. 客户类型：企业、政府、个人（也可填编码 ENTERPRISE/GOVERNMENT/PERSONAL）",
                "4. 客户分类：A、B、C",
                "5. 客户规模：千亿级、百亿级、亿级、其他",
                "6. 所属行业：ICT、新能源、光伏、汽车产业链、电器制造、装备制造、PCB、动力电池+储能",
                "7. 数据状态：生效/失效",
                "8. 地址类型：收单方、收货方",
                "9. 跟进人类型：技术人员、业务专家、销售人员",
                "10. 性别：男/女",
                "11. 是否默认地址/主要联系人/决策人/主跟进人：填「是」或「否」",
                "12. 跟进人填写系统内用户的用户名或姓名，系统会自动匹配",
                "",
                "提示：从其他Excel拷贝数据时，请使用「选择性粘贴 → 仅粘贴值」。"
        };
        for (int i = 0; i < notes.length; i++) {
            Row nr = writer.getSheet().createRow(i);
            Cell nc = nr.createCell(0);
            nc.setCellValue(notes[i]);
        }
        writer.getSheet().setColumnWidth(0, 90 * 256);
    }

    private void setSheetWidth(Sheet sheet, int[] widths) {
        for (int i = 0; i < widths.length; i++) {
            sheet.setColumnWidth(i, widths[i] * 256);
        }
        CellStyle textStyle = sheet.getWorkbook().createCellStyle();
        DataFormat fmt = sheet.getWorkbook().createDataFormat();
        textStyle.setDataFormat(fmt.getFormat("@"));
        textStyle.setBorderTop(BorderStyle.THIN);
        textStyle.setBorderBottom(BorderStyle.THIN);
        textStyle.setBorderLeft(BorderStyle.THIN);
        textStyle.setBorderRight(BorderStyle.THIN);
        for (int col = 0; col < widths.length; col++) {
            sheet.setDefaultColumnStyle(col, textStyle);
        }
    }

    private void setHeaderStyle(ExcelWriter writer, int colCount) {
        Workbook wb = writer.getWorkbook();
        Sheet sheet = writer.getSheet();
        CellStyle headerStyle = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        headerStyle.setFont(font);
        headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerStyle.setAlignment(HorizontalAlignment.CENTER);
        headerStyle.setBorderTop(BorderStyle.THIN);
        headerStyle.setBorderBottom(BorderStyle.THIN);
        headerStyle.setBorderLeft(BorderStyle.THIN);
        headerStyle.setBorderRight(BorderStyle.THIN);
        Row headerRow = sheet.getRow(0);
        if (headerRow != null) {
            for (int i = 0; i < colCount; i++) {
                Cell cell = headerRow.getCell(i);
                if (cell != null) cell.setCellStyle(headerStyle);
            }
        }
        sheet.createFreezePane(0, 1);
    }

    private String getDictName(String code, String value) {
        if (value == null) return "";
        Map<String, String> typeMap = new HashMap<>();
        typeMap.put("ENTERPRISE", "企业"); typeMap.put("GOVERNMENT", "政府"); typeMap.put("PERSONAL", "个人");
        typeMap.put("HUNDRED_BILLION", "千亿级"); typeMap.put("TEN_BILLION", "百亿级");
        typeMap.put("BILLION", "亿级"); typeMap.put("OTHER", "其他");
        typeMap.put("ICT", "ICT"); typeMap.put("NEW_ENERGY", "新能源"); typeMap.put("PHOTOVOLTAIC", "光伏");
        typeMap.put("AUTOMOTIVE", "汽车产业链"); typeMap.put("ELECTRICAL", "电器制造");
        typeMap.put("EQUIPMENT", "装备制造"); typeMap.put("PCB", "PCB");
        typeMap.put("BATTERY_STORAGE", "动力电池+储能");
        typeMap.put("BILLING", "收单方"); typeMap.put("SHIPPING", "收货方");
        typeMap.put("TECH", "技术人员"); typeMap.put("EXPERT", "业务专家"); typeMap.put("SALES", "销售人员");
        typeMap.put("ACTIVE", "生效"); typeMap.put("INACTIVE", "失效");
        if (typeMap.containsKey(value)) return typeMap.get(value);
        return value;
    }

    @Override
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        ExcelWriter writer = ExcelUtil.getWriter();

        writeTemplateCustomerSheet(writer);
        writer.setSheet("客户地址信息");
        writeTemplateAddressSheet(writer);
        writer.setSheet("客户联系人");
        writeTemplateContactSheet(writer);
        writer.setSheet("客户跟进人");
        writeTemplateFollowerSheet(writer);
        writer.setSheet("填写说明");
        writeNoteSheet(writer);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode("客户导入模板(多Sheet).xlsx", "UTF-8"));
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    private void writeTemplateCustomerSheet(ExcelWriter writer) {
        writer.renameSheet("客户基本信息");
        String[] headers = {"客户编码*", "客户名称*", "客户简称", "客户类型", "客户分类", "客户规模", "所属行业", "统一社会信用代码",
                "公司网址", "联系人", "联系电话", "联系邮箱", "办公地址", "注册地址", "开户银行", "银行账号", "税号", "数据状态", "客户描述"};
        for (int i = 0; i < headers.length; i++) writer.writeCellValue(i, 0, headers[i]);
        String[] demo = {"CA0001", "示例客户有限公司", "示例客户", "企业", "A", "亿级", "ICT", "91110000XXXXXXXXXX",
                "www.example.com", "张三", "138******00", "z*******@***********", "北京市朝阳区XX路XX号", "北京市海淀区XX路XX号",
                "中国工商银行", "1234567890123456789", "91110000XXXXXXXXXX", "生效", "示例数据，请删除后填写实际数据"};
        for (int i = 0; i < demo.length; i++) writer.writeCellValue(i, 1, demo[i]);
        setSheetWidth(writer.getSheet(), new int[]{18, 25, 15, 12, 10, 12, 15, 22, 20, 12, 14, 20, 30, 30, 18, 22, 22, 10, 25});
        setHeaderStyle(writer, headers.length);
        addDropdown(writer.getSheet(), 3, 1, 500, new String[]{"企业", "政府", "个人"});
        addDropdown(writer.getSheet(), 4, 1, 500, new String[]{"A", "B", "C"});
        addDropdown(writer.getSheet(), 5, 1, 500, new String[]{"千亿级", "百亿级", "亿级", "其他"});
        addDropdown(writer.getSheet(), 6, 1, 500, new String[]{"ICT", "新能源", "光伏", "汽车产业链", "电器制造", "装备制造", "PCB", "动力电池+储能"});
        addDropdown(writer.getSheet(), 17, 1, 500, new String[]{"生效", "失效"});
    }

    private void writeTemplateAddressSheet(ExcelWriter writer) {
        String[] headers = {"客户编码*", "客户名称", "数据状态", "地址类型", "国家", "省份", "城市", "区县",
                "街道", "详细地址", "邮编", "经度", "纬度", "收件人", "收件电话", "是否默认地址"};
        for (int i = 0; i < headers.length; i++) writer.writeCellValue(i, 0, headers[i]);
        // 示例数据：同一个客户CA0001有2条地址（收货方+收单方）
        String[][] demos = {
            {"CA0001", "示例客户有限公司", "生效", "收货方", "中国", "广东省", "深圳市", "南山区",
                "粤海街道", "科技园XX路XX号", "518000", "113.95", "22.54", "张三", "138******00", "是"},
            {"CA0001", "示例客户有限公司", "生效", "收单方", "中国", "广东省", "深圳市", "福田区",
                "福田街道", "金融中心XX大厦", "518001", "114.06", "22.52", "李四", "139******00", "否"}
        };
        for (int r = 0; r < demos.length; r++) {
            for (int i = 0; i < demos[r].length; i++) writer.writeCellValue(i, r + 1, demos[r][i]);
        }
        setSheetWidth(writer.getSheet(), new int[]{18, 25, 10, 12, 10, 12, 12, 12, 15, 30, 10, 12, 12, 12, 15, 12});
        setHeaderStyle(writer, headers.length);
        addDropdown(writer.getSheet(), 2, 1, 500, new String[]{"生效", "失效"});
        addDropdown(writer.getSheet(), 3, 1, 500, new String[]{"收单方", "收货方"});
        addDropdown(writer.getSheet(), 15, 1, 500, new String[]{"是", "否"});
    }

    private void writeTemplateContactSheet(ExcelWriter writer) {
        String[] headers = {"客户编码*", "客户名称", "数据状态", "联系人姓名*", "职位", "性别", "部门", "手机号码",
                "联系电话", "邮箱", "QQ", "微信", "是否主要联系人", "是否决策人"};
        for (int i = 0; i < headers.length; i++) writer.writeCellValue(i, 0, headers[i]);
        // 示例数据：同一个客户CA0001有2个联系人
        String[][] demos = {
            {"CA0001", "示例客户有限公司", "生效", "张三", "采购经理", "男", "采购部", "138******00",
                "0755-12345678", "z*******@***********", "123456789", "zhangsan_wx", "是", "是"},
            {"CA0001", "示例客户有限公司", "生效", "王五", "技术总监", "男", "技术部", "137******00",
                "0755-87654321", "w*****@***********", "987654321", "wangwu_wx", "否", "否"}
        };
        for (int r = 0; r < demos.length; r++) {
            for (int i = 0; i < demos[r].length; i++) writer.writeCellValue(i, r + 1, demos[r][i]);
        }
        setSheetWidth(writer.getSheet(), new int[]{18, 25, 10, 14, 14, 8, 14, 14, 14, 22, 14, 14, 14, 12});
        setHeaderStyle(writer, headers.length);
        addDropdown(writer.getSheet(), 2, 1, 500, new String[]{"生效", "失效"});
        addDropdown(writer.getSheet(), 5, 1, 500, new String[]{"男", "女"});
        addDropdown(writer.getSheet(), 12, 1, 500, new String[]{"是", "否"});
        addDropdown(writer.getSheet(), 13, 1, 500, new String[]{"是", "否"});
    }

    private void writeTemplateFollowerSheet(ExcelWriter writer) {
        String[] headers = {"客户编码*", "客户名称", "数据状态", "跟进人用户名/姓名*", "跟进人类型*", "是否主跟进人",
                "开始跟进日期", "结束跟进日期", "描述", "排序"};
        for (int i = 0; i < headers.length; i++) writer.writeCellValue(i, 0, headers[i]);
        // 示例数据：同一个客户CA0001有2个跟进人（销售人员+技术人员）
        String[][] demos = {
            {"CA0001", "示例客户有限公司", "生效", "admin", "销售人员", "是", "2024-01-01", "", "主要负责销售对接", "1"},
            {"CA0001", "示例客户有限公司", "生效", "admin", "技术人员", "否", "2024-01-01", "", "技术支持对接", "2"}
        };
        for (int r = 0; r < demos.length; r++) {
            for (int i = 0; i < demos[r].length; i++) writer.writeCellValue(i, r + 1, demos[r][i]);
        }
        setSheetWidth(writer.getSheet(), new int[]{18, 25, 10, 18, 14, 14, 14, 14, 25, 8});
        setHeaderStyle(writer, headers.length);
        addDropdown(writer.getSheet(), 2, 1, 500, new String[]{"生效", "失效"});
        addDropdown(writer.getSheet(), 4, 1, 500, new String[]{"技术人员", "业务专家", "销售人员"});
        addDropdown(writer.getSheet(), 5, 1, 500, new String[]{"是", "否"});
    }

    private void addDropdown(Sheet sheet, int col, int startRow, int endRow, String[] values) {
        DataValidationHelper helper = sheet.getDataValidationHelper();
        CellRangeAddressList regions = new CellRangeAddressList(startRow, endRow, col, col);
        DataValidationConstraint constraint = helper.createExplicitListConstraint(values);
        DataValidation validation = helper.createValidation(constraint, regions);
        validation.setShowErrorBox(true);
        validation.setErrorStyle(DataValidation.ErrorStyle.STOP);
        validation.createErrorBox("输入错误", "请从下拉列表中选择有效值");
        sheet.addValidationData(validation);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Object> importExcel(MultipartFile file) {
        validateFile(file);
        int inserted = 0, updated = 0, failed = 0;
        int addrInserted = 0, addrFailed = 0;
        int contactInserted = 0, contactFailed = 0;
        int followerInserted = 0, followerFailed = 0;
        List<String> errorMsgs = new ArrayList<>();

        Map<String, String> typeMap = new HashMap<>();
        typeMap.put("企业", "ENTERPRISE"); typeMap.put("政府", "GOVERNMENT"); typeMap.put("个人", "PERSONAL");
        Map<String, String> scaleMap = new HashMap<>();
        scaleMap.put("千亿级", "HUNDRED_BILLION"); scaleMap.put("百亿级", "TEN_BILLION");
        scaleMap.put("亿级", "BILLION"); scaleMap.put("其他", "OTHER");
        Map<String, String> industryMap = new HashMap<>();
        industryMap.put("ICT", "ICT"); industryMap.put("新能源", "NEW_ENERGY"); industryMap.put("光伏", "PHOTOVOLTAIC");
        industryMap.put("汽车产业链", "AUTOMOTIVE"); industryMap.put("电器制造", "ELECTRICAL");
        industryMap.put("装备制造", "EQUIPMENT"); industryMap.put("PCB", "PCB");
        industryMap.put("动力电池+储能", "BATTERY_STORAGE");
        Map<String, String> addrTypeMap = new HashMap<>();
        addrTypeMap.put("收单方", "BILLING"); addrTypeMap.put("收货方", "SHIPPING");
        Map<String, String> followerTypeMap = new HashMap<>();
        followerTypeMap.put("技术人员", "TECH"); followerTypeMap.put("业务专家", "EXPERT"); followerTypeMap.put("销售人员", "SALES");

        Map<String, PmtCustomer> customerCodeMap = new HashMap<>();

        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
             InputStream fis = file.getInputStream()) {
            IoUtil.copy(fis, baos);
            try (Workbook wb = WorkbookFactory.create(new ByteArrayInputStream(baos.toByteArray()))) {

            Sheet customerSheet = getSheetByName(wb, new String[]{"客户基本信息", "客户"});
            if (customerSheet == null) {
                throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "未找到【客户基本信息】Sheet页");
            }
            Sheet addressSheet = getSheetByName(wb, new String[]{"客户地址信息", "客户地址"});
            Sheet contactSheet = getSheetByName(wb, new String[]{"客户联系人", "联系人"});
            Sheet followerSheet = getSheetByName(wb, new String[]{"客户跟进人", "跟进人"});

            Map<String, Integer> customerHeaders = readHeaderMap(customerSheet.getRow(0));
            int customerRowNum = customerSheet.getLastRowNum();
            List<Map<String, Object>> allCustomerRows = new ArrayList<>();
            for (int i = 1; i <= customerRowNum; i++) {
                Row row = customerSheet.getRow(i);
                if (row == null) continue;
                Map<String, Object> rowMap = readRowToMap(row, customerHeaders);
                if (isEmptyRow(rowMap)) continue;
                allCustomerRows.add(rowMap);
            }

            Map<String, Long> codeToIdMap = new HashMap<>();
            int r = 1;
            for (Map<String, Object> row : allCustomerRows) {
                r++;
                try {
                    String customerCode = objToStr(row.get("客户编号"));
                    String customerName = objToStr(row.get("客户名称"));
                    List<String> rowErrors = new ArrayList<>();
                    if (customerName == null) rowErrors.add("客户名称不能为空");
                    if (!rowErrors.isEmpty()) { failed++; errorMsgs.add("第" + r + "行: " + String.join(",", rowErrors)); continue; }

                    if (customerCode == null) customerCode = "C" + System.currentTimeMillis() + r;

                    PmtCustomer existing = baseMapper.findByCode(customerCode.trim());
                    if (existing == null && customerName != null) existing = baseMapper.findByName(customerName.trim());

                    PmtCustomer customer = existing != null ? existing : new PmtCustomer();
                    customer.setCustomerCode(customerCode.trim());
                    customer.setCustomerName(customerName.trim());
                    customer.setStandardName(objToStr(row.get("客户标准全称")));
                    customer.setCustomerAddress(objToStr(row.get("客户地址")));
                    customer.setCustomerType(objToStr(row.get("客户类型")));
                    customer.setCustomerLevel(objToStr(row.get("客户级别")));
                    customer.setCustomerSource(objToStr(row.get("客户来源")));
                    customer.setCustomerIndustry(objToStr(row.get("客户行业")));
                    customer.setIndustry(objToStr(row.get("行业")));
                    customer.setIndustryL1(objToStr(row.get("行业L1")));
                    customer.setIndustryL2(objToStr(row.get("行业L2")));
                    customer.setIndustryL3(objToStr(row.get("行业L3")));
                    customer.setCustomerScale(objToStr(row.get("客户规模")));
                    customer.setCustomerNature(objToStr(row.get("客户性质")));
                    customer.setCustomerStatus(objToStr(row.get("客户状态")));
                    customer.setCallStatus(objToStr(row.get("通话状态")));
                    customer.setRegion(objToStr(row.get("区域")));
                    customer.setProvince(objToStr(row.get("省份")));
                    customer.setCity(objToStr(row.get("城市")));
                    customer.setListingStatus(objToStr(row.get("上市状态")));
                    customer.setRevenueYear(objToStr(row.get("营收年份")));
                    customer.setProfit(objToStr(row.get("盈利")));
                    customer.setRevenueScale(objToStr(row.get("营收规模")));
                    customer.setMarketValue(objToStr(row.get("市值")));
                    customer.setEmployeeCount(objToStr(row.get("员工数")));
                    customer.setCooperationStatus(objToStr(row.get("合作状态")));
                    customer.setMainProduct(objToStr(row.get("主要产品")));
                    customer.setDevelopmentStage(objToStr(row.get("当前开发阶段")));
                    String ts = objToStr(row.get("累计销售额"));
                    if (ts != null) { try { customer.setTotalSales(new BigDecimal(ts)); } catch (Exception ignored) {} }
                    customer.setHighestCustomerRelation(objToStr(row.get("最高客户关系")));
                    customer.setOngoingOpportunity(objToStr(row.get("进行中商机")));
                    customer.setMatchStatus(objToStr(row.get("匹配情况")));
                    customer.setWebsite(objToStr(row.get("官网")));
                    customer.setDataSource(objToStr(row.get("数据来源")));
                    customer.setCompanyProduct(objToStr(row.get("公司产品")));
                    customer.setCompanyTel(objToStr(row.get("公司总机")));
                    customer.setSalesman(objToStr(row.get("销售员")));
                    customer.setOriginalSalesman(objToStr(row.get("原销售人员")));
                    customer.setIndustryManager(objToStr(row.get("行业负责人")));
                    customer.setCsoTrainingClass(objToStr(row.get("CSO培训班")));
                    customer.setMainContact(objToStr(row.get("主要联系人")));
                    customer.setSecondContact(objToStr(row.get("第二联系人")));
                    customer.setManagerName(objToStr(row.get("客户负责人")));
                    customer.setFollowerName(objToStr(row.get("跟进人")));
                    customer.setContactName(objToStr(row.get("联系人姓名")));
                    customer.setContactMobile(objToStr(row.get("联系人手机")));
                    customer.setContactTel(objToStr(row.get("联系人座机")));
                    customer.setContactEmail(objToStr(row.get("联系人邮箱")));
                    customer.setContactWechat(objToStr(row.get("联系人微信")));
                    customer.setRemark(objToStr(row.get("客户备注")));

                    if (existing != null) {
                        if (customer.getCustomerStatus() == null) customer.setCustomerStatus("ACTIVE");
                        setUpdateFields(customer);
                        baseMapper.updateCustomer(customer);
                        codeToIdMap.put(customerCode.trim(), existing.getId());
                        customerCodeMap.put(customerCode.trim(), existing);
                        updated++;
                    } else {
                        if (customer.getCustomerStatus() == null) customer.setCustomerStatus("ACTIVE");
                        if (customer.getDealFlag() == null) customer.setDealFlag(0);
                        if (customer.getInPublicSea() == null) customer.setInPublicSea(0);
                        setCreateFields(customer);
                        baseMapper.insertCustomer(customer);
                        codeToIdMap.put(customerCode.trim(), customer.getId());
                        customerCodeMap.put(customerCode.trim(), customer);
                        inserted++;
                    }
                } catch (Exception e) {
                    log.error("导入客户第{}行失败", r, e);
                    failed++;
                    errorMsgs.add("【客户基本信息】第" + r + "行: " + e.getMessage());
                }
            }

            Map<String, String> userNameToIdMap = new HashMap<>();
            List<User> allUsers = userMapper.selectList(null);
            for (User u : allUsers) {
                if (u.getUsername() != null) userNameToIdMap.put(u.getUsername(), u.getRealName() != null ? u.getRealName() : u.getUsername());
                if (u.getRealName() != null) userNameToIdMap.putIfAbsent(u.getRealName(), u.getUsername());
            }
            Map<Long, Long> userIdMap = allUsers.stream().collect(Collectors.toMap(User::getId, User::getId, (a, b) -> a));
            Map<String, Long> usernameToIdMap = allUsers.stream().collect(Collectors.toMap(
                    u -> u.getUsername() != null ? u.getUsername() : "",
                    User::getId, (a, b) -> a));
            Map<String, Long> realNameToIdMap = allUsers.stream()
                    .filter(u -> u.getRealName() != null && !u.getRealName().isEmpty())
                    .collect(Collectors.toMap(User::getRealName, User::getId, (a, b) -> a));

            // 加载省市区数据，构建名称->ID的映射（用于导入时自动填充ID）
            List<Region> allRegions = regionMapper.selectList(null);
            Map<String, Long> countryIdMap = new HashMap<>();
            // key: "省名", value: id
            Map<String, Long> provinceIdMap = new HashMap<>();
            // key: "省id|市名", value: id  (处理同名城市)
            Map<String, Long> cityIdMap = new HashMap<>();
            // key: "市id|区县名", value: id  (处理同名区县)
            Map<String, Long> districtIdMap = new HashMap<>();
            for (Region reg : allRegions) {
                if (reg.getDeleted() != null && reg.getDeleted() != 0L) continue;
                if (reg.getLevel() == 1) {
                    countryIdMap.put(reg.getRegionName(), reg.getId());
                } else if (reg.getLevel() == 2) {
                    provinceIdMap.put(reg.getRegionName(), reg.getId());
                } else if (reg.getLevel() == 3) {
                    cityIdMap.put(reg.getParentId() + "|" + reg.getRegionName(), reg.getId());
                    // 也存一个简单的名称key，用于没有parentId时的fallback
                    cityIdMap.putIfAbsent(reg.getRegionName(), reg.getId());
                } else if (reg.getLevel() == 4) {
                    districtIdMap.put(reg.getParentId() + "|" + reg.getRegionName(), reg.getId());
                    districtIdMap.putIfAbsent(reg.getRegionName(), reg.getId());
                }
            }

            if (addressSheet != null) {
                Map<String, Integer> headers = readHeaderMap(addressSheet.getRow(0));
                int lastRow = addressSheet.getLastRowNum();
                // 先收集本Sheet实际出现的客户编码集合，只删除这些客户的旧地址数据
                Set<String> addrCustomerCodes = new HashSet<>();
                for (int i = 1; i <= lastRow; i++) {
                    Row row = addressSheet.getRow(i);
                    if (row == null) continue;
                    Map<String, Object> rowMap = readRowToMap(row, headers);
                    if (isEmptyRow(rowMap)) continue;
                    String code = objToStr(rowMap.get("客户编码*"));
                    if (code != null) addrCustomerCodes.add(code.trim());
                }
                List<Long> addrCustIds = addrCustomerCodes.stream()
                        .map(c -> codeToIdMap.get(c)).filter(Objects::nonNull).collect(Collectors.toList());
                if (!addrCustIds.isEmpty()) {
                    addressMapper.deleteByCustomerIds(addrCustIds);
                }

                int ar = 1;
                for (int i = 1; i <= lastRow; i++) {
                    Row row = addressSheet.getRow(i);
                    if (row == null) continue;
                    Map<String, Object> rowMap = readRowToMap(row, headers);
                    if (isEmptyRow(rowMap)) continue;
                    ar++;
                    try {
                        String code = objToStr(rowMap.get("客户编码*"));
                        String detailAddr = objToStr(rowMap.get("详细地址"));
                        if (code == null) { addrFailed++; errorMsgs.add("【客户地址】第" + ar + "行: 客户编码不能为空"); continue; }
                        Long custId = codeToIdMap.get(code.trim());
                        if (custId == null) { addrFailed++; errorMsgs.add("【客户地址】第" + ar + "行: 客户编码[" + code + "]在客户基本信息中不存在"); continue; }
                        String addrTypeStr = objToStr(rowMap.get("地址类型"));
                        String addrType = addrTypeMap.getOrDefault(addrTypeStr, addrTypeStr);
                        String statusStr = objToStr(rowMap.get("数据状态"));
                        String status = "失效".equals(statusStr) ? "INACTIVE" : "ACTIVE";
                        String isDefaultStr = objToStr(rowMap.get("是否默认地址"));
                        Integer isDefault = "是".equals(isDefaultStr) ? 1 : 0;
                        PmtCustomerAddress addr = new PmtCustomerAddress();
                        addr.setCustomerId(custId);
                        addr.setAddressType(addrType);
                        String countryName = objToStr(rowMap.get("国家"));
                        String provinceName = objToStr(rowMap.get("省份"));
                        String cityName = objToStr(rowMap.get("城市"));
                        String districtName = objToStr(rowMap.get("区县"));
                        addr.setCountryName(countryName);
                        addr.setProvinceName(provinceName);
                        addr.setCityName(cityName);
                        addr.setDistrictName(districtName);
                        // 根据名称查找并设置省市区ID
                        List<String> addrErrors = new ArrayList<>();
                        if (countryName != null && !countryName.trim().isEmpty()) {
                            Long countryId = countryIdMap.get(countryName.trim());
                            if (countryId != null) addr.setCountryId(countryId);
                        } else {
                            addr.setCountryName("中国");
                            addr.setCountryId(countryIdMap.get("中国"));
                        }
                        Long provinceId = null;
                        if (provinceName != null && !provinceName.trim().isEmpty()) {
                            provinceId = provinceIdMap.get(provinceName.trim());
                            if (provinceId == null) addrErrors.add("省份[" + provinceName + "]不存在");
                            else addr.setProvinceId(provinceId);
                        }
                        Long cityId = null;
                        if (cityName != null && !cityName.trim().isEmpty()) {
                            if (provinceId != null) {
                                cityId = cityIdMap.get(provinceId + "|" + cityName.trim());
                            }
                            if (cityId == null) cityId = cityIdMap.get(cityName.trim());
                            if (cityId == null) addrErrors.add("城市[" + cityName + "]不存在");
                            else addr.setCityId(cityId);
                        }
                        if (districtName != null && !districtName.trim().isEmpty()) {
                            Long districtId = null;
                            if (cityId != null) {
                                districtId = districtIdMap.get(cityId + "|" + districtName.trim());
                            }
                            if (districtId == null) districtId = districtIdMap.get(districtName.trim());
                            if (districtId == null) addrErrors.add("区县[" + districtName + "]不存在");
                            else addr.setDistrictId(districtId);
                        }
                        if (!addrErrors.isEmpty()) {
                            addrFailed++;
                            errorMsgs.add("【客户地址】第" + ar + "行: " + String.join("；", addrErrors));
                            continue;
                        }
                        addr.setStreet(objToStr(rowMap.get("街道")));
                        addr.setDetailAddress(detailAddr);
                        addr.setPostalCode(objToStr(rowMap.get("邮编")));
                        String lng = objToStr(rowMap.get("经度"));
                        addr.setLongitude(lng != null && !lng.trim().isEmpty() ? BigDecimal.valueOf(Double.parseDouble(lng.trim())) : null);
                        String lat = objToStr(rowMap.get("纬度"));
                        addr.setLatitude(lat != null && !lat.trim().isEmpty() ? BigDecimal.valueOf(Double.parseDouble(lat.trim())) : null);
                        addr.setContactPerson(objToStr(rowMap.get("收件人")));
                        addr.setContactPhone(objToStr(rowMap.get("收件电话")));
                        addr.setIsDefault(isDefault);
                        addr.setStatus(status);
                        setCreateFields(addr);
                        addressMapper.insertAddress(addr);
                        addrInserted++;
                    } catch (Exception e) { addrFailed++; errorMsgs.add("【客户地址】第" + ar + "行: " + e.getMessage()); }
                }
            }

            if (contactSheet != null) {
                Map<String, Integer> headers = readHeaderMap(contactSheet.getRow(0));
                int lastRow = contactSheet.getLastRowNum();
                // 先收集本Sheet实际出现的客户编码集合，只删除这些客户的旧联系人数据
                Set<String> contactCustomerCodes = new HashSet<>();
                for (int i = 1; i <= lastRow; i++) {
                    Row row = contactSheet.getRow(i);
                    if (row == null) continue;
                    Map<String, Object> rowMap = readRowToMap(row, headers);
                    if (isEmptyRow(rowMap)) continue;
                    String code = objToStr(rowMap.get("客户编码*"));
                    if (code != null) contactCustomerCodes.add(code.trim());
                }
                List<Long> contactCustIds = contactCustomerCodes.stream()
                        .map(c -> codeToIdMap.get(c)).filter(Objects::nonNull).collect(Collectors.toList());
                if (!contactCustIds.isEmpty()) {
                    contactMapper.deleteByCustomerIds(contactCustIds);
                }

                int cr = 1;
                for (int i = 1; i <= lastRow; i++) {
                    Row row = contactSheet.getRow(i);
                    if (row == null) continue;
                    Map<String, Object> rowMap = readRowToMap(row, headers);
                    if (isEmptyRow(rowMap)) continue;
                    cr++;
                    try {
                        String code = objToStr(rowMap.get("客户编码*"));
                        String contactName = objToStr(rowMap.get("联系人姓名*"));
                        if (code == null) { contactFailed++; errorMsgs.add("【客户联系人】第" + cr + "行: 客户编码不能为空"); continue; }
                        Long custId = codeToIdMap.get(code.trim());
                        if (custId == null) { contactFailed++; errorMsgs.add("【客户联系人】第" + cr + "行: 客户编码[" + code + "]在客户基本信息中不存在"); continue; }
                        if (contactName == null) { contactFailed++; errorMsgs.add("【客户联系人】第" + cr + "行: 联系人姓名不能为空"); continue; }
                        String statusStr = objToStr(rowMap.get("数据状态"));
                        String status = "失效".equals(statusStr) ? "INACTIVE" : "ACTIVE";
                        String gender = "男".equals(objToStr(rowMap.get("性别"))) ? "MALE" : "女".equals(objToStr(rowMap.get("性别"))) ? "FEMALE" : null;
                        String isPrimaryStr = objToStr(rowMap.get("是否主要联系人"));
                        Integer isPrimary = "是".equals(isPrimaryStr) ? 1 : 0;
                        String isDecisionStr = objToStr(rowMap.get("是否决策人"));
                        Integer isDecision = "是".equals(isDecisionStr) ? 1 : 0;
                        PmtCustomerContact ct = new PmtCustomerContact();
                        ct.setCustomerId(custId);
                        ct.setContactName(contactName);
                        ct.setContactTitle(objToStr(rowMap.get("职位")));
                        ct.setContactGender(gender);
                        ct.setDepartment(objToStr(rowMap.get("部门")));
                        ct.setContactMobile(objToStr(rowMap.get("手机号码")));
                        ct.setContactPhone(objToStr(rowMap.get("联系电话")));
                        ct.setContactEmail(objToStr(rowMap.get("邮箱")));
                        ct.setContactQq(objToStr(rowMap.get("QQ")));
                        ct.setContactWechat(objToStr(rowMap.get("微信")));
                        ct.setIsPrimary(isPrimary);
                        ct.setIsDecisionMaker(isDecision);
                        ct.setStatus(status);
                        setCreateFields(ct);
                        contactMapper.insertContact(ct);
                        contactInserted++;
                    } catch (Exception e) { contactFailed++; errorMsgs.add("【客户联系人】第" + cr + "行: " + e.getMessage()); }
                }
            }

            if (followerSheet != null) {
                Map<String, Integer> headers = readHeaderMap(followerSheet.getRow(0));
                int lastRow = followerSheet.getLastRowNum();
                // 先收集本Sheet实际出现的客户编码集合，只删除这些客户的旧跟进人数据
                Set<String> followerCustomerCodes = new HashSet<>();
                for (int i = 1; i <= lastRow; i++) {
                    Row row = followerSheet.getRow(i);
                    if (row == null) continue;
                    Map<String, Object> rowMap = readRowToMap(row, headers);
                    if (isEmptyRow(rowMap)) continue;
                    String code = objToStr(rowMap.get("客户编码*"));
                    if (code != null) followerCustomerCodes.add(code.trim());
                }
                List<Long> followerCustIds = followerCustomerCodes.stream()
                        .map(c -> codeToIdMap.get(c)).filter(Objects::nonNull).collect(Collectors.toList());
                if (!followerCustIds.isEmpty()) {
                    followerMapper.deleteByCustomerIds(followerCustIds);
                }

                int fr = 1;
                for (int i = 1; i <= lastRow; i++) {
                    Row row = followerSheet.getRow(i);
                    if (row == null) continue;
                    Map<String, Object> rowMap = readRowToMap(row, headers);
                    if (isEmptyRow(rowMap)) continue;
                    fr++;
                    try {
                        String code = objToStr(rowMap.get("客户编码*"));
                        String userKey = objToStr(rowMap.get("跟进人用户名/姓名*"));
                        String followerTypeStr = objToStr(rowMap.get("跟进人类型*"));
                        if (code == null) { followerFailed++; errorMsgs.add("【客户跟进人】第" + fr + "行: 客户编码不能为空"); continue; }
                        Long custId = codeToIdMap.get(code.trim());
                        if (custId == null) { followerFailed++; errorMsgs.add("【客户跟进人】第" + fr + "行: 客户编码[" + code + "]在客户基本信息中不存在"); continue; }
                        if (userKey == null) { followerFailed++; errorMsgs.add("【客户跟进人】第" + fr + "行: 跟进人不能为空"); continue; }
                        String followerType = followerTypeMap.getOrDefault(followerTypeStr, followerTypeStr);
                        Long userId = usernameToIdMap.get(userKey.trim());
                        if (userId == null) userId = realNameToIdMap.get(userKey.trim());
                        if (userId == null) { followerFailed++; errorMsgs.add("【客户跟进人】第" + fr + "行: 跟进人[" + userKey + "]在系统中不存在"); continue; }
                        String statusStr = objToStr(rowMap.get("数据状态"));
                        String status = "失效".equals(statusStr) ? "INACTIVE" : "ACTIVE";
                        String isPrimaryStr = objToStr(rowMap.get("是否主跟进人"));
                        Integer isPrimary = "是".equals(isPrimaryStr) ? 1 : 0;
                        String sortStr = objToStr(rowMap.get("排序"));
                        Integer sortOrder = sortStr != null ? Integer.parseInt(sortStr) : 0;
                        PmtCustomerFollower fl = new PmtCustomerFollower();
                        fl.setCustomerId(custId);
                        fl.setUserId(userId);
                        User u = userMapper.selectById(userId);
                        fl.setUserName(u != null ? (u.getRealName() != null ? u.getRealName() : u.getUsername()) : userKey);
                        fl.setFollowerType(followerType);
                        fl.setIsPrimary(isPrimary);
                        String startDateStr = objToStr(rowMap.get("开始跟进日期"));
                        String endDateStr = objToStr(rowMap.get("结束跟进日期"));
                        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                        fl.setStartDate(startDateStr != null && !startDateStr.trim().isEmpty() ? LocalDate.parse(startDateStr.trim(), dateFormatter) : null);
                        fl.setEndDate(endDateStr != null && !endDateStr.trim().isEmpty() ? LocalDate.parse(endDateStr.trim(), dateFormatter) : null);
                        fl.setRemark(objToStr(rowMap.get("描述")));
                        fl.setSortOrder(sortOrder);
                        fl.setStatus(status);
                        setCreateFields(fl);
                        followerMapper.insertFollower(fl);
                        followerInserted++;
                    } catch (Exception e) { followerFailed++; errorMsgs.add("【客户跟进人】第" + fr + "行: " + e.getMessage()); }
                }
            }

            }
        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            log.error("导入Excel失败", e);
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "Excel 解析失败: " + e.getMessage());
        }

        Map<String, Object> result = new HashMap<>();
        result.put("inserted", inserted);
        result.put("updated", updated);
        result.put("failed", failed);
        result.put("addressInserted", addrInserted);
        result.put("addressFailed", addrFailed);
        result.put("contactInserted", contactInserted);
        result.put("contactFailed", contactFailed);
        result.put("followerInserted", followerInserted);
        result.put("followerFailed", followerFailed);
        result.put("errors", errorMsgs);
        result.put("message", String.format("客户：新增%d、更新%d、失败%d；地址：新增%d、失败%d；联系人：新增%d、失败%d；跟进人：新增%d、失败%d",
                inserted, updated, failed, addrInserted, addrFailed, contactInserted, contactFailed, followerInserted, followerFailed));
        return result;
    }

    private Sheet getSheetByName(Workbook wb, String[] names) {
        for (String name : names) {
            Sheet s = wb.getSheet(name);
            if (s != null) return s;
        }
        return null;
    }

    private Map<String, Integer> readHeaderMap(Row headerRow) {
        Map<String, Integer> map = new HashMap<>();
        if (headerRow == null) return map;
        for (int i = 0; i < headerRow.getLastCellNum(); i++) {
            Cell cell = headerRow.getCell(i);
            if (cell != null) {
                String val = cell.toString().trim();
                if (!val.isEmpty()) map.put(val, i);
            }
        }
        return map;
    }

    private Map<String, Object> readRowToMap(Row row, Map<String, Integer> headers) {
        Map<String, Object> map = new HashMap<>();
        if (row == null) return map;
        for (Map.Entry<String, Integer> e : headers.entrySet()) {
            Cell cell = row.getCell(e.getValue());
            if (cell != null) {
                Object val;
                CellType ct = cell.getCellType();
                if (ct == CellType.NUMERIC) {
                    double d = cell.getNumericCellValue();
                    if (d == Math.floor(d)) val = String.valueOf((long) d);
                    else val = String.valueOf(d);
                } else {
                    val = cell.toString().trim();
                }
                map.put(e.getKey(), val);
            }
        }
        return map;
    }

    private boolean isEmptyRow(Map<String, Object> map) {
        for (Object v : map.values()) {
            if (v != null && !v.toString().trim().isEmpty()) return false;
        }
        return true;
    }

    private void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请选择要上传的文件");
        }
        String filename = file.getOriginalFilename();
        if (filename == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "文件名不能为空");
        }
        String lowerName = filename.toLowerCase();
        boolean validExt = false;
        for (String ext : ALLOWED_EXTENSIONS) {
            if (lowerName.endsWith(ext)) { validExt = true; break; }
        }
        if (!validExt) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "仅支持 .xlsx 或 .xls 格式");
        }
        String contentType = file.getContentType();
        if (contentType != null && !ALLOWED_MIME_TYPES.contains(contentType.toLowerCase())) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "文件类型不合法，请上传有效的Excel文件");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "文件大小不能超过 10MB");
        }
    }

    private String objToStr(Object obj) {
        if (obj == null) return null;
        String s = obj.toString().trim();
        return s.isEmpty() ? null : s;
    }

    @Override
    public List<PmtCustomerAddress> getAddresses(Long customerId) {
        return addressMapper.selectByCustomerId(customerId);
    }

    @Override
    public List<PmtCustomerContact> getContacts(Long customerId) {
        return contactMapper.selectByCustomerId(customerId);
    }

    @Override
    public List<PmtCustomerFollower> getFollowers(Long customerId) {
        return followerMapper.selectByCustomerId(customerId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void saveAddresses(Long customerId, List<Map<String, Object>> list) {
        addressMapper.deleteByCustomerId(customerId);
        if (list != null && !list.isEmpty()) {
            List<PmtCustomerAddress> entities = list.stream()
                    .map(m -> {
                        PmtCustomerAddress addr = BeanUtil.toBean(m, PmtCustomerAddress.class);
                        addr.setId(null);
                        addr.setCustomerId(customerId);
                        return addr;
                    })
                    .collect(Collectors.toList());
            for (PmtCustomerAddress entity : entities) {
                setCreateFields(entity);
                addressMapper.insertAddress(entity);
            }
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void saveContacts(Long customerId, List<Map<String, Object>> list) {
        contactMapper.deleteByCustomerId(customerId);
        if (list != null && !list.isEmpty()) {
            List<PmtCustomerContact> entities = list.stream()
                    .map(m -> {
                        PmtCustomerContact contact = BeanUtil.toBean(m, PmtCustomerContact.class);
                        contact.setId(null);
                        contact.setCustomerId(customerId);
                        return contact;
                    })
                    .collect(Collectors.toList());
            for (PmtCustomerContact entity : entities) {
                setCreateFields(entity);
                contactMapper.insertContact(entity);
            }
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void saveFollowers(Long customerId, List<Map<String, Object>> list) {
        followerMapper.deleteByCustomerId(customerId);
        if (list != null && !list.isEmpty()) {
            List<PmtCustomerFollower> entities = list.stream()
                    .map(m -> {
                        PmtCustomerFollower follower = BeanUtil.toBean(m, PmtCustomerFollower.class);
                        follower.setId(null);
                        follower.setCustomerId(customerId);
                        return follower;
                    })
                    .collect(Collectors.toList());
            for (PmtCustomerFollower entity : entities) {
                setCreateFields(entity);
                followerMapper.insertFollower(entity);
            }
        }
    }
}
