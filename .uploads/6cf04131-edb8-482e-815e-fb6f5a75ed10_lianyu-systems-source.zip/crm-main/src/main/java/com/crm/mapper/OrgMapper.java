package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.Org;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface OrgMapper extends BaseMapper<Org> {

    int countOrgColumn(@Param("columnName") String columnName);

    int updateManagerName(@Param("id") Long id, @Param("manager") String manager);

    List<Map<String, Object>> selectAllManagerNames();

    @Select("SELECT * FROM crm_org WHERE org_name = #{name} AND deleted = 0 LIMIT 1")
    Org findByName(@Param("name") String name);

    @Select("SELECT * FROM crm_org WHERE deleted = 0 AND status = 1 ORDER BY sort_order ASC")
    List<Org> selectAllActive();

    @Select("SELECT * FROM crm_org WHERE deleted = 0 ORDER BY sort_order ASC")
    List<Org> listAllActive();
}
