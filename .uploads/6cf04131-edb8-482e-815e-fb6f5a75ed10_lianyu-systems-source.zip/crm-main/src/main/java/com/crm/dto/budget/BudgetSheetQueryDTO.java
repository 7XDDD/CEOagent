package com.crm.dto.budget;

import com.crm.dto.PageQueryDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class BudgetSheetQueryDTO extends PageQueryDTO {

    private Integer fiscalYear;

    private Long versionId;

    private String catalogCode;

    private Long contractId;

    private Long customerId;

    private Long orgId;

    private Long productLineId;
}
