package com.crm.service.impl;

import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.common.BusinessException;
import com.crm.common.ResultCode;
import com.crm.common.SecurityContextUtil;
import com.crm.dataperm.DataPermBits;
import com.crm.dataperm.DataPermModule;
import com.crm.dto.PageResult;
import com.crm.dto.opportunity.OpportunityCreateDTO;
import com.crm.dto.opportunity.OpportunityQueryDTO;
import com.crm.dto.opportunity.OpportunityUpdateDTO;
import com.crm.entity.Opportunity;
import com.crm.entity.Contract;
import com.crm.entity.ContractOpportunity;
import com.crm.entity.User;
import com.crm.mapper.OpportunityMapper;
import com.crm.mapper.UserMapper;
import com.crm.mapper.contract.ContractMapper;
import com.crm.mapper.contract.ContractOpportunityMapper;
import com.crm.service.DataPermissionService;
import com.crm.service.OpportunityService;
import com.crm.service.contract.ContractService;
import com.crm.vo.opportunity.OpportunityVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@Slf4j
public class OpportunityServiceImpl implements OpportunityService {

    @Autowired
    private OpportunityMapper opportunityMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private ContractMapper contractMapper;

    @Autowired
    private ContractOpportunityMapper contractOpportunityMapper;

    @Autowired
    private DataPermissionService dataPermissionService;

    @Autowired
    private ContractService contractService;

    private static final Map<String, Integer> STAGE_RATE_MAP = new LinkedHashMap<>();
    static {
        STAGE_RATE_MAP.put("STAGE_01", 5);
        STAGE_RATE_MAP.put("STAGE_02", 10);
        STAGE_RATE_MAP.put("STAGE_03", 25);
        STAGE_RATE_MAP.put("STAGE_04", 50);
        STAGE_RATE_MAP.put("STAGE_05", 75);
        STAGE_RATE_MAP.put("STAGE_06", 90);
        STAGE_RATE_MAP.put("STAGE_07", 100);
    }

    @Override
    public PageResult<OpportunityVO> page(OpportunityQueryDTO query) {
        if (query == null) query = new OpportunityQueryDTO();
        int pageNum = query.getPageNum() != null ? query.getPageNum() : 1;
        int pageSize = query.getPageSize() != null ? query.getPageSize() : 10;

        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;

        // 行级数据权限：非管理员只能查看自己负责或创建的商机
        boolean isAdmin = SecurityContextUtil.hasRole("super_admin") || SecurityContextUtil.hasRole("ADMIN");
        if (!isAdmin) {
            query.setCurrentUserId(SecurityContextUtil.getCurrentUserId());
        }

        Page<OpportunityVO> page = new Page<>(pageNum, pageSize);
        IPage<OpportunityVO> result = opportunityMapper.selectPageList(page, companyId, query);
        List<OpportunityVO> records = result.getRecords();
        if (records != null && !records.isEmpty()) {
            Map<Long, Integer> bits = dataPermissionService.permBitsMap(
                    com.crm.dataperm.DataPermModule.OPPORTUNITY,
                    records.stream().map(OpportunityVO::getId).collect(Collectors.toList()));
            records.forEach(vo -> vo.setPermBits(bits.getOrDefault(vo.getId(), 0)));
        }
        return new PageResult<>(records, result.getTotal(), pageNum, pageSize);
    }

    @Override
    public List<OpportunityVO> list(OpportunityQueryDTO query) {
        if (query == null) query = new OpportunityQueryDTO();
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;
        boolean isAdmin = SecurityContextUtil.hasRole("super_admin") || SecurityContextUtil.hasRole("ADMIN");
        if (!isAdmin) {
            query.setCurrentUserId(SecurityContextUtil.getCurrentUserId());
        }
        return opportunityMapper.selectListByQuery(companyId, query);
    }

    @Override
    public OpportunityVO getById(Long id) {
        OpportunityVO vo = opportunityMapper.selectDetailById(id);
        if (vo == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "商机不存在");
        }
        vo.setPermBits(dataPermissionService.effectiveBits(DataPermModule.OPPORTUNITY, id));
        return vo;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public OpportunityVO save(OpportunityCreateDTO dto) {
        Long companyId = SecurityContextUtil.getCurrentCompanyId();
        if (companyId == null) companyId = 1L;

        Opportunity entity = new Opportunity();
        BeanUtils.copyProperties(dto, entity);
        entity.setCompanyId(companyId);
        entity.setOpportunityNo(generateOpportunityNo(companyId));
        // 归属人默认为创建人，销售默认为当前用户
        Long currentUserId = SecurityContextUtil.getCurrentUserId();
        if (entity.getOwnerId() == null) {
            entity.setOwnerId(currentUserId);
        }
        if ((entity.getSalesPerson() == null || entity.getSalesPerson().isEmpty()) && currentUserId != null) {
            User u = userMapper.selectById(currentUserId);
            if (u != null && u.getRealName() != null) {
                entity.setSalesPerson(u.getRealName());
                entity.setSalesPersonId(currentUserId);
            }
        }
        applyStageDefaults(entity);
        if (entity.getStatus() == null || entity.getStatus().isEmpty()) {
            entity.setStatus("IN_PROGRESS");
        }
        if (entity.getSalesStatus() == null || entity.getSalesStatus().isEmpty()) {
            entity.setSalesStatus("TARGET");
        }
        opportunityMapper.insert(entity);
        log.info("新增商机成功: id={}, no={}, name={}", entity.getId(), entity.getOpportunityNo(), entity.getOpportunityName());
        return getById(entity.getId());
    }

    /** 生成商机号 OPP-yyyyMMdd-NNNN，按公司+当日自增，唯一索引兜底重试 */
    private String generateOpportunityNo(Long companyId) {
        String dateStr = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String prefix = "OPP-" + dateStr + "-";
        for (int attempt = 0; attempt < 5; attempt++) {
            int seq = 1;
            QueryWrapper<Opportunity> qw = new QueryWrapper<>();
            qw.select("opportunity_no").eq("company_id", companyId)
                    .likeRight("opportunity_no", prefix)
                    .orderByDesc("opportunity_no").last("LIMIT 1");
            Opportunity last = opportunityMapper.selectOne(qw);
            if (last != null && last.getOpportunityNo() != null) {
                Matcher m = Pattern.compile("-(\\d{4})$").matcher(last.getOpportunityNo());
                if (m.find()) {
                    seq = Integer.parseInt(m.group(1)) + 1;
                }
            }
            String no = prefix + String.format("%04d", seq);
            try {
                return no;
            } catch (Exception e) {
                // 唯一索引冲突则重试
            }
        }
        return prefix + String.format("%04d", (int) (System.currentTimeMillis() % 10000));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public OpportunityVO update(OpportunityUpdateDTO dto) {
        Opportunity old = opportunityMapper.selectById(dto.getId());
        if (old == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "商机不存在");
        }
        dataPermissionService.assertWrite(DataPermModule.OPPORTUNITY, dto.getId(), DataPermBits.UPDATE);

        Opportunity entity = new Opportunity();
        BeanUtils.copyProperties(dto, entity);
        entity.setVersion(old.getVersion());
        entity.setOpportunityNo(old.getOpportunityNo()); // 商机号不可修改
        if (entity.getStage() != null && STAGE_RATE_MAP.containsKey(entity.getStage())) {
            entity.setStageRate(STAGE_RATE_MAP.get(entity.getStage()));
        }
        opportunityMapper.updateById(entity);
        log.info("更新商机成功: id={}", entity.getId());
        return getById(entity.getId());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Long id) {
        dataPermissionService.assertWrite(DataPermModule.OPPORTUNITY, id, DataPermBits.DELETE);
        opportunityMapper.deleteById(id);
        log.info("删除商机成功: id={}", id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteBatch(List<Long> ids) {
        if (ids != null) {
            ids.forEach(id -> dataPermissionService.assertWrite(DataPermModule.OPPORTUNITY, id, DataPermBits.DELETE));
        }
        opportunityMapper.deleteBatchIds(ids);
        log.info("批量删除商机成功: ids={}", ids);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public OpportunityVO changeStage(Long id, String stage) {
        if (stage == null || !STAGE_RATE_MAP.containsKey(stage)) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "阶段值无效");
        }
        Opportunity opp = opportunityMapper.selectById(id);
        if (opp == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "商机不存在");
        }
        opp.setStage(stage);
        opp.setStageRate(STAGE_RATE_MAP.get(stage));
        if ("STAGE_07".equals(stage)) {
            opp.setStatus("WON");
        } else if ("IN_PROGRESS".equals(opp.getStatus()) == false && "WON".equals(opp.getStatus()) == false) {
            opp.setStatus("IN_PROGRESS");
        }
        opportunityMapper.updateById(opp);
        log.info("更新商机阶段成功: id={}, stage={}", id, stage);
        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public OpportunityVO changeStatus(Long id, String status) {
        if (status == null || status.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请指定目标状态");
        }
        Opportunity opp = opportunityMapper.selectById(id);
        if (opp == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "商机不存在");
        }
        dataPermissionService.assertWrite(DataPermModule.OPPORTUNITY, id, DataPermBits.UPDATE);
        opp.setStatus(status);
        opportunityMapper.updateById(opp);
        log.info("更新商机状态成功: id={}, status={}", id, status);
        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public OpportunityVO transfer(Long id, Long newOwnerId, String newOwnerName) {
        if (newOwnerId == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请指定新负责人");
        }
        Opportunity opp = opportunityMapper.selectById(id);
        if (opp == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "商机不存在");
        }
        // 仅负责人或管理员可转移
        dataPermissionService.assertWrite(DataPermModule.OPPORTUNITY, id, DataPermBits.UPDATE);
        User target = userMapper.selectById(newOwnerId);
        if (target == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "目标用户不存在");
        }
        String name = (newOwnerName != null && !newOwnerName.isEmpty()) ? newOwnerName : target.getRealName();
        opp.setOwnerId(newOwnerId);
        // 同步更新销售代表为新负责人
        opp.setSalesPersonId(newOwnerId);
        opp.setSalesPerson(name);
        opportunityMapper.updateById(opp);
        log.info("转移商机负责人成功: id={}, newOwnerId={}", id, newOwnerId);
        return getById(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Long buildContract(Long opportunityId) {
        Opportunity opp = opportunityMapper.selectById(opportunityId);
        if (opp == null) {
            throw new BusinessException(ResultCode.DATA_NOT_FOUND.getCode(), "商机不存在");
        }
        Contract c = new Contract();
        c.setCompanyId(opp.getCompanyId());
        c.setContractName(opp.getOpportunityName() + "合同");
        c.setProjectName(opp.getOpportunityName());
        c.setCustomerId(opp.getCustomerId());
        c.setCustomerCode(opp.getCustomerCode());
        c.setCustomerName(opp.getCustomerName());
        c.setProductLine(opp.getProductLine());
        c.setSalesManager(opp.getSalesPerson());
        c.setManager(opp.getSalesPerson());
        c.setContractAmount(opp.getAmount());
        c.setExpectedSignDate(opp.getExpectedSignDate());
        c.setContractStatus("UNSIGNED");
        c.setOwnerId(opp.getOwnerId() != null ? opp.getOwnerId() : SecurityContextUtil.getCurrentUserId());
        c.setSourceType("OPPORTUNITY");
        c.setRemark("由商机[" + opp.getOpportunityName() + "]一键构建");
        String contractNo = "HT" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        c.setContractNo(contractNo);
        // 生成子合同号，避免唯一索引 uk_sub_contract_no(company_id, sub_contract_no, deleted) 冲突
        c.setSubContractNo(contractService.generateSubContractNo(opp.getCompanyId(), contractNo));
        contractMapper.insert(c);
        // 写入合同-商机关联
        ContractOpportunity co = new ContractOpportunity();
        co.setContractId(c.getId());
        co.setOpportunityId(opportunityId);
        co.setCreatedBy(SecurityContextUtil.getCurrentUserId());
        contractOpportunityMapper.insert(co);
        // 商机推进到合同签订阶段
        if (!"STAGE_07".equals(opp.getStage())) {
            opp.setStage("STAGE_06");
            opp.setStageRate(STAGE_RATE_MAP.get("STAGE_06"));
            opportunityMapper.updateById(opp);
        }
        log.info("由商机构建合同成功: oppId={}, contractId={}", opportunityId, c.getId());
        return c.getId();
    }

    private void applyStageDefaults(Opportunity entity) {
        if (entity.getStage() == null) {
            entity.setStage("STAGE_01");
        }
        if (STAGE_RATE_MAP.containsKey(entity.getStage())) {
            entity.setStageRate(STAGE_RATE_MAP.get(entity.getStage()));
        } else if (entity.getStageRate() == null) {
            entity.setStageRate(5);
        }
    }

    @Override
    public void exportOpportunities(OpportunityQueryDTO query, HttpServletResponse response) throws Exception {
        List<OpportunityVO> list = list(query);
        ExcelWriter writer = ExcelUtil.getWriter();
        String[] headers = {"商机名称*", "客户名称", "阶段", "赢率(%)", "预计金额(万元)", "预计成交时间", "预计签单时间", "商机来源", "新老客户", "行业", "产品线", "竞争对手", "下一步行动", "客户决策人", "状态", "备注"};
        for (int i = 0; i < headers.length; i++) {
            writer.writeCellValue(i, 0, headers[i]);
        }
        int rowNum = 1;
        for (OpportunityVO o : list) {
            writer.writeCellValue(0, rowNum, o.getOpportunityName());
            writer.writeCellValue(1, rowNum, o.getCustomerName());
            writer.writeCellValue(2, rowNum, stageToLabel(o.getStage()));
            writer.writeCellValue(3, rowNum, o.getStageRate());
            writer.writeCellValue(4, rowNum, o.getAmount() != null ? o.getAmount().doubleValue() : null);
            writer.writeCellValue(5, rowNum, o.getExpectedDealDate() != null ? o.getExpectedDealDate().toString() : null);
            writer.writeCellValue(6, rowNum, o.getExpectedSignDate() != null ? o.getExpectedSignDate().toString() : null);
            writer.writeCellValue(7, rowNum, o.getSource());
            writer.writeCellValue(8, rowNum, o.getCustomerType());
            writer.writeCellValue(9, rowNum, o.getIndustry());
            writer.writeCellValue(10, rowNum, o.getProductLine());
            writer.writeCellValue(11, rowNum, o.getCompetitor());
            writer.writeCellValue(12, rowNum, o.getNextAction());
            writer.writeCellValue(13, rowNum, o.getDecisionMaker());
            writer.writeCellValue(14, rowNum, statusToLabel(o.getStatus()));
            writer.writeCellValue(15, rowNum, o.getRemark());
            rowNum++;
        }
        for (int i = 0; i < headers.length; i++) {
            writer.setColumnWidth(i, i == 0 || i == 10 || i == 12 ? 24 : 16);
        }
        String fileName = URLEncoder.encode("商机数据_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".xlsx", "UTF-8");
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    @Override
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        ExcelWriter writer = ExcelUtil.getWriter();
        writer.addHeaderAlias("商机名称*", "opportunityName");
        writer.addHeaderAlias("客户名称", "customerName");
        writer.addHeaderAlias("阶段", "stage");
        writer.addHeaderAlias("预计金额(万元)", "amount");
        writer.addHeaderAlias("预计成交时间", "expectedDealDate");
        writer.addHeaderAlias("预计签单时间", "expectedSignDate");
        writer.addHeaderAlias("商机来源", "source");
        writer.addHeaderAlias("新老客户", "customerType");
        writer.addHeaderAlias("行业", "industry");
        writer.addHeaderAlias("产品线", "productLine");
        writer.addHeaderAlias("竞争对手", "competitor");
        writer.addHeaderAlias("下一步行动", "nextAction");
        writer.addHeaderAlias("客户决策人", "decisionMaker");
        writer.addHeaderAlias("状态", "status");
        writer.addHeaderAlias("备注", "remark");

        List<Map<String, Object>> demo = new ArrayList<>();
        Map<String, Object> row1 = new LinkedHashMap<>();
        row1.put("商机名称*", "示例商机-数据中台项目");
        row1.put("客户名称", "示例客户有限公司");
        row1.put("阶段", "验证机会点");
        row1.put("预计金额(万元)", 500.00);
        row1.put("预计成交时间", "2026-12-31");
        row1.put("预计签单时间", "2026-12-15");
        row1.put("商机来源", "客户转介绍");
        row1.put("新老客户", "老客户");
        row1.put("行业", "制造业");
        row1.put("产品线", "ISCP供应链计划系统");
        row1.put("竞争对手", "金蝶");
        row1.put("下一步行动", "安排方案演示");
        row1.put("客户决策人", "张总");
        row1.put("状态", "进行中");
        row1.put("备注", "示例数据-删除后填写实际商机");
        demo.add(row1);

        writer.write(demo, true);

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8");
        response.setHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode("商机导入模板.xlsx", "UTF-8"));
        try (OutputStream out = response.getOutputStream()) {
            writer.flush(out, true);
        } finally {
            writer.close();
        }
    }

    @Override
    public Map<String, Object> importExcel(Long companyId, MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "请选择要上传的文件");
        }
        int success = 0;
        int failed = 0;
        List<String> errorMsgs = new ArrayList<>();
        List<Map<String, Object>> allRows;
        try {
            ExcelReader reader = ExcelUtil.getReader(file.getInputStream());
            reader.addHeaderAlias("商机名称*", "opportunityName");
            reader.addHeaderAlias("商机名称", "opportunityName");
            reader.addHeaderAlias("客户名称", "customerName");
            reader.addHeaderAlias("阶段", "stage");
            reader.addHeaderAlias("预计金额(万元)", "amount");
            reader.addHeaderAlias("预计成交时间", "expectedDealDate");
            reader.addHeaderAlias("预计签单时间", "expectedSignDate");
            reader.addHeaderAlias("商机来源", "source");
            reader.addHeaderAlias("新老客户", "customerType");
            reader.addHeaderAlias("行业", "industry");
            reader.addHeaderAlias("产品线", "productLine");
            reader.addHeaderAlias("竞争对手", "competitor");
            reader.addHeaderAlias("下一步行动", "nextAction");
            reader.addHeaderAlias("客户决策人", "decisionMaker");
            reader.addHeaderAlias("状态", "status");
            reader.addHeaderAlias("备注", "remark");
            allRows = reader.readAll();
        } catch (Exception e) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "Excel 解析失败: " + e.getMessage());
        }
        if (allRows == null || allRows.isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "Excel 文件为空");
        }

        int rowNum = 1;
        for (Map<String, Object> row : allRows) {
            rowNum++;
            try {
                String opportunityName = objToStr(row.get("opportunityName"));
                String customerName = objToStr(row.get("customerName"));
                String stageStr = objToStr(row.get("stage"));
                String amountStr = objToStr(row.get("amount"));
                String dealDateStr = objToStr(row.get("expectedDealDate"));
                String signDateStr = objToStr(row.get("expectedSignDate"));
                String source = objToStr(row.get("source"));
                String customerType = objToStr(row.get("customerType"));
                String industry = objToStr(row.get("industry"));
                String productLine = objToStr(row.get("productLine"));
                String competitor = objToStr(row.get("competitor"));
                String nextAction = objToStr(row.get("nextAction"));
                String decisionMaker = objToStr(row.get("decisionMaker"));
                String statusStr = objToStr(row.get("status"));
                String remark = objToStr(row.get("remark"));

                if (opportunityName == null || opportunityName.isEmpty()) {
                    errorMsgs.add("第" + rowNum + "行: 商机名称不能为空");
                    failed++;
                    continue;
                }

                String stage = normalizeStage(stageStr);
                if (stage == null) stage = "STAGE_01";

                Opportunity entity = new Opportunity();
                entity.setCompanyId(companyId);
                entity.setOpportunityName(opportunityName);
                entity.setCustomerName(customerName);
                entity.setStage(stage);
                entity.setStageRate(STAGE_RATE_MAP.getOrDefault(stage, 5));
                if (amountStr != null && !amountStr.isEmpty()) {
                    try {
                        entity.setAmount(new BigDecimal(amountStr.replaceAll(",", "").trim()));
                    } catch (Exception e) {
                        errorMsgs.add("第" + rowNum + "行: 预计金额格式错误");
                        failed++;
                        continue;
                    }
                }
                if (dealDateStr != null && !dealDateStr.isEmpty()) {
                    try { entity.setExpectedDealDate(java.time.LocalDate.parse(dealDateStr)); } catch (Exception ignored) {}
                }
                if (signDateStr != null && !signDateStr.isEmpty()) {
                    try { entity.setExpectedSignDate(java.time.LocalDate.parse(signDateStr)); } catch (Exception ignored) {}
                }
                entity.setSource(source);
                entity.setCustomerType(customerType);
                entity.setIndustry(industry);
                entity.setProductLine(productLine);
                entity.setCompetitor(competitor);
                entity.setNextAction(nextAction);
                entity.setDecisionMaker(decisionMaker);
                entity.setStatus(normalizeStatus(statusStr));
                entity.setRemark(remark);
                entity.setSourceType("EXCEL");
                opportunityMapper.insert(entity);
                success++;
            } catch (Exception e) {
                errorMsgs.add("第" + rowNum + "行: " + e.getMessage());
                failed++;
            }
        }

        Map<String, Object> result = new HashMap<>();
        result.put("total", allRows.size());
        result.put("success", success);
        result.put("failed", failed);
        result.put("errors", errorMsgs);
        log.info("商机导入完成: 成功={}, 失败={}", success, failed);
        return result;
    }

    private String stageToLabel(String stage) {
        Map<String, String> m = new HashMap<>();
        m.put("STAGE_01", "目标客户");
        m.put("STAGE_02", "线索");
        m.put("STAGE_03", "验证机会点");
        m.put("STAGE_04", "推进机会点");
        m.put("STAGE_05", "评比与证明");
        m.put("STAGE_06", "合同与商务谈判");
        m.put("STAGE_07", "赢单");
        return m.getOrDefault(stage, stage);
    }

    private String normalizeStage(String stage) {
        if (stage == null) return "STAGE_01";
        String s = stage.trim();
        if ("目标客户".equals(s) || "STAGE_01".equalsIgnoreCase(s)) return "STAGE_01";
        if ("线索".equals(s) || "STAGE_02".equalsIgnoreCase(s)) return "STAGE_02";
        if ("验证机会点".equals(s) || "STAGE_03".equalsIgnoreCase(s)) return "STAGE_03";
        if ("推进机会点".equals(s) || "STAGE_04".equalsIgnoreCase(s)) return "STAGE_04";
        if ("评比与证明".equals(s) || "STAGE_05".equalsIgnoreCase(s)) return "STAGE_05";
        if ("合同与商务谈判".equals(s) || "STAGE_06".equalsIgnoreCase(s)) return "STAGE_06";
        if ("赢单".equals(s) || "STAGE_07".equalsIgnoreCase(s)) return "STAGE_07";
        return "STAGE_01";
    }

    private String statusToLabel(String status) {
        if ("IN_PROGRESS".equals(status)) return "进行中";
        if ("WON".equals(status)) return "赢单";
        if ("LOST".equals(status)) return "输单";
        return status;
    }

    private String normalizeStatus(String status) {
        if (status == null || status.isEmpty()) return "IN_PROGRESS";
        String s = status.trim();
        if ("进行中".equals(s) || "IN_PROGRESS".equalsIgnoreCase(s)) return "IN_PROGRESS";
        if ("赢单".equals(s) || "WON".equalsIgnoreCase(s)) return "WON";
        if ("输单".equals(s) || "LOST".equalsIgnoreCase(s)) return "LOST";
        return "IN_PROGRESS";
    }

    private String objToStr(Object obj) {
        if (obj == null) return null;
        return String.valueOf(obj).trim();
    }
}
