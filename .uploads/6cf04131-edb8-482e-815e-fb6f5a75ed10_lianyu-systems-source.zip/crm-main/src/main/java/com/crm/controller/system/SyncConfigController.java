package com.crm.controller.system;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.annotation.OperationLog;
import com.crm.annotation.OperationLog.OperationType;
import com.crm.common.BusinessException;
import com.crm.common.Result;
import com.crm.common.ResultCode;
import com.crm.config.HrProperties;
import com.crm.entity.SyncLog;
import com.crm.entity.SyncTaskConfig;
import com.crm.schedule.HrDataSyncSchedule;
import com.crm.service.HrDataService;
import com.crm.service.SyncConfigService;
import com.crm.service.SyncTaskExecutor;
import com.crm.service.SyncTaskExecutor.SyncExecutionResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/system/sync-config")
@RequiredArgsConstructor
public class SyncConfigController {

    private final HrProperties hrProperties;
    private final HrDataService hrDataService;
    private final SyncConfigService syncConfigService;
    private final HrDataSyncSchedule hrDataSyncSchedule;
    private final SyncTaskExecutor syncTaskExecutor;

    private static final List<String> BUILTIN_TYPES = Arrays.asList("org", "employee", "overtime", "attendance", "leave");

    @GetMapping("/status")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:view')")
    public Result<Map<String, Object>> getSyncStatus() {
        Map<String, Object> result = new HashMap<>();
        result.put("hrEnabled", hrProperties.isEnabled());
        result.put("schedules", syncConfigService.listTasks());
        return Result.success(result);
    }

    @GetMapping("/tasks")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:view')")
    public Result<Page<SyncTaskConfig>> pageTasks(
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "20") Integer pageSize) {
        return Result.success(syncConfigService.pageTasks(pageNum, pageSize, keyword));
    }

    @GetMapping("/logs")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:view')")
    public Result<Page<SyncLog>> getLogs(
            @RequestParam(required = false) String taskKey,
            @RequestParam(required = false) Integer status,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "20") Integer pageSize) {
        return Result.success(syncConfigService.pageLogs(taskKey, status, pageNum, pageSize));
    }

    @PostMapping("/task")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:create')")
    @OperationLog(module = "数据同步配置", description = "新增同步配置", type = OperationType.INSERT)
    public Result<SyncTaskConfig> createTask(@RequestBody SyncTaskConfig task) {
        validateTask(task);
        if (task.getEnabled() == null) {
            task.setEnabled(1);
        }
        SyncTaskConfig saved = syncConfigService.saveTask(task);
        hrDataSyncSchedule.refreshAllTasks();
        return Result.success("新增同步任务成功", saved);
    }

    @PutMapping("/task")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:update')")
    @OperationLog(module = "数据同步配置", description = "修改同步配置", type = OperationType.UPDATE)
    public Result<SyncTaskConfig> updateTask(@RequestBody SyncTaskConfig task) {
        if (task.getId() == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "任务ID不能为空");
        }
        validateTask(task);
        SyncTaskConfig updated = syncConfigService.updateTask(task);
        hrDataSyncSchedule.refreshTask(updated.getId());
        return Result.success("更新同步任务成功", updated);
    }

    @PostMapping("/task/{id}/toggle")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:update')")
    @OperationLog(module = "数据同步配置", description = "修改同步配置", type = OperationType.UPDATE)
    public Result<SyncTaskConfig> toggleTask(@PathVariable Long id, @RequestParam Integer enabled) {
        SyncTaskConfig cfg = syncConfigService.toggleTask(id, enabled);
        hrDataSyncSchedule.refreshTask(id);
        return Result.success(cfg);
    }

    @DeleteMapping("/task/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:delete')")
    @OperationLog(module = "数据同步配置", description = "删除同步配置", type = OperationType.DELETE)
    public Result<Void> deleteTask(@PathVariable Long id) {
        syncConfigService.deleteTask(id);
        hrDataSyncSchedule.refreshAllTasks();
        return Result.success("删除成功", null);
    }

    @PostMapping("/sync/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:run')")
    @OperationLog(module = "数据同步配置", description = "执行数据同步", type = OperationType.OTHER)
    public Result<Map<String, Object>> syncById(@PathVariable Long id) {
        SyncTaskConfig t = syncConfigService.getById(id);
        if (t == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "任务不存在");
        }
        if (t.getEnabled() == null || t.getEnabled() != 1) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "该任务已禁用，无法执行");
        }
        String syncType = t.getSyncType();
        boolean isHrBuiltin = BUILTIN_TYPES.contains(syncType);
        if (isHrBuiltin) {
            checkHrEnabled();
        }

        Instant start = Instant.now();
        SyncExecutionResult result = syncTaskExecutor.execute(t, "MANUAL");
        long duration = Duration.between(start, Instant.now()).toMillis();

        if ("http".equals(syncType)) {
            syncConfigService.logHttpSync(t.getTaskKey(), t.getTaskName(), "MANUAL",
                    result.isSuccess(), result.getMessage(),
                    result.getHttpStatus() == null ? 0 : result.getHttpStatus(),
                    result.getResponseBody(),
                    duration, result.isSuccess() ? null : result.getErrorMsg());
        } else {
            syncConfigService.logSync(t.getTaskKey(), t.getTaskName(), "MANUAL",
                    result.isSuccess(), result.getMessage(),
                    result.getAdded(), result.getUpdated(), result.getDeleted(), result.getTotal(),
                    duration, result.isSuccess() ? null : result.getErrorMsg());
        }

        if (!result.isSuccess()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), result.getMessage());
        }

        Map<String, Object> data = new HashMap<>();
        data.put("taskId", id);
        data.put("taskName", t.getTaskName());
        data.put("message", result.getMessage());
        data.put("duration", duration);
        if ("http".equals(syncType)) {
            data.put("httpStatus", result.getHttpStatus());
            data.put("responseBody", result.getResponseBody());
        } else {
            data.put("added", result.getAdded());
            data.put("updated", result.getUpdated());
            data.put("deleted", result.getDeleted());
            data.put("total", result.getTotal());
        }
        return Result.success(result.getMessage(), data);
    }

    @PostMapping("/sync/org")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:run')")
    @OperationLog(module = "数据同步配置", description = "执行数据同步", type = OperationType.OTHER)
    public Result<Map<String, Object>> syncOrg() {
        return syncByBuiltinKey("org");
    }

    @PostMapping("/sync/employee")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:run')")
    @OperationLog(module = "数据同步配置", description = "执行数据同步", type = OperationType.OTHER)
    public Result<Map<String, Object>> syncEmployee() {
        return syncByBuiltinKey("employee");
    }

    @PostMapping("/sync/overtime")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:run')")
    @OperationLog(module = "数据同步配置", description = "执行数据同步", type = OperationType.OTHER)
    public Result<Map<String, Object>> syncOvertime() {
        return syncByBuiltinKey("overtime");
    }

    @PostMapping("/sync/attendance")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:run')")
    @OperationLog(module = "数据同步配置", description = "执行数据同步", type = OperationType.OTHER)
    public Result<Map<String, Object>> syncAttendance() {
        return syncByBuiltinKey("attendance");
    }

    @PostMapping("/sync/leave")
    @PreAuthorize("@permissionChecker.hasPermission('crm:sync-config:run')")
    @OperationLog(module = "数据同步配置", description = "执行数据同步", type = OperationType.OTHER)
    public Result<Map<String, Object>> syncLeave() {
        return syncByBuiltinKey("leave");
    }

    private Result<Map<String, Object>> syncByBuiltinKey(String syncType) {
        checkHrEnabled();
        SyncTaskConfig t = syncConfigService.getOne(new LambdaQueryWrapper<SyncTaskConfig>()
                .eq(SyncTaskConfig::getSyncType, syncType)
                .eq(SyncTaskConfig::getEnabled, 1)
                .last("LIMIT 1"));
        if (t == null) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "该同步任务未启用或不存在");
        }
        return syncById(t.getId());
    }

    private void validateTask(SyncTaskConfig task) {
        if (task.getTaskName() == null || task.getTaskName().trim().isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "任务名称不能为空");
        }
        if (task.getSyncType() == null || task.getSyncType().trim().isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "同步类型不能为空");
        }
        String type = task.getSyncType().trim();
        boolean isBuiltin = BUILTIN_TYPES.contains(type);
        boolean isHttp = "http".equals(type);
        if (!isBuiltin && !isHttp) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "同步类型必须是 org/employee/overtime/attendance/leave/http 之一");
        }
        if (isHttp) {
            if (task.getTargetUrl() == null || task.getTargetUrl().trim().isEmpty()) {
                throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "自定义HTTP任务必须填写目标URL");
            }
        }
        if (task.getCron() == null || task.getCron().trim().isEmpty()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "Cron表达式不能为空");
        }
        try {
            new org.springframework.scheduling.support.CronTrigger(task.getCron().trim());
        } catch (Exception e) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "Cron表达式格式错误：" + e.getMessage());
        }
    }

    private void checkHrEnabled() {
        if (!hrProperties.isEnabled()) {
            throw new BusinessException(ResultCode.PARAM_ERROR.getCode(), "HR系统集成未启用（crm.hr.enabled=false），无法执行HR同步操作");
        }
    }
}
