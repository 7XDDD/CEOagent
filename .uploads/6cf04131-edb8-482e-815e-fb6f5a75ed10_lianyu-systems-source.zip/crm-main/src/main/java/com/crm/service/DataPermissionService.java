package com.crm.service;

import com.crm.entity.DataPermission;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface DataPermissionService {

    /** 校验当前用户对某条数据是否具备指定操作位，否则抛 403 */
    void assertWrite(String module, Long bizId, int requiredBit);

    /** 当前用户是否可写（编辑/删除） */
    boolean canWrite(String module, Long bizId, int requiredBit);

    /**
     * 批量计算当前用户对一批数据的有效权限位，用于列表 VO 填充、前端按钮控制。
     * key=bizId, value=权限位(管理员/负责人=7，共享者=授权位，无=0)
     */
    Map<Long, Integer> permBitsMap(String module, Collection<Long> bizIds);

    /** 单条有效权限位 */
    int effectiveBits(String module, Long bizId);

    /** 查询某条数据已授权名单 */
    List<DataPermission> listGrants(String module, Long bizId);

    /** 授权（授予人须为管理员或该数据负责人） */
    void grant(String module, Long bizId, Long granteeId, Integer permBits, LocalDate expireDate, String remark);

    /** 收回授权（管理员或数据负责人） */
    void revoke(String module, Long bizId, Long grantId);
}
