package com.crm.vo.system;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class PermissionVO {
    private Long id;
    private Long parentId;
    private String permissionName;
    private String permissionCode;
    private String permissionType;
    private String systemType;
    private String path;
    private String routePath;
    private String apiPath;
    private String httpMethod;
    private String component;
    private String icon;
    private Integer sortOrder;
    private Integer status;
    private Integer treeLevel;
    private String treePath;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
    private List<PermissionVO> children;
}
