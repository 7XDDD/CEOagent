package com.crm.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@TableName("crm_opportunity")
public class Opportunity implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    private String opportunityNo;

    private String opportunityName;

    private Long customerId;

    private String customerCode;

    private String customerName;

    private String stage;

    private Integer stageRate;

    private BigDecimal amount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedDealDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedSignDate;

    private String source;

    private String customerType;

    private String industry;

    private String productLine;

    private String competitor;

    private String nextAction;

    private String decisionMaker;

    private String status;

    private String salesStatus;

    private String projectLevel;

    private String salesPerson;

    private Long salesPersonId;

    private String companyOwner;

    private Long companyOwnerId;

    private String winRecord;

    private String projectDetail;

    private String stageSummary;

    private String closeReason;

    private String demandProduct;

    private String presalesResource;

    private String resourceConfig;

    private String sourceType;

    private String sourceFileName;

    private String opportunityType;

    private String projectAddress;

    private String salesResource;

    private String followPlan;

    private String followStatus;

    private String remark;

    private Long ownerId;

    private Long deptId;

    @TableField(value = "created_by", fill = FieldFill.INSERT)
    private Long createdBy;

    @TableField(value = "updated_by", fill = FieldFill.INSERT)
    private Long updatedBy;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    @Version
    @TableField(fill = FieldFill.INSERT)
    private Integer version = 0;

    @TableLogic
    @TableField(fill = FieldFill.INSERT)
    private Integer deleted = 0;
}
