package com.crm.vo.opportunity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class OpportunityVO {

    private Long id;
    private Long companyId;
    private String opportunityNo;
    private String opportunityName;
    private Long customerId;
    private String customerCode;
    private String customerName;
    private String stage;
    private Integer stageRate;
    private BigDecimal amount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedDealDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedSignDate;

    private String source;
    private String customerType;
    private String industry;
    private String productLine;
    private String competitor;
    private String nextAction;
    private String decisionMaker;
    private String status;
    private String salesStatus;
    private String projectLevel;
    private String salesPerson;
    private String companyOwner;
    private String winRecord;
    private String projectDetail;
    private String stageSummary;
    private String closeReason;
    private String demandProduct;
    private String presalesResource;
    private String resourceConfig;
    private String sourceType;
    private String sourceFileName;
    private String opportunityType;
    private String projectAddress;
    private String salesResource;
    private String followPlan;
    private String followStatus;
    private String remark;
    private Long ownerId;
    private String ownerName;
    private Long deptId;
    private Long salesPersonId;
    private Long companyOwnerId;
    /** 当前登录用户对该商机的有效数据权限位(1看2改4删, 7全权, 0无) */
    private Integer permBits;
    private Long createdBy;
    private Long updatedBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    private Integer version;
    private Integer deleted;
}
