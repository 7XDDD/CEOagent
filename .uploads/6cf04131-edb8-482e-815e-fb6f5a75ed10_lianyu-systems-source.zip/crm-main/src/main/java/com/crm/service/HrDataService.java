package com.crm.service;

import java.util.Map;

/**
 * HR 系统集成数据服务。
 * 默认 crm.hr.enabled=false，同步方法返回空结果。
 */
public interface HrDataService {

    /**
     * 从HR同步组织架构
     * @return {added, updated, deleted}
     */
    Map<String, Integer> syncOrg();

    /**
     * 从HR同步员工数据
     * @return {added, updated, deleted}
     */
    Map<String, Integer> syncEmployee();

    /**
     * 从HR同步加班数据
     * @return 同步条数
     */
    int syncOvertime();

    /**
     * 从HR同步考勤日历
     * @return 同步条数
     */
    int syncAttendanceCalendar();

    /**
     * 从HR同步请假数据
     * @return 同步条数
     */
    int syncLeave();
}
