package com.crm.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.crm.common.SecurityContextUtil;
import com.crm.entity.SyncLog;
import com.crm.entity.SyncTaskConfig;
import com.crm.mapper.SyncLogMapper;
import com.crm.mapper.SyncTaskConfigMapper;
import com.crm.service.SyncConfigService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class SyncConfigServiceImpl extends ServiceImpl<SyncTaskConfigMapper, SyncTaskConfig> implements SyncConfigService {

    private final SyncLogMapper syncLogMapper;

    private static final List<Map<String, String>> DEFAULT_TASKS = Arrays.asList(
            buildTask("org", "org", "组织架构", "0 0 2 ? * SUN", "每周日凌晨2:00", "/system/sync-config/sync/org", "每周全量同步HR组织架构，包含新增、更新和删除"),
            buildTask("employee", "employee", "员工数据", "0 0 1 * * ?", "每天凌晨1:00", "/system/sync-config/sync/employee", "每日全量同步HR员工数据"),
            buildTask("overtime", "overtime", "加班数据", "0 5 1 * * ?", "每天凌晨1:05", "/system/sync-config/sync/overtime", "每日增量/全量同步HR加班申请数据"),
            buildTask("leave", "leave", "请假数据", "0 10 1 * * ?", "每天凌晨1:10", "/system/sync-config/sync/leave", "每日全量同步HR请假申请数据"),
            buildTask("attendance", "attendance", "考勤日历", "0 15 2 ? * SUN", "每周日凌晨2:15", "/system/sync-config/sync/attendance", "每周同步下一年度考勤日历")
    );

    private static Map<String, String> buildTask(String key, String syncType, String name, String cron, String desc, String api, String description) {
        Map<String, String> m = new HashMap<>();
        m.put("key", key); m.put("syncType", syncType); m.put("name", name); m.put("cron", cron);
        m.put("cronDesc", desc); m.put("api", api); m.put("description", description);
        return m;
    }

    @PostConstruct
    public void init() {
        initDefaultTasks();
    }

    @Override
    public void initDefaultTasks() {
        long count = count();
        if (count > 0) return;
        List<SyncTaskConfig> tasks = new ArrayList<>();
        for (Map<String, String> t : DEFAULT_TASKS) {
            SyncTaskConfig cfg = new SyncTaskConfig();
            cfg.setTaskKey(t.get("key"));
            cfg.setSyncType(t.get("syncType"));
            cfg.setTaskName(t.get("name"));
            cfg.setCron(t.get("cron"));
            cfg.setCronDesc(t.get("cronDesc"));
            cfg.setApiUrl(t.get("api"));
            cfg.setDescription(t.get("description"));
            cfg.setEnabled(1);
            cfg.setSysBuiltIn(1);
            tasks.add(cfg);
        }
        saveBatch(tasks);
        log.info("初始化数据同步任务配置完成，共{}个任务", tasks.size());
    }

    @Override
    public List<SyncTaskConfig> listTasks() {
        List<SyncTaskConfig> list = list(new LambdaQueryWrapper<SyncTaskConfig>()
                .orderByAsc(SyncTaskConfig::getId));
        if (list.isEmpty()) {
            initDefaultTasks();
            list = list(new LambdaQueryWrapper<SyncTaskConfig>().orderByAsc(SyncTaskConfig::getId));
        }
        return list;
    }

    @Override
    public Page<SyncTaskConfig> pageTasks(Integer pageNum, Integer pageSize, String keyword) {
        listTasks();
        Page<SyncTaskConfig> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<SyncTaskConfig> wrapper = new LambdaQueryWrapper<SyncTaskConfig>()
                .orderByAsc(SyncTaskConfig::getId);
        if (keyword != null && !keyword.trim().isEmpty()) {
            wrapper.and(w -> w.like(SyncTaskConfig::getTaskName, keyword)
                    .or().like(SyncTaskConfig::getTaskKey, keyword)
                    .or().like(SyncTaskConfig::getDescription, keyword));
        }
        return page(page, wrapper);
    }

    @Override
    public SyncTaskConfig toggleTask(Long taskId, Integer enabled) {
        SyncTaskConfig cfg = getById(taskId);
        if (cfg == null) {
            throw new RuntimeException("任务不存在");
        }
        cfg.setEnabled(enabled == null ? 1 : (enabled == 1 ? 1 : 0));
        updateById(cfg);
        return cfg;
    }

    @Override
    public void recordLog(SyncLog log) {
        syncLogMapper.insert(log);
    }

    @Override
    public Page<SyncLog> pageLogs(String taskKey, Integer status, Integer pageNum, Integer pageSize) {
        Page<SyncLog> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<SyncLog> wrapper = new LambdaQueryWrapper<SyncLog>()
                .orderByDesc(SyncLog::getCreateTime);
        if (taskKey != null && !taskKey.isEmpty()) {
            wrapper.eq(SyncLog::getTaskKey, taskKey);
        }
        if (status != null) {
            wrapper.eq(SyncLog::getStatus, status);
        }
        return syncLogMapper.selectPage(page, wrapper);
    }

    @Override
    public boolean isTaskEnabled(String taskKey) {
        SyncTaskConfig cfg = getOne(new LambdaQueryWrapper<SyncTaskConfig>()
                .eq(SyncTaskConfig::getTaskKey, taskKey)
                .last("LIMIT 1"));
        return cfg != null && cfg.getEnabled() == 1;
    }

    @Override
    public SyncTaskConfig saveTask(SyncTaskConfig task) {
        task.setSysBuiltIn(0);
        task.setEnabled(task.getEnabled() == null ? 1 : task.getEnabled());
        if (task.getTaskKey() == null || task.getTaskKey().isEmpty()) {
            task.setTaskKey("custom_" + System.currentTimeMillis());
        }
        if ("http".equals(task.getSyncType())) {
            if (task.getHttpMethod() == null || task.getHttpMethod().isEmpty()) {
                task.setHttpMethod("POST");
            }
        }
        save(task);
        return task;
    }

    @Override
    public SyncTaskConfig updateTask(SyncTaskConfig task) {
        SyncTaskConfig exist = getById(task.getId());
        if (exist == null) {
            throw new RuntimeException("任务不存在");
        }
        exist.setTaskName(task.getTaskName());
        exist.setSyncType(task.getSyncType());
        exist.setCron(task.getCron());
        exist.setCronDesc(task.getCronDesc());
        exist.setApiUrl(task.getApiUrl());
        exist.setTargetUrl(task.getTargetUrl());
        exist.setHttpMethod(task.getHttpMethod());
        exist.setRequestBody(task.getRequestBody());
        exist.setDescription(task.getDescription());
        exist.setEnabled(task.getEnabled() == null ? exist.getEnabled() : task.getEnabled());
        updateById(exist);
        return exist;
    }

    @Override
    public void deleteTask(Long taskId) {
        SyncTaskConfig exist = getById(taskId);
        if (exist == null) {
            throw new RuntimeException("任务不存在");
        }
        if (exist.getSysBuiltIn() != null && exist.getSysBuiltIn() == 1) {
            throw new RuntimeException("系统内置任务不允许删除");
        }
        removeById(taskId);
    }

    @Override
    public void logSync(String taskKey, String taskName, String triggerType, boolean success,
                        String message, int added, int updated, int deleted, int total,
                        long duration, String errorMsg) {
        try {
            SyncLog syncLog = new SyncLog();
            syncLog.setTaskKey(taskKey);
            syncLog.setTaskName(taskName);
            syncLog.setTriggerType(triggerType);
            syncLog.setStatus(success ? 1 : 0);
            syncLog.setMessage(message);
            syncLog.setAddedCount(added);
            syncLog.setUpdatedCount(updated);
            syncLog.setDeletedCount(deleted);
            syncLog.setTotalCount(total);
            syncLog.setDuration(duration);
            syncLog.setErrorMsg(errorMsg);
            syncLog.setOperator(getCurrentUsername());
            syncLog.setCreateTime(LocalDateTime.now());
            syncLogMapper.insert(syncLog);
        } catch (Exception e) {
            log.warn("记录同步日志失败：{}", e.getMessage());
        }
    }

    private String getCurrentUsername() {
        try {
            String username = SecurityContextUtil.getCurrentUsername();
            return username != null ? username : "SYSTEM";
        } catch (Exception e) {
            return "SYSTEM";
        }
    }

    @Override
    public void logHttpSync(String taskKey, String taskName, String triggerType, boolean success,
                            String message, int httpStatus, String responseBody,
                            long duration, String errorMsg) {
        try {
            SyncLog syncLog = new SyncLog();
            syncLog.setTaskKey(taskKey);
            syncLog.setTaskName(taskName);
            syncLog.setTriggerType(triggerType);
            syncLog.setStatus(success ? 1 : 0);
            syncLog.setMessage(message);
            syncLog.setHttpStatus(httpStatus);
            String r = responseBody;
            if (r != null && r.length() > 1000) {
                r = r.substring(0, 1000) + "...";
            }
            syncLog.setResponseBody(r);
            syncLog.setDuration(duration);
            syncLog.setErrorMsg(errorMsg);
            syncLog.setOperator(getCurrentUsername());
            syncLog.setCreateTime(LocalDateTime.now());
            syncLogMapper.insert(syncLog);
        } catch (Exception e) {
            log.warn("记录HTTP同步日志失败：{}", e.getMessage());
        }
    }
}
