package com.crm.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.Version;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@TableName("crm_budget_version")
public class BudgetVersion implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long companyId;

    private Integer fiscalYear;

    private String versionCode;

    private String versionName;

    private String budgetScene;

    private Integer rollingMonth;

    private Integer isActive;

    private Integer isLocked;

    /**
     * 是否定稿：0=否（默认），1=是。仅年中调整版（budgetScene=ADJUST）使用
     */
    private Integer isFinalized;

    private String approvalStatus;

    private LocalDate effectiveDate;

    private LocalDate expireDate;

    private Long parentVersionId;

    private String remark;

    private Long ownerId;

    @TableField(value = "created_by", fill = FieldFill.INSERT)
    private Long createdBy;

    @TableField(value = "updated_by", fill = FieldFill.INSERT)
    private Long updatedBy;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT)
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    @Version
    @TableField(fill = FieldFill.INSERT)
    private Integer version = 0;

    @TableLogic
    @TableField(fill = FieldFill.INSERT)
    private Integer deleted = 0;

}
