package com.crm.vo.product;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ProductVO {

    private Long id;

    private Long companyId;

    private String productCode;

    private String productName;

    private String unit;

    private BigDecimal salesPrice;

    private String status;

    private String category;

    private String description;

    private String sourceType;

    private String sourceFileName;

    private String remark;

    private Long ownerId;

    private Long deptId;

    private Long createdBy;

    private Long updatedBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    private Integer version;

    private Integer deleted;
}
