package com.crm.service.budget;

import com.crm.dto.BudgetCalculateRequest;

public interface BudgetCalculateService {

    String calculateBudget(Long companyId, BudgetCalculateRequest request);
}
