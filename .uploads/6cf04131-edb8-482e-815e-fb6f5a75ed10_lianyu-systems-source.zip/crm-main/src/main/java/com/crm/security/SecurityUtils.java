package com.crm.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;
import java.util.Map;

public class SecurityUtils {

    @SuppressWarnings("unchecked")
    public static LoginUser getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !(authentication.getPrincipal() instanceof Map)) {
            return null;
        }
        Map<String, Object> principal = (Map<String, Object>) authentication.getPrincipal();
        LoginUser user = new LoginUser();
        user.setUserId(principal.get("userId") != null ? Long.valueOf(principal.get("userId").toString()) : null);
        user.setUsername((String) principal.get("username"));
        user.setOrgId(principal.get("orgId") != null ? Long.valueOf(principal.get("orgId").toString()) : null);
        user.setRoles((List<String>) principal.get("roles"));
        user.setPermissions((List<String>) principal.get("permissions"));
        return user;
    }

    public static Long getCurrentUserId() {
        LoginUser user = getCurrentUser();
        return user != null ? user.getUserId() : null;
    }

    public static String getCurrentUsername() {
        LoginUser user = getCurrentUser();
        return user != null ? user.getUsername() : null;
    }
}
