package com.crm.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.system.OperationLogQueryDTO;
import com.crm.entity.OperationLog;
import com.crm.mapper.OperationLogMapper;
import com.crm.service.OperationLogService;
import com.crm.vo.system.OperationLogVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class OperationLogServiceImpl implements OperationLogService {

    @Autowired
    private OperationLogMapper operationLogMapper;

    @Override
    public Page<OperationLogVO> pageList(OperationLogQueryDTO query) {
        Page<OperationLog> page = new Page<>(query.getPageNum(), query.getPageSize());
        Page<OperationLog> logPage = operationLogMapper.selectPageList(page, query);
        Page<OperationLogVO> voPage = new Page<>(logPage.getCurrent(), logPage.getSize(), logPage.getTotal());
        List<OperationLogVO> voList = logPage.getRecords().stream().map(this::convertToVO).collect(Collectors.toList());
        voPage.setRecords(voList);
        return voPage;
    }

    @Async
    @Override
    public void saveLog(OperationLog operationLog) {
        try {
            operationLogMapper.insert(operationLog);
        } catch (Exception e) {
            log.error("保存操作日志失败", e);
        }
    }

    private OperationLogVO convertToVO(OperationLog log) {
        OperationLogVO vo = new OperationLogVO();
        BeanUtils.copyProperties(log, vo);
        return vo;
    }
}
