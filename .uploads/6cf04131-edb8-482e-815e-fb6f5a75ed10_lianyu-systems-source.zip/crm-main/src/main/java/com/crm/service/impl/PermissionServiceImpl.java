package com.crm.service.impl;

import com.crm.common.BusinessException;
import com.crm.dto.system.PermissionCreateDTO;
import com.crm.dto.system.PermissionUpdateDTO;
import com.crm.entity.Permission;
import com.crm.mapper.PermissionMapper;
import com.crm.service.PermissionService;
import com.crm.vo.system.PermissionVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PermissionServiceImpl implements PermissionService {

    @Autowired
    private PermissionMapper permissionMapper;

    @Override
    public List<PermissionVO> tree(String systemType) {
        List<Permission> all;
        if (systemType != null && !systemType.isEmpty()) {
            all = permissionMapper.selectBySystemType(systemType);
        } else {
            all = permissionMapper.selectAllWithDeleted();
        }
        List<PermissionVO> voList = all.stream().map(this::convertToVO).collect(Collectors.toList());
        return buildTree(voList);
    }

    @Override
    public List<Permission> listAll() {
        return permissionMapper.selectAllActive();
    }

    @Override
    public Permission getDetail(Long id) {
        return permissionMapper.selectById(id);
    }

    @Override
    public Permission create(PermissionCreateDTO dto) {
        Permission permission = new Permission();
        BeanUtils.copyProperties(dto, permission);
        if (permission.getPath() == null && permission.getRoutePath() != null) {
            permission.setPath(permission.getRoutePath());
        }
        if (permission.getRoutePath() == null && permission.getPath() != null) {
            permission.setRoutePath(permission.getPath());
        }
        if (permission.getStatus() == null) permission.setStatus(1);
        if (permission.getSortOrder() == null) permission.setSortOrder(0);
        if (permission.getParentId() == null) permission.setParentId(0L);
        permissionMapper.insert(permission);
        updateTreeLevelAndPath(permission);
        return permission;
    }

    private void updateTreeLevelAndPath(Permission permission) {
        int level = 1;
        String path = String.valueOf(permission.getId());
        if (permission.getParentId() != null && permission.getParentId() > 0) {
            Permission parent = permissionMapper.selectById(permission.getParentId());
            if (parent != null) {
                level = (parent.getTreeLevel() != null ? parent.getTreeLevel() : 1) + 1;
                path = (parent.getTreePath() != null ? parent.getTreePath() : "") + "/" + permission.getId();
            }
        }
        permission.setTreeLevel(level);
        permission.setTreePath(path);
        permissionMapper.updateById(permission);
    }

    @Override
    public Permission update(Long id, PermissionUpdateDTO dto) {
        Permission permission = permissionMapper.selectById(id);
        if (permission == null) {
            throw new BusinessException("权限不存在");
        }
        BeanUtils.copyProperties(dto, permission);
        permissionMapper.updateById(permission);
        if (dto.getParentId() != null) {
            updateTreeLevelAndPath(permission);
        }
        return permission;
    }

    @Override
    public void delete(Long id) {
        List<Permission> children = permissionMapper.findByParentId(id);
        if (children != null && !children.isEmpty()) {
            throw new BusinessException("该权限下有子权限，无法删除");
        }
        permissionMapper.deleteById(id);
    }

    private List<PermissionVO> buildTree(List<PermissionVO> list) {
        Map<Long, List<PermissionVO>> childrenMap = list.stream()
                .filter(t -> t.getParentId() != null && t.getParentId() > 0)
                .collect(Collectors.groupingBy(PermissionVO::getParentId));
        List<PermissionVO> roots = list.stream()
                .filter(t -> t.getParentId() == null || t.getParentId() == 0)
                .collect(Collectors.toList());
        for (PermissionVO root : roots) {
            buildChildren(root, childrenMap);
        }
        return roots;
    }

    private void buildChildren(PermissionVO parent, Map<Long, List<PermissionVO>> childrenMap) {
        List<PermissionVO> children = childrenMap.get(parent.getId());
        if (children != null && !children.isEmpty()) {
            parent.setChildren(children);
            for (PermissionVO child : children) {
                buildChildren(child, childrenMap);
            }
        } else {
            parent.setChildren(new ArrayList<>());
        }
    }

    private PermissionVO convertToVO(Permission perm) {
        PermissionVO vo = new PermissionVO();
        BeanUtils.copyProperties(perm, vo);
        return vo;
    }
}
