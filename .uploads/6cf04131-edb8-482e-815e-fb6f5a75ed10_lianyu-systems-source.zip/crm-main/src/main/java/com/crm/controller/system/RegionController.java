package com.crm.controller.system;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.annotation.OperationLog;
import com.crm.annotation.OperationLog.OperationType;
import com.crm.common.Result;
import com.crm.entity.Region;
import com.crm.service.RegionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(tags = "系统管理-国家省市区管理")
@RestController
@RequestMapping("/system/region")
public class RegionController {

    @Autowired
    private RegionService regionService;

    @ApiOperation("获取区域树形结构")
    @PreAuthorize("@permissionChecker.hasPermission('crm:region:view')")
    @GetMapping("/tree")
    public Result<List<Region>> tree() {
        return Result.success(regionService.getTree());
    }

    @ApiOperation("获取子区域列表")
    @PreAuthorize("@permissionChecker.hasPermission('crm:region:view')")
    @GetMapping("/children")
    public Result<List<Region>> children(@RequestParam(required = false, defaultValue = "0") Long parentId) {
        return Result.success(regionService.getChildren(parentId));
    }

    @ApiOperation("按级别获取区域")
    @PreAuthorize("@permissionChecker.hasPermission('crm:region:view')")
    @GetMapping("/level/{level}")
    public Result<List<Region>> byLevel(@PathVariable Integer level) {
        return Result.success(regionService.getByLevel(level));
    }

    @ApiOperation("分页查询区域")
    @PreAuthorize("@permissionChecker.hasPermission('crm:region:view')")
    @GetMapping("/page")
    public Result<Page<Region>> page(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "20") Integer pageSize,
            @RequestParam(required = false) Long parentId,
            @RequestParam(required = false) Integer level,
            @RequestParam(required = false) String keyword) {
        Page<Region> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Region> wrapper = new LambdaQueryWrapper<>();
        if (parentId != null) wrapper.eq(Region::getParentId, parentId);
        if (level != null) wrapper.eq(Region::getLevel, level);
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.like(Region::getRegionName, keyword)
                    .or().like(Region::getShortName, keyword)
                    .or().like(Region::getRegionCode, keyword);
        }
        wrapper.orderByAsc(Region::getSortOrder).orderByAsc(Region::getId);
        return Result.success(regionService.page(page, wrapper));
    }

    @ApiOperation("获取区域详情")
    @PreAuthorize("@permissionChecker.hasPermission('crm:region:view')")
    @GetMapping("/{id:\\d+}")
    public Result<Region> getDetail(@PathVariable Long id) {
        return Result.success(regionService.getById(id));
    }

    @ApiOperation("新增区域")
    @PreAuthorize("@permissionChecker.hasPermission('crm:region:create')")
    @OperationLog(module = "国家省市区", description = "新增地区", type = OperationType.INSERT)
    @PostMapping
    public Result<?> create(@RequestBody Region region) {
        regionService.save(region);
        return Result.success("创建成功");
    }

    @ApiOperation("修改区域")
    @PreAuthorize("@permissionChecker.hasPermission('crm:region:update')")
    @OperationLog(module = "国家省市区", description = "修改地区", type = OperationType.UPDATE)
    @PutMapping("/{id:\\d+}")
    public Result<?> update(@PathVariable Long id, @RequestBody Region region) {
        region.setId(id);
        regionService.updateById(region);
        return Result.success("修改成功");
    }

    @ApiOperation("删除区域")
    @PreAuthorize("@permissionChecker.hasPermission('crm:region:delete')")
    @OperationLog(module = "国家省市区", description = "删除地区", type = OperationType.DELETE)
    @DeleteMapping("/{id}")
    public Result<?> delete(@PathVariable Long id) {
        long childCount = regionService.count(new LambdaQueryWrapper<Region>().eq(Region::getParentId, id).eq(Region::getDeleted, 0));
        if (childCount > 0) {
            return Result.error("该区域下存在子区域，无法删除");
        }
        regionService.removeById(id);
        return Result.success("删除成功");
    }

    @ApiOperation("初始化中国行政区划数据")
    @PreAuthorize("@permissionChecker.hasPermission('crm:region:create')")
    @OperationLog(module = "国家省市区", description = "初始化地区数据", type = OperationType.OTHER)
    @PostMapping("/init-china")
    public Result<?> initChina() {
        regionService.initChinaData();
        return Result.success("中国行政区划数据初始化成功");
    }
}
