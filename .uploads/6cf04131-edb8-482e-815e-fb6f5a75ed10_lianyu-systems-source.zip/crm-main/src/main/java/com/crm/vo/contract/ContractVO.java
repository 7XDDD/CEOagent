package com.crm.vo.contract;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
public class ContractVO {

    private Long id;
    private Long companyId;
    private Long parentId;
    private String parentContractNo;
    private String parentContractName;
    private String contractNo;
    private String subContractNo;
    private String projectCode;
    private String projectName;
    private String contractName;
    private Long customerId;
    private String customerCode;
    private String customerName;
    private Long contractTypeId;
    private String contractTypeCode;
    private String contractType;
    private Long orgId;
    private String productLineCode;
    private String productLine;
    private String manager;
    private String salesManager;
    private BigDecimal contractAmount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate signDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expectedSignDate;

    private String contractStatus;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate contractCreateTime;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate contractCompleteTime;

    private String sourceType;
    private String sourceFileName;
    private String remark;
    private Long ownerId;
    private Long deptId;
    private Integer permBits;
    private Long createdBy;
    private Long updatedBy;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;

    private Integer version;
    private Integer deleted;
    private String contractTypeName;
    private String stockFlag;
    private BigDecimal invoicedAmount;
    private BigDecimal uninvoicedAmount;
    private String invoiceStatus;

    /** 关联商机号列表(逗号分隔) */
    private String opportunityNos;

    /** 关联项目名列表(逗号分隔) */
    private String projectNames;

    /** 关联商机ID列表 */
    private List<Long> opportunityIds;

    /** 关联项目ID列表 */
    private List<Long> projectIds;
}
