package com.crm.service.contract;

import com.crm.dto.PageResult;
import com.crm.dto.contract.ContractCreateDTO;
import com.crm.dto.contract.ContractMilestoneDTO;
import com.crm.dto.contract.ContractQueryDTO;
import com.crm.dto.contract.ContractUpdateDTO;
import com.crm.vo.contract.ContractMilestoneVO;
import com.crm.vo.contract.ContractVO;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

public interface ContractService {

    PageResult<ContractVO> page(ContractQueryDTO query);

    List<ContractVO> list(ContractQueryDTO query);

    ContractVO getById(Long id);

    ContractVO save(ContractCreateDTO dto);

    ContractVO update(ContractUpdateDTO dto);

    void deleteById(Long id);

    void deleteBatch(List<Long> ids);

    ContractVO changeStatus(Long id, String status);

    /**
     * 复制合同（含全部里程碑等关联数据），新合同编号为原编号+copy
     * @param id 源合同ID
     * @return 新合同详情
     */
    ContractVO copyContract(Long id);

    List<ContractMilestoneVO> getMilestones(Long contractId);

    ContractMilestoneVO saveMilestone(ContractMilestoneDTO dto);

    ContractMilestoneVO updateMilestone(ContractMilestoneDTO dto);

    void deleteMilestone(Long id);

    void exportContracts(ContractQueryDTO query, HttpServletResponse response) throws Exception;

    void downloadImportTemplate(HttpServletResponse response) throws Exception;

    Map<String, Object> importExcel(Long companyId, MultipartFile file);

    /**
     * 生成子合同号：主合同号-NN，基于同主合同号下已有子合同的最大序号递增
     * @param companyId  公司ID
     * @param contractNo 主合同号
     * @return 子合同号
     */
    String generateSubContractNo(Long companyId, String contractNo);
}
