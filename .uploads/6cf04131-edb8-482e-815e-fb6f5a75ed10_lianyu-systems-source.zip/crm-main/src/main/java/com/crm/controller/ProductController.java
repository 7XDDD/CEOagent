package com.crm.controller;

import com.crm.annotation.OperationLog;
import com.crm.common.Result;
import com.crm.dto.PageResult;
import com.crm.dto.product.ProductCreateDTO;
import com.crm.dto.product.ProductQueryDTO;
import com.crm.dto.product.ProductUpdateDTO;
import com.crm.service.ProductService;
import com.crm.vo.product.ProductVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/product")
@Slf4j
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/page")
    @PreAuthorize("@permissionChecker.hasPermission('crm:product:view')")
    public Result<PageResult<ProductVO>> page(@RequestBody(required = false) ProductQueryDTO query) {
        return Result.success("查询成功", productService.page(query));
    }

    @PostMapping("/list")
    @PreAuthorize("@permissionChecker.hasPermission('crm:product:view')")
    public Result<List<ProductVO>> list(@RequestBody(required = false) ProductQueryDTO query) {
        return Result.success("查询成功", productService.list(query));
    }

    @GetMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:product:view')")
    public Result<ProductVO> getById(@PathVariable Long id) {
        return Result.success("查询成功", productService.getById(id));
    }

    @PostMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:product:add')")
    @OperationLog(module = "商品管理", description = "新增商品")
    public Result<ProductVO> save(@Valid @RequestBody ProductCreateDTO dto) {
        return Result.success("保存成功", productService.save(dto));
    }

    @PutMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:product:edit')")
    @OperationLog(module = "商品管理", description = "更新商品")
    public Result<ProductVO> update(@Valid @RequestBody ProductUpdateDTO dto) {
        return Result.success("更新成功", productService.update(dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:product:delete')")
    @Transactional(rollbackFor = Exception.class)
    @OperationLog(module = "商品管理", description = "删除商品")
    public Result<String> deleteById(@PathVariable Long id) {
        productService.deleteById(id);
        return Result.success("删除成功", null);
    }

    @DeleteMapping("/batch")
    @PreAuthorize("@permissionChecker.hasPermission('crm:product:delete')")
    @Transactional(rollbackFor = Exception.class)
    @OperationLog(module = "商品管理", description = "批量删除商品")
    public Result<String> deleteBatch(@RequestBody List<Long> ids) {
        productService.deleteBatch(ids);
        return Result.success("删除成功", null);
    }

    @PostMapping("/{id}/change-status")
    @PreAuthorize("@permissionChecker.hasPermission('crm:product:edit')")
    public Result<ProductVO> changeStatus(@PathVariable Long id, @RequestParam String status) {
        return Result.success("状态更新成功", productService.changeStatus(id, status));
    }

    @PostMapping("/export")
    @PreAuthorize("@permissionChecker.hasPermission('crm:product:export')")
    public void exportProducts(@RequestBody(required = false) ProductQueryDTO query,
                               HttpServletResponse response) throws Exception {
        productService.exportProducts(query, response);
    }

    @GetMapping("/import-template")
    @PreAuthorize("@permissionChecker.hasPermission('crm:product:import')")
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        productService.downloadImportTemplate(response);
    }

    @PostMapping("/import-excel")
    @PreAuthorize("@permissionChecker.hasPermission('crm:product:import')")
    @OperationLog(module = "商品管理", description = "导入商品")
    public Result<Map<String, Object>> importExcel(@RequestParam("companyId") Long companyId,
                                                    @RequestParam("file") MultipartFile file) {
        Map<String, Object> result = productService.importExcel(companyId, file);
        int success = (int) result.getOrDefault("success", 0);
        int failed = (int) result.getOrDefault("failed", 0);
        String msg = "导入完成，成功 " + success + " 条，失败 " + failed + " 条";
        return Result.success(msg, result);
    }
}
