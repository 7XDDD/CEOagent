package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.system.RoleQueryDTO;
import com.crm.entity.Role;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface RoleMapper extends BaseMapper<Role> {

    List<Role> findRolesByUserId(@Param("userId") Long userId);

    Role findByRoleCode(@Param("roleCode") String roleCode);

    Page<Role> selectPageList(Page<Role> page, @Param("q") RoleQueryDTO query);

    List<Role> selectListByCondition(@Param("q") RoleQueryDTO query);
}
