package com.crm.dto.dataperm;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;

@Data
public class DataPermGrantDTO {

    private String module;
    private Long bizId;
    private Long granteeId;
    /** 权限位: 1查看 2编辑 4删除（7全权，1只读） */
    private Integer permBits;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expireDate;

    private String remark;
}
