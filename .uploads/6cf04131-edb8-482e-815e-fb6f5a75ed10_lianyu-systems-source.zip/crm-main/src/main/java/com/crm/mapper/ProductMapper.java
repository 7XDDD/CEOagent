package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.crm.dto.product.ProductQueryDTO;
import com.crm.entity.Product;
import com.crm.vo.product.ProductVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ProductMapper extends BaseMapper<Product> {

    IPage<ProductVO> selectPageList(IPage<ProductVO> page,
                                    @Param("companyId") Long companyId,
                                    @Param("query") ProductQueryDTO query);

    List<ProductVO> selectListByQuery(@Param("companyId") Long companyId,
                                      @Param("query") ProductQueryDTO query);

    ProductVO selectDetailById(@Param("id") Long id);

    Product findByProductCode(@Param("companyId") Long companyId, @Param("productCode") String productCode);
}
