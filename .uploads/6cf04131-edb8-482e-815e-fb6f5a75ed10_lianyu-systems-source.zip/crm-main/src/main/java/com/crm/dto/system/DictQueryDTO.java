package com.crm.dto.system;

import com.crm.dto.PageQueryDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DictQueryDTO extends PageQueryDTO {
    private String keyword;
    private String dictName;
    private String dictCode;
    private Integer status;
    private String dictType;
    private String systemType;
}
