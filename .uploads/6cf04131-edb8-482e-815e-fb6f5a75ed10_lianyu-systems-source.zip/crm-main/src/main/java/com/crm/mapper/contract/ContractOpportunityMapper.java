package com.crm.mapper.contract;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.ContractOpportunity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ContractOpportunityMapper extends BaseMapper<ContractOpportunity> {
}
