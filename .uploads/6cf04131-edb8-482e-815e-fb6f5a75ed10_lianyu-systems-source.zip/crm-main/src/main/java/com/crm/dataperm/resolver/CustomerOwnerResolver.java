package com.crm.dataperm.resolver;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crm.dataperm.DataOwnerResolver;
import com.crm.dataperm.DataPermModule;
import com.crm.entity.PmtCustomer;
import com.crm.entity.PmtCustomerFollower;
import com.crm.mapper.PmtCustomerFollowerMapper;
import com.crm.mapper.PmtCustomerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 客户负责人：主跟进人(follower_id) / 创建人 / 客户跟进人关系表中有效关联人。
 */
@Component
public class CustomerOwnerResolver implements DataOwnerResolver {

    @Autowired
    private PmtCustomerMapper customerMapper;

    @Autowired
    private PmtCustomerFollowerMapper followerMapper;

    @Override
    public String module() {
        return DataPermModule.CUSTOMER;
    }

    @Override
    public boolean isOwner(Long bizId, Long userId) {
        if (bizId == null || userId == null) return false;
        LambdaQueryWrapper<PmtCustomer> w = new LambdaQueryWrapper<>();
        w.eq(PmtCustomer::getId, bizId)
                .and(x -> x.eq(PmtCustomer::getFollowerId, userId).or().eq(PmtCustomer::getCreateBy, userId));
        if (customerMapper.selectCount(w) > 0) return true;
        LambdaQueryWrapper<PmtCustomerFollower> fw = new LambdaQueryWrapper<>();
        fw.eq(PmtCustomerFollower::getCustomerId, bizId)
                .eq(PmtCustomerFollower::getUserId, userId)
                .eq(PmtCustomerFollower::getStatus, "ACTIVE");
        return followerMapper.selectCount(fw) > 0;
    }

    @Override
    public Set<Long> findOwnerIds(Collection<Long> bizIds, Long userId) {
        if (bizIds == null || bizIds.isEmpty() || userId == null) return Collections.emptySet();
        Set<Long> result = new HashSet<>();
        LambdaQueryWrapper<PmtCustomer> w = new LambdaQueryWrapper<>();
        w.in(PmtCustomer::getId, bizIds)
                .and(x -> x.eq(PmtCustomer::getFollowerId, userId).or().eq(PmtCustomer::getCreateBy, userId));
        result.addAll(customerMapper.selectList(w).stream().map(PmtCustomer::getId).collect(Collectors.toSet()));

        LambdaQueryWrapper<PmtCustomerFollower> fw = new LambdaQueryWrapper<>();
        fw.in(PmtCustomerFollower::getCustomerId, bizIds)
                .eq(PmtCustomerFollower::getUserId, userId)
                .eq(PmtCustomerFollower::getStatus, "ACTIVE");
        List<PmtCustomerFollower> rels = followerMapper.selectList(fw);
        result.addAll(rels.stream().map(PmtCustomerFollower::getCustomerId).collect(Collectors.toSet()));
        return result;
    }
}
