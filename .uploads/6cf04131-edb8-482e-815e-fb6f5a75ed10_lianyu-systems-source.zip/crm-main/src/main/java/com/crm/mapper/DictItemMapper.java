package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.DictItem;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface DictItemMapper extends BaseMapper<DictItem> {

    List<DictItem> findByDictId(@Param("dictId") Long dictId);

    DictItem findByDictIdAndItemCode(@Param("dictId") Long dictId, @Param("itemCode") String itemCode);

    List<DictItem> findByDictCode(@Param("dictCode") String dictCode);

    List<DictItem> findAllByDictCode(@Param("dictCode") String dictCode);

    DictItem findByItemCode(@Param("code") String code);

    List<DictItem> findByDictCodes(@Param("codes") String codes);

    List<DictItem> findByDictCodesAndSystemType(@Param("codes") String codes, @Param("systemType") String systemType);

    Long countByDictId(@Param("dictId") Long dictId);

    int softDeleteById(@Param("id") Long id);

    int softDeleteByDictId(@Param("dictId") Long dictId);
}
