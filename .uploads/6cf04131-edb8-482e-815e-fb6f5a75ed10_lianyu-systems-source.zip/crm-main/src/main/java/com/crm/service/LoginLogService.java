package com.crm.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.system.LoginLogQueryDTO;
import com.crm.vo.system.LoginLogVO;

public interface LoginLogService {

    Page<LoginLogVO> pageList(LoginLogQueryDTO query);
}
