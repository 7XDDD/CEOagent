package com.crm.controller.contract;

import com.crm.annotation.OperationLog;
import com.crm.common.Result;
import com.crm.dto.contract.ContractCreateDTO;
import com.crm.dto.contract.ContractMilestoneDTO;
import com.crm.dto.contract.ContractQueryDTO;
import com.crm.dto.contract.ContractUpdateDTO;
import com.crm.dto.PageResult;
import com.crm.service.contract.ContractService;
import com.crm.vo.contract.ContractMilestoneVO;
import com.crm.vo.contract.ContractVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/contract")
@Slf4j
public class ContractController {

    @Autowired
    private ContractService contractService;

    @PostMapping("/page")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:view')")
    public Result<PageResult<ContractVO>> page(@RequestBody(required = false) ContractQueryDTO query) {
        return Result.success("查询成功", contractService.page(query));
    }

    @PostMapping("/list")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:view')")
    public Result<List<ContractVO>> list(@RequestBody(required = false) ContractQueryDTO query) {
        return Result.success("查询成功", contractService.list(query));
    }

    @GetMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:view')")
    public Result<ContractVO> getById(@PathVariable Long id) {
        return Result.success("查询成功", contractService.getById(id));
    }

    @PostMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:add')")
    @OperationLog(module = "合同管理", description = "新增合同")
    public Result<ContractVO> save(@Valid @RequestBody ContractCreateDTO dto) {
        return Result.success("保存成功", contractService.save(dto));
    }

    @PutMapping
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:edit')")
    @OperationLog(module = "合同管理", description = "更新合同")
    public Result<ContractVO> update(@Valid @RequestBody ContractUpdateDTO dto) {
        return Result.success("更新成功", contractService.update(dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:delete')")
    @Transactional(rollbackFor = Exception.class)
    @OperationLog(module = "合同管理", description = "删除合同")
    public Result<String> deleteById(@PathVariable Long id) {
        contractService.deleteById(id);
        return Result.success("删除成功", null);
    }

    @DeleteMapping("/batch")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:delete')")
    @Transactional(rollbackFor = Exception.class)
    @OperationLog(module = "合同管理", description = "批量删除合同")
    public Result<String> deleteBatch(@RequestBody List<Long> ids) {
        contractService.deleteBatch(ids);
        return Result.success("删除成功", null);
    }

    @PostMapping("/{id}/change-status")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:status')")
    public Result<ContractVO> changeStatus(@PathVariable Long id, @RequestParam String status) {
        return Result.success("状态更新成功", contractService.changeStatus(id, status));
    }

    @PostMapping("/{id}/copy")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:copy')")
    @OperationLog(module = "合同管理", description = "复制合同")
    public Result<ContractVO> copy(@PathVariable Long id) {
        return Result.success("复制成功", contractService.copyContract(id));
    }

    @GetMapping("/{id}/milestones")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:view')")
    public Result<List<ContractMilestoneVO>> milestones(@PathVariable Long id) {
        return Result.success("查询成功", contractService.getMilestones(id));
    }

    @PostMapping("/milestone")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:edit')")
    public Result<ContractMilestoneVO> saveMilestone(@Valid @RequestBody ContractMilestoneDTO dto) {
        return Result.success("保存成功", contractService.saveMilestone(dto));
    }

    @PutMapping("/milestone")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:edit')")
    public Result<ContractMilestoneVO> updateMilestone(@Valid @RequestBody ContractMilestoneDTO dto) {
        return Result.success("更新成功", contractService.updateMilestone(dto));
    }

    @DeleteMapping("/milestone/{id}")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:delete')")
    public Result<String> deleteMilestone(@PathVariable Long id) {
        contractService.deleteMilestone(id);
        return Result.success("删除成功", null);
    }

    @PostMapping("/export")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:export')")
    public void exportContracts(@RequestBody(required = false) ContractQueryDTO query,
                                HttpServletResponse response) throws Exception {
        contractService.exportContracts(query, response);
    }

    @GetMapping("/import-template")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:import')")
    public void downloadImportTemplate(HttpServletResponse response) throws Exception {
        contractService.downloadImportTemplate(response);
    }

    @PostMapping("/import-excel")
    @PreAuthorize("@permissionChecker.hasPermission('crm:contract:import')")
    @OperationLog(module = "合同管理", description = "导入合同")
    public Result<Map<String, Object>> importExcel(@RequestParam("companyId") Long companyId,
                                                    @RequestParam("file") MultipartFile file) {
        Map<String, Object> result = contractService.importExcel(companyId, file);
        int contractsInserted = (int) result.getOrDefault("contractsInserted", 0);
        int milestonesInserted = (int) result.getOrDefault("milestonesInserted", 0);
        int failed = (int) result.getOrDefault("failed", 0);
        String msg = "导入完成，合同 " + contractsInserted + " 条，里程碑 " + milestonesInserted + " 条，失败 " + failed + " 条";
        return Result.success(msg, result);
    }
}
