package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.Permission;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface PermissionMapper extends BaseMapper<Permission> {

    List<Permission> findPermissionsByUserId(@Param("userId") Long userId);

    List<String> findPermissionCodesByUserId(@Param("userId") Long userId);

    List<Permission> selectAllActive();

    List<Permission> findByParentId(@Param("parentId") Long parentId);

    List<Permission> selectAllWithDeleted();

    List<Permission> selectBySystemType(@Param("systemType") String systemType);
}
