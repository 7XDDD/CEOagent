package com.crm.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.crm.entity.Region;

import java.util.List;

public interface RegionService extends IService<Region> {

    /**
     * 获取子区域列表
     */
    List<Region> getChildren(Long parentId);

    /**
     * 获取树形结构（从国家开始）
     */
    List<Region> getTree();

    /**
     * 按级别获取
     */
    List<Region> getByLevel(Integer level);

    /**
     * 初始化中国数据
     */
    void initChinaData();
}
