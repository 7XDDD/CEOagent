package com.crm.controller.payment;

import com.crm.common.Result;
import com.crm.dto.PageResult;
import com.crm.dto.payment.PaymentQueryDTO;
import com.crm.service.payment.PaymentService;
import com.crm.vo.payment.PaymentRecordVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 回款管理
 * 数据来源：已签订合同的收款里程碑
 */
@RestController
@RequestMapping("/payment")
@Slf4j
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/page")
    @PreAuthorize("@permissionChecker.hasPermission('crm:payment:view')")
    public Result<PageResult<PaymentRecordVO>> page(@RequestBody PaymentQueryDTO query) {
        try {
            return Result.success(paymentService.page(query));
        } catch (Exception e) {
            log.error("回款记录查询失败", e);
            return Result.error("查询失败: " + e.getMessage());
        }
    }
}
