package com.crm.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.system.OperationLogQueryDTO;
import com.crm.entity.OperationLog;
import com.crm.vo.system.OperationLogVO;

public interface OperationLogService {

    Page<OperationLogVO> pageList(OperationLogQueryDTO query);

    void saveLog(OperationLog log);
}
