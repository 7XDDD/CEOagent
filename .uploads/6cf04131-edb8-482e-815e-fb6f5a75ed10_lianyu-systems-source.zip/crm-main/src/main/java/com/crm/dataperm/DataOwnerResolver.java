package com.crm.dataperm;

import java.util.Collection;
import java.util.Set;

/**
 * 各业务模块的数据负责人判定扩展点。
 * 负责人对自己负责的数据天然拥有全部权限，无需写入授权表。
 * 每个模块实现一个 Spring Bean。
 */
public interface DataOwnerResolver {

    /** 模块编码，见 {@link DataPermModule} */
    String module();

    /** 判断用户是否为指定数据的负责人（含创建人） */
    boolean isOwner(Long bizId, Long userId);

    /** 批量返回给定数据集合中，属于该用户负责的数据ID */
    Set<Long> findOwnerIds(Collection<Long> bizIds, Long userId);
}
