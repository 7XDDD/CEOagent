package com.crm.dto.opportunity;

import com.crm.dto.PageQueryDTO;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class OpportunityQueryDTO extends PageQueryDTO {

    private String stage;
    private String status;
    private String salesStatus;
    private String projectLevel;
    private String customerName;

    /** 数据范围：mine=我负责的，viewable=我可查看的，all/空=全部(管理员) */
    private String scope;

    /** 服务端注入：当前登录用户ID，用于行级数据权限 */
    private Long currentUserId;
}
