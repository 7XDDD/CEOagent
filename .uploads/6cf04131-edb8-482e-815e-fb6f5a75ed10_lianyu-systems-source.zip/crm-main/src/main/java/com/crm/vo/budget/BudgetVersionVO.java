package com.crm.vo.budget;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class BudgetVersionVO {
    private Long id;
    private Long companyId;
    private Integer fiscalYear;
    private String versionCode;
    private String versionName;
    private String budgetScene;
    private Integer rollingMonth;
    private Integer isActive;
    private Integer isLocked;
    /**
     * 是否定稿：0=否，1=是。仅调整预算（ADJUST）版本使用
     */
    private Integer isFinalized;
    private String approvalStatus;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate effectiveDate;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate expireDate;
    private Long parentVersionId;
    private String remark;
    private Long ownerId;
    private Long createdBy;
    private Long updatedBy;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;
    private Integer version;
}
