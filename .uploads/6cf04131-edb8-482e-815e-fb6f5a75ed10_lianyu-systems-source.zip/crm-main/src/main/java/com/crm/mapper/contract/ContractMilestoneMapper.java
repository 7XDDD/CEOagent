package com.crm.mapper.contract;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.ContractMilestone;
import com.crm.vo.contract.ContractMilestoneVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Collection;
import java.util.List;

@Mapper
public interface ContractMilestoneMapper extends BaseMapper<ContractMilestone> {

    List<ContractMilestoneVO> selectByContractId(@Param("contractId") Long contractId);

    List<ContractMilestoneVO> selectByContractIds(@Param("contractIds") Collection<Long> contractIds);

    void softDeleteByContractId(@Param("contractId") Long contractId);

    void softDeleteByIds(@Param("ids") List<Long> ids);

    List<ContractMilestone> selectInvoicedByContracts(@Param("contractIds") Collection<Long> contractIds, @Param("fiscalYear") Integer fiscalYear);

    List<ContractMilestone> selectInvoicedByContractsWithLastDec(@Param("contractIds") Collection<Long> contractIds, @Param("fiscalYear") Integer fiscalYear);

    List<ContractMilestone> findInvoicedInYear(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    List<ContractMilestone> findInvoicedInMonth(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("month") Integer month);

    List<ContractMilestone> listByContractIds(@Param("contractIds") java.util.List<Long> contractIds);
}
