package com.crm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.crm.entity.BudgetPeriod;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface BudgetPeriodMapper extends BaseMapper<BudgetPeriod> {

    List<BudgetPeriod> listByCompanyAndYearAndType(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("periodType") String periodType);
}
