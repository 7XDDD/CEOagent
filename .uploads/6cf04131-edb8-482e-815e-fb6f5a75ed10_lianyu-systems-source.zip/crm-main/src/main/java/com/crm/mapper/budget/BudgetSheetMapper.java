package com.crm.mapper.budget;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.crm.dto.budget.BudgetSheetQueryDTO;
import com.crm.entity.BudgetSheet;
import com.crm.vo.budget.BudgetSheetVO;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Mapper
public interface BudgetSheetMapper extends BaseMapper<BudgetSheet> {

    IPage<BudgetSheetVO> selectPageList(IPage<BudgetSheetVO> page, @Param("companyId") Long companyId, @Param("query") BudgetSheetQueryDTO query);

    List<BudgetSheetVO> selectListByCondition(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("versionId") Long versionId, @Param("catalogCode") String catalogCode, @Param("orgId") Long orgId, @Param("productLineId") Long productLineId);

    List<BudgetSheetVO> selectByContract(@Param("contractId") Long contractId);

    @Delete("DELETE FROM crm_budget_sheet WHERE company_id = #{companyId} AND fiscal_year = #{fiscalYear} AND version_id = #{versionId}")
    int physicalDeleteByVersion(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("versionId") Long versionId);

    @Delete("DELETE FROM crm_budget_sheet WHERE company_id = #{companyId} AND fiscal_year = #{fiscalYear} AND version_id = #{versionId} AND catalog_code = #{catalogCode}")
    int physicalDeleteByVersionAndCatalog(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("versionId") Long versionId, @Param("catalogCode") String catalogCode);

    @Delete("DELETE FROM crm_budget_sheet WHERE company_id = #{companyId} AND fiscal_year = #{fiscalYear} AND contract_id = 0")
    int deleteInvalidByCompanyYear(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear);

    List<BudgetSheet> selectByVersionAndCatalog(@Param("versionId") Long versionId, @Param("catalogCode") String catalogCode);

    List<BudgetSheet> selectByVersion(@Param("companyId") Long companyId, @Param("versionId") Long versionId);

    List<BudgetSheet> selectDetailsByVersion(@Param("companyId") Long companyId, @Param("fiscalYear") Integer fiscalYear, @Param("versionId") Long versionId);

    Map<String, Object> sumTotalsByVersion(@Param("companyId") Long companyId, @Param("versionId") Long versionId);

    List<Long> selectSummarySheetIds(@Param("companyId") Long companyId, @Param("query") BudgetSheetQueryDTO query);

    List<Map<String, Object>> selectSummaryMonthAmounts(@Param("sheetIds") List<Long> sheetIds);

    Map<String, Object> selectSummaryBaseStats(@Param("companyId") Long companyId, @Param("query") BudgetSheetQueryDTO query, @Param("sheetIds") List<Long> sheetIds);
}