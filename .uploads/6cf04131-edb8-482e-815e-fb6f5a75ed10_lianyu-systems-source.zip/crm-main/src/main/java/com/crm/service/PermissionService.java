package com.crm.service;

import com.crm.dto.system.PermissionCreateDTO;
import com.crm.dto.system.PermissionUpdateDTO;
import com.crm.entity.Permission;
import com.crm.vo.system.PermissionVO;

import java.util.List;

public interface PermissionService {

    List<PermissionVO> tree(String systemType);

    List<Permission> listAll();

    Permission getDetail(Long id);

    Permission create(PermissionCreateDTO dto);

    Permission update(Long id, PermissionUpdateDTO dto);

    void delete(Long id);
}
