package com.crm.dto.system;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class DictItemCreateDTO {
    @NotNull(message = "字典ID不能为空")
    private Long dictId;
    @NotBlank(message = "字典项编码不能为空")
    private String itemCode;
    @NotBlank(message = "字典项名称不能为空")
    private String itemName;
    private String itemValue;
    private Integer sortOrder;
    private Integer status;
    private String remark;
}
