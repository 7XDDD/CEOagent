package com.crm.vo.project;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class ProjectVO {

    private Long id;
    private Long companyId;
    private String projectCode;
    private String projectName;
    private String projectType;
    private Long parentId;
    private Long customerId;
    private String customerCode;
    private String customerName;
    private Long pmId;
    private String pmName;
    private Long salesId;
    private String salesName;
    private Long orgId;
    private String orgCode;
    private String orgName;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate plannedStartDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate plannedEndDate;

    private BigDecimal budgetAmount;
    private BigDecimal contractAmount;
    private BigDecimal actualCost;
    private String status;
    private Integer progress;
    private String priority;
    private String remark;
    private Long ownerId;

    private Integer permBits;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updateTime;
}
