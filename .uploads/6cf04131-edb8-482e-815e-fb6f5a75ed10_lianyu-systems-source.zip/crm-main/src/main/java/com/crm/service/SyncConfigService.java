package com.crm.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.crm.entity.SyncLog;
import com.crm.entity.SyncTaskConfig;

import java.util.List;

public interface SyncConfigService extends IService<SyncTaskConfig> {

    List<SyncTaskConfig> listTasks();

    Page<SyncTaskConfig> pageTasks(Integer pageNum, Integer pageSize, String keyword);

    SyncTaskConfig toggleTask(Long taskId, Integer enabled);

    void recordLog(SyncLog log);

    Page<SyncLog> pageLogs(String taskKey, Integer status, Integer pageNum, Integer pageSize);

    void initDefaultTasks();

    boolean isTaskEnabled(String taskKey);

    SyncTaskConfig saveTask(SyncTaskConfig task);

    SyncTaskConfig updateTask(SyncTaskConfig task);

    void deleteTask(Long taskId);

    void logSync(String taskKey, String taskName, String triggerType, boolean success,
                 String message, int added, int updated, int deleted, int total,
                 long duration, String errorMsg);

    void logHttpSync(String taskKey, String taskName, String triggerType, boolean success,
                     String message, int httpStatus, String responseBody,
                     long duration, String errorMsg);
}
