package com.crm.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.crm.dto.system.RoleCreateDTO;
import com.crm.dto.system.RoleQueryDTO;
import com.crm.dto.system.RoleUpdateDTO;
import com.crm.entity.Role;
import com.crm.vo.system.RoleVO;

import java.util.List;

public interface RoleService {

    Page<RoleVO> pageList(RoleQueryDTO query);

    List<Role> listAll();

    RoleVO getDetail(Long id);

    Role create(RoleCreateDTO dto);

    Role update(Long id, RoleUpdateDTO dto);

    void delete(Long id);

    List<Long> getPermissionIds(Long roleId);

    void assignPermissions(Long roleId, List<Long> permissionIds);

    List<Long> getProjectIds(Long roleId);

    void assignProjects(Long roleId, List<Long> projectIds);
}
