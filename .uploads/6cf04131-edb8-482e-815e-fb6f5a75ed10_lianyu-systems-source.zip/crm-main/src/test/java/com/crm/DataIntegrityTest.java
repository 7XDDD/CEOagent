package com.crm;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.crm.entity.Contract;
import com.crm.entity.Opportunity;
import com.crm.entity.Project;
import com.crm.mapper.contract.ContractMapper;
import com.crm.mapper.OpportunityMapper;
import com.crm.mapper.ProjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 业务数据完整性测试
 * 验证商机、合同、项目模块补齐后的关键字段非空及数据合理性
 */
@SpringBootTest
@DisplayName("业务数据完整性测试")
class DataIntegrityTest {

    @Autowired
    private OpportunityMapper opportunityMapper;

    @Autowired
    private ContractMapper contractMapper;

    @Autowired
    private ProjectMapper projectMapper;

    // ==================== 商机数据完整性 ====================

    @Test
    @DisplayName("商机-所有商机编号非空且格式正确")
    void opportunity_no_not_blank_and_format_valid() {
        List<Opportunity> list = opportunityMapper.selectList(null);
        assertFalse(list.isEmpty(), "商机表不应为空");
        for (Opportunity o : list) {
            assertNotNull(o.getOpportunityNo(), "商机 " + o.getId() + " 的商机号不应为空");
            assertTrue(o.getOpportunityNo().matches("OPP-\\d{8}-\\d{4}"),
                    "商机 " + o.getId() + " 的商机号格式应为 OPP-yyyyMMdd-NNNN，实际: " + o.getOpportunityNo());
        }
    }

    @Test
    @DisplayName("商机-销售代表与公司责任人非空")
    void opportunity_sales_and_owner_not_blank() {
        List<Opportunity> list = opportunityMapper.selectList(null);
        for (Opportunity o : list) {
            assertNotNull(o.getSalesPerson(), "商机 " + o.getId() + " 销售代表姓名不应为空");
            assertNotNull(o.getSalesPersonId(), "商机 " + o.getId() + " 销售代表ID不应为空");
            assertNotNull(o.getCompanyOwner(), "商机 " + o.getId() + " 公司责任人姓名不应为空");
            assertNotNull(o.getCompanyOwnerId(), "商机 " + o.getId() + " 公司责任人ID不应为空");
        }
    }

    @Test
    @DisplayName("商机-分类字段非空")
    void opportunity_category_fields_not_blank() {
        List<Opportunity> list = opportunityMapper.selectList(null);
        for (Opportunity o : list) {
            assertNotNull(o.getProjectLevel(), "商机 " + o.getId() + " 项目级别不应为空");
            assertNotNull(o.getSalesStatus(), "商机 " + o.getId() + " 销售阶段不应为空");
            assertNotNull(o.getSource(), "商机 " + o.getId() + " 商机来源不应为空");
            assertNotNull(o.getCustomerType(), "商机 " + o.getId() + " 客户类型不应为空");
            assertNotNull(o.getIndustry(), "商机 " + o.getId() + " 行业不应为空");
            assertNotNull(o.getProductLine(), "商机 " + o.getId() + " 产品线不应为空");
        }
    }

    @Test
    @DisplayName("商机-业务详情字段非空")
    void opportunity_detail_fields_not_blank() {
        List<Opportunity> list = opportunityMapper.selectList(null);
        for (Opportunity o : list) {
            assertNotNull(o.getDemandProduct(), "商机 " + o.getId() + " 需求产品不应为空");
            assertNotNull(o.getCompetitor(), "商机 " + o.getId() + " 竞争对手不应为空");
            assertNotNull(o.getDecisionMaker(), "商机 " + o.getId() + " 客户决策人不应为空");
            assertNotNull(o.getPresalesResource(), "商机 " + o.getId() + " 售前资源不应为空");
            assertNotNull(o.getResourceConfig(), "商机 " + o.getId() + " 资源配置不应为空");
            assertNotNull(o.getSalesResource(), "商机 " + o.getId() + " 销售资源不应为空");
            assertNotNull(o.getNextAction(), "商机 " + o.getId() + " 下一步行动不应为空");
            assertNotNull(o.getStageSummary(), "商机 " + o.getId() + " 阶段进展总结不应为空");
        }
    }

    @Test
    @DisplayName("商机-日期字段非空")
    void opportunity_date_fields_not_blank() {
        List<Opportunity> list = opportunityMapper.selectList(null);
        for (Opportunity o : list) {
            assertNotNull(o.getExpectedDealDate(), "商机 " + o.getId() + " 预计成交时间不应为空");
            assertNotNull(o.getExpectedSignDate(), "商机 " + o.getId() + " 预计签单时间不应为空");
            assertTrue(o.getExpectedSignDate().compareTo(o.getExpectedDealDate()) >= 0,
                    "商机 " + o.getId() + " 预计签单时间应晚于或等于预计成交时间");
        }
    }

    @Test
    @DisplayName("商机-金额与赢单率合理性")
    void opportunity_amount_and_rate_valid() {
        List<Opportunity> list = opportunityMapper.selectList(null);
        for (Opportunity o : list) {
            assertNotNull(o.getAmount(), "商机 " + o.getId() + " 预计金额不应为空");
            assertTrue(o.getAmount().doubleValue() > 0, "商机 " + o.getId() + " 预计金额应大于0");
            assertNotNull(o.getStageRate(), "商机 " + o.getId() + " 赢单率不应为空");
            assertTrue(o.getStageRate() >= 0 && o.getStageRate() <= 100,
                    "商机 " + o.getId() + " 赢单率应在0-100之间，实际: " + o.getStageRate());
        }
    }

    // ==================== 合同数据完整性 ====================

    @Test
    @DisplayName("合同-项目编码与客户非空")
    void contract_project_and_customer_not_blank() {
        List<Contract> list = contractMapper.selectList(
                new LambdaQueryWrapper<Contract>().eq(Contract::getDeleted, 0));
        assertFalse(list.isEmpty(), "合同表不应为空");
        for (Contract c : list) {
            assertNotNull(c.getProjectCode(), "合同 " + c.getId() + " 项目编码不应为空");
            assertNotNull(c.getCustomerId(), "合同 " + c.getId() + " 客户ID不应为空");
            assertNotNull(c.getCustomerName(), "合同 " + c.getId() + " 客户名称不应为空");
        }
    }

    @Test
    @DisplayName("合同-负责人与产品线非空")
    void contract_manager_and_product_line_not_blank() {
        List<Contract> list = contractMapper.selectList(
                new LambdaQueryWrapper<Contract>().eq(Contract::getDeleted, 0));
        for (Contract c : list) {
            assertNotNull(c.getManager(), "合同 " + c.getId() + " Sponsor不应为空");
            assertNotNull(c.getSalesManager(), "合同 " + c.getId() + " 销售经理不应为空");
            assertNotNull(c.getProductLine(), "合同 " + c.getId() + " 产品线不应为空");
            assertNotNull(c.getDeptId(), "合同 " + c.getId() + " 部门ID不应为空");
        }
    }

    @Test
    @DisplayName("合同-类型与日期字段非空")
    void contract_type_and_dates_not_blank() {
        List<Contract> list = contractMapper.selectList(
                new LambdaQueryWrapper<Contract>().eq(Contract::getDeleted, 0));
        for (Contract c : list) {
            assertNotNull(c.getContractType(), "合同 " + c.getId() + " 合同类型不应为空");
            assertNotNull(c.getSignDate(), "合同 " + c.getId() + " 签约日期不应为空");
            assertNotNull(c.getExpectedSignDate(), "合同 " + c.getId() + " 预计签约时间不应为空");
            assertNotNull(c.getContractCreateTime(), "合同 " + c.getId() + " 创建日期不应为空");
        }
    }

    @Test
    @DisplayName("合同-金额合理性")
    void contract_amount_valid() {
        List<Contract> list = contractMapper.selectList(
                new LambdaQueryWrapper<Contract>().eq(Contract::getDeleted, 0));
        for (Contract c : list) {
            assertNotNull(c.getContractAmount(), "合同 " + c.getId() + " 合同金额不应为空");
            assertTrue(c.getContractAmount().doubleValue() > 0,
                    "合同 " + c.getId() + " 合同金额应大于0");
        }
    }

    // ==================== 项目数据完整性 ====================

    @Test
    @DisplayName("项目-表有数据且核心字段非空")
    void project_has_data_and_core_fields_not_blank() {
        List<Project> list = projectMapper.selectList(
                new LambdaQueryWrapper<Project>().eq(Project::getDeleted, 0));
        assertFalse(list.isEmpty(), "项目表应有数据");
        for (Project p : list) {
            assertNotNull(p.getProjectCode(), "项目 " + p.getId() + " 项目编码不应为空");
            assertNotNull(p.getProjectName(), "项目 " + p.getId() + " 项目名称不应为空");
            assertNotNull(p.getProjectType(), "项目 " + p.getId() + " 项目类型不应为空");
            assertNotNull(p.getPmId(), "项目 " + p.getId() + " 项目经理ID不应为空");
            assertNotNull(p.getPmName(), "项目 " + p.getId() + " 项目经理姓名不应为空");
            assertNotNull(p.getSalesId(), "项目 " + p.getId() + " 销售ID不应为空");
            assertNotNull(p.getSalesName(), "项目 " + p.getId() + " 销售姓名不应为空");
            assertNotNull(p.getStatus(), "项目 " + p.getId() + " 状态不应为空");
            assertNotNull(p.getPlannedStartDate(), "项目 " + p.getId() + " 计划开始日期不应为空");
            assertNotNull(p.getPlannedEndDate(), "项目 " + p.getId() + " 计划结束日期不应为空");
            assertTrue(p.getPlannedEndDate().compareTo(p.getPlannedStartDate()) >= 0,
                    "项目 " + p.getId() + " 计划结束日期应晚于或等于开始日期");
        }
    }

    @Test
    @DisplayName("项目-进度与优先级合理性")
    void project_progress_and_priority_valid() {
        List<Project> list = projectMapper.selectList(
                new LambdaQueryWrapper<Project>().eq(Project::getDeleted, 0));
        for (Project p : list) {
            assertNotNull(p.getProgress(), "项目 " + p.getId() + " 进度不应为空");
            assertTrue(p.getProgress() >= 0 && p.getProgress() <= 100,
                    "项目 " + p.getId() + " 进度应在0-100之间，实际: " + p.getProgress());
            assertNotNull(p.getPriority(), "项目 " + p.getId() + " 优先级不应为空");
        }
    }

    @Test
    @DisplayName("项目-合同金额与预算合理性")
    void project_budget_valid() {
        List<Project> list = projectMapper.selectList(
                new LambdaQueryWrapper<Project>().eq(Project::getDeleted, 0));
        for (Project p : list) {
            assertNotNull(p.getBudgetAmount(), "项目 " + p.getId() + " 预算金额不应为空");
            assertTrue(p.getBudgetAmount().doubleValue() > 0,
                    "项目 " + p.getId() + " 预算金额应大于0");
        }
    }

    // ==================== 跨模块数据一致性 ====================

    @Test
    @DisplayName("跨模块-合同项目编码在项目表中存在")
    void contract_project_code_exists_in_project_table() {
        List<Contract> contracts = contractMapper.selectList(
                new LambdaQueryWrapper<Contract>().eq(Contract::getDeleted, 0));
        List<Project> projects = projectMapper.selectList(
                new LambdaQueryWrapper<Project>().eq(Project::getDeleted, 0));
        long projectCodeCount = projects.stream().map(Project::getProjectCode).distinct().count();
        assertTrue(projectCodeCount > 0, "项目表中应有项目编码");
        // 至少有部分合同的项目编码在项目表中存在
        long matched = contracts.stream()
                .map(Contract::getProjectCode)
                .filter(code -> projects.stream().anyMatch(p -> p.getProjectCode().equals(code)))
                .count();
        assertTrue(matched > 0, "至少应有部分合同的项目编码在项目表中存在");
    }
}
